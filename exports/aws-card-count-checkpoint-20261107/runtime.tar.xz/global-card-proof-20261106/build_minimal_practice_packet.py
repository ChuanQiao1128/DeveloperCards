"""Apply explicit, human-readable draft edits; no semantic approval is inferred."""
from pathlib import Path
import copy, hashlib, json, shutil, sys
V=Path(__file__).resolve().parent
rd=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
wr=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
number=int(sys.argv[1]); edits_path=V/'drafts'/f'correction-edits{number:02d}.json';edits=rd(edits_path)
P=V/'review'/f'corrected-variants{number:02d}'/'input';P.mkdir(parents=True,exist_ok=True)
assert not (P/'manifest.json').exists(), 'Never overwrite a frozen packet'
q=rd(V.parent/'domain1-final-card-catalog-20261105/questions.all.json');index={r['qid']:r for r in rd(V/'validation/current-question-proof-index.json')['rows']};out=[];sources=set()
for e in edits:
 i=e['qid'];assert i!=868 and i in index and index[i]['reportedStatus']=='SOURCE_ISSUE',i
 o=q[str(i)];c=copy.deepcopy(o)
 for a,b in e.get('stemReplacements',[]):
  assert c['stem'].count(a)==1,(i,a);c['stem']=c['stem'].replace(a,b)
 if e.get('clarification') or e.get('question'):
  s=c['stem'];pos=max(s.rfind('\nWhich '),s.rfind('\nWhat '),s.rfind('\nHow '));pos=pos+1 if pos>=0 else 0
  c['stem']=s[:pos]+(('For this practice only: '+e['clarification']+'\n') if e.get('clarification') else '')+(e.get('question') or s[pos:])
 for ordinal,text in e.get('options',{}).items():next(x for x in c['options'] if x['ordinal']==int(ordinal))['text']=text
 assert c!=o
 ds=([dict(field='stem',old=o['stem'],new=c['stem'])] if c['stem']!=o['stem'] else [])+[dict(field='option:'+str(a['ordinal']),old=a['text'],new=b['text']) for a,b in zip(o['options'],c['options']) if a!=b]
 r=index[i];src=Path(r['proofPath']);assert sha(src)==r['proofSha256'];frozen=V/'validation/immutable-contexts'/(sha(src)+'.json')
 if not frozen.exists():shutil.copyfile(src,frozen)
 assert sha(frozen)==sha(src);sources.add(frozen)
 out.append(dict(variantId=f'Q{i:03d}-CV{number:02d}',originalQid=i,variantType='minimal_corrected_practice_not_original_question',authorRole='root_native',originalQuestion=o,originalQuestionCanonicalSha256=canon(o),correctedQuestion=c,correctedQuestionCanonicalSha256=canon(c),deltas=ds,originalOptionsUnchanged=c['options']==o['options'],minimalChangeRationale=e['note'],sourceFinding=dict(independentResultPath=str(frozen),originalResultPath=str(src),independentResultSha256=sha(frozen),originalQid=i,recordLocator='original-question record matching qid; not a corrected-variant record'),variantReviewStatus='PENDING',doesNotUpgradeOriginal=True))
assert len(out)==len({r['originalQid'] for r in out})
f=V/'deliverables'/f'corrected-variants.source-errors{number:02d}.json';assert not f.exists();wr(f,out);shutil.copyfile(f,P/'cases.json');shutil.copyfile(V/'deliverables/core-visible-knowledge.provisional.json',P/'core-visible.frozen.json')
paths=[edits_path,f,P/'cases.json',P/'core-visible.frozen.json',V/'rules.md',V/'inputs/teaching-standard.md',V/'inputs/source-ambiguity-rule-clarification-20261107.md',V/'inputs/user-knowledge-scope-accepted.json',V/'inputs/user-source-correction-policy-accepted.json']+sorted(sources)
wr(P/'manifest.json',{str(p):sha(p) for p in paths});print(f'{len(out)} explicitly edited practices frozen; no semantic PASS claimed')

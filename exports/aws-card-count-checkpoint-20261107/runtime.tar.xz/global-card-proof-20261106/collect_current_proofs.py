"""Merge existing independent proofs and check current body bindings; no semantic gate."""
from pathlib import Path
from collections import Counter
import copy
import hashlib
import json

V = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
cards = {c['ruleId']: c for c in read(V / 'deliverables/cards.current.json')}
initial = {c['ruleId']: c['body'] for c in read(V / 'inputs/existing176.json')}
card_states = {c['ruleId']: c['status'] for c in
               read(V / 'validation/current-card-review-index.json')['cards']}
fields = ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']
question_path = V.parent / 'domain1-final-card-catalog-20261105/questions.all.json'
assert sha(question_path) == read(V / 'inputs/source-manifest.json')[str(question_path)]
expected_qids = {int(q) for q in read(question_path)} - {868}
assert len(expected_qids) == 1018
ledger = {}


def canon(rid):
    if not rid:
        return ''
    rid = rid if rid.startswith(('CUR:', 'GSC-', 'GCL-', 'VC-')) else 'CUR:' + rid
    return 'CUR:CA19' if rid == 'CUR:XA010' else rid


def add(relative, key='results', legacy=False, status_key='status', base=False):
    path = V / relative
    if not path.exists():
        return
    data = read(path)
    if isinstance(data, list):
        assert key == 'results', (relative, key)
        records = data
    else:
        records = data.get(key, [])
    for row in records:
        if 'qid' not in row:
            continue
        if legacy and row['status'] != 'eligible_reuse':
            continue
        qid = row['qid']
        assert qid in expected_qids
        if base:
            assert qid not in ledger, (qid, relative)
        old = ledger.get(qid)
        normalized = copy.deepcopy(row)
        if 'necessaryAnchors' not in normalized and 'necessaryCardAnchors' in normalized:
            normalized['necessaryAnchors'] = normalized['necessaryCardAnchors']
        if 'necessaryAnchors' not in normalized and 'necessaryCardEvidence' in normalized:
            normalized['necessaryAnchors'] = [
                {'ruleId': e['ruleId'], 'bodySha256': e['bodySha256'],
                 'field': q['field'], 'quote': q['quote']}
                for e in normalized['necessaryCardEvidence']
                for q in e.get('visibleQuotes', [])]
        ledger[qid] = {
            'qid': qid, 'reportedStatus': row.get('reuseVerdict', row.get(status_key)),
            'proofPath': str(path), 'proofSha256': sha(path), 'legacyReuse': legacy,
            'proof': normalized,
            'supersededProofPath': old['proofPath'] if old else None,
        }


add('review/reuse-a/question-reuse371.json', legacy=True, base=True)
for area in ['questions-a', 'questions-a/extra33', 'questions-b', 'questions-c']:
    add('review/' + area + '/results.json', base=True)
assert set(ledger) == expected_qids
for area in ['gap-a', 'gap-b']:
    add('review/' + area + '/results.json')
add('review/reuse-a/anchor-locator-addendum.json',
    status_key='statusAfterTargetedCurrentBodyRecheck')
add('review/cards-c/repair08.review.json', key='affectedQuestions')
for area in ['a', 'b']:
    add('review/current-impact01/' + area + '/results.json')
add('review/reuse-a/supplemental01.review.json', key='questionImpactReview')
for area in ['a', 'b']:
    add('review/remaining-gap-current/' + area + '/results.json')
add('review/cards-c/supplemental02.review.json', key='affectedQuestions')
add('review/cards-c/supplemental02-ca17-repair01.review.json', key='affectedQuestions')
add('review/reuse-a/supplemental03.review.json', key='questionImpactReview')
add('review/source-current-final/a/results.json')
add('review/source-current-final/b/review.json')
add('review/reuse-a/supplemental04.review.json', key='questionImpactReview')
add('review/reuse-a/supplemental05.review.json', key='affectedQuestions')
for area in ['a', 'b']:
    add('review/source-unknown02/' + area + '/results.json')
add('review/cards-c/supplemental06.review.json', key='affectedQuestions')
add('review/reuse-a/supplemental07-and05repair01.review.json', key='affectedQuestions')
add('review/reuse-a/supplemental08.review.json', key='questionImpactReview')
add('review/reuse-a/supplemental08-repair01.review.json', key='questionImpactReview')
add('validation/retained-removal-proof-reuse.json')
add('validation/legacy-current-exact-proof-reuse.json')
for area in ['a', 'b', 'c']:
    add('review/final-core-closure01/' + area + '/results.json')

add('review/open-condition-review01/results.json')
add('review/reuse-a/supplemental09.review.json', key='questionImpactReview')

add('review/reuse-a/supplemental10.review.json', key='questionImpactReview')

add('review/reuse-a/supplemental11.review.json', key='questionImpactReview')

add('review/remaining-source10/results.json')
add('review/reuse-a/supplemental12.review.json', key='questionImpactReview')

add('review/reuse-a/supplemental13.review.json', key='questionImpactReview')

add('review/reuse-a/supplemental14.review.json', key='questionImpactReview')

add('review/reuse-a/supplemental15.review.json', key='questionImpactReview')

add('review/residual-conditions02-current01/results.json')
add('review/cost-source-final03/results.json')
add('review/reuse-a/supplemental16.review.json', key='questionImpactReview')

add('review/reuse-a/supplemental17.review.json', key='questionImpactReview')

add('review/last-conditions03/results.json')

add('review/reuse-a/supplemental18.review.json', key='questionImpactReview')

for area in ['a','b']:
    add('review/current-impact02/' + area + '/results.json')

add('review/reuse-a/supplemental19.review.json', key='questionImpactReview')

add('review/unchanged-service-scope01/results.json')


def binding_issues(entry, current_cards):
    row = entry['proof']
    issues = []
    if entry['legacyReuse']:
        for rid in map(canon, row['completeDependencyIds']):
            old = initial.get(rid)
            current = current_cards.get(rid)
            if not old or not current or current['visibleBody'] != {
                    k: old.get(k, '') for k in fields}:
                issues.append({'ruleId': rid, 'reason': 'legacy actual body changed'})
        return issues
    for anchor in row.get('necessaryAnchors', []):
        rid = canon(anchor.get('ruleId', anchor.get('cardId')))
        card = current_cards.get(rid)
        locators = [anchor['field']] if anchor.get('field') else fields
        quote = anchor.get('quote', '')
        located = card and quote and any(
            quote in card['visibleBody'].get(k, '') for k in locators)
        if not card or anchor.get('bodySha256') != card['bodySha256'] or not located:
            issues.append({'ruleId': rid, 'reason': 'body hash or exact quote changed'})
    bound = {}
    for key in ['providedVisibleCardBindings', 'additionalVisibleCardBindings']:
        bound.update(row.get(key, {}))
    for key in ['visibleCardBodies', 'additionalVisibleBodyBindings']:
        bound.update(row.get('bindings', {}).get(key, {}))
    for item in row.get('actualVisibleGroup', []):
        bound[item['ruleId']] = item['bodySha256']
    for rid, expected in bound.items():
        rid = canon(rid)
        if rid not in current_cards or current_cards[rid]['bodySha256'] != expected:
            issues.append({'ruleId': rid, 'reason': 'declared visible body changed'})
    return issues


rows = []
for qid, entry in sorted(ledger.items()):
    issues = binding_issues(entry, cards)
    used = {canon(r) for r in entry['proof'].get('usedRuleIds', entry['proof'].get('usedCardIds', []))}
    used |= {canon(a.get('ruleId', a.get('cardId'))) for a in entry['proof'].get('necessaryAnchors', [])}
    if entry['reportedStatus'] == 'SUPPORTED':
        for rid in used:
            if card_states.get(rid) != 'PASS':
                issues.append({'ruleId': rid, 'reason': 'current card not fully passed'})
    entry['currentBindingIssues'] = issues
    entry['effectiveStatus'] = 'NEEDS_RECHECK' if issues else entry['reportedStatus']
    rows.append(entry)

# A real retained proof must reject a changed body; do not test with fabricated PASS text.
probe = next(e for e in rows if e['reportedStatus'] == 'SUPPORTED'
             and not e['legacyReuse'] and not e['currentBindingIssues']
             and e['proof'].get('necessaryAnchors'))
rid = canon(probe['proof']['necessaryAnchors'][0].get(
    'ruleId', probe['proof']['necessaryAnchors'][0].get('cardId')))
mutated = copy.deepcopy(cards)
mutated[rid]['bodySha256'] = '0' * 64
assert binding_issues(probe, mutated)
counts = dict(Counter(e['effectiveStatus'] for e in rows))
data = {'questionCount': len(rows), 'counts': counts,
        'scope': 'proof merge and current body binding only; not semantic re-review',
        'questionSourceSha256': sha(question_path),
        'currentCardsSha256': sha(V / 'deliverables/cards.current.json'),
        'pending_ids': [e['qid'] for e in rows if e['effectiveStatus'] != 'SUPPORTED'],
        'semanticClosureVerifiedByThisScript': False,
        'prerequisiteClosureCertifiedByThisScript': False,
        'finalCoreCountVerified': False, 'rows': rows}
(V / 'validation/current-question-proof-index.json').write_text(
    json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'questionCount': len(rows), 'counts': counts,
                  'changedBodyNegativeControl': 'PASS', 'finalNVerified': False}))

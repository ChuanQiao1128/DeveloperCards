import subprocess,pathlib,json,hashlib,datetime,re,concurrent.futures,sys
from html.parser import HTMLParser
class Extract(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style'):self.skip+=1
 def handle_endtag(self,tag):
  if tag in ('script','style'):self.skip=max(0,self.skip-1)
 def handle_data(self,d):
  if not self.skip:self.parts.append(d)
def fetch(item):
 name,url=item
 res=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','35',url,'--write-out','\n%{url_effective}\n%{http_code}'],capture_output=True,check=True).stdout
 raw,final,status=res.rsplit(b'\n',2);p=Extract();p.feed(raw.decode('utf-8'));t=re.sub(r'\s+',' ',' '.join(p.parts)).strip()
 d={'requestedUrl':url,'url':final.decode(),'status':int(status),'retrievedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'htmlSha256':hashlib.sha256(raw).hexdigest(),'textSha256':hashlib.sha256(t.encode()).hexdigest(),'text':t,'extraction':'Python HTMLParser text nodes except script/style; whitespace collapsed'}
 out=pathlib.Path(__file__).parent;target=out/(name+'.json');target.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(out/(name+'.html')).write_bytes(raw)
 return name,final.decode(),len(t)
if __name__=='__main__':
 for item in json.loads(sys.argv[1]).items():
  try:print(fetch(item))
  except Exception as e:print(item[0],type(e).__name__,str(e))

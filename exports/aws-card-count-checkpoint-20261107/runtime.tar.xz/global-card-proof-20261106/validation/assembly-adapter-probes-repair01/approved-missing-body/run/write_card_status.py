from pathlib import Path
import collections
import hashlib
import json

V = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
cards = read(V / 'deliverables/cards.current.json')
current = {x['ruleId']: x for x in cards}
initial = {x['ruleId']: {k: x['body'].get(k, '') for k in
                        ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']}
           for x in read(V / 'inputs/existing176.json')}
proofs = collections.defaultdict(list)
for owner in ['reuse-a', 'cards-c']:
    for path in (V / 'review' / owner).glob('*.review.json'):
        result = read(path)
        for entry in result.get('cards', result.get('results', [])):
            rid = entry.get('ruleId')
            verdict = entry.get('verdict', entry.get('status'))
            if verdict is None:
                verdict = entry.get('FACT') if entry.get('FACT') in {'FAIL', 'UNKNOWN'} else None
            if verdict is None:
                continue  # A fact-only positive receipt does not certify all teaching checks.
            scope = entry.get('reviewScope', entry.get('scope', result.get('reviewScope', result.get('scope', ''))))
            scope = str(scope).upper().replace('-', '_').replace(' ', '_')
            gates = entry.get('gates', result.get('gates'))
            gate_names = {str(k).upper() for k in gates} if isinstance(gates, (dict, list, tuple)) else set()
            if verdict == 'PASS' and (scope in {'FACT', 'FACT_ONLY', 'FACTS_ONLY'} or gate_names == {'FACT'}):
                continue
            if rid in current and entry.get('bodySha256') == current[rid]['bodySha256']:
                proofs[rid].append({'path': str(path), 'sha256': sha(path),
                                    'verdict': verdict})
reuse_path = V / 'review/reuse-a/reuse-results.json'
reuse = {x['ruleId']: x for x in read(reuse_path)['results']}
dep_path = V / 'review/reuse-a/dependency5.review.json'
dep = read(dep_path)
dep_rows = dep.get('results', dep.get('cards', []))
dep_ids = {x['ruleId'] for x in dep_rows
           if x.get('status', x.get('verdict')) == 'PASS'}
rows = []
for card in cards:
    rid = card['ruleId']
    matches = proofs[rid]
    old = reuse.get(rid)
    if (not matches and old and card['origin'] == 'prior_chinese_prototype'
            and card['visibleBody'] == initial[rid]):
        assert card['priorBodySha256'] == old['bodySha256']
        if old['eligibleFACT'] and (old['eligibleTEACHING'] or rid in dep_ids):
            matches = [{'path': str(reuse_path), 'sha256': sha(reuse_path),
                        'verdict': 'PASS', 'kind': 'unchanged_body_reuse',
                        'dependencyOverlay': str(dep_path) if rid in dep_ids else None}]
    statuses = {p['verdict'] for p in matches}
    status = 'PASS' if statuses == {'PASS'} else 'FAIL' if 'FAIL' in statuses else 'UNKNOWN'
    if card['knowledgeUseState'] == 'QUARANTINED':
        assert status != 'PASS', rid
    rows.append({'ruleId': rid, 'currentBodySha256': card['bodySha256'],
                 'status': status, 'proofs': matches})
selection = read(V / 'inputs/card-catalogue.frozen-design.json')
if (V / 'inputs/supplemental-catalogue.approved.json').exists():
    selection += read(V / 'inputs/supplemental-catalogue.approved.json')
assert len(rows) == len({x['ruleId'] for x in rows}) == len(selection)
assert {x['ruleId'] for x in rows} == {x['ruleId'] for x in selection}
counts = dict(collections.Counter(x['status'] for x in rows))
data = {'scope': 'current_Chinese_FACT_and_teaching_only_not_question_coverage',
        'candidateCount': len(rows), 'counts': counts, 'cards': rows,
        'formalBilingualAcceptance': False, 'finalCoreCountVerified': False,
        'globalDependencyClosureVerifiedByThisFormatter': False}
(V / 'validation/current-card-review-index.json').write_text(
    json.dumps(data, ensure_ascii=False, indent=2) + '\n')
status_by = {x['ruleId']: x['status'] for x in rows}
names = {x['ruleId']: x['label'] for x in selection}
lines = ['# 全库中文验证短稿', '',
         '这是实际候选正文，尚非最终核心包或双语发布包。', '',
         '正文FACT与教学状态：' + '，'.join(f'{k} {v}' for k, v in counts.items()) + '。',
         '正文通过不等于对应原题已经充分支撑；最终卡数仍由逐题验证与删除核查决定。', '']
for card in cards:
    rid = card['ruleId']
    if status_by[rid] != 'PASS':
        lines.extend([f'## {rid}（已隔离／未通过，不作为学习正文）', '',
                      '当前失败及原始草稿保留在验证账本中；不以错误推荐补充题目支撑。', ''])
        continue
    body = card['visibleBody']
    lines.extend([f'## {rid} · {names[rid]}', '',
                  '**问：** ' + body['frontZH'], '',
                  '**答：** ' + body['answerZH'], '',
                  '**考点：** ' + body['keyPointZH'], ''])
    if body.get('watchOutZH'):
        lines.extend(['**易错提醒：** ' + body['watchOutZH'], ''])
(V / 'deliverables/cards.current.zh.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'candidateCount': len(rows), 'cardReviewCounts': counts,
                  'fullQuestionCoverageOrFinalNVerified': False}, ensure_ascii=False))

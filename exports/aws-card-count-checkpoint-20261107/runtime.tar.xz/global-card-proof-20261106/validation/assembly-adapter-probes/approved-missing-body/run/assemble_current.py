from pathlib import Path
import json,hashlib,sys
V=Path(__file__).resolve().parent;R=V.parent
read=lambda p:json.loads(p.read_text())
canon=lambda x:'CUR:CA19' if x=='CUR:XA010' else x
existing=read(V/'inputs/existing176.json');selected=read(V/'inputs/card-catalogue.frozen-design.json')
if (V/'inputs/supplemental-catalogue.approved.json').exists():selected+=read(V/'inputs/supplemental-catalogue.approved.json')
sel={x['ruleId']:x for x in selected};assert len(sel)==len(selected)
by={}
for x in existing:
 b=x['body'];rid=x['ruleId'];body={k:b.get(k,'') for k in ['frontZH','answerZH','keyPointZH','watchOutZH']}
 by[rid]={'ruleId':rid,'visibleBody':body,'origin':'prior_chinese_prototype','sourceFile':str(V/'inputs/existing176.json'),'prerequisiteRuleIds':[canon('CUR:'+i) for i in b.get('prerequisiteIds',[])],'priorBodySha256':b['bodySha256'],'scopeRevisionRequired':bool(x['scopeDecisions']),'currentScopeApplied':not bool(x['scopeDecisions'])}
seen=set()
for f in sorted((V/'drafts').glob('batch*.json')):
 if '.v' in f.name:continue
 for x in read(f):
  rid=x['ruleId'];assert rid in sel and rid not in seen,(rid,f)
  seen.add(rid);previous=by.get(rid,{})
  by[rid]={**previous,'ruleId':rid,'visibleBody':{k:x.get(k,'') for k in ['frontZH','answerZH','keyPointZH','watchOutZH']},'origin':'current_native_short_draft','sourceFile':str(f),'sourceKeys':x.get('sourceKeys',[]),'sourceUrls':x.get('sourceUrls',[]),'prerequisiteRuleIds':x.get('prerequisiteRuleIds',previous.get('prerequisiteRuleIds',[])),'currentScopeApplied':True}
for f in sorted((V/'drafts').glob('repair*.json')):
 for x in read(f):
  rid=x['ruleId'];assert rid in by
  by[rid].update(visibleBody={k:x.get(k,'') for k in ['frontZH','answerZH','keyPointZH','watchOutZH']},sourceFile=str(f),repairOf=x.get('repairOf'))
  by[rid]['sourceUrls']=sorted(set(by[rid].get('sourceUrls',[])+x.get('sourceUrls',[])))
catalog={x['sourceKey']:x['url'] for x in read(R/'domain1-final-card-catalog-20261105/official-sources.catalog.json')}
for rid,x in by.items():
 x['sourceUrls']=sorted(set(x.get('sourceUrls',[])+[catalog[k] for k in x.get('sourceKeys',[]) if k in catalog]))
 x['bodySha256']=hashlib.sha256(json.dumps(x['visibleBody'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();x['questionIds']=sel[rid]['questionIds']
quarantine=read(V/'review/quarantined-rules.json') if (V/'review/quarantined-rules.json').exists() else {}
for rid,x in by.items():x['knowledgeUseState']='QUARANTINED' if rid in quarantine else 'PROVISIONAL_PENDING_CURRENT_REVIEW'
ready={rid for rid,x in by.items() if x['currentScopeApplied'] and rid not in quarantine}
q=read(V/'inputs/question-allocation1018.json');reuse=read(V/'review/reuse-a/question-reuse371.json');reuseids=set(reuse['eligibleQuestionIds']);raw=read(R/'domain1-final-card-catalog-20261105/questions.all.json')
readyqs=[];pending=[]
assigned=set()
for f in (V/'review').glob('questions-*/input/cases*.json'):
 if not f.stem[5:].isdigit():continue
 for x in read(f):assigned.add(x['qid'])
for x in q:
 if x['qid'] in reuseids:continue
 ids=x['designRuleIdsIncludingPrerequisites']
 if set(ids)<=ready:
  readyqs.append({'qid':x['qid'],'question':raw[str(x['qid'])],'cardRuleIds':ids,'visibleCards':[{k:by[rid][k] for k in ['ruleId','visibleBody','bodySha256']} for rid in ids]})
 else:pending.append(x['qid'])
(V/'deliverables/cards.current.json').write_text(json.dumps(list(by.values()),ensure_ascii=False,indent=2)+'\n')
(V/'deliverables/visible-knowledge-current.json').write_text(json.dumps([x for rid,x in by.items() if rid not in quarantine],ensure_ascii=False,indent=2)+'\n')
assert set(by)==set(sel)
(V/'validation/body-progress.json').write_text(json.dumps({'expectedCards':len(sel),'currentBodies':len(by),'currentScopeReady':len(ready),'missingBodyRuleIds':sorted(set(sel)-set(by)),'readyFreshQuestions':len(readyqs),'pendingFreshQuestions':len(pending),'reusedQuestionEligibilityCount':len(reuseids)},indent=2)+'\n')
# A fresh reviewer receives original stems/options and visible card text only, no prior verdicts.
remaining=[x for x in readyqs if x['qid'] not in assigned]
if remaining:
 who=sys.argv[1] if len(sys.argv)>1 else 'questions-a'
 assert who.startswith('questions-') and '/' not in who
 p=V/'review'/who/'input';p.mkdir(parents=True,exist_ok=True)
 number=1
 while (p/f'cases{number:02d}.json').exists():number+=1
 batch=remaining[:220];f=p/f'cases{number:02d}.json';f.write_text(json.dumps(batch,ensure_ascii=False,indent=2)+'\n')
 fs=[f,V/'rules.md',V/'inputs/teaching-standard.md'];(p/f'cases{number:02d}.manifest.json').write_text(json.dumps({str(z):hashlib.sha256(z.read_bytes()).hexdigest() for z in fs},indent=2)+'\n');print('NEW_QUESTION_PACKET',f,len(batch))
print('READY',len(ready),'missing',len(sel)-len(ready),'fresh questions ready',len(readyqs),'pending',len(pending))

# -*- coding: utf-8 -*-
import json,pathlib,hashlib,shutil,subprocess,sys,datetime
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106')
OUT=V/'validation/assembly-adapter-probes-repair01';OUT.mkdir(exist_ok=True)
def rd(p):return json.loads(pathlib.Path(p).read_text())
def wr(p,j):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def cp(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
base=OUT/'base';w=base/'run'
if base.exists():shutil.rmtree(base)
w.mkdir(parents=True)
for rel in ['assemble_current.py','write_card_status.py','inputs/existing176.json','inputs/card-catalogue.frozen-design.json','inputs/supplemental-catalogue.approved.json','inputs/question-allocation1018.json','review/quarantined-rules.json','review/reuse-a/question-reuse371.json','review/reuse-a/reuse-results.json','review/reuse-a/dependency5.review.json','rules.md','inputs/teaching-standard.md']:
 cp(V/rel,w/rel)
for p in (V/'drafts').glob('*.json'):cp(p,w/'drafts'/p.name)
for owner in ['reuse-a','cards-c']:
 for p in (V/'review'/owner).glob('*.review.json'):cp(p,w/'review'/owner/p.name)
for p in ['official-sources.catalog.json','questions.all.json']:cp(V.parent/'domain1-final-card-catalog-20261105'/p,base/'domain1-final-card-catalog-20261105'/p)
wr(w/'review/questions-fixture/input/cases01.json',[{'qid':x['qid']} for x in rd(V/'inputs/question-allocation1018.json')])
(w/'deliverables').mkdir(exist_ok=True);(w/'validation').mkdir(exist_ok=True)
def run(p,name):
 r=subprocess.run([sys.executable,str(p)],text=True,capture_output=True);return {'name':name,'returnCode':r.returncode,'stdout':r.stdout[-1600:],'stderr':r.stderr[-1600:]}
def clone(name):
 p=OUT/name
 if p.exists():shutil.rmtree(p)
 shutil.copytree(base,p);return p/'run'
checks=[];f=clone('positive');r=run(f/'assemble_current.py','positive_current_assembly');checks.append(r);assert r['returnCode']==0
actual=rd(V/'deliverables/cards.current.json');ac={x['ruleId']:x for x in actual};generated=rd(f/'deliverables/cards.current.json');gc={x['ruleId']:x for x in generated}
assert len(gc)==358 and set(gc)==set(ac)
assert all(gc[k]['bodySha256']==ac[k]['bodySha256'] and gc[k]['visibleBody']==ac[k]['visibleBody'] for k in ac)
assert set(x['ruleId'] for x in rd(f/'deliverables/visible-knowledge-current.json'))=={k for k,x in ac.items() if x['knowledgeUseState']!='QUARANTINED'}
assert all(set(ac[k].get('sourceUrls',[]))<=set(gc[k].get('sourceUrls',[])) for k in ac)
checks.append({'name':'positive_body_and_source_readback','status':'PASS','currentBodies':len(gc),'visibleBodies':len(rd(f/'deliverables/visible-knowledge-current.json')),'canonicalCurrentBodiesIdentical':True,'currentSourceUrlsPreserved':True})
r=run(f/'write_card_status.py','positive_current_status');checks.append(r);assert r['returnCode']==0
ix=rd(f/'validation/current-card-review-index.json');assert ix['candidateCount']==358;assert next(x for x in ix['cards'] if x['ruleId']=='GCL-020')['status']!='PASS'
checks.append({'name':'positive_status_count_and_quarantine','status':'PASS','counts':ix['counts'],'globalDependencyClosureVerified':ix['globalDependencyClosureVerifiedByThisFormatter']})
f=clone('unapproved');p=f/'drafts/batch22.json';wr(p,[{'ruleId':'VC-UNAPPROVED','frontZH':'x','answerZH':'x','keyPointZH':'x'}]);r=run(f/'assemble_current.py','negative_unapproved_new_id');checks.append(r);assert r['returnCode']!=0 and not (f/'deliverables/cards.current.json').exists()
f=clone('duplicate-approved');p=f/'inputs/supplemental-catalogue.approved.json';j=rd(p);j.append(j[0]);wr(p,j);r=run(f/'assemble_current.py','negative_duplicate_approved_id');checks.append(r);assert r['returnCode']!=0 and not (f/'deliverables/cards.current.json').exists()
f=clone('approved-missing-body');(f/'drafts/batch21.json').unlink();r=run(f/'assemble_current.py','negative_approved_id_missing_body');r['wroteCurrentBeforeFailure']=(f/'deliverables/cards.current.json').exists();r['wroteVisibleBeforeFailure']=(f/'deliverables/visible-knowledge-current.json').exists();checks.append(r);assert r['returnCode']!=0
# Independent fixtures remove every VC-001 holistic receipt before adding the probe.
def status_fixture(name,entry):
 f=clone(name);assert run(f/'assemble_current.py','setup')['returnCode']==0
 for owner in ['reuse-a','cards-c']:
  for p in (f/'review'/owner).glob('*.review.json'):
   j=rd(p)
   for k in ['cards','results']:
    if k in j:j[k]=[x for x in j[k] if x.get('ruleId')!='VC-001']
   wr(p,j)
 wr(f/'review/reuse-a/probe.review.json',{'results':[{'ruleId':'VC-001','bodySha256':ac['VC-001']['bodySha256'],**entry}]})
 r=run(f/'write_card_status.py',name);assert r['returnCode']==0;r['targetStatus']=next(x for x in rd(f/'validation/current-card-review-index.json')['cards'] if x['ruleId']=='VC-001')['status'];checks.append(r);return r
assert status_fixture('negative_FACT_only_positive',{'FACT':'PASS'})['targetStatus']=='UNKNOWN'
assert status_fixture('negative_FACT_only_failure',{'FACT':'FAIL'})['targetStatus']=='FAIL'
r=status_fixture('negative_explicit_FACT_only_PASS',{'status':'PASS','gates':{'FACT':'PASS'},'reviewScope':'FACT_ONLY'});r['expectedSafeStatus']='UNKNOWN';assert r['targetStatus']=='UNKNOWN'
# Scope of no-supplement baseline: existing356 selection/file is used unmodified.
f=clone('original356');(f/'inputs/supplemental-catalogue.approved.json').unlink();(f/'drafts/batch21.json').unlink();r=run(f/'assemble_current.py','original356_without_optional_supplement');checks.append(r);assert r['returnCode']==0 and len(rd(f/'deliverables/cards.current.json'))==356
findings=[]
if next(x for x in checks if x['name']=='negative_approved_id_missing_body')['wroteCurrentBeforeFailure']:
 findings.append({'id':'ADP-001','priority':'P2','file':str(V/'assemble_current.py'),'line':45,'title':'Validate complete selected bodies before replacing current outputs','reason':'已批准新增目标缺失batch21正文时，脚本先写cards.current/visible-knowledge-current为356条，再在set(by)==set(sel)断言失败。负控实证两个current文件均在失败前被替换；若直接运行会留下不完整当前快照。','requestedFix':'将完整ID集合断言移到任何current输出写入前；保留旧失败及本负控。'})
if r is None:pass
p=next(x for x in checks if x['name']=='negative_explicit_FACT_only_PASS')
if p['targetStatus']=='PASS':
 findings.append({'id':'ADP-002','priority':'P2','file':str(V/'write_card_status.py'),'line':21,'title':'Explicit FACT-only receipts must not become teaching PASS','reason':'仅含gates={FACT:PASS}、reviewScope=FACT_ONLY但行status=PASS的收据被纳入全教学PASS；去掉其它VC001证明后的隔离负控仍得到PASS。当前补丁正确忽略裸FACT:PASS，但未识别明确FACT-only范围。','requestedFix':'对明确FACT-only收据拒绝作为教学positive proof；继续保留其FAIL/UNKNOWN事实阻断。无需拒绝既有有完整教学范围的PASS收据。'})
report={'schemaVersion':1,'status':'FAIL_requires_two_targeted_adapter_fixes' if findings else 'PASS_local_adapter_checks_only','reviewer':'reuse-a independent minimal code reviewer','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inspectedSourceHashes':{str(V/x):sha(V/x) for x in ['assemble_current.py','write_card_status.py']},'originalFrozen356CataloguePath':str(V/'inputs/card-catalogue.frozen-design.json'),'originalFrozen356CatalogueSha256':sha(V/'inputs/card-catalogue.frozen-design.json'),'approvedSupplementCataloguePath':str(V/'inputs/supplemental-catalogue.approved.json'),'approvedSupplementCatalogueSha256':sha(V/'inputs/supplemental-catalogue.approved.json'),'positiveCurrentBodiesAndSourceUrlsMatch':True,'checks':checks,'findings':findings,'fixtureRoot':str(OUT),'priorFailureReceiptPath':str(V/'validation/assembly-adapter-review.fail01.json'),'priorFailureReceiptSha256':sha(V/'validation/assembly-adapter-review.fail01.json'),'priorFailureAndProbeHistoryPreserved':True,'productionCodeOrDataMutated':False,'notVerified':['Global prerequisite closure','All card FACT or teaching semantics','All1018 question coverage','Final core N','Formal bilingual import or production deployment'],'directCliApiCalls':0,'nativeUsage':'unknown'}
op=V/'validation/assembly-adapter-review.json';wr(op,report)
lines=['# Current assembly adapter review','','Local isolated code/probe review only. No global prerequisite, question coverage or final-N acceptance.','',f"Result: {report['status']}",'','Positive replay reproduced358 candidate/357 visible bodies, preserved source URLs and quarantine, and preserved the original356-only path. Bare FACT-only positive is ignored; FACT-only failure blocks.','']
for x in findings:lines += [f"- {x['id']} ({x['priority']}): {x['title']}. {x['reason']} Requested: {x['requestedFix']}",'']
lines += ['Every probe ran in validation/assembly-adapter-probes copies. Live scripts, current files, catalogue, source selection and original evidence were not edited. CLI/API calls0; native usage unknown.']
(V/'validation/assembly-adapter-review.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':report['status'],'findings':findings,'reportSha256':sha(op)},ensure_ascii=False,indent=2))

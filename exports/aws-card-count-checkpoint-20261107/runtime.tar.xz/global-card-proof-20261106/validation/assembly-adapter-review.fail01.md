# Current assembly adapter review

Local isolated code/probe review only. No global prerequisite, question coverage or final-N acceptance.

Result: FAIL_requires_two_targeted_adapter_fixes

Positive replay reproduced358 candidate/357 visible bodies, preserved source URLs and quarantine, and preserved the original356-only path. Bare FACT-only positive is ignored; FACT-only failure blocks.

- ADP-001 (P2): Validate complete selected bodies before replacing current outputs. 已批准新增目标缺失batch21正文时，脚本先写cards.current/visible-knowledge-current为356条，再在set(by)==set(sel)断言失败。负控实证两个current文件均在失败前被替换；若直接运行会留下不完整当前快照。 Requested: 将完整ID集合断言移到任何current输出写入前；保留旧失败及本负控。

- ADP-002 (P2): Explicit FACT-only receipts must not become teaching PASS. 仅含gates={FACT:PASS}、reviewScope=FACT_ONLY但行status=PASS的收据被纳入全教学PASS；去掉其它VC001证明后的隔离负控仍得到PASS。当前补丁正确忽略裸FACT:PASS，但未识别明确FACT-only范围。 Requested: 对明确FACT-only收据拒绝作为教学positive proof；继续保留其FAIL/UNKNOWN事实阻断。无需拒绝既有有完整教学范围的PASS收据。

Every probe ran in validation/assembly-adapter-probes copies. Live scripts, current files, catalogue, source selection and original evidence were not edited. CLI/API calls0; native usage unknown.

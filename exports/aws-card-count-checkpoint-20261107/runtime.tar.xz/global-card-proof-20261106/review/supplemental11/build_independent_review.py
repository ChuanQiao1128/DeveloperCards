import json,pathlib,hashlib,datetime,collections,re
O=pathlib.Path(__file__).parent;V=O.parent.parent;I=O/'input';OUT=V/'review/reuse-a'
def sha(b):return hashlib.sha256(b).hexdigest()
def can(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
fields=['frontZH','answerZH','keyPointZH','watchOutZH']
manifest=json.loads((I/'manifest.json').read_text())
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,p
D=json.loads((I/'cards.json').read_text());base=json.loads((I/'visible-pool.frozen.json').read_text());cards={c['ruleId']:dict(c) for c in base};draftById={c['ruleId']:c for c in D}
for d in D:
 old=cards[d['ruleId']];assert old['bodySha256']==d['repairOf'],d['ruleId'];body={f:d.get(f,'') for f in fields};cards[d['ruleId']]={**old,'visibleBody':body,'bodySha256':sha(can(body)),'reviewOverlayFrom':str(I/'cards.json'),'baseBodySha256':old['bodySha256']}
questions=json.loads((I/'questions.json').read_text());qs={x['qid']:x['question'] for x in questions}
E={};validation=[];inputs=json.loads((I/'official-evidence.json').read_text())
for n,e in enumerate(inputs,1):
 p=pathlib.Path(e['snapshotPath']);d=json.loads(p.read_text());t=d['text'];assert sha(p.read_bytes())==e['snapshotSha256'];assert sha(t.encode())==e['textSha256'];st=t.find(e['quote']);assert st>=0,(n,'author quote not verbatim')
 validation.append({'ordinal':n,'url':e['url'],'snapshotPath':str(p),'snapshotSha256':e['snapshotSha256'],'textSha256':e['textSha256'],'quoteStart':st,'quoteEnd':st+len(e['quote']),'quoteSha256':sha(e['quote'].encode()),'status':'PASS'})
def evidence(eid,selector,needles,other=None):
 if selector.startswith('@'):p=O/'evidence'/(selector[1:]+'.snapshot.json')
 elif other:p=pathlib.Path(other)
 else:
  match=[e for e in inputs if selector in e['url']];assert match,selector;p=pathlib.Path(match[0]['snapshotPath'])
 d=json.loads(p.read_text());t=d['text'];anchors=[]
 for n in needles:
  m=re.search(r'\s+'.join(re.escape(w) for w in n.split()),t,re.I);assert m,(eid,n);a=max(0,m.start()-90);b=min(len(t),m.end()+250);anchors.append({'quote':t[a:b],'start':a,'end':b})
 E[eid]={'url':d['url'],'snapshotPath':str(p),'snapshotSha256':sha(p.read_bytes()),'textSha256':sha(t.encode()),'quotes':anchors}
def oldpath(key):
 cat=json.loads((V/'review/open-condition-review01/input/official-snapshot-catalogue.json').read_text());return next(e['snapshotPath'] for e in cat if key in e['snapshotPath'])
evidence('FLINK_SOURCE','how-sources',['KinesisStreamsSource','Amazon MSK'])
evidence('FLINK_SINK','how-sinks',['FlinkKinesisFirehoseProducer is a reliable','StreamingFileSink'])
evidence('GLUE_STREAM','add-job-streaming',['jobs that run continuously','load the results into Amazon S3'])
evidence('GLUE_GENERAL','@glue-serverless',['serverless data integration','crawler'])
evidence('LOG_SUBSCRIPTIONS','SubscriptionFilters',['You can use a subscription filter','AWS Lambda receives the data'])
evidence('FIREHOSE_CWLOGS_UNSUPPORTED','@firehose-cwlogs-unsupported',['Currently, Firehose does not support the delivery of CloudWatch Logs to Amazon OpenSearch Service destination'])
evidence('OPENSEARCH_KINESIS','@opensearch-kinesis',['uses Amazon Kinesis Data Streams as the data source'])
evidence('SNAPSTART','snapstart',['Java 11 and later',"For Java managed runtimes, there's no additional cost for SnapStart",'uniqueness of state','published function versions'])
evidence('AURORA_NATIVE_REPLICA','Replica.html',['That starts a replication process','Stop all database write workload','Promoting an Aurora'])
evidence('DMS_CDC','unused',['bidirectional replication'],oldpath('cache-0f344512')) if False else None
evidence('DMS_CDC','unused',["AWS DMS bidirectional replication isn't intended as a full multi-master solution"],str(V/'review/open-condition-review01/evidence/dms-bidirectional.snapshot.json'))
evidence('MRAP','MultiRegionAccessPoints',['closest proximity S3 bucket with an active routing status','failover controls'])
evidence('DX_VIF','WorkingWithVirtualInterfaces',['Private virtual interface:','Public virtual interface:','Transit virtual interface:'])
evidence('DX_GATEWAY','direct-connect-gateways-intro',['globally available resource','does not allow gateway associations'])
evidence('DX_SITELINK','@dx-sitelink',['To route traffic between your data centers','SiteLink'])
evidence('REDSHIFT_MPP','c_high_level_system_architecture',['The slices then work in parallel','distributes the compiled code to the compute nodes'])
evidence('REDSHIFT_SERVERLESS','serverless-whatis',['without having to manage data warehouse infrastructure'])
evidence('DDB_CORE','unused',['primary key','attributes'],oldpath('cache-8c959bb5499a47ead16c'))
evidence('LUSTRE_DRA','@lustre-dra',['data repository association','S3'])
evidence('SNOW_IMPORT','importtype',['Amazon S3','import'])
evidence('HTTP_AUTHORIZER','http-api-lambda-authorizer',['sourceIp','2.0','caching'])
evidence('HTTP_API_COMPARE','@http-compare',['lower price','Resource policies'])
# Revision-specific card review: every body is this candidate overlay, not the old frozen body.
notes={
'CUR:NC01':('连续输入需要计算消费与结果输出连接，不能把缓冲交付当分析执行。KDS/Kafka及两个sink是同一数据流判断的例子，不要求背连接器清单。','识别连续分析需要实际处理代码，并能指出Firehose是结果交付端；不要求把所列源和sink逐个背全。',['FLINK_SOURCE','FLINK_SINK']),
'GSC-095':('一个核心判断是目录发现不等于转换，批与流只是同一读取→转换→写出机制的两个输入形态。','须回答实际ETL而非crawler，说明crawler只更新元数据；不另评分未问的MSK配置/worker参数。',['GLUE_STREAM','GLUE_GENERAL']),
'CUR:XR101':('计数与原文分流本身清楚，但新增加的Firehose→OpenSearch在CWLogs输入条件下被官方明确否定，不能拿通用Firehose目的地支持来放行。','问题明确问两种方法，两种都应回答；不要求背订阅权限清单。',['LOG_SUBSCRIPTIONS','FIREHOSE_CWLOGS_UNSUPPORTED']),
'GSC-135':('Java11、非严格预热保证和免费功能费用一起构成SnapStart的有用取舍；原因是保存初始化状态而非增大超时。','解释版本初始化快照与恢复机制，以及为什么先比较SnapStart；唯一值/兼容提醒不另增成部署清单。',['SNAPSTART']),
'GSC-060':('一个判断是持续写入期间必须追变化；DMS和原生Aurora迁移副本均作为该机制实现示例，不要求机械背两套操作。','只评分全量后仍有新写入、选择受支持持续复制并追平切换；原生例子里的提升不得误当双向同步。',['AURORA_NATIVE_REPLICA','DMS_CDC']),
'GCL-029':('统一请求入口与复制数据各司其职，因果直接；同一任务仍是为什么单开复制不足以得到就近入口。','回答MRAP统一入口、复制另管对象分布；不要求复述给定多Region前提或备份配置。',['MRAP']),
'GSC-073':('按目标地址匹配VIF路径，并提醒DXGW并不自动形成全网络传递互通；不是把专线本身等同任意路由。','回答公有服务与私网的对应VIF/网关及可达性原因，边界只在题问相应互通时参与评分。',['DX_VIF','DX_GATEWAY','DX_SITELINK']),
'CUR:XB013':('在线键访问与仓库并行分析是一个核心取舍，MPP机制和Serverless减少仓库基础设施管理补足必要解释，未变成多服务配置清单。','依访问任务选DynamoDB或Redshift，说明键定位与并行分析差异；不强记所有键设计或节点配置。',['REDSHIFT_MPP','REDSHIFT_SERVERLESS','DDB_CORE']),
'GSC-006':('S3持久仓库与Lustre计算文件视图是一条输入/输出路径。Snowball返运句说明上游只到S3，不把设备导入与文件系统挂载当同一接口。','回答关联S3后以文件处理及显式导出结果；题面已给数据在S3，Snowball背景不作为额外必答。',['LUSTRE_DRA','SNOW_IMPORT']),
'CUR:XA053':('同一IP准入目标在REST与HTTP API使用不同机制，具体上下文sourceIp与禁用缓存防串IP直接服务这个判断。','两种产品机制须区分；HTTP用authorizer可信上下文，并在不同IP可能不同结果时不跨IP缓存。未问的长期角色配置不评分。',['HTTP_AUTHORIZER','HTTP_API_COMPARE'])}
cardResults=[]
for d in D:
 r=d['ruleId'];c=cards[r];why,assessment,evs=notes[r];g={k:'PASS' for k in ['FACT','U1','R1','T1','S1','P1']};g['B1']='N/A_CHINESE_ONLY';findings=[]
 if r=='CUR:XR101':
  g.update(FACT='FAIL',U1='FAIL',T1='FAIL');findings=[{'id':'SUP11-FACT-001','priority':'P1','field':'answerZH','quote':'原文检索用subscription filter，可接Firehose交付OpenSearch','reason':'AWS明确CloudWatch Logs多事件一record，Firehose不支持此输入到OpenSearch目的地；不是权限/解压的普通漏配。另列Lambda有效路径不抵消这句错误。','evidenceIds':['FIREHOSE_CWLOGS_UNSUPPORTED'],'minimumRepair':'删除该错误默认路径，保留有官方正证的订阅集成；若要支撑Q676的KDS路径，须在同一核心任务内教实际支持的消费者/解析连接，不能直接反选B。','affectedQuestions':[676]}]
 cardResults.append({'ruleId':r,'status':'FAIL' if findings else 'PASS','gates':g,'visibleBody':c['visibleBody'],'bodySha256':c['bodySha256'],'fieldSha256':{f:sha(c['visibleBody'][f].encode()) for f in fields},'bodyHashContract':'sha256(sorted UTF8 JSON of frontZH/answerZH/keyPointZH/watchOutZH, ensure_ascii=False, compact separators)','fullDraftSha256':sha(can(d)),'priorBodySha256':d['repairOf'],'namedValidPriorFACTProofs':[],'unchangedFactReuseScope':'No prior semantic conclusion assumed; unchanged clauses checked against actual visible context and applicable official facts; new interfaces explicitly checked.','evidenceIds':evs,'teachingAndRecallTaskReason':why,'prerequisiteRuleIds':c['prerequisiteRuleIds'],'assessmentCheck':assessment,'findings':findings})
QR=[]
def anchors(ids):
 used=[]
 def u(r):
  if r in used:return
  assert r in cards;r0=cards[r];used.append(r)
  for p in r0['prerequisiteRuleIds']:u(p)
 for r in ids:u(r)
 out=[]
 for r in used:
  c=cards[r]
  for f,t in c['visibleBody'].items():
   if t:out.append({'ruleId':r,'bodySha256':c['bodySha256'],'field':f,'quote':t,'start':0,'end':len(t)})
 return used,out

def Q(q,status,ids,choice,reason,remain='',evs=(),source=None):
 ids=ids.split();used,a=anchors(ids);question=qs[q];QR.append({'qid':q,'status':status,'selectedOptionOrdinals':choice if status=='SUPPORTED' else [],'candidateOptionOrdinals':choice,'questionSha256':sha(can(question)),'originalStemUtf8Sha256':sha(question['stem'].encode()),'originalOptionsCanonicalSha256':sha(can(question['options'])),'completeStemAndEveryOptionRead':True,'usedRuleIds':used,'directlyUsedRuleIds':ids,'necessaryAnchors':a,'recursiveUsedPrerequisiteBindings':[{'ruleId':r,'bodySha256':cards[r]['bodySha256'],'prerequisiteRuleIds':cards[r]['prerequisiteRuleIds']} for r in used],'reasoningAndClosestCompetitor':reason,'minimumRemainingJudgments':remain,'conditions':[] if not remain else [remain],'implementationChecksNotNewCards':'普通连接权限、适用配额、目标配置与部署测试单列；未把这些本身当源错误，也不追加题目未问的零RPO/绝对SLA。','officialEvidenceIds':list(evs),'sourceIssues':source,'usesTeachingFailedCandidateOverlay':'CUR:XR101' in used,'candidateOverlayAcceptanceDoesNotPromoteQuestion':True,'noPrivateTargetsOrPrintedAnswersUsed':True})
Q(267,'CONDITIONAL','CUR:NC01 CUR:NS01 VC-011 GSC-093',[4], 'D的托管分析＋Firehose交付是低维护方向，Firehose可把兼容流数据转Parquet写S3，新上传的SSE-S3满足普通静态加密。A/B的KDS本身不直接写S3，额外Lambda/EMR增加维护；C仍管理EMR。新NC01明确Firehose应作Flink输出，而非可读取的Flink输入。','若D的“create Analytics”允许配置独立受支持的输入源，再以Flink sink写Firehose，链路成立；原文没有命名实际输入接口，不能仅因两服务均创建就声称Firehose被Flink读取。当前只给条件支撑，不把未写方向硬宣称成确认源错。',('FLINK_SOURCE','FLINK_SINK'))
Q(292,'SUPPORTED','CUR:NC01 CUR:NS01 GSC-095 CUR:CC03',[1,2], 'A的KDS→Flink处理→Firehose→S3→Athena接口成立；B的MSK→Glue streaming ETL→S3→Athena也成立，新卡已经把两个原先缺的输入/输出连接教清。C的通用DMS未给可复制数据库源，D/E用RDS query editor替代对S3落地数据的Athena查询，缺对应服务路径。','',('FLINK_SOURCE','FLINK_SINK','GLUE_STREAM'))
Q(501,'SOURCE_ISSUE','CUR:CA17 CUR:XB004 CUR:NC01 CUR:NS01 CUR:CMP-M06 CUR:NA05',[1,4], '现行可见卡仍允许A的KDS→Lambda与D的API Gateway→Lambda两条托管实时分析后写S3路径；新增Flink源/sink知识不会凭空告诉原题已有哪种生产入口/重放要求。C若被读为Firehose→Flink输入则不成立，不能借旧Kinesis SQL功能补接口。','原题仍缺真正区分A/D的输入/持续保留要求；卡修订不把原题自动升级。',('FLINK_SOURCE','FLINK_SINK'),{'subtype':'decisive_input_missing','construct1':'付款方已有HTTP POST入口，API Gateway→Lambda分析后写S3满足每分钟到达，D直接。','construct2':'付款方已有持久Kinesis多消费者/重放路径，A沿流消费分析后写S3，不需要改成HTTP函数入口。','minimumClarification':'优先多选可行路径，或只新增确实必需的入口/重放设定；不伪称知道原作者所想。'})
Q(573,'SUPPORTED','GSC-135 GSC-134',[4], 'Java11且不要求严格预热保证，D用初始化快照恢复减少扩容初始化，Java managed runtime的SnapStart无额外功能费。A持续维持预热容量有不同费用/保证；B只延长超时不减少初始化，C可能提速但不是专门消除初始化重做的最省功能。','',('SNAPSTART',))
Q(601,'SUPPORTED','GSC-060 GSC-067',[2], 'B创建原生Aurora PostgreSQL迁移只读副本，持续复制源库写入，切换前停源写、确认追平后提升，减少停机和丢失窗口。A/C/D的一次性快照/导出导入不会追赶持续源写入，必须更长停写或另配复制。','',('AURORA_NATIVE_REPLICA',))
Q(676,'INSUFFICIENT_CARDS','CUR:NA03 CUR:XR101 CUR:NS01',[1], 'Flow Logs→CloudWatch Logs由NA03明确，C/D把网络日志投CloudTrail不正确。B的新卡所写CWLogs→Firehose→OpenSearch被AWS明确否定，不能沿用该假链。A可经受支持的OpenSearch Ingestion/Kinesis消费者处理到OpenSearch，但该实际消费者和日志解压/解析路径尚未被有效卡面教出。','修CUR:XR101的FACT错误；若要原题充分，须给A的实际受支持转发/解析接口可见锚点。官方能力存在不等于学习者当前已学会。未确认整道原题无有效选项。',('FIREHOSE_CWLOGS_UNSUPPORTED','OPENSEARCH_KINESIS','LOG_SUBSCRIPTIONS'))
Q(702,'SUPPORTED','GSC-006 GSC-005',[2], '已装载并返运的Snowball导入目标为S3，先落桶再关联Lustre；GSC-005为全数据集亚毫秒目标选择SSD并行文件系统，因此B可由可见卡组完成。D直接导入Lustre不是该返运导入路径，A缓存文件网关与C通用EFS不具同一并行SSD文件机制。原题已实际持有设备，不重复追加新客户订购资格。','',('SNOW_IMPORT','LUSTRE_DRA'))
Q(734,'CONDITIONAL','GSC-073 GSC-075 CUR:CB16',[4], 'D的DXGW通过private VIF/各VPC VGW把机房连接扩展到跨Region VPC，减少逐VPC专线维护；A的peering不提供机房传递，B不能把一个private VIF直接附多个远端VPC，C的EC2全网状VPN维护更高。','D只在“两个机房各自可达两Region VPC”的范围充分；若还要求VPC↔VPC、机房↔机房全互通，DXGW不自动给这些传递路径，应明确所需流向并用支持的转接/SiteLink等机制。新卡的“不自动”边界正确，未被用成绝对禁止所有可配置绕接。',('DX_GATEWAY','DX_VIF','DX_SITELINK'))
Q(804,'INSUFFICIENT_CARDS','GSC-095 CUR:XB013 GSC-103 GSC-089',[3], 'C是正确方向：每日ETL→Redshift Serverless MPP仓库→Redshift ML SQL训练。新XB013已补MPP和少维护仓库，GSC103教SQL建模；B的Aurora不是所问MPP仓库，D的Athena查询表不代替Redshift ML仓库。','当前可见GSC-095只说Glue ETL实际转换、streaming接口，没有明示Glue免管理服务器的执行性质；故尚不能从卡句完整解释“serverless wherever possible”对A/C的差异。官方Glue无服务器事实已核，但不能用审查者看过的官方段落抵学习卡缺句。可在现有同一任务中简短补这项必要性质，无须另开长卡。',('REDSHIFT_MPP','REDSHIFT_SERVERLESS','GLUE_GENERAL'))
Q(891,'SUPPORTED','GCL-029 CUR:NEW04',[4], 'D的单个MRAP全局入口通过AWS网络路由到近的活动桶，active-active减少手工故障流量管理，CRR另保证数据分布。A/C由应用自行挑区域且复制不是入口，B把统一全局入口误成每Region各一个。异步复制不等于任意刚写对象立即全局可见。','',('MRAP',))
Q(920,'INSUFFICIENT_CARDS','GSC-080 CUR:CA17 CUR:XA053',[4], 'SNS是独立订阅的pub/sub，排除竞争同队列的A；B/D都给API Gateway→Lambda→SNS路径，C引入有状态流和增强扇出而题目只需要一般事件发布订阅。','新XA053改为IP准入机制，旧版HTTP API较低单价的可见句已删除。当前卡组没有B的REST API与D的HTTP API在相同所需功能下的费用关系，无法只凭卡完成MOST cost-effective唯一取舍。官方lower price可证，但尚未进入学习者可见理由；不能复用已删除的旧句PASS。',('HTTP_API_COMPARE',))
Q(1019,'SOURCE_ISSUE','CUR:XA053 CUR:CA19 CUR:CMP-M04',[2], '按原文HTTP API产品，B的resource policy不受支持；新XA053给出的有效替代是Lambda authorizer依据API上下文sourceIp判断，并避免跨IP授权缓存。A是后端private integration而非前门IP准入，C/D把托管API当可直接部署子网并挂NACL/SG的实例，均未给该HTTP API的准入控制。','新卡能力可用，但有效Lambda authorizer未出现在原选项，不能直接把B现有resource policy当成已修复。若HTTP API只是泛指协议而非产品，须明示REST，不能静默改读。',('HTTP_API_COMPARE','HTTP_AUTHORIZER'),{'subtype':'explicit_product_capability_conflict','fact':'HTTP APIs do not support resource policies; REST APIs do.','minimumClarification':'保留HTTP API时，最小修B为按可信sourceIp判断的Lambda authorizer且避免跨IP缓存；另存练习并独立验。也可明确原指REST产品，但不能冒称原文已是REST。','originalUnchanged':True,'correctedVariantAuthored':False})
transfer=[
 {'ruleId':'CUR:NC01','changedCondition':'只需查已落地S3数据','status':'PASS','reason':'watchOut导向Athena；原任务若还要流处理，源和sink仍须接实际支持接口，不能把Firehose输出读成输入。'},
 {'ruleId':'GSC-095','changedCondition':'输入从已落地CSV变为持续MSK记录','status':'PASS','reason':'同一ETL与crawler区别保持，streaming输入→处理→S3输出已有原句正证。'},
 {'ruleId':'CUR:XR101','changedCondition':'日志已入CWLogs，输出选Firehose到OpenSearch','status':'FAIL','reason':'新答把通用目的地支持迁移到不支持的CWLogs记录封装；官方直接反证。'},
 {'ruleId':'GSC-135','changedCondition':'改为严格预热容量/冷启动保证','status':'PASS','reason':'题面限制已说明本卡不是严格预热保证；GSC134明确provisioned concurrency的准备环境作用，不把SnapStart快照等同常驻。'},
 {'ruleId':'GSC-060','changedCondition':'迁移应用开始在两库写同一行','status':'PASS','reason':'watchOut保留单向复制不解决冲突，不能据原生副本或DMS名称自动保证双向。'},
 {'ruleId':'CUR:XA053','changedCondition':'同一令牌从一个允许IP换到被拒IP','status':'PASS','reason':'新卡显式禁跨IP缓存，TTL0每次读requestContext.http.sourceIp，避免复用旧Allow。'}]
counts={'cardPASS':sum(x['status']=='PASS' for x in cardResults),'cardFAIL':sum(x['status']=='FAIL' for x in cardResults),'questionStatuses':dict(collections.Counter(q['status'] for q in QR))}
report={'schemaVersion':1,'batch':'supplemental11','reviewer':'independent_native_open_condition_review_agent','status':'FAIL_REQUIRES_LOCAL_REPAIR','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(I/'manifest.json'),'inputManifestSha256':sha((I/'manifest.json').read_bytes()),'inputHashes':manifest,'frozenVisiblePoolCount':len(base),'candidateOverlayCount':len(cards),'candidateOverlayMechanism':'Explicitly overlay ten draft bodies on frozen old bodies using repairOf equality; input pool and current remain unchanged.','proposedNewCards':0,'revisedExistingCards':10,'appliedToCurrent':False,'counts':counts,'results':cardResults,'questionImpactReview':QR,'usedExistingCardProofBindings':[{'ruleId':r,'bodySha256':cards[r]['bodySha256'],'prerequisiteRuleIds':cards[r]['prerequisiteRuleIds']} for r in sorted(set(r for q in QR for r in q['usedRuleIds'])) if r not in draftById],'evidenceRegistry':E,'officialInputRecordValidation':validation,'newCardSubstitutionTests':[],'newCardDomainMetadataReview':[],'transferChecks':transfer,'minimumRepairScope':[{'ruleId':'CUR:XR101','findingId':'SUP11-FACT-001','questions':[676],'action':'只修错误CWLogs→Firehose→OpenSearch路径并复核受影响链；其余九卡有效结果保留。'},{'ruleId':'GSC-095','questions':[804],'action':'若要关闭Q804卡组支撑，短句教明Glue ETL的无服务器执行性质；不因卡片FACT通过就冒称整题已覆盖。'},{'ruleId':'CUR:XA053','questions':[920],'action':'需要可见的HTTP/REST相同必要能力下费用关系；勿复用已删除句的旧支撑，也不为此把IP卡写成大清单。'}],'externalOfficialReadOnlyFetches':[str(p) for p in sorted((O/'evidence').glob('*.json'))],'formalBilingualAcceptance':'N/A_CHINESE_ONLY','privateGradingContractAcceptance':'NOT_PROVIDED; S1 reviewed as visible task only','learnerMemoryOrAccuracyMeasured':False,'originalQuestionStatusesAutomaticallyPromoted':False,'finalCardCountVerified':False,'priorFailuresPreserved':True,'currentPointersChangedByReviewer':False,'authoringPerformed':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
out=OUT/'supplemental11.review.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2))
checks=collections.Counter()
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h;checks['inputHashes']+=1
assert len(cardResults)==10 and len(QR)==12 and len(set(x['qid'] for x in QR))==12
for r in cardResults:assert sha(can(r['visibleBody']))==r['bodySha256'];checks['candidateBodyHashes']+=1
for q in QR:
 assert q['questionSha256']==sha(can(qs[q['qid']]));checks['completeQuestionBindings']+=1
 for a in q['necessaryAnchors']:
  c=cards[a['ruleId']];assert c['bodySha256']==a['bodySha256'];assert c['visibleBody'][a['field']][a['start']:a['end']]==a['quote'];checks['cardQuoteAnchors']+=1
 for b in q['recursiveUsedPrerequisiteBindings']:assert set(b['prerequisiteRuleIds'])<=set(q['usedRuleIds']);checks['recursiveBindings']+=1
for eid,e in E.items():
 p=pathlib.Path(e['snapshotPath']);assert sha(p.read_bytes())==e['snapshotSha256'];t=json.loads(p.read_text())['text'];assert sha(t.encode())==e['textSha256']
 for a in e['quotes']:assert t[a['start']:a['end']]==a['quote'];checks['officialQuoteAnchors']+=1
 checks['officialSnapshots']+=1
assert json.loads(out.read_text())==report
rb={'status':'PASS','meaning':'deterministic readback only; semantic result contains one failed card and open original questions','reviewPath':str(out),'reviewSha256':sha(out.read_bytes()),'inputManifestSha256':report['inputManifestSha256'],'candidateOverlayCount':len(cards),'reviewedCards':10,'reviewedOriginalQuestions':12,'counts':counts,'checks':dict(checks),'appliedToCurrent':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
(OUT/'supplemental11.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2));(O/'readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2));print(json.dumps(rb,ensure_ascii=False,indent=2))

import json,pathlib,requests,hashlib,concurrent.futures,datetime
from html.parser import HTMLParser
class Parser(HTMLParser):
 def __init__(self): super().__init__();self.out=[];self.skip=0
 def handle_starttag(self,tag,attrs):
  if tag in ("script","style","nav"): self.skip+=1
 def handle_endtag(self,tag):
  if tag in ("script","style","nav") and self.skip: self.skip-=1
 def handle_data(self,data):
  if not self.skip and data.strip():self.out.append(data.strip())
base=pathlib.Path(__file__).parent/'evidence'
urls={
'firehose-cwlogs-unsupported':'https://docs.aws.amazon.com/firehose/latest/dev/writing-with-cloudwatch-logs.html',
'opensearch-kinesis':'https://docs.aws.amazon.com/opensearch-service/latest/developerguide/configure-client-kinesis.html',
'http-compare':'https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-vs-rest.html',
'glue-serverless':'https://docs.aws.amazon.com/glue/latest/dg/what-is-glue.html',
'lustre-dra':'https://docs.aws.amazon.com/fsx/latest/LustreGuide/create-dra-linked-data-repo.html',
'dx-sitelink':'https://aws.amazon.com/blogs/networking-and-content-delivery/advanced-routing-scenarios-with-aws-direct-connect-sitelink/',
}

def fetch(kv):
 k,u=kv;r=requests.get(u,timeout=45);r.raise_for_status();s=Parser();s.feed(r.text);t='\n'.join(s.out);d={'url':u,'finalUrl':r.url,'httpStatus':r.status_code,'retrievedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':t,'textSha256':hashlib.sha256(t.encode()).hexdigest(),'htmlSha256':hashlib.sha256(r.content).hexdigest()};f=base/(k+'.snapshot.json');f.write_text(json.dumps(d,ensure_ascii=False,indent=2));return(k,len(t),r.url)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
 for item in urls.items():
  try:print(fetch(item))
  except Exception as e:print(item[0],str(e))

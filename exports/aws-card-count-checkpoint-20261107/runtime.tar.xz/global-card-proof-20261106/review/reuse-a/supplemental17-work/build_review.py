import collections, datetime, hashlib, json, pathlib

V = pathlib.Path(__file__).resolve().parents[3]
P = V/'review/supplemental17/input'
O = V/'review/reuse-a'
F = ['frontZH','answerZH','keyPointZH','watchOutZH']
def rd(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s): return hashlib.sha256(s.encode()).hexdigest()
def ch(x): return th(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def body(c): return {f:c.get(f,'') for f in F}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest = rd(P/'manifest.json')
assert all(sha(p)==h for p,h in manifest.items())
base = {c['ruleId']:c for c in rd(P/'visible-pool.frozen.json')}
drafts = rd(P/'cards.json')
assert len(base)==362 and len(drafts)==3
assert all(ch(c['visibleBody'])==c['bodySha256'] for c in base.values())
index_path = V/'validation/current-card-review-index.json'
index_hash = sha(index_path)
index = {c['ruleId']:c for c in rd(index_path)['cards']}
assert all(index[r]['currentBodySha256']==c['bodySha256'] for r,c in base.items())
legacy_path = V/'inputs/existing176.json'
legacy = {c['ruleId']:c for c in rd(legacy_path)}
proof_cache = {}
def bind_old(rid):
    if rid in proof_cache:return proof_cache[rid]
    c=base[rid];ix=index[rid]
    assert ix['status']=='PASS' and ix['currentBodySha256']==c['bodySha256']
    out=[]
    for p in ix['proofs']:
        assert sha(p['path'])==p['sha256']
        d=rd(p['path']);r=next(x for x in d.get('results',d.get('cards',[])) if x['ruleId']==rid)
        h=r['bodySha256'];contract='canonical four visible fields including empty fields'
        if h!=c['bodySha256']:
            lb=body(legacy[rid]['body'])
            assert lb==c['visibleBody'] and ch({k:v for k,v in lb.items() if v})==h
            contract='legacy omitted-empty hash reconstructed from existing176, exact four-field visible body matched'
        if r.get('visibleBody'):assert r['visibleBody']==c['visibleBody']
        z=dict(ruleId=rid,path=p['path'],sha256=p['sha256'],receiptBodySha256=h,currentBodySha256=c['bodySha256'],bodyBindingContract=contract)
        if r.get('proofs'):
            for pp in r['proofs']:assert sha(pp['path'])==pp['sha256']
            z['parentGateReceipts']=r['proofs']
        out.append(z)
    proof_cache[rid]=out
    return out

failed_path=O/'supplemental16.review.json'
failed=next(r for r in rd(failed_path)['results'] if r['ruleId']=='GSC-047')
assert failed['status']=='FAIL' and failed['gates']['R1']=='FAIL'
pool=dict(base)
for c in drafts:
    rid=c['ruleId']
    if rid=='GSC-047':
        assert c['repairOf']==failed['bodySha256'] and c['priorAcceptedBodySha256']==base[rid]['bodySha256']
        assert c['repairAttemptAfterSupplemental16']==1
    else: assert c['repairOf']==base[rid]['bodySha256']
    pool[rid]=dict(base[rid],visibleBody=body(c),bodySha256=ch(body(c)))
    bind_old(rid)

registry={}
def cite(p,needle,claim,end=None):
    p=pathlib.Path(p)
    if not p.is_absolute():p=V/p
    d=rd(p);s=d['text'];lo=s.index(needle);hi=lo+len(needle) if end is None else s.index(end,lo)+len(end);q=s[lo:hi]
    z=dict(claim=claim,url=d['url'],sourcePath=str(p),sourceFileSha256=sha(p),sourceTextSha256=th(s),quote=q,startChar=lo,endChar=hi,quoteSha256=th(q))
    if d.get('textSha256'):assert d['textSha256']==th(s)
    k=ch(z);registry[k]=z;return k

inputs=rd(P/'official-evidence.json');input_validation=[]
for i,e in enumerate(inputs):
    p=pathlib.Path(e['snapshotPath']);d=rd(p)
    assert sha(p)==e['snapshotSha256']==p.stem
    assert th(d['text'])==e['textSha256'] and d['url']==e['url']
    assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
    input_validation.append(dict(ordinal=i,status='PASS_immutable_filename_file_text_quote_binding',snapshotPath=str(p),snapshotSha256=sha(p),textSha256=e['textSha256'],quoteStart=e['quoteStart'],quoteEnd=e['quoteEnd'],quoteSha256=th(e['quote'])))
assert len(inputs)==4
def src(i,needle,claim,end=None):return cite(inputs[i]['snapshotPath'],needle,claim,end)
E={}
E['native-auto']=src(0,'Amazon RDS creates and saves automated backups of your DB instance or Multi-AZ DB cluster','Native automated backup retention applies to DB instances and Multi-AZ clusters.','backup retention period.')
E['cluster-window']=src(1,'BackupRetentionPeriod\nThe number of days for which automated backups are retained.','Native Multi-AZ DB cluster automated backup retention is 1–35 days; 30 is valid and zero disable is outside the range.','Type: Integer')
E['backup-cluster']=src(2,'AWS Backup supports continuous backups and point-in-time recovery for all Amazon RDS instances','AWS Backup currently excludes RDS Multi-AZ clusters from continuous backups/PITR.','Amazon RDS Multi-AZ clusters.')
E['backup-mechanism']=src(2,'Continuous backup works by first creating a full backup of','PITR combines a full baseline and transaction logs, whereas snapshots represent individual restoration points.','both continuous and snapshot backup rules.')
E['restore-new']=src(3,'A snapshot contains data from any databases that are running on your cluster.','Redshift snapshot restores historical snapshot data into a newly created cluster, not an ongoing source replica.','Then it restores all the databases from the snapshot\ndata.')
E['restore-console']=src(3,'To restore a cluster from a snapshot on the console','Console is a supported ordinary management path for the explicit Redshift snapshot restore capability.','new cluster to be created using the snapshot information.')
E['manual-no-expiry']=cite('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/retrieval-v3/corpus/sources/1d55ef02f6fb91fea3351a23c7b4c2e130508c5d9688519adc91ee279f1cd988.json',"Unlike automated backups, manual snapshots aren't subject to the backup retention period. Snapshots don't expire.",'Manual snapshot lifecycle moved from VC010 to047 is independently retained until explicit cleanup.')

# Validate prior official claims for the unchanged PITR mechanism, including the
# explicit DB-instance-only log cadence; do not turn evidence into visible cards.
prior47=rd(proof_cache['GSC-047'][0]['path'])
prior47_row=next(r for r in prior47['cards'] if r['ruleId']=='GSC-047')
prior47_evidence=[]
for e in prior47_row['evidence']:
    d=rd(e['sourcePath'])
    assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(d['text'])==e['textSha256']
    assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote'] and d['url']==e['url']
    prior47_evidence.append(e)

reason={
'GSC-047':dict(FACT='原PITR基线/日志/35天/DB实例约5分钟的事实精确复用；manual不受auto保留期控制、留到主动删除有独立原句。',U1='近期时间点由日志重放提供，多年历史由长期保留的离散快照提供；保留手工快照属性解释为何能长留。',R1='一个近期连续恢复与多年历史恢复点的对比。manual主动删除是长期快照生命周期的必要机制，不再另教Backup支持矩阵。',T1='若只要多年固定恢复点，可留manual；若要求多年任意秒，manual仍不能给这种连续窗口。auto改14天也不令manual自动过期。',S1='只评“不够、近期PITR+长期恢复点”及原因；不用复述未问的日志周期数字。',P1='PITR由快照+日志、长期快照由拍摄点及主动删除解释，不依赖私有目标。'),
'VC-010':dict(FACT='当前AWS Backup明确不支持RDS Multi-AZ cluster持续备份/PITR；原生ModifyDBCluster范围1–35天，周期快照不是该连续窗口。',U1='固定快照只能恢复离散时刻，解释为何不能接管原生PITR窗口；部署类型已经给定。',R1='题面与正文同问一个自动窗口管理路径判断，1–35为当前30天可行及不可禁用的边界；manual生命周期已转到047。',T1='保留改14天仍可原生设置；改成AWS Backup周期快照不会变成连续PITR。不能将特定cluster限制套所有RDS实例。',S1='答不能接管、原生设置30天及连续/离散机制即可，不要求部署命令或配额清单。',P1='当前同包047先解释PITR与快照恢复点，本卡再应用到特定cluster支持范围；可见先修已存在。'),
'CUR:NB04':dict(FACT='旧RDS/Aurora/DynamoDB/缓存事实沿精确旧正文凭证复用；官方Redshift快照恢复创建new cluster并恢复snapshot数据。',U1='持续复制追随当前状态，快照副本保存历史点；Redshift是同一机制的具体例子。',R1='仍是“当前复制副本能否替代历史备份”一个判断；Redshift新集群不增加暂停、加密或部署配置任务。',T1='Redshift源集群在快照后继续变化，新快照副本不自动追随；需要后续同步时不能把这项恢复当持续复制。',S1='只评不能替代及历史点/当前复制区别；不要求逐个背完卡中各服务名称。',P1='快照、持续复制及新集群作用随文说明；没有用私有摘录补学习前提。')}
keys={'GSC-047':['native-auto','backup-mechanism','manual-no-expiry'],'VC-010':['cluster-window','backup-cluster','backup-mechanism'],'CUR:NB04':['restore-new','restore-console']}
results=[]
for c in drafts:
    rid=c['ruleId'];b=body(c)
    results.append(dict(ruleId=rid,status='PASS',gates=dict({g:'PASS' for g in ['FACT','U1','R1','T1','S1','P1']},B1='N/A_chinese_stage'),gateReasons=reason[rid],visibleBody=b,bodySha256=ch(b),fieldSha256={f:th(b[f]) for f in F},fullDraftSha256=ch(c),priorAcceptedBodySha256=base[rid]['bodySha256'],repairOf=c['repairOf'],namedValidPriorFACTProofs=bind_old(rid),unchangedFieldsExactlyReused=[f for f in F if b[f]==base[rid]['visibleBody'][f]],evidenceIds=[E[k] for k in keys[rid]],prerequisiteRuleIds=pool[rid].get('prerequisiteRuleIds',[]),semanticVisiblePrerequisiteRuleIds=['GSC-047'] if rid=='VC-010' else [],assessmentCheck='仅核可见题面对齐；未收到私有mustAnswer，不宣称正式评分契约、双语或学习效果通过。',findings=[]))

canonical_path=V.parent/'domain1-final-card-catalog-20261105/questions.all.json'
canonical=rd(canonical_path)
questions={q['qid']:q['question'] for q in rd(P/'questions.json')}
for qid,q in questions.items():assert q==canonical[str(qid)]
cvs=rd(P/'corrected-cases.json');assert len(cvs)==1;cv=cvs[0]
assert cv['originalQuestion']==questions[515] and ch(cv['originalQuestion'])==cv['originalQuestionCanonicalSha256']
assert ch(cv['correctedQuestion'])==cv['correctedQuestionCanonicalSha256']
source_result_path=pathlib.Path(cv['sourceFinding']['independentResultPath'])
assert sha(source_result_path)==cv['sourceFinding']['independentResultSha256']
source_result=rd(source_result_path)
source_evidence_validation=[]
for k in ['RED_SHIFT_ENCRYPTION','REDSHIFT_SERVER_ENCRYPTION','REDSHIFT_COPY_RETIREMENT','REDSHIFT_PAUSE','REDSHIFT_RESTORE','REDSHIFT_API']:
    e=source_result['officialSources'][k];d=rd(e['snapshotPath'])
    assert sha(e['snapshotPath'])==e['snapshotSha256'] and th(d['text'])==e['textSha256']
    assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote'] and d['url']==e['url']
    source_evidence_validation.append(dict(key=k,**e))
    E[k]=cite(e['snapshotPath'],e['quote'],'Source-defect/corrected-practice factual basis only; not substituted for visible teaching.')

def A(rid,fields=F):
    c=pool[rid]
    return [dict(ruleId=rid,bodySha256=c['bodySha256'],field=f,quote=c['visibleBody'][f],startChar=0,endChar=len(c['visibleBody'][f]),candidateOverlay=(c['bodySha256']!=base[rid]['bodySha256'])) for f in fields if c['visibleBody'].get(f)]
def Q(qid,status,ids,q=None):
    q=q or questions[qid]
    out=dict(qid=qid,status=status,questionSha256=ch(q),stemUtf8Sha256=th(q['stem']),optionsCanonicalSha256=ch(q['options']),completeStemAndEveryOptionRead=True,usedRuleIds=ids,necessaryAnchors=sum([A(r) for r in ids],[]),recursiveUsedPrerequisiteBindings=[],selectedOptionOrdinals=[],noPrintedAnswersOrPrivateGoalsUsed=True,noOfficialSourceSubstitutedForMissingVisibleCard=True)
    todo=list(ids);seen=set()
    while todo:
        r=todo.pop()
        if r in seen:continue
        seen.add(r);bind_old(r)
        for dep in pool[r].get('prerequisiteRuleIds',[]):
            out['recursiveUsedPrerequisiteBindings'].append(dict(fromRuleId=r,ruleId=dep,bodySha256=pool[dep]['bodySha256'],visibleBody=pool[dep]['visibleBody']));todo.append(dep)
    return out

# Full-pool retrieval reads every Chinese body; all encryption and Redshift hits
# were semantically inspected for service-specific support rather than assuming
# every generic database rule applies to Redshift.
terms={'encryption':['加密','kms','密文','cipher','encryption','落盘'],
       'redshift':['redshift'], 'history':['snapshot','快照','副本','复制','备份','历史','恢复'],
       'schedule':['调度','定时','schedule','data api']}
retrieval={k:[dict(ruleId=rid,bodySha256=c['bodySha256']) for rid,c in pool.items() if any(t in ' '.join(c['visibleBody'].values()).lower() for t in ts)] for k,ts in terms.items()}
relevant_ids=['CUR:CMP-M20','CUR:CC05','CUR:CC08','CUR:CC09','CUR:CMP-M11','VC-011','CUR:NS04','CUR:CC03','GSC-047','CUR:NB04','GSC-089','GSC-102','CUR:XB013','GSC-101','GSC-032']
for rid in relevant_ids:bind_old(rid)
gap=dict(findingId='S17-Q515-B-SERVER-TEACHING',kind='visible_card_group_gap_not_card_defect_or_source_fact_unknown',qid=515,variantId='Q515-CV12',optionOrdinal=2,
         minimumRemainingJudgment='当前可见学习材料须明确Redshift确实支持服务端静态加密；通用加密概念不能证明指定服务已经实现该能力。',
         clientSideTransferVerdict='SUPPORTED: M20明说数据交给S3或数据库前由应用完成客户端加密；CV12明确为应用先加密字段，因此不要求已退役的Redshift COPY/UNLOAD解密集成。',
         whyGenericAlternativesDoNotClose='M20的SSE-C示例明确属于S3；CC08属于RDS，CC09属于EBS，VC011属于S3，NS04也只在S3场景给KMS设置。CC05以“服务同时支持”作为已给前提，不负责证明Redshift支持。全池Redshift可见句只有API/分析/外部表/ML/数据流/新snapshot集群等，没有服务端静态加密支持句。',
         externalFactIsKnownButNotTaught=True)
q989=Q(989,'SUPPORTED',['GSC-047','VC-010'])
q989.update(selectedOptionOrdinals=[3],reasoningAndClosestCompetitor='C：010给出该Multi-AZ cluster的原生auto 1–35天与30天设置，并明确AWS Backup周期快照不能接管这段连续窗口，排A；下限1也排B/D的禁用auto。047说明manual留到主动删除且独立长期保留，故超过30天需独立清理，保留未满30天的原有恢复点。只有C满足保留目标；不为最省费另造数字计算，也不把CloudFormation部署细节省略升为源错。',minimumRemainingJudgments=[],sourceIssueConfirmed=False,officialEvidenceIds=[E[k] for k in ['cluster-window','backup-cluster','manual-no-expiry']])
q515=Q(515,'SOURCE_ISSUE',['GSC-102','CUR:XB013','GSC-089','CUR:CMP-M20','CUR:NB04','GSC-047','GSC-032'])
q515.update(candidateOptionOrdinals=[1,2,3,6],reasoningAndClosestCompetitor='原文未限定B的客户端加密是否指已退役COPY/UNLOAD集成，也未限定F的secondary replica是持续同步还是snapshot另建独立集群。当前官方对通用client/server加密、DataAPI、按时段运行分析和console从snapshot恢复new cluster分别有正证；采用通用字段密文与历史副本读法时至少A/B/C/F四项成立，和Choose three冲突。不能暗加“持续自动同步”来排F，亦不能将特定旧CSE集成退役扩张成应用不能存密文。',sourceIssueConfirmed=True,sourceFinding=dict(subtype='selection_count_and_underspecified_encryption_replica_meanings',originalConditionsPreserved=True,sourceFactCandidateOptionOrdinals=[1,2,3,6],ambiguousTerms=['client-side encryption','secondary replica']),visibleCardGroupStatus='INSUFFICIENT_CARDS_for_full_ABCF_explanation',minimumRemainingJudgments=[gap['minimumRemainingJudgment']],officialEvidenceIds=[E[k] for k in ['RED_SHIFT_ENCRYPTION','REDSHIFT_SERVER_ENCRYPTION','REDSHIFT_COPY_RETIREMENT','REDSHIFT_PAUSE','REDSHIFT_RESTORE','REDSHIFT_API']])
practice=Q(515,'INSUFFICIENT_CARDS',q515['usedRuleIds'],cv['correctedQuestion'])
practice.update(variantId=cv['variantId'],originalQid=515,originalQuestionCanonicalSha256=ch(cv['originalQuestion']),correctedQuestionCanonicalSha256=ch(cv['correctedQuestion']),completeOriginalAndCorrectedEveryOptionRead=True,originalDefectIndependentlyConfirmed=True,minimalityVerdict='PASS',minimalityReview='只把数量改全选，明确B为应用预加密字段、F为snapshot独立新集群，分别解决原有计数与语义歧义；未替换迁移/Redshift能力目标，不宣称恢复原作者未写条件。',sourceFactExpectedOptionOrdinals=[1,2,3,6],standalonePracticeCardGroupStatus='INSUFFICIENT_CARDS',closureEligibleUnderAcceptedCorrectionPolicy=False,originalStatusNotUpgraded=True,reasoningAndClosestCompetitor='A由102的服务API运行SQL迁移到普通、容器和事件应用；C由XB013的MPP分析+089按时调度+102提交SQL推出，题面没有要求原生pause/resume，故不添加该新卡门槛。F由本包NB04明确Redshift snapshot另建独立时间点cluster，047/原NB04历史点与当前复制区别强化机制；console为该已明示恢复能力的普通管理入口，不要求背界面步骤。D由032缓存命中减少DB重复工作与XB013仓库分析定位排除；E的在线全球高请求量与MPP分析职责不同。B的客户端预加密可以迁移，但server-side Redshift支持不能从S3/RDS例子硬推，因此不接受整题充分。',minimumRemainingJudgments=[gap['minimumRemainingJudgment']],officialEvidenceIds=q515['officialEvidenceIds'],optionTransferReview=[dict(ordinal=1,verdict='SUPPORTED',mechanism='服务API提交SQL可由不同受授权计算形态调用；没有新增原生容器集成要求。',ruleIds=['GSC-102']),dict(ordinal=2,verdict='PARTIAL_client_only',mechanism=gap['clientSideTransferVerdict'],missing=gap['minimumRemainingJudgment'],ruleIds=['CUR:CMP-M20']),dict(ordinal=3,verdict='SUPPORTED',mechanism='分析计算+按时触发+SQL API可组成按业务空闲时段的分析，不要求新增服务特有暂停能力。',ruleIds=['CUR:XB013','GSC-089','GSC-102']),dict(ordinal=4,verdict='EXCLUDE',mechanism='ElastiCache命中内存减少重复DB工作，Redshift是MPP仓库分析。',ruleIds=['GSC-032','CUR:XB013']),dict(ordinal=5,verdict='EXCLUDE',mechanism='全球海量在线请求不是当前已教的仓库并行分析职责。',ruleIds=['CUR:XB013']),dict(ordinal=6,verdict='SUPPORTED',mechanism='新NB04明确Redshift从snapshot另建独立历史点cluster，不跟随后续更新；不是仅据泛化备份规则推断Redshift支持。',ruleIds=['CUR:NB04','GSC-047'])])

lineage=rd(P/'knowledge-transfer-lineage.json')
assert lineage['oldVC010ManualLifecycleMovedTo']=='GSC-047' and lineage['newCardCount']==0
assert '手工快照留到主动删除' in pool['GSC-047']['visibleBody']['keyPointZH']
assert 'AWS Backup当前不支持这种Multi-AZ DB cluster' in pool['VC-010']['visibleBody']['keyPointZH']
assert 'Redshift从snapshot另建集群' in pool['CUR:NB04']['visibleBody']['keyPointZH']
metadata=[dict(ruleId='VC-010',changed=True,oldPrincipalGoal='自动保留期不自动删除手工快照',newPrincipalGoal='特定Multi-AZ DB cluster原生连续窗口与AWS Backup周期快照的管理能力比较',oldGoalTransferredTo='GSC-047',action='采用时同步主目标/标签/语义绑定，不再把VC010单独作为manual生命周期知识证据。'),dict(ruleId='GSC-047',changed=True,principalGoalRetained='近期PITR与长期历史恢复点',addedNecessaryAttribute='manual留到主动删除；可接住原VC010生命周期关系。',action='原manual关系转到047，不能只换正文hash保留旧单卡归因。'),dict(ruleId='CUR:NB04',changed=True,principalGoalRetained='历史备份与持续复制职责区别',addedServiceExample='Redshift snapshot独立新cluster',action='服务范围/题515相关绑定需要刷新；不把历史例子记为持续复制或加密支撑。')]
report=dict(schemaVersion=1,batch='supplemental17',reviewer='independent actual Chinese card/original/corrected-practice reviewer',reviewedAtUtc=now(),status='PASS_three_cards_one_original_supported_one_original_source_issue_practice_held_by_single_visible_gap',inputManifestPath=str(P/'manifest.json'),inputManifestSha256=sha(P/'manifest.json'),inputHashes=manifest,currentReviewIndexPath=str(index_path),currentReviewIndexSha256=index_hash,legacyBodyBindingSourcePath=str(legacy_path),legacyBodyBindingSourceSha256=sha(legacy_path),frozenVisiblePoolCount=362,candidateOverlayCount=3,newCards=0,appliedToCurrent=False,counts=dict(cardPASS=3,cardFAIL=0,originalQuestionStatuses={'SUPPORTED':1,'SOURCE_ISSUE':1},correctedPracticeStatuses={'INSUFFICIENT_CARDS':1},correctedMinimalityPASS=1,correctionClosureEligible=0),results=results,questionImpactReview=[q989,q515],correctedVariantImpactReview=[practice],evidenceRegistry=registry,officialInputRecordValidation=input_validation,reusedPriorGSC047ExactEvidenceValidation=prior47_evidence,independentlyRevalidatedOriginal515OfficialEvidence=source_evidence_validation,priorSourceFindingBinding=dict(path=str(source_result_path),sha256=sha(source_result_path),priorFindingUsedAsConclusion=False),usedExistingCardProofBindings=proof_cache,fullVisiblePoolTransferCheck=dict(scannedBodyCount=len(pool),poolFileSha256=sha(P/'visible-pool.frozen.json'),overlayBodyHashes={c['ruleId']:ch(body(c)) for c in drafts},retrievalTerms=terms,retrievalHits=retrieval,semanticallyInspectedRelevantCurrentBodies=[dict(ruleId=r,bodySha256=pool[r]['bodySha256'],visibleBody=pool[r]['visibleBody']) for r in relevant_ids],BVerdict='client application pre-encryption transferable; Redshift server-side support not present in visible pool',FVerdict='explicit new Redshift snapshot/new-cluster sentence supports the service capability, historical-copy rules explain meaning',noGenericServiceSupportAssumption=True),knowledgeTransferLineagePath=str(P/'knowledge-transfer-lineage.json'),knowledgeTransferLineageSha256=sha(P/'knowledge-transfer-lineage.json'),knowledgeTransferIndependentlyValidated=True,metadataPrincipalGoalChanges=metadata,metadataFieldsActuallyMutated=False,formalDomainNumberReassigned=False,findings=[gap],minimumRepairScope=dict(cardDefects=[],visibleNecessaryKnowledgeGapOption='Q515-CV12:B Redshift server-side encryption support',unaffectedPASSRuleIds=['GSC-047','VC-010','CUR:NB04'],unaffectedSupportedOriginalIds=[989]),failureClosure=[dict(findingId='S16-GSC047-R1',status='CLOSED_BY_TARGETED_REORGANIZATION',priorReviewPath=str(failed_path),priorReviewSha256=sha(failed_path),priorFailedBodySha256=failed['bodySha256'],priorAcceptedBodySha256=base['GSC-047']['bodySha256'],repairBodySha256=pool['GSC-047']['bodySha256'],repairAttempt=1,oldFailureRetained=True,reason='047恢复时间尺度主任务，独立cluster/Backup目标转010，原manual生命周期转047；无新卡。')],formalBilingualAcceptance=False,privateGradingContractAcceptance=False,learnerMemoryOrAccuracyMeasured=False,finalCardCountVerified=False,originalQuestionStatusesAutomaticallyPromoted=False,currentPointersChangedByReviewer=False,authoringPerformed=False,externalOfficialReadOnlyFetches=0,directCliApiCalls=0,nativeUsage='unknown')
rp=O/'supplemental17.review.json';rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
z=rd(rp)
for r in z['results']:
    assert ch(r['visibleBody'])==r['bodySha256'] and {f:th(r['visibleBody'][f]) for f in F}==r['fieldSha256']
for q in z['questionImpactReview']+z['correctedVariantImpactReview']:
    for a in q['necessaryAnchors']:
        assert pool[a['ruleId']]['bodySha256']==a['bodySha256'] and pool[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
    for d in q['recursiveUsedPrerequisiteBindings']:
        assert pool[d['ruleId']]['bodySha256']==d['bodySha256'] and pool[d['ruleId']]['visibleBody']==d['visibleBody']
for k,e in z['evidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256'] and s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256'] and ch(e)==k
assert all(sha(p)==h for p,h in manifest.items()) and sha(index_path)==index_hash
rb=dict(status='PASS_readback_with_explicit_corrected_practice_gap',reviewPath=str(rp),reviewSha256=sha(rp),inputManifestSha256=sha(P/'manifest.json'),readBackAtUtc=now(),counts=z['counts'],checks=dict(threeCanonicalFourFieldBodiesAndPerFieldHashes=True,twoCompleteOriginalsEveryOption=True,completeOriginalAndCorrectedVariantEveryOption=True,allExactNecessaryAnchorsAndRecursivePrerequisites=True,allNamedCurrentPriorProofsAndBodyBindings=True,allFourFrozenOfficialFilesMatchHashNamedImmutablePaths=True,allOfficialFileTextQuoteOffsetsAndHashes=True,full362PoolBAndFTransferInspectionRecorded=True,correctedMinimalitySeparateFromCardGroupSufficiency=True,originalSourceIssueNotUpgradedByPractice=True,knowledgeTransfersAndMetadataChangesExplicit=True,failed16GSC047LineageAndSingleRepairRetained=True,allFrozenInputsStillUnchanged=True,noCurrentSourceProductionOrHistoryMutation=True),formalBilingualAcceptance=False,learnerEffectMeasured=False,finalNVerified=False,directCliApiCalls=0,nativeUsage='unknown')
(O/'supplemental17.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(review=str(rp),sha256=sha(rp),counts=z['counts']),ensure_ascii=False))

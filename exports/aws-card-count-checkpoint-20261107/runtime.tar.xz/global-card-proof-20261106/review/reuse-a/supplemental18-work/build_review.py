import copy, datetime, hashlib, json, pathlib

V=pathlib.Path(__file__).resolve().parents[3]
P=V/'review/supplemental18/input'
O=V/'review/reuse-a'
F=['frontZH','answerZH','keyPointZH','watchOutZH']
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s):return hashlib.sha256(s.encode()).hexdigest()
def ch(x):return th(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def body(c):return {f:c.get(f,'') for f in F}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest=rd(P/'manifest.json')
assert all(sha(p)==h for p,h in manifest.items())
base={c['ruleId']:c for c in rd(P/'visible-pool.frozen.json')}
drafts=rd(P/'cards.json');assert len(base)==362 and len(drafts)==1
c=drafts[0];assert c['ruleId']=='CUR:CC08' and c['repairOf']==base[c['ruleId']]['bodySha256']
assert all(ch(x['visibleBody'])==x['bodySha256'] for x in base.values())
pool=dict(base);pool[c['ruleId']]=dict(base[c['ruleId']],visibleBody=body(c),bodySha256=ch(body(c)))
index_path=V/'validation/current-card-review-index.json';index_hash=sha(index_path)
index={x['ruleId']:x for x in rd(index_path)['cards']}
assert all(index[r]['status']=='PASS' and index[r]['currentBodySha256']==x['bodySha256'] for r,x in base.items())
legacy_path=V/'inputs/existing176.json';legacy={x['ruleId']:x for x in rd(legacy_path)}
proof_cache={}
def bind_old(rid):
    if rid in proof_cache:return proof_cache[rid]
    x=base[rid];out=[]
    for p in index[rid]['proofs']:
        assert sha(p['path'])==p['sha256'];d=rd(p['path']);r=next(z for z in d.get('results',d.get('cards',[])) if z['ruleId']==rid)
        h=r['bodySha256'];contract='canonical four current visible fields including empty fields'
        if h!=x['bodySha256']:
            lb=body(legacy[rid]['body']);assert lb==x['visibleBody'] and ch({k:v for k,v in lb.items() if v})==h
            contract='legacy omitted-empty hash reconstructed from hash-bound existing176 and exact visible fields matched'
        if r.get('visibleBody'):assert r['visibleBody']==x['visibleBody']
        z=dict(ruleId=rid,path=p['path'],sha256=p['sha256'],receiptBodySha256=h,currentBodySha256=x['bodySha256'],bodyBindingContract=contract)
        if r.get('proofs'):
            for pp in r['proofs']:assert sha(pp['path'])==pp['sha256']
            z['parentGateReceipts']=r['proofs']
        out.append(z)
    proof_cache[rid]=out;return out

inputs=rd(P/'official-evidence.json');assert len(inputs)==1
e=inputs[0];ep=pathlib.Path(e['snapshotPath']);d=rd(ep);s=d['text']
assert sha(ep)==e['snapshotSha256']==ep.stem and th(s)==e['textSha256']
assert s[e['quoteStart']:e['quoteEnd']]==e['quote'] and d['url']==e['url']
registry={}
def cite(needle,end,claim):
    lo=s.index(needle);hi=s.index(end,lo)+len(end);q=s[lo:hi]
    z=dict(claim=claim,url=d['url'],sourcePath=str(ep),sourceFileSha256=sha(ep),sourceTextSha256=th(s),quote=q,startChar=lo,endChar=hi,quoteSha256=th(q));k=ch(z);registry[k]=z;return k
E1=cite('In Amazon Redshift, your database is encrypted by default to protect your data at rest.','customer managed key.','Redshift provides native at-rest storage encryption and KMS integration; current card claims capability, not that every database needs identical migration steps.')
E2=cite('Amazon Redshift uses a hierarchy of encryption keys to encrypt the database.','Amazon Redshift automatically integrates with AWS KMS but not with an HSM.','Explicit service-specific KMS integration supports the newly visible Redshift sentence.')

old=base['CUR:CC08']['visibleBody'];new=body(c)
assert new['keyPointZH']==old['keyPointZH'] and new['watchOutZH']==old['watchOutZH']
assert '已有未加密RDS应制作快照' in new['answerZH'] and '若已有RDS未加密运行' in new['frontZH']
cc05_before=base['CUR:CC05']['bodySha256']
assert pool['CUR:CC05']['bodySha256']==cc05_before
result=dict(ruleId='CUR:CC08',status='PASS',gates=dict({g:'PASS' for g in ['FACT','U1','R1','T1','S1','P1']},B1='N/A_chinese_stage'),visibleBody=new,bodySha256=ch(new),fieldSha256={f:th(new[f]) for f in F},fullDraftSha256=ch(c),priorAcceptedBodySha256=c['repairOf'],repairOf=c['repairOf'],namedValidPriorFACTProofs=bind_old('CUR:CC08'),unchangedFieldsExactlyReused=['keyPointZH','watchOutZH'],evidenceIds=[E1,E2],prerequisiteRuleIds=pool['CUR:CC08'].get('prerequisiteRuleIds',[]),gateReasons=dict(FACT='原RDS KMS/快照加密迁移/TLS边界精确沿有效凭证；新增Redshift基于KMS的服务端落盘加密由完整当前官方原句支持，没有引入AWS-owned/AWS-managed类型等同。',U1='KMS静态加密保护落盘，TLS保护连接；增加Redshift同一作用范围，原因未改变。',R1='仍是一个“服务端存储加密不能由TLS替代”的判断。Redshift是同一保护层的第二个明确实例；未添加其独立迁移/轮换部署任务。旧RDS改造步骤仍严格限定已有未加密RDS。',T1='把RDS换成Redshift，落盘加密与TLS仍是不同边界；不能因此将RDS snapshot复制步骤外推为Redshift唯一或必需改造流程。',S1='按题面回答新建存储的加密能力和已有RDS的改造/TLS区别；不要求CC05密钥类型、Redshift迁移命令或未问默认值。',P1='KMS作用及快照复制产生加密数据的机制在正文；当前M20另教客户端先加密，可组合辨别两层而不用私有来源。'),assessmentCheck='只核可见题面对齐；未收到私有mustAnswer，不宣称正式评分契约、双语或记忆效果通过。',findings=[])

prior_path=O/'supplemental17.review.json';prior_hash=sha(prior_path)
assert prior_hash=='460089a67ecd7181ddf325dea079a8e12108725338845e1be0b49cb9d2b701d8'
prior=rd(prior_path);oldpractice=prior['correctedVariantImpactReview'][0]
assert oldpractice['status']=='INSUFFICIENT_CARDS' and len(oldpractice['minimumRemainingJudgments'])==1
cv=rd(P/'corrected-cases.json')[0];q=rd(P/'questions.json')[0]['question']
canonical_path=V.parent/'domain1-final-card-catalog-20261105/questions.all.json'
assert q==rd(canonical_path)['515']==cv['originalQuestion']
assert ch(q)==cv['originalQuestionCanonicalSha256']==oldpractice['originalQuestionCanonicalSha256']
assert ch(cv['correctedQuestion'])==cv['correctedQuestionCanonicalSha256']==oldpractice['correctedQuestionCanonicalSha256']
for qa in prior['questionImpactReview']+prior['correctedVariantImpactReview']:
    for a in qa['necessaryAnchors']:
        assert base[a['ruleId']]['bodySha256']==a['bodySha256']
        assert base[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
        bind_old(a['ruleId'])
    for p in qa['recursiveUsedPrerequisiteBindings']:
        assert base[p['ruleId']]['bodySha256']==p['bodySha256'] and base[p['ruleId']]['visibleBody']==p['visibleBody']
for k,ee in prior['evidenceRegistry'].items():
    ss=rd(ee['sourcePath'])['text'];assert sha(ee['sourcePath'])==ee['sourceFileSha256'] and th(ss)==ee['sourceTextSha256']
    assert ss[ee['startChar']:ee['endChar']]==ee['quote'] and th(ee['quote'])==ee['quoteSha256'] and ch(ee)==k
registry.update(prior['evidenceRegistry'])

def A(rid,fields=F):
    x=pool[rid]
    return [dict(ruleId=rid,bodySha256=x['bodySha256'],field=f,quote=x['visibleBody'][f],startChar=0,endChar=len(x['visibleBody'][f]),candidateOverlay=(x['bodySha256']!=base[rid]['bodySha256'])) for f in fields if x['visibleBody'].get(f)]
ids=oldpractice['usedRuleIds']+['CUR:CC08']
practice=copy.deepcopy(oldpractice)
practice.update(status='SUPPORTED',selectedOptionOrdinals=[1,2,3,6],usedRuleIds=ids,necessaryAnchors=sum([A(r) for r in ids],[]),minimumRemainingJudgments=[],standalonePracticeCardGroupStatus='SUPPORTED',closureEligibleUnderAcceptedCorrectionPolicy=True,
                reasoningAndClosestCompetitor='A由102服务API运行SQL支持不同应用计算形态；B现在由CC08实际可见句“Redshift也提供基于KMS的服务端存储加密”给出服务端能力，M20实际可见句给出应用先加密再交数据库。CV12明确客户端是应用侧预加密字段，故两句可共同支持B，不借私有来源补能力、不复活旧COPY/UNLOAD集成。C沿有效当前句由MPP分析+089调度+102提交SQL迁移，未要求pause/resume。F由已采用NB04明确Redshift snapshot独立新cluster，047解释长期历史点，console是普通管理入口；不能当持续自动复制。D由032缓存职责与XB013分析定位排除，E在线全球高请求量不是MPP分析职责。',officialEvidenceIds=oldpractice['officialEvidenceIds']+[E1,E2])
practice['optionTransferReview'][1]=dict(ordinal=2,verdict='SUPPORTED',mechanism='M20的应用在交给数据库前先加密+新增CC08明确Redshift服务端KMS存储加密，分别给出B的两部分。',ruleIds=['CUR:CMP-M20','CUR:CC08'],exactNewServiceCapabilityAnchor=A('CUR:CC08',['answerZH']),clientSideActualVisibleAnchor=A('CUR:CMP-M20',['frontZH','answerZH','keyPointZH']),noGenericServiceSupportAssumption=True)
for r in ids:bind_old(r)
original=copy.deepcopy(next(z for z in prior['questionImpactReview'] if z['qid']==515))
original.update(usedRuleIds=ids,necessaryAnchors=sum([A(r) for r in ids],[]),minimumRemainingJudgments=[],visibleCardGroupStatus='SUPPORTED_capability_explanations_but_original_SOURCE_ISSUE_preserved',sourceIssueConfirmed=True,selectedOptionOrdinals=[],officialEvidenceIds=original['officialEvidenceIds']+[E1,E2],reasoningAndClosestCompetitor='新增CC08闭合B的服务端能力教学，既有M20解释应用先加密，当前卡组可以解释ABCF的合理能力读法。但原题仍Choose three且未限定client-side与secondary replica的语义；至少ABCF四项的合理读法冲突依旧。修订练习可选全项，不把原文偷偷改全选或按新定义升级原题。')
assert original['status']=='SOURCE_ISSUE' and practice['minimalityVerdict']=='PASS'

report=dict(schemaVersion=1,batch='supplemental18',reviewer='independent actual card and targeted visible-card-group reviewer',reviewedAtUtc=now(),status='PASS_one_card_and_corrected_practice_original_source_issue_preserved',inputManifestPath=str(P/'manifest.json'),inputManifestSha256=sha(P/'manifest.json'),inputHashes=manifest,currentReviewIndexPath=str(index_path),currentReviewIndexSha256=index_hash,legacyBodyBindingSourcePath=str(legacy_path),legacyBodyBindingSourceSha256=sha(legacy_path),frozenVisiblePoolCount=362,candidateOverlayCount=1,newCards=0,appliedToCurrent=False,counts=dict(cardPASS=1,cardFAIL=0,originalQuestionStatuses={'SOURCE_ISSUE':1},correctedPracticeStatuses={'SUPPORTED':1},correctedMinimalityPASS=1,correctionClosureEligible=1),results=[result],questionImpactReview=[original],correctedVariantImpactReview=[practice],evidenceRegistry=registry,officialInputRecordValidation=[dict(status='PASS_immutable_filename_file_text_quote_binding',snapshotPath=str(ep),snapshotSha256=sha(ep),textSha256=th(s),quoteStart=e['quoteStart'],quoteEnd=e['quoteEnd'],quoteSha256=th(e['quote']))],usedExistingCardProofBindings=proof_cache,priorTargetedReviewBinding=dict(path=str(prior_path),sha256=prior_hash,unchangedOriginalAndCorrectedQuestionHashesValidated=True,allReusedNecessaryAnchorsAndOfficialSourcesRevalidated=True,unchangedOptionJudgmentsReused=['A','C','D','E','F'],targetedOptionRetested='B'),gapClosure=[dict(findingId='S17-Q515-B-SERVER-TEACHING',status='CLOSED_BY_EXPLICIT_VISIBLE_SERVICE_CAPABILITY',priorReviewPath=str(prior_path),priorReviewSha256=prior_hash,priorGapPreserved=True,ruleId='CUR:CC08',repairBodySha256=ch(new),exactNewVisibleSentence='Redshift也提供基于KMS的服务端存储加密。',combinedCurrentRuleIds=['CUR:CC08','CUR:CMP-M20'],reason='服务端特定能力现在直接写入卡面，客户端应用预加密由M20已有规则迁移；不再依赖未教官方摘录。')],transferChecks=[dict(ruleId='CUR:CC08',conditionChange='只启用TLS但存储未采用适用静态加密',status='PASS',reason='TLS仅保护连接，不能替代落盘加密。'),dict(ruleId='CUR:CC08',conditionChange='已有未加密存储从RDS改为Redshift',status='PASS',reason='当前snapshot复制迁移步骤明确限RDS；可确认Redshift有KMS存储加密，但不能由该卡声称两服务改造步骤相同。')],metadataPrincipalGoalChanges=[dict(ruleId='CUR:CC08',principalGoalChanged=False,serviceScopeExpanded=['RDS','Redshift'],rdsMigrationScopeRetained=True,action='服务范围及Q515的B绑定需刷新；不把RDS snapshot改造映射为Redshift迁移流程。')],cc05UnchangedBinding=dict(ruleId='CUR:CC05',bodySha256=cc05_before,changed=False,noAWSOwnedAWSManagedTypeEquivalenceIntroduced=True),minimumRepairScope=dict(cardRuleIds=[],questionIds=[],newScopeStarted=False,nextStage='current_dependency_readback_or_metadata_final_review_by_parent'),formalBilingualAcceptance=False,privateGradingContractAcceptance=False,learnerMemoryOrAccuracyMeasured=False,finalCardCountVerified=False,currentPointersChangedByReviewer=False,authoringPerformed=False,externalOfficialReadOnlyFetches=0,directCliApiCalls=0,nativeUsage='unknown')
rp=O/'supplemental18.review.json';rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
z=rd(rp)
assert ch(z['results'][0]['visibleBody'])==z['results'][0]['bodySha256']
assert {f:th(z['results'][0]['visibleBody'][f]) for f in F}==z['results'][0]['fieldSha256']
assert z['gapClosure'][0]['exactNewVisibleSentence'] in z['results'][0]['visibleBody']['answerZH']
for qa in z['questionImpactReview']+z['correctedVariantImpactReview']:
    for a in qa['necessaryAnchors']:
        assert pool[a['ruleId']]['bodySha256']==a['bodySha256'] and pool[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
for k,ee in z['evidenceRegistry'].items():
    ss=rd(ee['sourcePath'])['text'];assert sha(ee['sourcePath'])==ee['sourceFileSha256'] and th(ss)==ee['sourceTextSha256'] and ss[ee['startChar']:ee['endChar']]==ee['quote'] and th(ee['quote'])==ee['quoteSha256'] and ch(ee)==k
assert all(sha(p)==h for p,h in manifest.items()) and sha(index_path)==index_hash
rb=dict(status='PASS_targeted_review_readback',reviewPath=str(rp),reviewSha256=sha(rp),inputManifestSha256=sha(P/'manifest.json'),readBackAtUtc=now(),counts=z['counts'],checks=dict(canonicalFourFieldBodyAndPerFieldHashes=True,completeOriginalAndCorrectedEveryOptionBound=True,allExactNecessaryAnchorsAndCurrentProofs=True,immutableOfficialFileTextQuoteHashMatches=True,prior17SourcesAndQuestionHashesStillBound=True,BClosedByActualVisibleCC08PlusM20=True,noPrivateSourceUsedAsHiddenTeaching=True,rdsSnapshotMigrationNotAppliedToRedshift=True,cc05BodyAndKeyTypeConditionsUnchanged=True,originalSourceIssuePreserved=True,allFrozenInputsStillUnchanged=True,noCurrentSourceProductionOrHistoryMutation=True),formalBilingualAcceptance=False,learnerEffectMeasured=False,finalNVerified=False,directCliApiCalls=0,nativeUsage='unknown')
(O/'supplemental18.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(review=str(rp),sha256=sha(rp),counts=z['counts']),ensure_ascii=False))

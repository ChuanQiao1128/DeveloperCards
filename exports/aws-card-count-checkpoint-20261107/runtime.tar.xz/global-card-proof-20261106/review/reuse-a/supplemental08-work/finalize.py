# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib,collections,datetime
V=Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106');P=V/'review/supplemental08/input';W=V/'review/reuse-a/supplemental08-work'
def rd(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ch(j):return hashlib.sha256(json.dumps(j,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def body(c):return {k:c.get(k,'') for k in ['frontZH','answerZH','keyPointZH','watchOutZH']}
mp=P/'manifest.json';manifest=rd(mp)
for p,h in manifest.items():assert sha(p)==h
base={r['ruleId']:r for r in rd(P/'visible-pool.frozen.json')};drafts=rd(P/'cards.json');pool={k:dict(c) for k,c in base.items()};forbidden={'CUR:XB039','GCL-017','GSC-019','GSC-072','GSC-084','GSC-098','GSC-108','GCL-020'};assert len(base)==351 and not(set(base)&forbidden)
for c in drafts:
 rid=c['ruleId']
 if c.get('repairOf'):assert base[rid]['bodySha256']==c['repairOf']
 pool[rid]={'ruleId':rid,'visibleBody':body(c),'bodySha256':ch(body(c)),'prerequisiteRuleIds':c.get('prerequisiteRuleIds',base.get(rid,{}).get('prerequisiteRuleIds',[]))}
for c in pool.values():assert ch(c['visibleBody'])==c['bodySha256']
qs=rd(P/'questions.json');qb={r['qid']:r['question'] for r in qs};assert len(qb)==5
# Names plus exact body contracts bind retained official facts, rather than accepting arbitrary source directories.
ip=V/'inputs/existing176.json';initial={r['ruleId']:r['body'] for r in rd(ip)};ixp=V/'validation/current-card-review-index.json';ixsha=sha(ixp);ix={r['ruleId']:r for r in rd(ixp)['cards']};proofs={};records={};reg={}
def bind(rid):
 if rid in proofs:return proofs[rid]
 x=ix[rid];old=base[rid]
 if x['currentBodySha256']!=old['bodySha256']:
  if rid=='CUR:CB02':
   historical=[{'path':str(V/'review/reuse-a/batch08.review.json'),'sha256':'d2ad703cafefab0e469ece8ee4bea1a5adbf34f12101481cceeac75428c49213','currentPriorBodySha256':old['bodySha256']}]
  else:historical=rd(V/'review/reuse-a/supplemental04.review.json')['usedExistingQuestionAndPrerequisiteCardProofBindings'][rid]
  assert all(r['currentPriorBodySha256']==old['bodySha256'] for r in historical)
  x={'status':'PASS','currentBodySha256':old['bodySha256'],'proofs':historical}
 assert x['status']=='PASS' and x['currentBodySha256']==old['bodySha256'];out=[];rs=[]
 for p in x['proofs']:
  assert sha(p['path'])==p['sha256'];j=rd(p['path']);rr=j.get('results',j.get('cards',[]));r=next((r for r in rr if r.get('ruleId')==rid and r.get('bodySha256')==old['bodySha256']),None);contract='canonical four-field exact body'
  if r is None:
   assert rid in initial and body(initial[rid])==old['visibleBody'];lh=ch({k:v for k,v in old['visibleBody'].items() if v});assert lh==initial[rid]['bodySha256'];r=next(r for r in rr if r.get('ruleId')==rid and r.get('bodySha256')==lh);contract='exact four fields reconstructed from existing176; legacy omitted-empty-field receipt hash'
  assert r.get('status',r.get('verdict'))=='PASS' or (r.get('eligibleFACT') and r.get('eligibleTEACHING'))
  for pr in r.get('proofs',[]):assert sha(pr['path'])==pr['sha256']
  out.append({'ruleId':rid,'path':p['path'],'sha256':p['sha256'],'receiptBodySha256':r['bodySha256'],'currentPriorBodySha256':old['bodySha256'],'bodyBindingContract':contract,'parentGateReceipts':r.get('proofs',[])});rs.append((j,r))
 proofs[rid]=out;records[rid]=rs;return out
for rid in ['GSC-123','CUR:NS02']:bind(rid)
def cite(p,needle,n,claim):
 p=Path(p);j=rd(p);s=j['text'];st=s.index(needle);q=s[st:st+n];e={'claim':claim,'url':j['url'],'sourcePath':str(p),'sourceFileSha256':sha(p),'sourceTextSha256':hashlib.sha256(s.encode()).hexdigest(),'quote':q,'startChar':st,'endChar':st+len(q),'quoteSha256':hashlib.sha256(q.encode()).hexdigest()};hp=p.with_suffix('.html')
 if hp.exists():
  e.update(rawHtmlPath=str(hp),rawHtmlSha256=sha(hp))
  if j.get('rawSha256'):assert j['rawSha256']==sha(hp)
 eid=ch(e);reg[eid]=e;return eid
oldrefs={}
for rid,rr in records.items():
 refs=[]
 for j,r in rr:
  es=r.get('evidence',[])
  er=j.get('evidenceRegistry',j.get('sourceEvidenceRegistry',{}));es+= [er[e] for e in r.get('evidenceIds',r.get('factEvidenceIds',[]))]
  for e in es:
   p=e['sourcePath'];s=rd(p)['text'];assert sha(p)==e.get('sourceFileSha256',e.get('fileSha256'));assert hashlib.sha256(s.encode()).hexdigest()==e.get('sourceTextSha256',e.get('textSha256'));q=e['quote'];assert q in s
   if 'quoteStart' in e:assert s[e['quoteStart']:e['quoteEnd']]==q
   refs.append(cite(p,q,len(q),'Retained valid '+rid+' FACT scope from named receipt.'))
 oldrefs[rid]=refs
es=rd(P/'official-evidence.json');checks=[];seen=set()
for e in es:
 p=e['snapshotPath'];s=rd(p)['text'];assert sha(p)==e['snapshotSha256'] and hashlib.sha256(s.encode()).hexdigest()==e['textSha256'];assert s[e['quoteStart']:e['quoteEnd']]==e['quote'];k=(p,e['quoteStart'],e['quoteEnd'],e['quote']);checks.append({'snapshotPath':p,'snapshotSha256':sha(p),'textSha256':e['textSha256'],'startChar':e['quoteStart'],'endChar':e['quoteEnd'],'quoteSha256':hashlib.sha256(e['quote'].encode()).hexdigest(),'duplicate':k in seen,'mechanicalValidationOnlyForUnrelated06Sources':True});seen.add(k)
def E(urlpart,needle,n,claim):return cite(next(e['snapshotPath'] for e in es if urlpart in e['url']),needle,n,claim)
refs={rid:list(v) for rid,v in oldrefs.items()}
refs['GSC-123'] += [E('load-balancer-cloudwatch','ActiveConnectionCount The total number',245,'ActiveConnectionCount counts concurrent TCP connections, not response duration.'),E('load-balancer-cloudwatch','TargetResponseTime The time elapsed',300,'TargetResponseTime measures target response-header timing; front gives its diagnostic meaning.'),E('load-balancer-cloudwatch','RequestCount The number of requests processed',335,'RequestCount is processed-request count; it is diagnostic context, not an LOR control threshold.')]
refs['CUR:NS02'] += [E('secure-vpc-connections','When you add a Network Load Balancer',1040,'GA directly targets VPC/private-subnet LB endpoints without public LB IPs; VPC IGW attachment still required.')]
refs['VC-007']=[E('USER_WorkingWithReservedDBInstances','Using reserved DB instances,',370,'RDS RI offers one/three-year commitment tied to eligible DB usage.'),E('USER_WorkingWithReservedDBInstances','Your No Upfront reserved DB instance bills',550,'RDS agreed charges persist regardless of actual hours; payment options and eligibility vary.'),E('what-is-savings-plans','Savings Plans provide savings',360,'Applicable compute plans exchange hourly commitment for one/three-year prices.'),E('PurchaseScheduledInstances','You can no longer purchase Scheduled Instances.',len('You can no longer purchase Scheduled Instances.'),'Scheduled Instances cannot now be newly purchased.'),cite(W/'sources/ec2-ri-overview.json','Term commitment',410,'EC2 RI three-year commitments give a bigger discount than one-year.'),cite(W/'sources/ec2-ri-overview.json','Generally speaking,',210,'Higher upfront RI payment generally gives more savings.'),cite(W/'sources/rds-ri-pricing.json','All Upfront RIs –',400,'RDS All Upfront has highest payment-option discount and explicitly includes three-year term.'),cite(W/'sources/sp-faq.json','What payment options are available',780,'Compute/EC2 Instance SP have payment options; Database SP is an explicit exception, so draft scope must remain narrowed.'),cite(W/'sources/sp-longer-term.json',"If you're considering staying in AWS for a longer period",210,'Official guidance confirms deeper savings with three-year compute commitments.')]
manual=E('USER_CreateSnapshot.html',"Unlike automated backups, manual snapshots aren't subject",152,'RDS manual snapshots do not follow automated backup retention and do not expire.')
cluster=cite(W/'sources/rds-cluster-snapshot.json','Creating a Multi-AZ DB cluster snapshot',1900,'Manual snapshot creation and separate deletion are supported for the actual Multi-AZ DB cluster topology.')
ranges=E('BackupRetention.html','You can set the backup retention period of a DB instance',490,'Retention reference distinguishes DB instance0–35 and Multi-AZ DB cluster1–35.')
disable=cite(W/'sources/rds-disable.json','Disabling automatic backups for a DB instance or Multi-AZ DB cluster',390,'Conflicting official deletion guide explicitly states disabling instance/cluster backups deletes all existing automated backups.')
disableexample=cite(W/'sources/rds-disable.json','The following example immediately disables automatic backups',530,'Same official page even gives Multi-AZ cluster retention0 CLI example; cannot hide the contradiction.')
api=cite(W/'sources/rds-modify-cluster-api.json','BackupRetentionPeriod The number',300,'API reference sets minimum1 for Aurora and Multi-AZ DB clusters, conflicting with retention0 deletion guide.')
refs['VC-010']=[manual,cluster,ranges,disable,disableexample,api]
# Complete questions use visible wording only, with recursive prerequisite bindings and named old receipts.
def anchor(rid,fields):
 c=pool[rid];return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'startChar':0,'endChar':len(c['visibleBody'][f]),'candidateOverlay':rid in {c['ruleId'] for c in drafts}} for f in fields if c['visibleBody'].get(f)]
def Q(qid,status,options,items,reason,conditions=None,missing=None):
 aa=[]
 for item in items:
  rid,fs=item if isinstance(item,tuple) else (item,('answerZH','keyPointZH','watchOutZH'));aa+=anchor(rid,fs)
 used=sorted({a['ruleId'] for a in aa});pre=[];todo=list(used);done=set()
 while todo:
  k=todo.pop()
  if k in done:continue
  done.add(k)
  for z in pool[k].get('prerequisiteRuleIds',[]):
   assert z in pool and z not in forbidden;pre.append({'from':k,'ruleId':z,'visibleBody':pool[z]['visibleBody'],'bodySha256':pool[z]['bodySha256']});todo.append(z)
 for k in done:
  if k in base and k not in {c['ruleId'] for c in drafts}:bind(k)
 return {'qid':qid,'status':status,'selectedOptionOrdinals':options if status=='SUPPORTED' else [],'candidateOptionOrdinals':options,'questionSha256':ch(qb[qid]),'originalStemUtf8Sha256':hashlib.sha256(qb[qid]['stem'].encode()).hexdigest(),'originalOptionsCanonicalSha256':ch(qb[qid]['options']),'completeStemAndEveryOptionRead':True,'usedRuleIds':used,'necessaryAnchors':aa,'recursiveUsedPrerequisiteBindings':pre,'reasoningAndClosestCompetitor':reason,'conditions':conditions or [],'minimumRemainingJudgments':missing or [],'forbiddenDeletedOrQuarantinedCardsUsed':False,'privateTargetsSourceFindingsOrPrintedAnswersUsedAsTeaching':False}
qr=[]
qr.append(Q(700,'SUPPORTED',[1,3],['CUR:NS02','CUR:XB041','CUR:CB03'],'NLB承载TCP/UDP，GA面向全球按性能和健康选各Region入口；新NS02明确公网GA可到internal LB，所以A+C实际成立。ALB/CloudFront不支持本题原生UDP，geolocation按国家而非实时网络路径性能。',conditions=['落实GA支持的LB部署、VPC所需IGW attachment和目标健康检查；无需给LB公网IP或给其子网公网路由。这是配置已有路径，不另出新卡。']))
qr.append(Q(714,'SUPPORTED',[4],[('GSC-123',('frontZH','answerZH','keyPointZH','watchOutZH'))],'D把请求量/后端耗时的已给诊断情境与least outstanding requests分配相连。轮流不能主动避开积压目标；B的ActiveConnectionCount是连接数，不能替代响应耗时。原based on按诊断依据理解，实际算法按进行中请求数而非两条CloudWatch阈值直接路由；新卡没有再要求额外默写两个指标。',conditions=['若将原选项based on硬解释成算法直接读取两项CloudWatch指标作阈值，则原D也不是实际机制；保留这项措辞限制，不把它教成配置方式。']))
qr.append(Q(940,'SUPPORTED',[4],['VC-007','GSC-054','CUR:CB02'],'长期稳定用量用服务匹配的承诺折扣；D三年全预付在给定一年/三年支付选项中让出更多期限/付款灵活性，费用通常更低。A让RDS继续按需，B/C只一年/较少预付。EC2 Instance SP名字不必强加新卡：原选项已给同类承诺期限和支付选项，VC007机制可迁移比较；独立官方FAQ也确认其支付选项相同。',conditions=['按原题长期运行语境规划并确认三年用量/预付可承担及引擎/Region属性匹配；不声称每个其它服务的所有SavingsPlan都提供三年全预付，也不将标价百分比当实际账单保证。']))
qr.append(Q(989,'CONDITIONAL',[3],[('VC-010',('frontZH','answerZH','keyPointZH')),'GSC-047','CUR:NS03'],'主生命周期机制已能解释C：自动备份设30天，手工旧快照另删，保住最近30天两类备份。A另加AWSBackup不比原生retention必要；B/D关闭自动备份既非清手工快照途径，官方删除页还说明会失去已有自动恢复点。原题是Multi-AZ DB cluster：不得引用单实例0行为断言cluster支持；也不得把相冲突的“cluster绝不能禁用”作为必要知识。',conditions=['VC010当前watchOut仍有受冲突官方页影响的绝对cluster断言，卡片FACT未通过；须先局部删掉该非必要断言并复核VC010/989，才能沿此正文正式升级充分。'],missing=['当前待修仅VC010的非必要绝对拓扑边界，不是缺另一张知识卡。']))
qr.append(Q(1013,'SUPPORTED',[2],['VC-007','GSC-146','GSC-147'],'当前AWS下A的Scheduled Instances不能新购，C/D的Spot与不能中断硬条件冲突，B是原列选项中可行且使用承诺折扣的组合。VC007说明周日只运行12小时不会只付12小时承诺费；这不让B成为选项外全市场最便宜方案，仍按高利用稳定工作量比较费用。',conditions=['购买现行受支持RI并核对实际总账单；不把Convertible理解成按周日小时收费或无任何故障，也不悄悄将A已停售产品改名为现代方案。']))
assert {r['qid'] for r in qr}==set(qb)
old06p=V/'review/supplemental06/input/cards.json';old06={c['ruleId']:c for c in rd(old06p)};priorlineage=[]
for c in drafts:
 if c['ruleId'] in old06:
  o=old06[c['ruleId']]
  expected=c.get('failedVersionBodySha256',c.get('revisionOfProposedBodySha256'));assert expected==ch(body(o))
  priorlineage.append({'ruleId':c['ruleId'],'priorDraftPath':str(old06p),'priorDraftFileSha256':sha(old06p),'priorBodySha256':ch(body(o)),'priorFullDraftSha256':ch(o),'currentBodySha256':ch(body(c)),'priorFailureNotOverwritten':True,'priorIndependent06ReviewStillBeingFinalizedAtDispatch':True})
# Whole-pool substitution audit: nearest rules have distinct learning mechanisms, not merely different IDs.
sub=[]
for rid,near,reason,qids in [('VC-007',['GSC-054','CUR:CB02','GSC-147','GSC-155'],'服务覆盖、容量保证、utilization分母不能推出每小时承诺仍收费以及期限/预付如何改变折扣；须保留共同承诺机制。无需为EC2 Instance SP或其它服务再建同义卡。',[940,1013]),('VC-010',['GSC-047','CUR:NB04','CUR:NS03','CUR:NB05'],'PITR窗口、历史状态与当前副本、跨服务备份调度、误删回收均没有教自动retention不管理手工快照。相同scope口号不能推出AWS实际手工生命周期。必要候选仍是一项自动/手工管理范围判断，不应为cluster禁用争议拆新卡。',[989])]:
 sub.append({'ruleId':rid,'entireFrozenPoolCountChecked':351,'nearestRuleIds':near,'nearestVisibleCards':[{'ruleId':k,'bodySha256':base[k]['bodySha256'],'visibleBody':base[k]['visibleBody']} for k in near],'status':'INDEPENDENT_MINIMUM_RULE_CANDIDATE','reason':reason,'questionIds':qids,'finalCoreAdmissionNotAutomatic':True,'singleQuestionLowFrequency':len(qids)==1,'lowFrequencyBoundary':'全库约300张仍是目标，候选必要性不确认最终N；可通过替换/精炼与卡组复用控制负担，不增加主题同义卡。'})
guide=V/'review/reuse-a/supplemental04-work/sources/saa-c03-guide.json';g=rd(guide);assert sha(g['sourcePdfPath'])==g['sourcePdfSha256'];gs=g['text']
g42=cite(guide,'AWS purchasing options (for example, Spot Instances, Reserved Instances, Savings Plans)',len('AWS purchasing options (for example, Spot Instances, Reserved Instances, Savings Plans)'),'Task4.2 explicitly includes purchasing options and commitment pricing.')
g43=cite(guide,'Designing appropriate backup and retention policies',100,'Task4.3 explicitly includes database backup and retention policies.')
domain=[{'ruleId':'VC-007','status':'PASS','primaryDomain':'4','primaryTask':'4.2','crossDomainTasks':['4.3'],'evidenceIds':[g42,g43],'reason':'跨EC2/RDS共享承诺规则以compute购买选项4.2主归、数据库成本4.3交叉引用，不复制正文。'}, {'ruleId':'VC-010','status':'PASS','primaryDomain':'4','primaryTask':'4.3','evidenceIds':[g43],'reason':'原题数据库备份保留和清理的成本范围，4.3明确列backup/retention，主归合理。'}]
notes={
'GSC-123':('PASS','请求数/耗时含义放在给定情境，正面仅问如何避开未完成工作多的目标；算法名与原因是一项回忆。相比06同问指标名+算法的失败版本，已收窄自评，不强迫背CloudWatch阈值或公式。'),
'VC-007':('PASS','承诺费换价格折扣是同一个因果判断：只在开机时付费的误解与三年更多预付的取舍由同一费用灵活性解释。匹配服务/供给前提保留，未扩大到DatabaseSP。Scheduled停售只是当下题族边界，不列新增必答，也不让它吞掉主任务。'),
'CUR:NS02':('PASS','单Region与多Region固定入口同一选型；补internal LB仅解释公网统一入口不要求后端公开，机制和现有前提相连，不要求背IGW/ENI安全配置清单。'),
'VC-010':('FAIL','自动窗口是否清手工快照是有用的单一判断，答及原因可理解。额外“Multi-AZ DB cluster不能禁用”不是本次所问必答且存在直接官方冲突；该绝对句未闭合前FACT不可PASS，应删除它而非扩一轮拓扑教学。')}
find={'id':'S08-FACT-VC010-001','gate':'FACT','severity':'P1','status':'FAIL','field':'watchOutZH','quote':'Multi-AZ DB cluster则不能禁用自动备份。','reason':'BackupRetention页及ModifyDBCluster API下限1，与官方Deleting页明确cluster禁用及retention0示例冲突。当前卡把一个争议/非必要范围写成绝对事实，不能凭其中一页覆盖另一页。','evidenceIds':[ranges,api,disable,disableexample],'minimalRequiredAction':'删掉该非必要的绝对cluster断言；保留自动/手工生命周期独立及不能用关闭自动备份保住全部现有恢复点的必要机制。不得把制作争议写进学习卡。','newCardRequired':False,'affectedQuestions':[989]}
rows=[]
for c in drafts:
 rid=c['ruleId'];status,why=notes[rid];gates={g:('FAIL' if rid=='VC-010' and g=='FACT' else 'PASS') for g in ['FACT','U1','R1','T1','S1','P1']};gates['B1']='N/A_chinese_stage'
 rows.append({'ruleId':rid,'status':status,'gates':gates,'bodySha256':ch(body(c)),'fullDraftSha256':ch(c),'visibleBody':body(c),'priorBodySha256':c.get('repairOf'),'namedValidPriorFACTProofs':proofs.get(rid,[]),'evidenceIds':refs[rid],'teachingAndRecallTaskReason':why,'assessmentCheck':'只按正面所问结论及关键原因自评；已给指标、供给、利用率前提及未问边界不新增mustAnswer。私有评分契约未提供。','prerequisiteRuleIds':pool[rid].get('prerequisiteRuleIds',[]),'findings':[find] if rid=='VC-010' else [],'officialConflictContainedToNonessentialBoundary':rid=='VC-010','doesNotAutomaticallyPromoteQuestionStatus':True})
trans=[{'ruleId':'GSC-123','changedCondition':'请求耗时与目标能力都很接近','status':'PASS','reason':'卡面以“更能反映这类忙闲差异”限定比较，不硬说轮流总错误；LOR统计仍不是CPU。'}, {'ruleId':'VC-007','changedCondition':'未来用量不稳定或无法承担预付','status':'PASS','reason':'不再满足三年稳定/可预付条件，不能仅因折扣深购买；服务供给与闲置风险须比较。'}, {'ruleId':'CUR:NS02','changedCondition':'区域端点改为internalNLB','status':'PASS','reason':'新keyPoint明确GA公网入口可接内部支持LB，不必公开后端；固定入口及协议机制仍成立。'}, {'ruleId':'VC-010','changedCondition':'自动retention从30天减为7天','status':'PASS_CORE_RULE_ONLY','reason':'手工快照生命周期仍不随它清理；该迁移不依赖有争议的cluster禁用断言，不抵扣当前FACT失败。'}]
for p,h in manifest.items():assert sha(p)==h
for e in reg.values():
 s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and hashlib.sha256(s.encode()).hexdigest()==e['sourceTextSha256'];assert s[e['startChar']:e['endChar']]==e['quote'];assert hashlib.sha256(e['quote'].encode()).hexdigest()==e['quoteSha256']
for q in qr:
 for a in q['necessaryAnchors']:assert pool[a['ruleId']]['bodySha256']==a['bodySha256'] and pool[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
assert sha(ixp)==ixsha
out={'schemaVersion':1,'batch':'supplemental08','reviewer':'actual_reuse_review independent reviewer','status':'PARTIAL_PASS_VC010_FACT_FAIL','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(mp),'inputManifestSha256':sha(mp),'inputHashes':manifest,'frozenVisiblePoolCount':351,'candidateOverlayCount':4,'revisedExistingCards':2,'proposedNewCards':2,'appliedToCurrent':False,'counts':{'cardPASS':3,'cardFAIL':1,'questionStatuses':dict(collections.Counter(r['status'] for r in qr))},'results':rows,'questionImpactReview':qr,'newCardSubstitutionTests':sub,'newCardDomainMetadataReview':domain,'transferChecks':trans,'priorFailureLineage':priorlineage,'priorReviewIndexPath':str(ixp),'priorReviewIndexSha256':ixsha,'legacyBodyBindingSourcePath':str(ip),'legacyBodyBindingSourceSha256':sha(ip),'usedExistingCardProofBindings':proofs,'evidenceRegistry':reg,'officialInputRecordValidation':{'inputRecords':len(es),'uniqueSourceQuoteRecords':len(seen),'all20RecordOffsetFileTextHashesVerified':True,'records':checks,'semanticScope':'Only sources relevant to these4cards/5questions examined for substantive claims; unrelated06source snapshots mechanically validated only.'},'supplemental04ApprovedBodiesUsed':[],'minimumRepairScope':{'ruleIds':['VC-010'],'questionIds':[989],'doNotReReviewOtherThreePassedCandidates':True,'doNotReReviewOther06Cards':True},'sourceMetadataAdvice':'Preserve named prior receipt/source URLs forGSC123 LOR andNS02 staticIPs/TCPUDP/global network; current draft sourceUrls alone list additions. VC007 narrowed scope is essential because current DatabaseSP has different terms/payment options. VC010 failed absolute topology statement must be removed, while original conflicting evidence stays in private review ledger.','allSnapshotOffsetAndHashChecksPassed':True,'allVisibleBodyAndQuestionAnchorChecksPassed':True,'allFrozenInputsUnchanged':True,'formalBilingualAcceptance':False,'privateGradingContractAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'priorFailuresPreserved':True,'originalQuestionStatusesAutomaticallyPromoted':False,'directCliApiCalls':0,'nativeUsage':'unknown','externalOfficialReadOnlyFetches':'Public official AWS docs only to confirm commitment/payment depth and to retain the actualRDScluster/manual/disable evidence conflict; no service mutation or modelCLI/API.'}
p=V/'review/reuse-a/supplemental08.review.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');z=rd(p)
for r in z['results']:assert ch(r['visibleBody'])==r['bodySha256'] and ch(next(c for c in drafts if c['ruleId']==r['ruleId']))==r['fullDraftSha256']
assert len(z['questionImpactReview'])==5 and {r['qid'] for r in z['questionImpactReview']}==set(qb)
for pp,hh in manifest.items():assert sha(pp)==hh
rb={'status':'PASS_SERIALIZED_PARTIAL_REVIEW','reviewPath':str(p),'reviewSha256':sha(p),'inputManifestPath':str(mp),'inputManifestSha256':sha(mp),'readBackAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':z['counts'],'actualContentVerdict':'3PASS_1FACT_FAIL','checks':{'fourExactCanonicalBodiesAndDrafts':True,'fiveCompleteOriginalQuestionHashesAndOptions':True,'literalVisibleAnchorsAndRecursivePrerequisites':True,'namedValidOldReceiptsAndBodyContracts':True,'allOfficialQuoteOffsetsFileTextHashes':True,'conflictingClusterDocsBothRetained':True,'failed06DraftVersionsPreserved':True,'noOther06CardsReReviewed':True,'frozenInputsUnchanged':True,'noCurrentApprovedInventoryCatalogueOrSourceEdits':True},'minimumRepairScope':z['minimumRepairScope'],'formalBilingualAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'directCliApiCalls':0,'nativeUsage':'unknown'};rp=V/'review/reuse-a/supplemental08.readback.json';rp.write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n');print('REVIEW',sha(p),z['counts']);print('READBACK',sha(rp));print('sources',len(reg))

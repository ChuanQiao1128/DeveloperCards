# -*- coding: utf-8 -*-
import json,pathlib,hashlib,collections
from datetime import datetime,timezone
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106')
OUT=V/'review/reuse-a'
def rd(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(x): return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def body(c): return {f:c.get(f,'') for f in ['frontZH','answerZH','keyPointZH','watchOutZH']}
mp=V/'review/supplemental01/input/manifest.json';manifest=rd(mp)
for p,h in manifest.items(): assert sha(p)==h,(p,sha(p),h)
cp=V/'deliverables/visible-knowledge-current.json';base={c['ruleId']:c for c in rd(cp)};basehash=sha(cp)
drafts=rd(V/'review/supplemental01/input/cards.json');overlay={k:dict(c) for k,c in base.items()}
for c in drafts:
 if c.get('repairOf'): assert c['repairOf']==base[c['ruleId']]['bodySha256']
 overlay[c['ruleId']]={'ruleId':c['ruleId'],'visibleBody':body(c),'bodySha256':ch(body(c)),'prerequisiteRuleIds':c.get('prerequisiteRuleIds',base.get(c['ruleId'],{}).get('prerequisiteRuleIds',[]))}
for c in base.values(): assert ch(c['visibleBody'])==c['bodySha256'],c['ruleId']
reg={}
def cite(p,needle,length,claim):
 p=pathlib.Path(p);d=rd(p);s=d['text'];st=s.index(needle);q=s[st:st+length]
 e={'claim':claim,'url':d['url'],'sourcePath':str(p),'sourceFileSha256':sha(p),'sourceTextSha256':hashlib.sha256(s.encode()).hexdigest(),'quote':q,'startChar':st,'endChar':st+len(q),'quoteSha256':hashlib.sha256(q.encode()).hexdigest()};eid=ch(e);reg[eid]=e;return eid
es=rd(V/'review/supplemental01/input/official-evidence.json')
for e in es:
 assert sha(e['snapshotPath'])==e['snapshotSha256'];s=rd(e['snapshotPath'])['text'];assert hashlib.sha256(s.encode()).hexdigest()==e['textSha256'];assert s[e['quoteStart']:e['quoteEnd']]==e['quote']
def E(urlpart,needle,length,claim):
 e=next(x for x in es if urlpart in x['url']);return cite(e['snapshotPath'],needle,length,claim)
def A(rid,field,needle=None,role='decisive visible premise'):
 c=overlay[rid];s=c['visibleBody'][field];q=needle or s;st=s.index(q);return {'ruleId':rid,'bodySha256':ch(c['visibleBody']),'field':field,'quote':q,'startChar':st,'endChar':st+len(q),'role':role,'fromCandidateOverlay':rid in {x['ruleId'] for x in drafts}}
# Full current bodies and official snapshots, never private objectives, form the knowledge basis.
refs={
 'VC-001':[E('with-sqs.html','With Amazon SQS event source mappings, Lambda polls the queue',430,'Lambda服务轮询SQS、批量调用、成功后删除，受管连接替代自建轮询主机。'),E('with-sqs.html','By default, if your function encounters an error',410,'默认整批失败重现以及须安全处理重复消息。')],
 'VC-002':[E('/batch/latest/userguide/fargate','Fargate is a technology',390,'Batch可用Fargate运行容器、免配置/伸缩EC2集群。'),E('/batch/latest/userguide/fargate','When you run your jobs with Fargate resources',440,'程序封装成容器，按CPU/内存要求运行，每作业有独立运行边界。'),E('what-is-batch','AWS Batch automatically provisions compute resources',350,'Batch按工作量规模分配运行资源。'),E('what-is-batch','AWS Batch is a fully managed batch computing service that plans, schedules, and runs',400,'Batch调度并执行容器化批作业，支持Fargate计算。'),E('/batch/latest/userguide/fargate','Fargate is only available',300,'Fargate支持范围有限，须匹配运行方式而非假定任何Batch作业均可用。')],
 'CUR:CB16':[E('vpc-peering-basics','To enable the flow of traffic',280,'私网通信两边分别添加指向对端的路由。'),E('vpc-peering-basics','You cannot create a VPC peering connection',410,'任意IPv4/IPv6 CIDR重叠不能建peering，不能只择不重叠范围。')],
 'GSC-015':[E('ebs/latest/userguide/general-purpose','General Purpose SSD (gp3) volumes are the latest generation',660,'gp3为EBS最低成本SSD，容量与性能可独立配置，不需仅为IOPS额外买容量。'),E('ebs/latest/userguide/general-purpose','gp3 volumes deliver a consistent baseline IOPS performance',390,'EC2 EBS gp3支持配置15000IOPS；容量/IOPS比例限制仍适用，不套用RDS条带化阈值。')]
}
reuse=rd(OUT/'reuse-results.json');oldsrc=reuse['sourceEvidenceRegistry']['7199346f8dbeea3d21cf16fc8b918c6e3874dbebc68e94dc783e3043eee6787b']
assert sha(oldsrc['sourcePath'])==oldsrc['fileSha256']
refs['CUR:CB16'].append(cite(oldsrc['sourcePath'],'AWS uses the existing infrastructure',300,'peering复用VPC设施、无独立硬件单点或带宽瓶颈。'))
ixp=V/'validation/current-card-review-index.json';ix={c['ruleId']:c for c in rd(ixp)['cards']}
for rid in ['GSC-015','CUR:CB16']:
 assert ix[rid]['currentBodySha256']==base[rid]['bodySha256'] and ix[rid]['status']=='PASS'
 for proof in ix[rid]['proofs']: assert sha(proof['path'])==proof['sha256']
rows=[]
teach={
'VC-001':'一个受管队列消费判断：谁取消息、谁确认成功。取消息与成功确认是同一处理生命周期，不是新增两套配置任务；先修GSC-079已教持久性、成功后删、失败重试与幂等。卡面解释队列保存待办、函数处理业务，事件源映射的职责由答案直接说明。',
'VC-002':'一个带运行前提的托管批任务选型。Batch安排作业、容器封装不同程序、Fargate承担服务器管理，三者是解释同一组合为何符合场景的因果链；不要求背队列、IAM和网络完整部署。',
'CUR:CB16':'保留原直接互联与双向路由判断，提醒仅限定已有地址不重叠前提，不增加另一个自评动作。新增重叠边界能解释为何不能通过只用不重叠地址绕过限制。',
'GSC-015':'保留容量与性能独立一个判断；15000IOPS是EC2原题性能条件的具体可行性例子，不要求记新上限表，不将EC2的规则套到RDS。仍明说容量与实例性能限制。'}
for c in drafts:
 rid=c['ruleId'];b=body(c);pre=overlay[rid]['prerequisiteRuleIds']
 for p in pre: assert p in overlay
 row={'ruleId':rid,'status':'PASS','gates':{'FACT':'PASS','U1':'PASS','R1':'PASS','T1':'PASS','S1':'PASS_visible_question_alignment','P1':'PASS','B1':'N/A_chinese_stage'},'visibleBody':b,'bodySha256':ch(b),'bodyHashContract':'four named ZH fields including empty watchOutZH; canonical sorted JSON UTF-8','fullDraftSha256':ch(c),'evidenceIds':refs[rid],'FACTReason':'All changed technical claims checked against literal official snapshots; whole source text, exact character offsets and hashes bound below.','teachingReason':teach[rid],'prerequisiteRuleIds':pre,'prerequisiteBodyBindings':{p:ch(overlay[p]['visibleBody']) for p in pre},'assessmentCheck':'只评价正面提出的判断与关键原因；给定前提和提醒不另列必答。私有mustAnswer未提供，本凭证不验收正式评分或双语契约。','findings':[],'originalQuestionStatusAutomaticallyPromoted':False}
 if c.get('repairOf'):
  row['priorBodySha256']=c['repairOf'];row['priorProofs']=ix[rid]['proofs'];row['reusedUnchangedFACTScope']='Only unchanged statements of the exact bound current body; new statements use fresh literal evidenceIds. CB16 entire causal explanation additionally independently rebound above.'
 if rid=='GSC-015': row['evidenceScopeNote']='RDS CHAP_Storage snapshots were verified as packaged inputs, but do not prove the EC2 EBS15000IOPS example. This claim uses only the EBS General Purpose source. The prior current-body proof remains for unchanged instance-limit caveat.'
 rows.append(row)
# Actual current-pool substitution test for the two additions.
new_need=[
 {'ruleId':'VC-001','disposition':'independently_needed_shared_mechanism','existingNearestRuleIds':['GSC-079','GSC-029','CUR:CA17'],'visibleComparisonAnchors':[A('GSC-079','answerZH'),A('GSC-029','answerZH'),A('CUR:CA17','keyPointZH')],'reason':'持久队列卡教处理成功后确认，S3卡教投递目的地，HTTP函数卡教免常驻服务器；三者都没教Lambda服务对SQS轮询/调用/整批确认。该新增不是这些现有规则可凭字面推出的服务集成。','actualNecessaryUseQuestionIds':[18,94,228,316,1005],'wholeQuestionPassNotRequired':True},
 {'ruleId':'VC-002','disposition':'retain_low_frequency_independent_necessary_mechanism','existingNearestRuleIds':['CUR:XB019','GSC-088','GSC-089','GSC-133'],'visibleComparisonAnchors':[A('CUR:XB019','answerZH'),A('GSC-088','keyPointZH'),A('GSC-089','answerZH'),A('GSC-133','watchOutZH')],'reason':'Fargate主机责任、Step Functions步骤状态、时钟触发和Lambda时限都不能推出Batch可按资源排队调度独立容器作业。Q369和Q1014有共同的批作业判断，属只有两题但无法从既有卡推导的必要机制；不为凑复用数添加题号。','actualNecessaryUseQuestionIds':[369,1014],'wholeQuestionPassNotRequired':True}]
domains=[{'ruleId':'VC-001','proposedPrimaryDomain':'2','reviewVerdict':'PASS','examTask':'2.1 Design scalable and loosely coupled architectures','rationale':'核心判断是用持久队列与受管消费者解耦并可靠推进工作；主归按这一判断，不因Lambda属于计算或为平衡计数转到3/4。'},{'ruleId':'VC-002','proposedPrimaryDomain':'3','reviewVerdict':'PASS','examTask':'3.3 Determine high-performing compute solutions','rationale':'核心判断是长时异构批作业的计算运行方式与资源调度；少运维为选型约束。通用计算运行选择主归3，可靠性或成本题可跨域引用，不重新复制正文。'}]
qs=rd(V/'review/supplemental01/input/questions.json');qb={q['qid']:q['question'] for q in qs}
proof=[]
def Q(qid,status,selected,anchors,reason,conditions=None,missing=None):
 proof.append({'qid':qid,'status':status,'selectedOptionOrdinals':selected if status=='SUPPORTED' else [],'candidateOptionOrdinals':selected,'questionSha256':ch(qb[qid]),'originalStemUtf8Sha256':hashlib.sha256(qb[qid]['stem'].encode()).hexdigest(),'originalOptionsCanonicalSha256':ch(qb[qid]['options']),'fullStemAndAllOptionsRead':True,'necessaryAnchors':anchors,'usedRuleIds':sorted({a['ruleId'] for a in anchors}),'reasoningAndClosestCompetitor':reason,'conditions':conditions or [],'remainingMissingJudgments':missing or [],'proofScope':'Local nine-question retest against actual current355 plus unapplied supplemental01 overlay. Global question ledger remains unchanged.'})
Q(18,'SUPPORTED',[1,2],[A('GSC-029','answerZH'),A('GSC-079','answerZH'),A('VC-001','answerZH'),A('VC-001','keyPointZH')],'S3对象创建事件可投SQS，持久队列保存任务，Lambda受管取批并成功后删，A+B能自动推进压缩且不以本地进程内文件保存工作状态。C/D的内存或实例文本状态不满足持久无状态；E只邮件给人不执行自动压缩。源桶与目标桶分开保留，未把同桶递归风险改写成原题条件。')
Q(94,'SUPPORTED',[3],[A('GSC-029','answerZH'),A('VC-001','answerZH'),A('VC-001','keyPointZH'),A('CUR:CA17','keyPointZH'),A('CUR:XB013','keyPointZH'),A('GSC-038','answerZH')],'小文件一次简单转换适用短时按需处理；C的S3事件→SQS→Lambda已经实际教会，JSON结果可用DynamoDB文档访问。B保留自管EC2取队列，A引入EMR与关系数据库，D加Kinesis与Aurora中间链；这些额外长期资源/链路不比当前受管队列和按需函数减少本场景运维。无需把这些弱干扰项的全部部署知识另造卡。')
Q(228,'CONDITIONAL',[3],[A('GSC-079','answerZH'),A('VC-001','answerZH'),A('GSC-134','answerZH'),A('GSC-080','keyPointZH')],'C用持久队列保留突发写入，并由Lambda受管拉取处理；但仅接上Lambda并不自动最小化数据库连接。当前GSC-134已经教限制同时执行名额，可把写并发约束在数据库承载量内，因此这不是缺一张新卡。A不处理持久积压，B不把普通Multi-AZ变成并行写，D广播不是持久工作队列。',['按已教GSC-134设置适合数据库承载量的消费者并发上限；不能默认未限流的Lambda天然减少连接。'])
Q(296,'SUPPORTED',[4],[A('GSC-076','watchOutZH'),A('CUR:CB16','watchOutZH')],'A/C的/32不能作为VPC IPv4 CIDR；B与192.168.0.0/24重叠，不能peering；给定项中D的10.0.1.0/24有效且不重叠。原题的SMALLEST按给定选项比较，未把未出现的/28偷换为答案。')
Q(316,'SUPPORTED',[3],[A('VC-001','answerZH'),A('VC-001','keyPointZH'),A('CUR:CA17','keyPointZH'),A('GSC-133','watchOutZH')],'C把消息业务处理迁为适用runtime的Lambda，由服务取队列，免维护常驻EC2轮询；A更大EC2、B停EC2与D按需命令都没有同等受管持续消费。原题没给超过函数时限的任务，不能凭空制造不适用；已有时限/运行环境规则用于实际实施检查，不把无限轮询循环原样搬入单次函数。')
Q(369,'SUPPORTED',[1],[A('VC-002','answerZH'),A('VC-002','keyPointZH'),A('GSC-089','answerZH'),A('GSC-133','watchOutZH')],'一小时超过标准Lambda900秒，C不合；多团队不同语言可分别封装程序依赖并交Batch调度，固定时钟由已教EventBridge调度路径触发，A。B把服务平台当自动创建容器/批作业的工具，D复制整机仍不等于按每个作业资源调度。Fargate是使选定Batch方案满足少管理主机的可用计算环境，不声称所有Batch环境都免主机管理。')
Q(425,'SUPPORTED',[3],[A('GSC-015','answerZH'),A('GSC-015','keyPointZH'),A('GSC-015','watchOutZH'),A('GSC-051','watchOutZH')],'容量性能独立且15000IOPS在适当容量的EC2 gp3可配置范围内，C满足；gp2容量随性能耦合，io1/io2不必仅为该性能购买。这里15000是可行性例子而非新最大值；不拿RDS gp3400GiB/12000基线条带规则限制EC2。')
Q(1005,'INSUFFICIENT_CARDS',[1],[A('VC-001','answerZH'),A('GSC-079','answerZH'),A('GSC-105','answerZH'),A('GSC-105','keyPointZH'),A('GSC-040','keyPointZH'),A('CUR:CA17','answerZH')],'A的SQS→Lambda、文本情绪Comprehend和TTL过期时刻已有当前可见教学；C的Rekognition视觉与D的Lex对话不匹配情绪理解，B继续自管EC2。仍不能从API Gateway→Lambda卡推出API Gateway可直接写SQS，原题A的必要入口连接没有可见事实，故不因其余链路已闭合而升整题充分。',missing=['API Gateway将HTTP请求直接写入SQS的受支持服务集成及其在本题的用途；不可由私有目标或作者知识补充。'])
Q(1014,'SUPPORTED',[2],[A('VC-002','answerZH'),A('VC-002','keyPointZH'),A('GSC-088','answerZH'),A('GSC-088','keyPointZH'),A('CUR:NA05','answerZH'),A('CUR:XB019','keyPointZH')],'B的Batch管理增长中的批作业，使用已教适用Fargate计算环境免自管主机；Step Functions保留流程步骤状态/重试，S3独立对象存大输出。A的SQS不是工作流步骤编排且EC2 Spot仍需实例管理，C/D继续管理EC2。三个职责由不同已教卡共同完成，不要求Batch新卡单独解完整题。')
assert len(proof)==len(qs)==9 and {p['qid'] for p in proof}==set(qb)
transfers=[{'ruleId':'VC-001','changedCondition':'一批中有一个处理失败','result':'默认整批消息可在visibility timeout后重现，故不能只靠成功删除假设永不重复；卡面watchOut和GSC-079已教幂等。','status':'PASS'},{'ruleId':'VC-002','changedCondition':'任务必须自行修改Linux内核','result':'不能无条件选Fargate；VC-002要求符合支持范围，当前XB019已教需要可自管OS的EC2等方式。Batch调度判断可保留但计算环境改变。','status':'PASS','prerequisiteOrContextRuleId':'CUR:XB019'},{'ruleId':'CUR:CB16','changedCondition':'有多个CIDR且只有一个重叠，业务只打算使用不重叠范围','result':'仍不能建立peering；新增提醒直接覆盖这一反例，不让使用地址范围掩盖VPC级重叠限制。','status':'PASS'},{'ruleId':'GSC-015','changedCondition':'现卷容量太小，使所需IOPS超过该容量可配比例','result':'不能承诺只改IOPS总能满足；答案支持范围和提醒容量相关约束仍有效。15000例子明说适当容量，不是所有1GiB卷均可配15000。','status':'PASS'}]
for e in reg.values():
 s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'];assert s[e['startChar']:e['endChar']]==e['quote'];assert hashlib.sha256(s.encode()).hexdigest()==e['sourceTextSha256'];assert hashlib.sha256(e['quote'].encode()).hexdigest()==e['quoteSha256']
for p in proof:
 for a in p['necessaryAnchors']:
  c=overlay[a['ruleId']];assert ch(c['visibleBody'])==a['bodySha256'];assert c['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
report={'schemaVersion':1,'reviewer':'reuse-a independent isolated actual-content reviewer','batch':'supplemental01','status':'PASS_four_local_chinese_candidates_only','reviewedAtUtc':datetime.now(timezone.utc).isoformat(),'inputManifestPath':str(mp),'inputManifestSha256':sha(mp),'inputHashes':manifest,'actualBasePoolPath':str(cp),'actualBasePoolSha256':basehash,'actualBaseUniqueCardCount':len(base),'overlayAppliedToProduction':False,'counts':{'cardPASS':4,'newMechanisms':2,'smallRevisions':2,'localQuestionStatuses':dict(collections.Counter(p['status'] for p in proof))},'results':rows,'evidenceRegistry':reg,'newCardNecessityAndActualReuse':new_need,'primaryDomainReview':domains,'questionImpactReview':proof,'transferChecks':transfers,'allSnapshotQuoteOffsetHashChecksPassed':True,'allCanonicalBodyAndLiteralAnchorChecksPassed':True,'questionSufficiencyGate':'Only the local candidate-overlay results above are reviewed; global statuses and allocation are not mutated or automatically promoted. Q1005 remains insufficient; Q228 retains explicit concurrency condition.','formalBilingualAcceptance':False,'learnerRecallOrAccuracyMeasured':False,'finalCardCountVerified':False,'directCliApiCalls':0,'nativeUsage':'unknown','priorFailureHistoryPreserved':True}
op=OUT/'supplemental01.review.json';op.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for p,h in manifest.items(): assert sha(p)==h,(p,'input changed during review')
readback={'status':'PASS','reviewPath':str(op),'reviewSha256':sha(op),'cardBodyBindings':{r['ruleId']:r['bodySha256'] for r in rows},'canonicalFourFieldBodiesChecked':4,'officialLiteralQuoteBindings':len(reg),'completeOriginalQuestionsRead':9,'literalCurrentOverlayQuestionAnchors':sum(len(p['necessaryAnchors']) for p in proof),'sourceAndInputHashesRechecked':True,'productionMutation':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
(OUT/'supplemental01.readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n');print(json.dumps(readback,ensure_ascii=False,indent=2))

import collections
import datetime
import hashlib
import json
import pathlib

V = pathlib.Path(__file__).resolve().parents[3]
P = V / 'review/supplemental16/input'
O = V / 'review/reuse-a'
F = ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']

def rd(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s): return hashlib.sha256(s.encode()).hexdigest()
def ch(x): return th(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
def body(c): return {f: c.get(f, '') for f in F}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest = rd(P / 'manifest.json')
assert all(sha(p) == h for p, h in manifest.items())
base = {c['ruleId']: c for c in rd(P / 'visible-pool.frozen.json')}
drafts = rd(P / 'cards.json')
assert len(base) == 362 and len(drafts) == 3
assert all(ch(c['visibleBody']) == c['bodySha256'] for c in base.values())
index_path = V / 'validation/current-card-review-index.json'
index_hash = sha(index_path)
index = {c['ruleId']: c for c in rd(index_path)['cards']}
assert all(index[r]['currentBodySha256'] == c['bodySha256'] for r, c in base.items())

proof_cache = {}
def bind_old(rid):
    if rid in proof_cache: return proof_cache[rid]
    c = base[rid]
    ix = index[rid]
    assert ix['status'] == 'PASS' and ix['currentBodySha256'] == c['bodySha256']
    rows = []
    for p in ix['proofs']:
        assert sha(p['path']) == p['sha256']
        d = rd(p['path'])
        r = next(x for x in d.get('results', d.get('cards', [])) if x['ruleId'] == rid)
        assert r['bodySha256'] == c['bodySha256']
        if r.get('visibleBody'): assert r['visibleBody'] == c['visibleBody']
        rows.append(dict(ruleId=rid, path=p['path'], sha256=p['sha256'], bodySha256=c['bodySha256']))
    proof_cache[rid] = rows
    return rows

registry = {}
def cite(path, needle, claim, end=None):
    path = pathlib.Path(path)
    if not path.is_absolute(): path = V / path
    d = rd(path)
    s = d['text']
    lo = s.index(needle)
    hi = lo + len(needle) if end is None else s.index(end, lo) + len(end)
    q = s[lo:hi]
    r = dict(claim=claim, url=d['url'], sourcePath=str(path), sourceFileSha256=sha(path),
             sourceTextSha256=th(s), quote=q, startChar=lo, endChar=hi, quoteSha256=th(q))
    if d.get('textSha256'): assert d['textSha256'] == th(s)
    k = ch(r)
    registry[k] = r
    return k

inputs = rd(P / 'official-evidence.json')
validations = []
effective_sources = {}
snapshot_drifts = []
for i, e in enumerate(inputs):
    d = rd(e['snapshotPath'])
    assert d['url'] == e['url']
    same = sha(e['snapshotPath']) == e['snapshotSha256'] and th(d['text']) == e['textSha256']
    effective = pathlib.Path(e['snapshotPath'])
    status = 'PASS_literal_hash_offset_validation'
    if not same:
        # The research process repaired mojibake in three shared snapshots after
        # this input was frozen. Bind this review to the complete frozen text,
        # rather than silently rebinding an input to a mutable source file.
        assert e['quoteStart'] == 0 and e['quoteEnd'] == len(e['quote'])
        assert th(e['quote']) == e['textSha256']
        repaired = e['quote']
        for old, new in [('â\x80\x93','–'),('â\x80\x94','—'),('â\x80\x99','’'),('â\x80\x9c','“'),('â\x80\x9d','”')]:
            repaired = repaired.replace(old,new)
        assert repaired == d['text'], i
        effective = pathlib.Path(__file__).parent / 'sources' / f'frozen-input-{i:02d}.json'
        effective.parent.mkdir(exist_ok=True)
        reconstructed = dict(url=e['url'], text=e['quote'], textSha256=e['textSha256'],
                             reconstructedFromFrozenEvidencePath=str(P/'official-evidence.json'),
                             frozenEvidenceFileSha256=sha(P/'official-evidence.json'),
                             frozenEvidenceOrdinal=i, originalSnapshotPath=e['snapshotPath'],
                             expectedOriginalSnapshotSha256=e['snapshotSha256'])
        effective.write_text(json.dumps(reconstructed,ensure_ascii=False,indent=2)+'\n')
        snapshot_drifts.append(dict(ordinal=i, originalSnapshotPath=e['snapshotPath'],
                                   expectedOriginalSnapshotSha256=e['snapshotSha256'],
                                   observedCurrentSnapshotSha256=sha(e['snapshotPath']),
                                   frozenTextSha256=e['textSha256'], observedCurrentTextSha256=th(d['text']),
                                   difference='only explicit UTF-8 mojibake recovery; all other text exactly equal',
                                   reconstructedFrozenTextPath=str(effective), reconstructedFileSha256=sha(effective)))
        status = 'PASS_complete_frozen_text_reconstruction_with_documented_shared_snapshot_drift'
    ed = rd(effective)
    assert ed['text'][e['quoteStart']:e['quoteEnd']] == e['quote']
    assert th(ed['text']) == e['textSha256']
    effective_sources[i] = effective
    validations.append(dict(ordinal=i, status=status, originalSnapshotFileStillMatchesFrozenHash=same,
                            snapshotPath=e['snapshotPath'], snapshotSha256=e['snapshotSha256'],
                            effectiveFrozenTextSourcePath=str(effective), effectiveSourceFileSha256=sha(effective),
                            textSha256=e['textSha256'], quoteStart=e['quoteStart'],
                            quoteEnd=e['quoteEnd'], quoteSha256=th(e['quote'])))
assert len(validations) == 5
def src(i, needle, claim, end=None): return cite(effective_sources[i], needle, claim, end)

E = {}
E['activity'] = src(1, 'Gets information about the scaling activities in the account and Region.', 'Account/Region scaling activity records.', 'Amazon EC2 Auto Scaling User Guide\n.')
E['activity-status'] = src(1, 'If the scaling event succeeds, the value of the', 'Activity records include Successful/Failed/Cancelled outcomes and failure cause.', 'Troubleshooting Amazon EC2 Auto Scaling')
E['activity-id'] = src(1, '<ActivityId>12345678-1234-1234-1234-123456789012</ActivityId>', 'Response includes per-activity identifier.')
E['metric'] = src(4, 'You can use metric streams to continually stream CloudWatch metrics', 'Metric streams export CloudWatch metrics, not structured scaling activity records.', 'low latency.')
E['metric-firehose'] = src(4, 'Custom setup with Firehose', 'Firehose delivers the existing numeric metrics stream to S3 and other supported destinations.', 'third-party providers.')
E['metric-statistics'] = src(4, 'Metric streams always include the Minimum', 'Metric stream payload represents metric statistics.', 'Sum statistics.')
E['schedule'] = cite('evidence/cards-c/S0251.json', 'With EventBridge Scheduler, you can create schedules using cron and rate expressions', 'Recurring schedule frequency is configurable, without promising a numeric near-real-time SLA.', 'one-time invocations.')
E['schedule-lambda'] = cite('evidence/cards-c/Scheduler-targets.json', "For example, you can target Lambda's Invoke API operation", 'Scheduler can invoke Lambda outside an EC2 bootstrap path.', 'target.')
E['scheduled-rule'] = cite('evidence/cards-c/EventBridge-rules.json', 'You can create two types of rules:', 'Original scheduled EventBridge rule is supported even though Scheduler is recommended for new tasks.', 'defined schedule.')
E['cluster-window'] = src(2, 'BackupRetentionPeriod\nThe number of days for which automated backups are retained.', 'Native Multi-AZ cluster automated backup retention is configurable for 1–35 days; 30 is valid and zero/disable is unavailable.', 'Type: Integer')
E['backup-cluster'] = src(3, 'AWS Backup supports continuous backups and point-in-time recovery for all Amazon RDS instances', 'AWS Backup explicitly excludes RDS Multi-AZ clusters from continuous backups/PITR.', 'Amazon RDS Multi-AZ clusters.')
E['backup-window'] = src(3, 'When you enable continuous backups for an\n          Amazon RDS instance through AWS Backup', 'Taking over native RDS automated backup scheduling is continuous-backup behavior, not a periodic-snapshot rule.', 'daily snapshot that anchors point-in-time recovery).')
E['native-backup'] = src(0, 'Amazon RDS creates and saves automated backups of your DB instance or Multi-AZ DB cluster', 'RDS native automated backups follow the selected retention period.', 'backup retention period.')
E['manual-independent'] = src(0, 'However, DB snapshots (both final', 'Manual snapshots are independent from the automated backup lifecycle.', 'Manual snapshots are not deleted when an instance\n            is deleted.')
E['long-snapshot'] = src(3, 'Snapshot backups can be stored for up to a maximum of 100 years.', 'Snapshot retention and continuous PITR are distinct capabilities.')

# Revalidate exact original fact evidence from the accepted prior bodies. These
# sources support unchanged fields; their private excerpts are never learning cards.
for rid in ['GCL-004', 'GSC-047', 'VC-010', 'GSC-089', 'CUR:CA17']:
    bind_old(rid)
prior47 = rd(proof_cache['GSC-047'][0]['path'])
prior47_row = next(x for x in prior47['cards'] if x['ruleId'] == 'GSC-047')
prior_reused_evidence = []
for e in prior47_row['evidence']:
    d = rd(e['sourcePath'])
    assert sha(e['sourcePath']) == e['sourceFileSha256']
    assert th(d['text']) == e['textSha256'] and d['url'] == e['url']
    assert d['text'][e['quoteStart']:e['quoteEnd']] == e['quote']
    prior_reused_evidence.append(e)
E['manual-no-expiry'] = cite('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/retrieval-v3/corpus/sources/1d55ef02f6fb91fea3351a23c7b4c2e130508c5d9688519adc91ee279f1cd988.json', "Unlike automated backups, manual snapshots aren't subject to the backup retention period. Snapshots don't expire.", 'Manual snapshot retention is independent and requires explicit cleanup.')

finding = dict(findingId='S16-GSC047-R1', gate='R1', severity='P1',
               field='watchOutZH',
               exactText='RDS Multi-AZ DB cluster原生窗口为1–35天；AWS Backup当前不支持其持续备份/PITR，周期快照计划不等于接管这个自动备份窗口。',
               reason='题面只问近期PITR与多年历史是否可用一个自动窗口解决。新增句另考特定cluster的原生保留范围、AWS Backup持续备份支持及周期快照是否接管管理；不能从快照恢复点/日志重放机制推导该产品支持矩阵。它是为Q989补的独立管理路径判断，不是本题恢复时间尺度的同一竞争条件。',
               minimumRepair='仅收窄GSC-047；维持近期PITR/长期快照主任务，把新增的cluster/AWS Backup兼容与管理权判断移出本卡。若该边界用于Q989，须由另一个通过单任务门禁的可见学习任务承载并回测该题；不必新增卡或扩大其他卡。')

reasons = {
 'GCL-004': dict(FACT='PASS: API原句给活动记录、ID和状态；指标流原句给数值指标/统计与Firehose交付。调度Lambda可在启动路径外读API并写S3，没有承诺固定秒级SLA。', U1='PASS: 活动明细和数值指标的内容不同，决定数据取得路径。', R1='PASS: 一个“活动状态能否从指标流取得、应改走什么”的比较判断，补救路径服务同一任务。', T1='PASS: 若目标改为已有CPU或容量数值指标，可重新考虑Metric Streams；若仍需活动ID/结果，API路线保持。', S1='PASS: 只评不能取得该明细、改独立定时API采集及数据类型原因，不要求代码、IAM或分页清单。', P1='PASS: 明细、指标与独立采集的作用随文解释；Lambda/调度的现有可见规则可复用。'),
 'GSC-047': dict(FACT='PASS: 新增cluster 1–35天和AWS Backup持续备份不支持边界有当前官方正证；未把该限制误套所有RDS实例。原PITR/日志/快照事实逐句复用有效凭证。', U1='PASS: 主问题的快照恢复点与连续日志因果仍清楚。', R1='FAIL: 为原题989补入独立的特定cluster/AWS Backup兼容与管理权判断，超出题面近期PITR/多年快照主任务。', T1='PASS_main_task_only: 长期快照不能替代多年任意秒PITR的迁移成立；此项不抵扣新增内容的R1失败。', S1='PASS_visible_question_scope_only: 自评只问近期与多年两类恢复需求；未提供mustAnswer，不把新增边界认作正式评分通过。', P1='PASS: 未发现需要部署清单或隐藏技术先修；独立产品边界已明确写出，但这不抵扣记忆任务超载。'),
 'VC-010': dict(FACT='PASS: 官方明确manual快照不受自动保留期约束且不自动过期。删除旧禁用提醒消除了对不同RDS部署的泛化后果。', U1='PASS: 两套生命周期互不自动清理的原因明确。', R1='PASS: 仅一个“设置auto 30天会不会清manual”的判断。', T1='PASS: 自动窗口改14天仍不令manual过期；manual生命周期需独立清理。', S1='PASS: 答不会、手工另删及生命周期独立即可，不要求复述自动备份禁用结果。', P1='PASS: 自动/手工两类对象及各自作用在题面和正文中已经区分。')
}
evkeys = {'GCL-004':['activity','activity-status','activity-id','metric','metric-firehose','metric-statistics','schedule','schedule-lambda','scheduled-rule'], 'GSC-047':['cluster-window','backup-cluster','backup-window','long-snapshot'], 'VC-010':['manual-independent','manual-no-expiry','native-backup']}
results = []
overlay = dict(base)
eligible = dict(base)
for c in drafts:
    rid = c['ruleId']
    assert c['repairOf'] == base[rid]['bodySha256']
    b = body(c)
    h = ch(b)
    ok = rid != 'GSC-047'
    gates = {g: ('FAIL' if g == 'R1' and not ok else 'PASS') for g in ['FACT','U1','R1','T1','S1','P1']}
    gates['B1'] = 'N/A_chinese_stage'
    r = dict(ruleId=rid, status='PASS' if ok else 'FAIL', gates=gates, gateReasons=reasons[rid],
             visibleBody=b, bodySha256=h, fieldSha256={f:th(b[f]) for f in F}, fullDraftSha256=ch(c),
             priorAcceptedBodySha256=c['repairOf'], repairOf=c['repairOf'],
             namedValidPriorFACTProofs=bind_old(rid),
             unchangedFieldsExactlyReused=[f for f in F if b[f] == base[rid]['visibleBody'][f]],
             evidenceIds=[E[x] for x in evkeys[rid]], prerequisiteRuleIds=base[rid].get('prerequisiteRuleIds',[]),
             findings=[] if ok else [finding],
             assessmentCheck='只核可见题面对齐；没有私有mustAnswer输入，不宣称正式评分契约或双语通过。')
    results.append(r)
    z = dict(base[rid], visibleBody=b, bodySha256=h)
    overlay[rid] = z
    if ok: eligible[rid] = z

questions = rd(P / 'questions.json')
canonical_path = V.parent / 'domain1-final-card-catalog-20261105/questions.all.json'
canonical = rd(canonical_path)
def anchors(pool, rid, fields=F):
    c = pool[rid]
    return [dict(ruleId=rid, bodySha256=c['bodySha256'], field=f, quote=c['visibleBody'][f], startChar=0, endChar=len(c['visibleBody'][f]), candidateOverlay=(c['bodySha256'] != base[rid]['bodySha256'])) for f in fields if c['visibleBody'].get(f)]
qrows = []
for q in questions:
    qid = q['qid']; original = q['question']
    assert original == canonical[str(qid)]
    r = dict(qid=qid, questionSha256=ch(original), stemUtf8Sha256=th(original['stem']),
             optionsCanonicalSha256=ch(original['options']), completeStemAndEveryOptionRead=True,
             sourceIssueConfirmed=False, noPrintedAnswersOrPrivateGoalsUsed=True,
             noOfficialEvidenceSubstitutedForMissingVisibleCard=True,
             selectedOptionOrdinals=[], sourceFactValidatedFeasibleOptionOrdinals=[3])
    if qid == 257:
        ids = ['GCL-004','GSC-089','CUR:CA17']
        r.update(status='SUPPORTED', selectedOptionOrdinals=[3], usedRuleIds=ids,
                 necessaryAnchors=sum([anchors(eligible,i) for i in ids],[]),
                 reasoningAndClosestCompetitor='C：当前GCL004直接教活动记录API→独立定时Lambda→S3，GSC089提供按时钟触发，CA17解释短时计算由托管入口/计算承载、无需维持常驻服务器。A只导出数值指标，不是伸缩活动ID/结果；B引入需运行的EMR cluster而不是所需serverless路径；D把安装/采集步骤塞入实例启动路径，违背启动不受影响。C未逐字列DescribeScalingActivities、分页及S3权限属于普通实现省略，不据此升为源错。',
                 conditions=['近实时为定性要求，按需求选择合理调度频率；未推定零延迟或硬性秒级保证。'], minimumRemainingJudgments=[],
                 officialEvidenceIds=[E[k] for k in ['activity','activity-status','activity-id','metric','scheduled-rule']])
    else:
        assert qid == 989
        ids = ['VC-010','GSC-047']
        r.update(status='INSUFFICIENT_CARDS', usedRuleIds=ids,
                 necessaryAnchors=sum([anchors(eligible,i) for i in ids],[]),
                 reasoningAndClosestCompetitor='技术上C可行：原生Multi-AZ cluster自动保留30天在1–35范围内，manual超过30天独立删除。A不能用AWS Backup持续备份接管该cluster自动窗口，B/D的禁用原生auto也不适用这个cluster；这些是现行官方正证，不把普通实施省略判源错。但候选047承载这些决定性事实的新增句未通过R1，当前可采用卡组只剩VC010的生命周期区别及旧047的PITR/长期恢复任务，不能用私有官方摘录直接补成学会后可排A/B/D。',
                 minimumRemainingJudgments=['由一个通过单任务门禁的可见学习任务解释Multi-AZ DB cluster原生自动备份1–35天与AWS Backup当前不支持其持续备份管理的边界，以排除A/B/D。'],
                 candidateOnlyFactualCoverage='SUPPORTED_if_failed_GSC047_candidate_were_accepted_but_not_counted',
                 failedCandidateRuleIds=['GSC-047'], failedCandidateBodySha256=overlay['GSC-047']['bodySha256'],
                 rejectedCandidateVisibleAnchors=anchors(overlay,'GSC-047',['watchOutZH']),
                 acceptedFallbackBodySha256=base['GSC-047']['bodySha256'],
                 sourceFinding='原题保留，不确认源错；官方正证已给出可行C及竞争路径限制，当前障碍是教学任务承载。',
                 officialEvidenceIds=[E[k] for k in ['cluster-window','backup-cluster','backup-window','manual-no-expiry']])
    r['recursiveUsedPrerequisiteBindings'] = []
    for rid in r['usedRuleIds']:
        assert not eligible[rid].get('prerequisiteRuleIds',[])
        bind_old(rid)
    qrows.append(r)

report = dict(schemaVersion=1, batch='supplemental16', reviewer='independent actual Chinese card and original-question reviewer',
              status='PARTIAL_two_cards_PASS_one_R1_FAIL', reviewedAtUtc=now(),
              inputManifestPath=str(P/'manifest.json'), inputManifestSha256=sha(P/'manifest.json'), inputHashes=manifest,
              currentReviewIndexPath=str(index_path), currentReviewIndexSha256=index_hash,
              frozenVisiblePoolCount=362, candidateOverlayCount=3, newCards=0, appliedToCurrent=False,
              counts=dict(cardPASS=2, cardFAIL=1, originalQuestionStatuses=dict(collections.Counter(r['status'] for r in qrows))),
              results=results, questionImpactReview=qrows, evidenceRegistry=registry,
              officialInputRecordValidation=validations, sharedSnapshotPostFreezeDrift=snapshot_drifts,
              frozenEvidenceTextReconstructionExplicit=True,
              reusedPriorGSC047ExactEvidenceValidation=prior_reused_evidence,
              usedExistingCardProofBindings=proof_cache,
              findings=[finding], minimumRepairScope=dict(cardRuleIds=['GSC-047'], affectedQuestionIds=[989], unaffectedPASSRuleIds=['GCL-004','VC-010'], unaffectedSupportedQuestionIds=[257], nextFullDependencyBacktest='awaiting_parent_frozen_package'),
              transferChecks=[dict(ruleId='GCL-004', conditionChange='把活动ID和成功失败详情改为已经采集的CPU数值指标', status='PASS', reason='此时可改用Metric Streams；原任务因数据形态不同而须活动API。'), dict(ruleId='VC-010', conditionChange='自动保留30天改14天', status='PASS', reason='manual仍独立存在，不能据auto窗口推定自动删除。'), dict(ruleId='GSC-047', conditionChange='多年任意时间点恢复改为多年固定快照恢复点', status='PASS_main_task_only', reason='旧机制可解释快照可满足固定点、不能长期任意秒PITR；不抵扣新增产品矩阵R1失败。')],
              lowFrequencyReview=dict(newCards=0, semanticScope='3条现卡，不因单题细节增加卡数；GCL004保留数值指标/Firehose内容区别，VC010保留auto/manual必要判断。047新增边界未据此被接受。', all362Or1018BacktestPerformed=False),
              formalBilingualAcceptance=False, privateGradingContractAcceptance=False,
              learnerMemoryOrAccuracyMeasured=False, finalCardCountVerified=False,
              priorFailuresPreserved=True, currentPointersChangedByReviewer=False, authoringPerformed=False,
              externalOfficialReadOnlyFetches=0, directCliApiCalls=0, nativeUsage='unknown')
rp = O/'supplemental16.review.json'
rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
r = rd(rp)
for c in r['results']:
    assert ch(c['visibleBody']) == c['bodySha256']
    assert {f:th(c['visibleBody'][f]) for f in F} == c['fieldSha256']
for e in r['evidenceRegistry'].values():
    d = rd(e['sourcePath']); s = d['text']
    assert sha(e['sourcePath']) == e['sourceFileSha256'] and th(s) == e['sourceTextSha256']
    assert s[e['startChar']:e['endChar']] == e['quote'] and th(e['quote']) == e['quoteSha256']
for q in r['questionImpactReview']:
    for a in q['necessaryAnchors']:
        assert eligible[a['ruleId']]['bodySha256'] == a['bodySha256']
        assert eligible[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']] == a['quote']
assert all(sha(p) == h for p,h in manifest.items()) and sha(index_path) == index_hash
rb = dict(status='PASS_review_readback_with_explicit_semantic_FAIL', reviewPath=str(rp), reviewSha256=sha(rp),
          inputManifestSha256=sha(P/'manifest.json'), readBackAtUtc=now(), counts=r['counts'],
          checks=dict(threeCanonicalFourFieldBodiesAndPerFieldHashes=True, twoCompleteOriginalsEveryOption=True,
                      allExactNecessaryAnchors=True, namedCurrentPriorProofsAndBodyBindings=True,
                      allFiveFrozenOfficialEvidenceTextsValidated=True, originalSnapshotFilesAllStillMatchFrozenHashes=(not snapshot_drifts),
                      threeSharedSnapshotMojibakeRepairsExplicitAndFrozenFullTextReconstructed=(len(snapshot_drifts)==3),
                      allEffectiveOfficialFileTextQuoteOffsetsAndHashes=True,
                      failedCandidateExcludedFromEligibleCardGroup=True, currentFallbackBodyExplicit=True,
                      noOrdinaryImplementationOmissionPromotedToSourceIssue=True, allFrozenInputsStillUnchanged=True,
                      noCurrentSourceProductionOrHistoryMutation=True),
          formalBilingualAcceptance=False, learnerEffectMeasured=False, finalNVerified=False,
          directCliApiCalls=0, nativeUsage='unknown')
(O/'supplemental16.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(review=str(rp), sha256=sha(rp), counts=r['counts']),ensure_ascii=False))

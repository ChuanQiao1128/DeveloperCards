import audit_reuse as a
from pathlib import Path
import json,collections
V,C,O,OUT=a.V,a.C,a.O,a.OUT
qs=a.rd(C/'deliverables/question-support371.json');cm=a.rd(C/'deliverables/manifest.json');assert a.sha(C/'deliverables/question-support371.json')==cm['artifacts'][str(C/'deliverables/question-support371.json')]
original=a.rd(O/'questions.all.json');eligible={r['cardId']:r for r in a.result};outputs=[]
def idsclosure(ids,pool):return set().union(*(a.closure(c,pool) for c in ids)) if ids else set()
def shape(q):return {k:q[k] for k in ['qid','stem','options']}
def hasherr(p,h,errors,code):
 if not p.is_file() or a.sha(p)!=h:errors.append({'code':code,'path':str(p),'expected':h,'actual':a.sha(p) if p.is_file() else None})
def checkmap(m,errors):
 for n,h in m.items():hasherr(Path(n),h,errors,'BOUND_INPUT_HASH_MISMATCH')
manifestpaths=list((O/'backtest-input').glob('manifest.v*.json'))+[O/'catalogue.current.manifest.json',O/'retest-input/manifest.json']
manifest_by_hash={a.sha(p):p for p in manifestpaths}
for q in qs:
 qid=q['qid'];errors=[];proofs=[];p=Path(q['proofProvenance']['path']);hasherr(p,q['proofProvenance']['sha256'],errors,'PROOF_HASH_MISMATCH');proofs.append(a.ref(p));d=a.rd(p);rows=d.get('results',d.get('records',[]));raw=next((r for r in rows if r['qid']==qid),None)
 if not raw:errors.append({'code':'ACTUAL_QUESTION_ROW_MISSING'})
 else:
  for k in ['verdict','selectedOptionOrdinals','conditionalSelectedOptionOrdinals','usedCardIds','anchors','necessaryReason','closestAlternative','missingJudgments','applicabilityConditions','sourceIssues']:
   if raw.get(k,[])!=q.get(k,[]):errors.append({'code':'QUESTION_RESULT_CHANGED','field':k})
 used=q['usedCardIds'];currentclosure=idsclosure(used,a.by);missing=sorted(currentclosure-set(a.by));expanded=sorted(currentclosure&a.scope)
 if missing:errors.append({'code':'CURRENT_DEPENDENCY_MISSING','cardIds':missing})
 if expanded:errors.append({'code':'CURRENT_DEPENDENCY_SCOPE_CHANGED','cardIds':expanded})
 if not set(used)<=set(a.by):errors.append({'code':'USED_CARD_REMOVED','cardIds':sorted(set(used)-set(a.by))})
 for cid in sorted(currentclosure&set(a.by)):
  r=eligible[cid]
  if not r['eligibleFACT'] or not r['eligibleTEACHING']:errors.append({'code':'DEPENDENCY_CARD_REVIEW_NOT_ELIGIBLE','cardId':cid})
 oldclosure=idsclosure(used,a.oldcomp)
 if currentclosure!=oldclosure:errors.append({'code':'COMPLETE_DEPENDENCY_SET_CHANGED','old':sorted(oldclosure),'current':sorted(currentclosure)})
 for cid in sorted(oldclosure&set(a.by)):
  if a.body(a.by[cid])!=a.body(a.oldcomp[cid]) or a.assess(a.by[cid])!=a.assess(a.oldcomp[cid]):errors.append({'code':'COMPRESSED_BODY_OR_ASSESSMENT_CHANGED','cardId':cid})
 expectedq=original[str(qid)];boundquestion=None;boundpool={};boundids=None
 if q['proofProvenance']['kind']=='independent_full_question_retest':
  for k,h in d['inputHashes'].items():
   names={'manifestSha256':'manifest.json','visibleCardsSha256':'visible-cards.json','batchSha256':p.name,'bodyAcceptanceReviewSha256':str(C/'reviews/existing-gap-r1/review.json')};n=names.get(k,k);ip=Path(n) if Path(n).is_absolute() else p.parent/'input'/n;hasherr(ip,h,errors,'BOUND_INPUT_HASH_MISMATCH');proofs.append(a.ref(ip))
  ip=p.parent/'input'/p.name;inp=a.rd(ip);item=next((i for i in inp['questions'] if i['question']['qid']==qid),None)
  if item:boundquestion=item['question'];boundids=item['learnerCardIds']
  boundpool={z['id']:z for z in a.rd(p.parent/'input/visible-cards.json')}
  if not oldclosure<=set(boundids or []):errors.append({'code':'ORIGINAL_VISIBLE_CONTEXT_MISSES_DEPENDENCY','visible':boundids,'closure':sorted(oldclosure)})
  reviewedcontext=set(boundids or []);oldclosure=idsclosure(reviewedcontext,a.oldcomp)
  for cid in sorted(oldclosure):
   if cid not in boundpool:errors.append({'code':'ORIGINAL_CONTEXT_CARD_MISSING','cardId':cid});continue
   if a.body(boundpool[cid])!=a.body(a.oldcomp[cid]) or a.assess(boundpool[cid])!=a.assess(a.oldcomp[cid]):errors.append({'code':'BOUND_BODY_OR_ASSESSMENT_MISMATCH','cardId':cid})
  vh=q.get('visibleContextBodySha256')
  if vh!={cid:a.oldcomp[cid]['bodySha256'] for cid in sorted(oldclosure)}:errors.append({'code':'RECORDED_COMPLETE_CONTEXT_HASH_MISMATCH'})
 else:
  h=d['inputManifestSha256'];mp=manifest_by_hash.get(h)
  if not mp:errors.append({'code':'ORIGINAL_MANIFEST_NOT_FOUND','sha256':h})
  else:
   proofs.append(a.ref(mp));md=a.rd(mp);checkmap(md.get('hashes',{}),errors)
  version=q['proofProvenance'].get('originalCatalogueVersion',3 if q['proofProvenance']['kind']=='targeted_current_body_retest' else None)
  if version:
   bp=O/f'backtest-input/catalogue.v{version}.json';boundpool={z['id']:z for z in a.rd(bp)};proofs.append(a.ref(bp))
  part=int(p.parent.name)
  if q['proofProvenance']['kind']=='targeted_current_body_retest':
   im=O/'retest-input/manifest.json';hasherr(im,d['retestInputManifestSha256'],errors,'RETEST_INPUT_MANIFEST_MISMATCH');proofs.append(a.ref(im));checkmap(a.rd(im).get('inputHashes',{}),errors);qp=O/f'retest-input/part-{part}.json';inp=a.rd(qp);boundquestion=next((z['question'] for z in inp['items'] if z['question']['qid']==qid),None)
   if 'retestQuestionInputSha256' in d:hasherr(qp,d['retestQuestionInputSha256'],errors,'QUESTION_INPUT_MISMATCH')
   # Later readback may bind a genuine superset; verify the addendum's actual bytes separately.
   if d.get('baseReviewedManifestSha256'):hasherr(O/'backtest-input/manifest.v3.json',d['baseReviewedManifestSha256'],errors,'BASE_MANIFEST_MISMATCH')
   if d.get('v4AddendumSha256'):hasherr(O/'retest-input/v4-addendum.json',d['v4AddendumSha256'],errors,'ADDENDUM_MISMATCH')
  else:
   qp=O/f'backtest-input/questions-{part}.json';inp=a.rd(qp);boundquestion=next((z for z in inp['questions'] if z['qid']==qid),None)
  proofs.append(a.ref(qp));origclosure=idsclosure(used,a.oldfull)
  if origclosure!=oldclosure:errors.append({'code':'ORIGINAL_DEPENDENCY_CLOSURE_CHANGED','original':sorted(origclosure),'compressed':sorted(oldclosure)})
  for cid in sorted(origclosure):
   if cid not in boundpool or cid not in a.oldcomp:errors.append({'code':'ORIGINAL_CLOSURE_NOT_IN_BOUND_VISIBLE_POOL','cardId':cid});continue
   if a.body(boundpool[cid])!=a.body(a.oldcomp[cid]):errors.append({'code':'ORIGINAL_VISIBLE_BODY_CHANGED','cardId':cid})
   if a.oldfull[cid].get('mustAnswer',[])!=a.oldcomp[cid].get('mustAnswer',[]) or set(a.oldfull[cid].get('prerequisiteIds',[]))!=set(a.oldcomp[cid].get('prerequisiteIds',[])):errors.append({'code':'ORIGINAL_ASSESSMENT_OR_PREREQUISITES_CHANGED','cardId':cid})
  recorded=q.get('compressionProofReuse',{}).get('currentBodySha256')
  if recorded!={cid:a.oldcomp[cid]['bodySha256'] for cid in sorted(oldclosure)}:errors.append({'code':'COMPRESSED_REUSE_CONTEXT_HASH_MISMATCH'})
 if q['proofProvenance']['kind']=='independent_full_question_retest':
  currentclosure=idsclosure(set(boundids or []),a.by)
  extraexpanded=sorted(currentclosure&a.scope)
  if extraexpanded and not expanded:errors.append({'code':'CURRENT_DEPENDENCY_SCOPE_CHANGED','cardIds':extraexpanded})
  for cid in sorted(currentclosure&set(a.by)):
   r=eligible[cid]
   if (not r['eligibleFACT'] or not r['eligibleTEACHING']) and not any(e.get('cardId')==cid and e['code']=='DEPENDENCY_CARD_REVIEW_NOT_ELIGIBLE' for e in errors):errors.append({'code':'DEPENDENCY_CARD_REVIEW_NOT_ELIGIBLE','cardId':cid})
 if boundquestion is None or shape(boundquestion)!=shape(expectedq):errors.append({'code':'ORIGINAL_FULL_STEM_OPTIONS_NOT_IDENTICAL'})
 for z in q['anchors']:
  cid=z['cardId']
  if cid not in a.by or not any(z['quote'] in t for t in a.body(a.by[cid]).values()):errors.append({'code':'ANCHOR_NOT_VERBATIM_CURRENT_BODY','cardId':cid})
 outputs.append({'qid':qid,'status':'eligible_reuse' if not errors else 'needs_retest','priorVerdict':q['verdict'],'reuseVerdict':q['verdict'] if not errors else None,'usedCardIds':used,'completeDependencyIds':sorted(currentclosure),'bodySha256':{cid:a.by[cid]['bodySha256'] for cid in sorted(currentclosure) if cid in a.by},'learningSha256':{cid:a.by[cid]['learningSha256'] for cid in sorted(currentclosure) if cid in a.by},'originalQuestionStemAndOptionsSha256':a.ch(shape(expectedq)),'proofs':list({z['path']:z for z in proofs}.values()),'limitations':errors,'preservedApplicabilityConditions':q.get('applicabilityConditions',[]),'preservedSourceIssues':q.get('sourceIssues',[])})
assert len(outputs)==371 and len({q['qid'] for q in outputs})==371
report={'schemaVersion':1,'questionSupportSource':a.ref(C/'deliverables/question-support371.json'),'questionSupportManifest':a.ref(C/'deliverables/manifest.json'),'eligibilityScope':'Exact original stem/all options, actual original proof row and pinned visible complete dependency context, exact current local bodies/assessment/closure and eligible card proofs. Scope-changed dependencies invalidate reuse regardless unchanged bytes. No new semantic whole-question PASS generated.','counts':dict(collections.Counter(q['status'] for q in outputs)),'eligibleVerdictCounts':dict(collections.Counter(q['priorVerdict'] for q in outputs if q['status']=='eligible_reuse')),'eligibleQuestionIds':[q['qid'] for q in outputs if q['status']=='eligible_reuse'],'needsRetestQuestionIds':[q['qid'] for q in outputs if q['status']=='needs_retest'],'results':outputs,'directCliApiCalls':0,'nativeUsage':'unknown'}
(OUT/'question-reuse371.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('QUESTION counts',report['counts'],report['eligibleVerdictCounts']);print('issue codes',collections.Counter(e['code'] for q in outputs for e in q['limitations']));print('other errors',[(q['qid'],q['limitations']) for q in outputs if any(e['code'] not in ['CURRENT_DEPENDENCY_SCOPE_CHANGED','DEPENDENCY_CARD_REVIEW_NOT_ELIGIBLE'] for e in q['limitations'])][:20])

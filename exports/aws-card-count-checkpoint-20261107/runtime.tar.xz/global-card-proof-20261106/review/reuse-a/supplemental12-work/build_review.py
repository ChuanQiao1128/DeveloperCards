import pathlib, json, hashlib, collections, datetime, re

V = pathlib.Path(__file__).resolve().parents[3]
P = V / 'review/supplemental12/input'
O = V / 'review/reuse-a'
W = O / 'supplemental12-work'
FIELDS = ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']
def rd(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s): return hashlib.sha256(s.encode()).hexdigest()
def ch(x): return th(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
def body(c): return {f: c.get(f, '') for f in FIELDS}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest = rd(P/'manifest.json')
assert all(sha(p) == h for p, h in manifest.items())
base = {c['ruleId']: c for c in rd(P/'visible-pool.frozen.json')}
drafts = rd(P/'cards.json')
cards = dict(base)
for c in drafts:
    rid = c['ruleId']
    if c.get('repairOf'): assert c['repairOf'] == base[rid]['bodySha256']
    cards[rid] = {'ruleId': rid, 'visibleBody': body(c), 'bodySha256': ch(body(c)), 'prerequisiteRuleIds': c.get('prerequisiteRuleIds', base.get(rid, {}).get('prerequisiteRuleIds', []))}
assert len(base) == 359 and len(cards) == 361 and len(drafts) == 6
assert all(ch(c['visibleBody']) == c['bodySha256'] for c in cards.values())
index_path = V/'validation/current-card-review-index.json'
index_hash = sha(index_path)
index = {x['ruleId']: x for x in rd(index_path)['cards']}
legacy_path = V/'inputs/existing176.json'
legacy = {c['ruleId']: c for c in rd(legacy_path)}
proof_cache = {}
def bind_old(rid):
    if rid in proof_cache: return proof_cache[rid]
    c = base[rid]; ix = index[rid]
    assert ix['status'] == 'PASS' and ix['currentBodySha256'] == c['bodySha256']
    out = []
    for p in ix['proofs']:
        assert sha(p['path']) == p['sha256']
        d = rd(p['path']); rs = d.get('results', d.get('cards', []))
        if isinstance(rs, dict): rs = list(rs.values())
        matches = [x for x in rs if x.get('ruleId') == rid]
        assert matches, (rid, p['path'])
        r = matches[-1]; rh = r['bodySha256']
        contract = 'canonical four-field current visible body including empty values'
        if rh != c['bodySha256']:
            lb = body(legacy[rid]['body'])
            assert lb == c['visibleBody'] and ch({f: s for f, s in lb.items() if s}) == rh, rid
            contract = 'legacy omitted-empty hash; exact four visible fields reconstructed from hash-bound existing176 and matched'
        elif 'visibleBody' in r: assert r['visibleBody'] == c['visibleBody'], rid
        z = {'ruleId': rid, 'path': p['path'], 'sha256': p['sha256'], 'receiptBodySha256': rh, 'currentPriorBodySha256': c['bodySha256'], 'bodyBindingContract': contract}
        if r.get('proofs'):
            for pp in r['proofs']: assert sha(pp['path']) == pp['sha256']
            z['parentGateReceipts'] = r['proofs']
        out.append(z)
    proof_cache[rid] = out
    return out

registry = {}
def cite(p, needle, length, claim, occurrence=0):
    p = pathlib.Path(p)
    if not p.is_absolute(): p = V/p
    d = rd(p); s = d['text']; positions = [m.start() for m in re.finditer(re.escape(needle), s)]
    assert positions, (p, needle)
    start = positions[occurrence]; q = s[start:start+length]
    z = {'claim': claim, 'url': d['url'], 'sourcePath': str(p), 'sourceFileSha256': sha(p), 'sourceTextSha256': th(s), 'quote': q, 'startChar': start, 'endChar': start+len(q), 'quoteSha256': th(q)}
    if d.get('rawSha256') and p.with_suffix('.html').exists():
        z.update(rawHtmlPath=str(p.with_suffix('.html')), rawHtmlSha256=d['rawSha256'])
        assert sha(z['rawHtmlPath']) == z['rawHtmlSha256']
    if d.get('textSha256'): assert th(s) == d['textSha256']
    eid = ch(z); registry[eid] = z
    return eid

inputs = rd(P/'official-evidence.json'); input_validation = []
for i, e in enumerate(inputs):
    d = rd(e['snapshotPath']); s = d['text']
    assert sha(e['snapshotPath']) == e['snapshotSha256'] and th(s) == e['textSha256']
    assert s[e['quoteStart']:e['quoteEnd']] == e['quote'] and d['url'] == e['url']
    input_validation.append({'ordinal': i, 'url': e['url'], 'snapshotPath': e['snapshotPath'], 'snapshotSha256': e['snapshotSha256'], 'textSha256': e['textSha256'], 'quoteStart': e['quoteStart'], 'quoteEnd': e['quoteEnd'], 'quoteSha256': th(e['quote']), 'status': 'PASS_literal_hash_offset_validation'})
def src(i, needle, n, claim): return cite(inputs[i]['snapshotPath'], needle, n, claim)

# Accepted batch10 versions are an additional hash-bound context, never a rewrite of this frozen input.
accepted10_path=O/'supplemental10.review.json'; accepted10=rd(accepted10_path)
accepted10_hash=sha(accepted10_path); drift=[]; supplementary=[]
for r in accepted10['results']:
    if r['status']!='PASS':continue
    rid=r['ruleId']; prior=base.get(rid); oldhash=prior.get('bodySha256') if prior else None
    if oldhash==r['bodySha256']:continue
    assert index[rid]['currentBodySha256']==r['bodySha256'] and index[rid]['status']=='PASS'
    nc=dict(prior or {});nc.update(ruleId=rid,visibleBody=r['visibleBody'],bodySha256=r['bodySha256'],prerequisiteRuleIds=r['prerequisiteRuleIds'])
    supplementary.append({'ruleId':rid,'frozenBodySha256':oldhash,'currentBodySha256':r['bodySha256'],'visibleBody':r['visibleBody'],'proofPath':str(accepted10_path),'proofSha256':accepted10_hash})
    if prior:drift.append(rid)
    base[rid]=nc
    if rid not in {x['ruleId'] for x in drafts}:cards[rid]=nc
assert len(base)==360 and len(cards)==362

E={}
E['dx-low']=cite(W/'sources/dx-product.json','Reduce networking costs Low rates',200,'Direct Connect official product page identifies low egress rates that may lower networking costs; it is not a universal cheapest-route guarantee.')
E['dx-metering']=src(0,'Data transfer out (DTO) over AWS Direct Connect refers',605,'DX data-out cost is per GB and varies by source Region and DX location.')
E['dx-example']=src(0,'AWS Region sending data US East (Ohio)',410,'Official same-region Ohio/Columbus example bills DX data out at0.02USD/GB.')
E['dx-ports']=src(0,'Port hours measure the time that a port is provisioned',430,'DX port fees accrue even when not carrying traffic; existing-line egress comparison differs from new-line total costs.')
E['internet-free']=cite('review/reuse-a/sources/e0bded851e40c799b5b0.json','100GB of data transfer out to the internet free each month',470,'EC2 pricing states100GB monthly Internet DTO allowance aggregated across services/regions except China/GovCloud; payer allowance usage is decisive for Q240.')
E['snow-256']=src(7,'256-bit encryption',260,'Snowball Edge device security includes256-bit encryption and physical protections.')
E['snow-kms']=src(7,'In AWS Snowball Edge, AWS KMS protects the encryption keys',450,'KMS protects the unique device data-encryption keys.')
E['snow-eligibility']=cite(W/'sources/snow-faq.json','NOTICE: Effective November 7, 2025',360,'Snowball Edge available only to existing customers; not blanket retirement.')
E['cf-default']=src(3,'The origin adds a Cache-Control: max-age',650,'Origin max-age and min/max/default TTL interactions.') if 'The origin adds a Cache-Control: max-age' in rd(inputs[3]['snapshotPath'])['text'] else src(3,'If you opt out of using a cache policy',1150,'Cache duration combines behavior TTL settings and origin max-age/Expires.')
E['cf-origin-viewer']=cite(W/'sources/cf-trigger-lifecycle.json','Origin response The function executes after',1000,'Origin-response runs before caching; viewer-response runs before delivery including existing cache hits, so viewer edits do not set stored-object TTL.')
E['cf-viewer-headers']=cite(W/'sources/cf-headers.json','If you add headers that control browser caching',345,'Viewer response headers affect browser response, not CloudFront cached-object lifetime; corroborates lifecycle boundary.')
E['ssec-never-store']=src(2,'S3 never stores the encryption key',610,'SSE-C does not retain the supplied key and requires it for subsequent reads.')
E['ssec-block']=src(2,'Starting April 2026',1080,'SSE-C writes may be blocked by default; explicitly allowing them is different from choosing a default encryption algorithm.')
E['ssec-copy']=src(4,'When copying an object, if you want to use a different type of encryption setting',730,'CopyObject may explicitly encrypt target with customer key; SSE-C source also requires source key.')
E['s3-default-api']=cite(W/'sources/s3-put-encryption.json','By default, all buckets have a default encryption configuration',800,'PutBucketEncryption documents default SSE-S3, optional SSE-KMS/DSSE-KMS, not SSE-C as automatic default algorithm.')
E['s3-default-enum']=cite(W/'sources/s3-default-api.json','SSEAlgorithm Server-side encryption algorithm to use for the default encryption.',400,'API default algorithm enum excludes SSE-C; blocked encryption control does not mean SSE-C can be the stored default key method.')
E['copy-doc-conflict']=src(4,'If the destination bucket has a default encryption configuration',388,'Conflicting CopyObject guide sentence explicitly mentions default SSE-C; retained as a documentation conflict, not accepted evidence of default SSE-C capability.')
E['media']=src(1,'Solid state drives (SSD)',1250,'EBS SSD favors small random I/O, HDD favors large sequential throughput.') if 'Solid state drives (SSD)' in rd(inputs[1]['snapshotPath'])['text'] else src(1,'SSD-backed volumes',1450,'EBS SSD versus HDD workload design and gp3/io/st1/sc1 class mapping.')
E['domain1']=cite(O/'supplemental04-work/sources/saa-c03-guide.json','Task 1.3: Determine appropriate data security controls\nKnowledge of:',730,'SAA-C03 data encryption/key control task1.3.')
E['domain3']=cite(O/'supplemental04-work/sources/saa-c03-guide.json','Task 3.1: Determine high-performing and/or scalable storage solutions\nKnowledge of:',1500,'SAA-C03 task3.1 storage performance and storage-type workload characteristics.')

reason={
'GSC-078':'原卡已同时解释传输量和计费路径单价，修订只把既有专线比较具体化并保留实际计费档/端口费边界。主判断仍是按量×价减少传输费用；不要求额外背专线购买流程。',
'GSC-077':'一个迁移可行性判断：实际带宽推算窗口，不够时比较合格离线设备；加密是离线搬运敏感数据的能力说明，不另考256/KMS配置或新增部署步骤。',
'GSC-131':'围绕同一缓存新鲜度机制区分单次失效与持续重验证；default/max-age/min/max的作用是避免只改一个TTL就误判生效，不考完整HTTP清单。',
'CUR:XA013':'一个执行位置判断：边缘函数运行逻辑，viewer阶段可改用户响应却不改已缓存对象寿命；提醒直接约束代码与缓存策略的职责边界。',
'VC-013':'一个SSE-C机制判断：key逐请求提供、S3不保留，所以不能靠桶自动默认代替请求；旧对象仍须显式copy/重写。旧/新两阶段是题面同一加密目标，不另列完整审计清单。',
'VC-014':'按随机小I/O与连续吞吐选择SSD/HDD，一个有用途的媒体取舍；给出gp/io与st/sc的EBS实例，不把数据库一律判给最贵io2。'}
keys={'GSC-078':['dx-low','dx-metering','dx-ports'],'GSC-077':['snow-256','snow-kms','snow-eligibility'],'GSC-131':['cf-default'],'CUR:XA013':['cf-origin-viewer','cf-viewer-headers'],'VC-013':['ssec-never-store','ssec-block','ssec-copy','s3-default-api','s3-default-enum'],'VC-014':['media']}
results=[]
for c in drafts:
    rid=c['ruleId'];results.append({'ruleId':rid,'status':'PASS','gates':dict({g:'PASS' for g in ['FACT','U1','R1','T1','S1','P1']},B1='N/A_chinese_stage'),
        'visibleBody':body(c),'bodySha256':ch(body(c)),'fieldSha256':{f:th(c.get(f,'')) for f in FIELDS},'fullDraftSha256':ch(c),'priorBodySha256':base.get(rid,{}).get('bodySha256'),
        'namedValidPriorFACTProofs':bind_old(rid) if rid in base else [],'evidenceIds':[E[k] for k in keys[rid]],'teachingAndRecallTaskReason':reason[rid],
        'prerequisiteRuleIds':cards[rid]['prerequisiteRuleIds'],'assessmentCheck':'只按本次正面问题的主要判断及因果自评；GSC077的256/KMS说明不扩成必背数字或配置，边界提醒不追加未问评分。未提供私有mustAnswer，不验收正式评分/双语。','findings':[]})

qb={q['qid']:q['question'] for q in rd(P/'questions.json')};overlay_ids={c['ruleId'] for c in drafts}
def A(rid,fields=('answerZH','keyPointZH')):
    c=cards[rid];return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'startChar':0,'endChar':len(c['visibleBody'][f]),'candidateOverlay':rid in overlay_ids} for f in fields if c['visibleBody'].get(f)]
def Q(qid,status,opts,ids,reason,missing=(),conditions=(),ev=(),issues=(),correction=None):
    aa=sum([A(r) for r in ids],[]);used=sorted(set(ids));todo=list(used);seen=set();pre=[]
    while todo:
        r=todo.pop()
        if r in seen:continue
        seen.add(r)
        for dep in cards[r].get('prerequisiteRuleIds',[]):pre.append({'from':r,'ruleId':dep,'bodySha256':cards[dep]['bodySha256'],'visibleBody':cards[dep]['visibleBody']});todo.append(dep)
    for r in seen:
        if r not in overlay_ids:bind_old(r)
    q=qb[qid]
    return {'qid':qid,'status':status,'selectedOptionOrdinals':opts if status=='SUPPORTED' else [],'candidateOptionOrdinals':opts,'questionSha256':ch(q),'originalStemUtf8Sha256':th(q['stem']),'originalOptionsCanonicalSha256':ch(q['options']),
        'completeStemAndEveryOptionRead':True,'usedRuleIds':used,'necessaryAnchors':aa,'recursiveUsedPrerequisiteBindings':pre,'reasoningAndClosestCompetitor':reason,'minimumRemainingJudgments':list(missing),'conditions':list(conditions),'officialEvidenceIds':[E[k] for k in ev],'sourceIssues':list(issues),'minimalCorrectionProposal':correction,'noPrivateTargetsOrPrintedAnswersUsed':True,'officialSourcesNotUsedAsMissingLearningCards':True}
qs=[]
qs.append(Q(240,'SOURCE_ISSUE',[1,2,4],['GSC-078','CUR:NB01'], '量的方向由GSC078可见机制推出：把50MB查询在AWS内处理，只出500KB页面，B/D比A/C少传100倍。已有DX在收费档可能使D进一步便宜，但不能对原题无条件强选D：Internet出站每payer每月有100GB共享免费额度，原题未给是否已耗尽或月访问量。1000次查询/页面且额度未用时，A约50GB、B约0.5GB均为零Internet DTO，而D按Ohio例子的0.02/GB仍有出站费。若额度已耗尽，A与B按同一路径正单价收费，A的100倍传输量使其不再最低。两种具体情境都满足原题，最低结论改变。',missing=['月计费量/共享Internet免费额度是否耗尽及适用DX/Internet计费档。'],ev=['internet-free','dx-example','dx-metering'],issues=[{'subtype':'decisive_input_missing','confirmed':True,'counterexamples':['1000 queries/pages with unused100GB allowance: A/B both zero Internet DTO, DX positive.','Same traffic after allowance consumed: A Internet bill is100x B; A no longer a minimum candidate.']}],correction='另存练习明确共享免费额度已耗尽，并给出适用同Region DX与Internet正单价（DX更低）；只比较数据出站、已有端口费用视为相同，此时D。不得倒写成原题事实。'))
qs.append(Q(398,'SOURCE_ISSUE',[3],['GSC-077'], '按卡面数据量÷实际带宽，600TB×8/100Mbps=48000000秒，约555.6天，远超14天，A/B不因HTTPS/VPN消除物理带宽下限。GSC077及正证支持合格Snowball设备离线运输、加密；C是合格既有客户的方向。现行Snowball仅限既有客户，原题未给资格：既有客户可比较C的设备/物流方案，新客户不能按该选项订购，D则另取决于新10Gbps专线交付及费用。不是把所有Snowball判退役，也不拿缺生产SLA实测作源错。',conditions=['既有客户且容量/物流方案能覆盖两周时才可采用C；新客户C不可订购。'],ev=['snow-eligibility','snow-256','snow-kms'],issues=[{'subtype':'decisive_input_missing','confirmed':True,'counterexamples':['Eligible existing Snowball customer can order the encrypted offline devices.','New customer cannot order Snowball Edge under current official availability policy; same600TB/100Mbps original facts do not change.']}],correction='另存练习只补“公司是符合Snowball订购资格的既有客户”，并在确需保证窗口时把设备容量/运输导入时间作为已验证计划前提；不声称恢复原作者隐含资格。'))
qs.append(Q(558,'INSUFFICIENT_CARDS',[3],['CUR:CB16','GSC-075'], 'CB16说明两VPC直连及双向路由，GSC075说明TGW服务多网络中心转接，C是合理简单拓扑。两VPC500GB的题目优化目标是成本，但当前卡仍没教peering与TGW attachment/data-processing的计费差异；仅凭设备少不能当计费证明。VPN和DX也不是此直接同Region连接的已教最低费用路径。',missing=['同Region peering的同/跨AZ数据传输与TGW attachment/processing收费比较；500GB条件不能只作装饰。']))
qs.append(Q(620,'SUPPORTED',[3],['VC-014','GSC-014','GSC-032','CUR:NB04'], 'GSC014把实例停止/主机丢失后仍需保留的数据交给EBS等持久存储，排A临时instance store；GSC032/NB04说明Memcached是缓存且快照不是每次写入持久保存，不能替题中主持久存储。VC014把随机小I/O低延迟指向SSD而非D的吞吐HDD；给定选项C的Provisioned IOPS SSD最匹配一致低延迟与耐久。无需凭空添加gp3到原选项。',ev=['media']))
qs.append(Q(740,'SOURCE_ISSUE',[],['VC-013','CUR:CMP-M03','CUR:CMP-M20'], 'CMPM03说明默认不回写历史对象，CMPM20/VC013解释SSE-C逐请求提供客户key。A/D都要求把SSE-C设成桶自动默认，S3 API默认算法/配置明确不支持这种选择；B/C的默认SSE-KMS同样不改已有未加密对象，且AWS usage report不等于加密状态Inventory。无完整正确选项。copy-object一段声称桶默认可SSE-C与API冲突，已隔离；本结论用PutBucketEncryption及默认算法枚举、SSE-C逐请求机制正证确认。',ev=['s3-default-api','s3-default-enum','ssec-never-store','ssec-copy'],issues=[{'subtype':'unsupported_required_configuration','confirmed':True,'detail':'SSE-C cannot be the automatic bucket default algorithm; blocking/unblocking SSE-C is a different configuration.'}],correction='另存最小练习把A的未来对象部分改为逐请求提供SSE-C密钥，历史部分用支持SSE-C的copy/重写请求（可由清单驱动自定义处理），不声称原生S3 Batch Copy支持SSE-C；其余原选项保留。'))
qs.append(Q(881,'SUPPORTED',[1,5],['GSC-131','CUR:XA013'], 'GSC131说明default TTL只在源未给缓存时长时决定回存，max-age须服从min/max；A可给无显式源时长的对象2分钟缓存，E对指定对象给24小时max-age并在部署时失效更新版本，失效让后续回源。XA013明确viewer-response头修改不改变边缘已缓存对象TTL，排D；B不是S3桶默认TTL功能，C的private不对应共享边缘缓存目标。A/E不必被错误解释为同一对象同时强制两个TTL。',conditions=['按卡面min/max范围配置使目标缓存时长可生效；在部署发布修改对象后执行对应失效，普通实现不是额外新卡门槛。'],ev=['cf-default','cf-origin-viewer']))

near13=[c for c in base.values() if re.search(r'SSE|S3.*加密|加密.*S3|默认.*加密|copy|重写',json.dumps(c['visibleBody'],ensure_ascii=False),re.I)]
near14=[c for c in base.values() if re.search(r'IOPS|SSD|HDD|Lustre|gp3|io2|块卷',json.dumps(c['visibleBody'],ensure_ascii=False),re.I)]
subs=[]
for rid,near,nearest,why,qid in [
 ('VC-013',near13,['CUR:CMP-M20','CUR:CMP-M03','VC-011','CUR:CC09'],'CMPM20已教逐请求SSE-C与客户端加密差异，CMPM03已教默认不回写旧对象；VC011仅教SSE-S3/KMS。它们仍不能直接推出SSE-C不可设自动默认及支持SSE-C的copy/目标重加密请求。复用旧机制后保留真正新增能力边界，不把每条旧知识重复计新核心规则。',740),
 ('VC-014',near14,['GSC-005','GSC-014','GSC-015','GSC-016','GSC-051'],'Lustre卡讲文件系统SSD访问，014讲持久性，015/051讲gp性能范围、016讲条带/实例瓶颈；这些不直接教EBSSSD/HDD随机小I/O与连续吞吐的媒体/类型映射。当前051已换批10正文，仍是RDSgp3边界，没有替代本规则。',620)]:
    for r in nearest:bind_old(r)
    subs.append({'ruleId':rid,'status':'INDEPENDENT_NECESSARY_LOCAL_RULE_CANDIDATE_FINAL_CORE_ADMISSION_DEFERRED','frozenPoolCount':359,'effectiveAcceptedContextPoolCount':360,'candidateRuleIdsExamined':[c['ruleId'] for c in near],
        'nearestRuleIds':nearest,'visibleNearestCards':[{'ruleId':r,'bodySha256':base[r]['bodySha256'],'visibleBody':base[r]['visibleBody']} for r in nearest],'reason':why,'actualNecessaryOriginalQuestionIds':[qid],
        'lowFrequencyAdmission':'当前仅一题的真实必要用途不自动升级全库约300核心包纳入；本审查保留缺口/来源去向，不以标签或新增目标扩卡。','noExistingRuleDeleted':True})
for s in supplementary:
    if s['ruleId'] in proof_cache:assert proof_cache[s['ruleId']]
report={'schemaVersion':1,'batch':'supplemental12','reviewer':'independent actual content and full-original reviewer','status':'PASS_six_current_Chinese_local_cards_not_all_originals_supported','reviewedAtUtc':now(),'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'inputHashes':manifest,
    'priorReviewIndexPath':str(index_path),'priorReviewIndexSha256':index_hash,'legacyBodyBindingSourcePath':str(legacy_path),'legacyBodyBindingSourceSha256':sha(legacy_path),'frozenVisiblePoolCount':359,'effectiveAcceptedContextPoolCount':360,'candidateOverlayCount':6,'proposedNewCards':2,'revisedExistingCards':4,'appliedToCurrent':False,
    'additionalAccepted10Context':{'path':str(accepted10_path),'sha256':accepted10_hash,'onlySevenPASSUsed':True,'GSC024RejectedDraftUsed':False,'sixChangedFrozenVersions':drift,'bodyBindings':supplementary},
    'counts':{'cardPASS':6,'cardFAIL':0,'questionStatuses':dict(collections.Counter(q['status'] for q in qs))},'results':results,'questionImpactReview':qs,'usedExistingCardProofBindings':dict(sorted(proof_cache.items())),
    'evidenceRegistry':registry,'officialInputRecordValidation':input_validation,'newCardSubstitutionTests':subs,'newCardDomainMetadataReview':[{'ruleId':'VC-013','status':'PASS','primaryDomain':'1','primaryTask':'1.3','reason':'客户提供加密key与对象静态加密控制，主归安全数据控制。','evidenceIds':[E['domain1']]},{'ruleId':'VC-014','status':'PASS','primaryDomain':'3','primaryTask':'3.1','reason':'按I/O模式选择存储介质/类型，主归高性能存储。','evidenceIds':[E['domain3']]}],
    'sourceConflicts':[{'id':'S12-SSEC-DOC-CONFLICT','conflictingEvidenceId':E['copy-doc-conflict'],'resolutionEvidenceIds':[E['s3-default-api'],E['s3-default-enum'],E['ssec-never-store']],'resolution':'隔离copy-object声称默认SSE-C的段落；只采用其中目标copy显式加密及源key要求，并以S3 API配置/枚举确认默认能力。未更改来源快照。'}],
    'transferChecks':[{'ruleId':'GSC-078','conditionChange':'Internet免费额度未耗尽而DX仍按GB计费','status':'PASS','reason':'不能套通常较低单价强选DX；按实际计费档比较。'},{'ruleId':'GSC-077','conditionChange':'仅50Mbps可用于迁移而链路总带宽100Mbps','status':'PASS','reason':'用50Mbps计算，不能拿总带宽压缩期限。'},{'ruleId':'GSC-131','conditionChange':'源max-age24小时与default TTL2分钟同时存在','status':'PASS','reason':'default不强行覆盖明确max-age，须看min/max。'},{'ruleId':'VC-013','conditionChange':'复制源本身已为SSE-C','status':'PASS','reason':'除目标加密材料还需源解密key；只设桶默认不能代替。'},{'ruleId':'VC-014','conditionChange':'随机小I/O变成连续扫描大文件','status':'PASS','reason':'可比较HDD吞吐卷，不再只按数据库名字选io2。'}],
    'minimumRepairScope':{'cardRuleIds':[],'sourceCorrectionsOnlySuggestedFor':[240,398,740],'original558CardGapNotClosed':True},'formalBilingualAcceptance':False,'privateGradingContractAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'originalQuestionStatusesAutomaticallyPromoted':False,'currentPointersChangedByReviewer':False,'priorFailuresPreserved':True,'directCliApiCalls':0,'nativeUsage':'unknown','externalOfficialReadOnlyFetches':9}
out=O/'supplemental12.review.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
z=rd(out)
for r in z['results']:assert ch(r['visibleBody'])==r['bodySha256'] and r['fieldSha256']=={f:th(r['visibleBody'][f]) for f in FIELDS}
for q in z['questionImpactReview']:
    assert q['questionSha256']==ch(qb[q['qid']])
    for a in q['necessaryAnchors']:assert cards[a['ruleId']]['bodySha256']==a['bodySha256'] and cards[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
for eid,e in z['evidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256'] and s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256'] and ch(e)==eid
assert all(sha(p)==h for p,h in manifest.items()) and sha(index_path)==index_hash and sha(accepted10_path)==accepted10_hash
rb={'status':'PASS_review_serialization_and_exact_bindings','reviewPath':str(out),'reviewSha256':sha(out),'readBackAtUtc':now(),'counts':z['counts'],'checks':{'sixFourFieldHashesAndBodies':True,'sixFullOriginalsAllOptionsAndExactFrozenSet':set(qb)=={q['qid'] for q in qs},'allOfficialHashesOffsetsAndQuotes':True,'allNineInputEvidenceRecordsValidated':True,'changedBatch10VersionsPreciselyBound':True,'onlyValidCurrentOldProofsUsed':True,'allFrozenInputsUnchanged':True,'noProductionOrSourceMutation':True},'formalBilingualAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
(O/'supplemental12.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':str(out),'sha256':sha(out),'counts':z['counts']},ensure_ascii=False))


import json,pathlib,hashlib,collections
from datetime import datetime,timezone
OUT=pathlib.Path(__file__).resolve().parent
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
files=['reuse-results.json','question-reuse371.json','batch04.review.json','repair01.review.json','batch05.review.json','batch06.review.json','batch07.review.json','batch08.review.json','dependency5.review.json'];counts={};effective={}
for name in files:
 d=rd(OUT/name);counts[name]=d.get('counts');
 for p,h in d.get('inputHashes',{}).items():assert sha(p)==h,(name,p)
 if name.endswith('.review.json') and name!='dependency5.review.json':
  for r in d['results']:effective[r['ruleId']]=r
 for e in d.get('evidenceRegistry',{}).values():
  assert sha(e['sourcePath'])==e['sourceFileSha256'];s=rd(e['sourcePath'])['text'];assert s[e['startChar']:e['endChar']]==e['quote'];assert hashlib.sha256(e['quote'].encode()).hexdigest()==e['quoteSha256'];assert hashlib.sha256(s.encode()).hexdigest()==e['sourceTextSha256']
  if e.get('rawHtmlPath'):assert sha(e['rawHtmlPath'])==e['rawHtmlSha256']
assert len(effective)==46 and sum(r['status']=='PASS' for r in effective.values())==45
assert [r['ruleId'] for r in effective.values() if r['status']=='FAIL']==['GSC-066']
q=rd(OUT/'question-reuse371.json');assert len(q['results'])==371 and len(set(x['qid'] for x in q['results']))==371 and 868 not in {x['qid'] for x in q['results']};assert q['counts']=={'eligible_reuse':325,'needs_retest':46}
r=rd(OUT/'reuse-results.json');assert len(r['results'])==176 and r['counts']['eligibleFACT']==160 and r['counts']['eligibleTEACHING']==155
for p,x in r['frozenInputChecks'].items():assert sha(p)==x['actual']==x['expected']
result={'status':'PASS_readback_only','reviewedAtUtc':datetime.now(timezone.utc).isoformat(),'files':{str(OUT/n):sha(OUT/n) for n in files},'countsByArtifact':counts,'effectiveLocalAuthoredTaskResults':{'uniqueTasks':46,'PASS':45,'FAIL':1,'failedRuleIds':['GSC-066'],'repairsDoNotIncreaseUniqueTaskCount':True},'dependencyRechecks':5,'questionReuse':q['counts'],'checks':['All frozen review input files re-read by exact hash','All actual fresh quoted sources/offsets/quote/full-text hashes match','Acquired raw HTML hashes match','176 card and371 question dispositions exactly unique; Q868 excluded','Both old batch04 FAILs retained; repair01 local PASSs replace only those2 current bodies','One unresolved GSC066 task teaching issue retained'],'limits':['Readback is mechanical integrity, not a second semantic review.','45 local draft PASSs do not establish1018 question sufficiency or learner accuracy.','Any later body/context/scope edit must invalidate affected receipts.'],'directCliApiCalls':0,'nativeUsage':'unknown'}
(OUT/'reviewer-readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','effectiveLocalAuthoredTaskResults','dependencyRechecks','questionReuse']},ensure_ascii=False))

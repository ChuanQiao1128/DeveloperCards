import json,pathlib,hashlib,collections
from datetime import datetime,timezone
V=pathlib.Path(__file__).resolve().parents[2];OUT=V/'review/reuse-a';O=V.parent/'domain1-final-card-catalog-20261105'
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
manifest=rd(OUT/'input/batch04.manifest.json');assert all(sha(p)==h for p,h in manifest.items());cards=rd(V/'drafts/batch04.json');cat={e['sourceKey']:e for e in rd(O/'official-sources.catalog.json')};evidence={}
def proof(key,quote,claim):
 p=pathlib.Path(cat[key]['sourcePath']) if key in cat else OUT/'sources'/key;d=rd(p);txt=d['text'];assert quote in txt,(key,quote);st=txt.index(quote);e={'claim':claim,'url':d['url'],'sourcePath':str(p),'sourceFileSha256':sha(p),'sourceTextSha256':hashlib.sha256(txt.encode()).hexdigest(),'quote':quote,'startChar':st,'endChar':st+len(quote),'quoteSha256':hashlib.sha256(quote.encode()).hexdigest()};assert txt[e['startChar']:e['endChar']]==quote
 if key in cat:assert sha(p)==cat[key]['fileSha256'] and e['sourceTextSha256']==cat[key]['textSha256']
 else:
  raw=p.with_suffix('.html');assert raw.is_file() and sha(raw)==d['rawSha256'];e['rawHtmlPath']=str(raw);e['rawHtmlSha256']=sha(raw)
 eid=ch(e);evidence[eid]=e;return eid
E={}
E['cache']=proof('S0232','Even the most optimized database\nquery or remote API call is noticeably slower than retrieving a flat key from an in-memory\ncache.','缓存命中降低重复后端工作和响应延迟。')
E['rep']=proof('S0125','If the cluster with replicas has Multi-AZ enabled and the primary\nnode fails, the primary fails over to a read replica.','Valkey/Redis OSS复制组实际启用Multi-AZ才提供主节点故障接管。')
E['node']=proof('d6b8467069b03a9039a4.json','High availability (replication) No Yes Yes Automatic failover No Optional Required','该比较表只针对node-based部署：Memcached无复制或自动接管，Valkey/Redis OSS列提供对应特性。')
E['serverless']=proof('2d10ae623baa69279c7e.json','Serverless caches automatically mitigate node failures with a replicated Multi-AZ architecture so that node failures are transparent to your application.','该句位于Mitigating Failures when Running Memcached/Node Failures章节；Memcached serverless是无部署限定排除规则的反例。')
E['pool']=proof('S0264','RDS Proxy establishes a database connection pool and reuses connections in this pool.\nThis approach avoids the memory and CPU overhead of opening a new database connection each time.','连接池管理连接；不是存储查询结果的命中缓存。')
E['stale']=proof('S0162','Stale data. If data is written to the cache only when there is a cache miss, data in the cache can become stale. This result occurs because there are no updates to the cache when data is changed in the database. To address this issue, you can use the Write-through and Adding TTL strategies.','cache-aside/lazy-loading策略不会因数据库写入自动更新独立缓存；需要写入更新或相应失效方案。')
E['ttl']=proof('S0162',"This approach doesn't guarantee\nthat a value isn't stale. However, it keeps data from getting too stale and\nrequires that values in the cache are occasionally refreshed from the\ndatabase.",'TTL限制陈旧时间，不提供每次写后的立即最新。')
E['daxwrite']=proof('2b7c28a5dcc73d5efe28.json','DAX writes the item to its item cache.','DAX写入路径先完成DynamoDB写入再更新item cache，是把所有缓存概括为不自动维护的反例。')
E['sorted']=proof('S0232',"With Valkey or Redis OSS sorted sets you can move the computational complexity of leaderboards from your application to\nyour cluster.\n\nLeaderboards, such as the top 10 scores for a game, are computationally complex. This is\nespecially true when there is a large number of concurrent players and continually\nchanging scores. Valkey and Redis OSS sorted sets guarantee both uniqueness and element ordering.\nWith sorted sets, each time a new element is added to the sorted set it's reranked\nin real time. It's then added to the set in its correct numeric order.",'有序集合维持成员与分数排序并重新排名，适合持续变化的前十名。')
E['geo']=proof('76fd9345e20fe732cd54.json','Using GEOSEARCH , you can quickly find the vehicles in a given radius.','地理索引可按给定坐标半径查询邻近成员；无需应用先逐个GET所有对象。')
E['coords']=proof('8328264fa8927558e643.json','GEOPOS Returns the longitude and latitude of members from a geospatial index.','地理空间索引保存成员位置；纯按ID取键值不是距离查询。')
E['dax']=proof('S0051','As an in-memory cache, DAX reduces the response times of eventually consistent read workloads by an order of magnitude from single-digit milliseconds to microseconds.','DAX为DynamoDB最终一致读提供内存缓存和微秒响应，适用重复读。')
E['daxstrong']=proof('2b7c28a5dcc73d5efe28.json','DAX passes strongly consistent read requests to DynamoDB.','DAX强一致读取穿透到DynamoDB。')
E['daxnocache']=proof('2b7c28a5dcc73d5efe28.json','it does not cache the results.','强一致读取结果不进入DAX缓存。')
E['consistency']=proof('S0163','DynamoDB returns a response with the most\nup-to-date data, reflecting the updates from all prior write operations that were\nsuccessful. Strongly consistent reads are only supported on tables and local\nsecondary indexes. Strongly consistent reads from a global secondary index or a\nDynamoDB stream are not supported.','强一致读取反映此前成功写入；限制table/LSI，GSI/stream不支持。')
E['capacity']=proof('S0123','On-demand capacity mode is the better choice because it can handle\nfluctuating traffic without requiring you to predict or adjust capacity.','无法预测波动且不想管理容量时按需模式适合。')
E['provisioned']=proof('S0123','An ideal workload for provisioned capacity mode is one with a more steady and predictable\nusage pattern like the graph below.','稳定可预测业务可比较provisioned；并非任何稳定业务必然更便宜。')
E['bill']=proof('S0123','billing is based off of the total capacity\nprovisioned rather than the number of requests consumed.','provisioned按预置总容量收费；接近实际利用以控制成本。')
E['limit']=proof('S0123','your table will instantly accommodate requests to your table without the need to scale any\nresources up or down (up to twice the previous peak throughput of the table).','按需并非任意瞬时无限峰值；原卡不要求背数值。')
E['gt']=proof('S0040','Global tables automatically replicate your DynamoDB table data across AWS Regions and optionally across AWS accounts without\nrequiring you to build and maintain your own replication solution.','global tables提供跨Region受管复制；就近读写地域副本。')
E['gtactive']=proof('S0040','Any global table replica\ncan serve reads and writes.','每个地域副本可读写。')
E['gtmodes']=proof('S0040','Global tables\nsupport two consistency modes: multi-Region eventual consistency (MREC) and multi-Region\nstrong consistency (MRSC).','当前有MREC/MRSC两模式，不能把所有跨Region写入传播一概说成立即可见或一概仅最终一致。')
E['dttl']=proof('S0245','DynamoDB automatically deletes expired items within a few\ndays of their expiration time, without consuming write throughput.','TTL后台过期删除不在到期瞬间保证完成。')
E['filter']=proof('S0245','Use filter expressions to remove expired items from Scan and Query results.','读取时过滤过期项；不能因TTL打开就视为记录已即时消失。')
E['large']=proof('S0196','You can also store the item as an object in Amazon Simple Storage Service (Amazon S3) and store the Amazon S3 object identifier\nin your DynamoDB item.','大正文放S3，DynamoDB只存对象标识和查询元数据。')
E['sqsjava']=proof('77bb8b31146944b48b0f.json','Use the Amazon SQS Extended Client Library for Java','SQS Extended Client Java受支持，作为可选兼容实现而非强制先修。')
E['sqspayload']=proof('77bb8b31146944b48b0f.json','store the message payload in an Amazon S3 bucket','消息正文外置S3。')
E['sqsref']=proof('77bb8b31146944b48b0f.json','send a reference','队列发送引用；消费端或兼容库仍须取回正文。')
# Source-specific rationale is authored by this reviewer; source keys never count as evidence.
rows=[
('GSC-032',['cache','rep','node','serverless','pool'],'FAIL','清楚围绕缓存HA引擎选型且有减负因果。','当前题面未限定node-based；Memcached serverless也提供replicated Multi-AZ容错，不能据副本接管要求排除所有Memcached。','B04-FACT-032','仅将比较限定node-based，并明确相应Multi-AZ接管条件；不新增durability知识任务。'),
('GSC-033',['stale','ttl','daxwrite'],'FAIL','读到旧值的具体情境和数据库/缓存两份数据的因果易懂；TTL边界正确。','当前“缓存不会自动跟数据库变”的答与原因泛化所有缓存；DAX支持经DAX写后自动维护item cache。独立cache-aside缓存假设需在题面明确。','B04-FACT-033','将对象限定为应用维护的独立ElastiCache/cache-aside缓存；保留更新/失效和TTL原因，不扩成所有缓存策略清单。'),
('GSC-034',['sorted'],'PASS','玩家/分数及前十名使有序集合的排序用途可理解；答案和原因恰好对应结构选择。','普通键值按ID取对象与维护全体排序是同一决策差异。',None,None),
('GSC-035',['geo','coords'],'PASS','门店坐标和附近查询明确一个空间检索任务；随文解释地理索引用途，未要求记GEO命令。','普通按ID获取没有距离筛选语义；索引查询支持按半径取得邻近成员。RedisUseCases原URL目前只重定向文档根目录，已用真实官方命令及场景页补证，不以URL可打开抵扣。',None,None),
('GSC-036',['dax','daxstrong','daxnocache'],'PASS','重复项目读与亚毫秒条件直接导向兼容DynamoDB缓存；命中机制清楚。','强一致路径转发DynamoDB且不缓存；卡面不承诺任何读取都获微秒或强一致。仅当前DynamoDB局部用途。',None,None),
('GSC-037',['consistency','daxstrong','daxnocache'],'PASS','要求读到此前成功写入，因此改变一致性而非以缓存代替可见性。','GSI例外明示，答案限定支持接口；不要求学习者补背API清单。',None,None),
('GSC-038',['capacity','provisioned','bill','limit'],'PASS','同一容量模式取舍，按不可预测/稳定可规划条件对比，原因连接管理负担和预置容量费用。','使用“考虑/比较/可更经济”保留成本适用范围，未许诺稳定就必省；按需有限伸缩边界准确。',None,None),
('GSC-039',['gt','gtactive','gtmodes'],'PASS','多Region就近读写是单一架构判断；跨Region受管复制解释了为什么单一地域表不足。','提醒按模式区分一致性，不误说所有global table均仅最终一致，也不承诺所有写立即全球可见；不考模式配置清单。',None,None),
('GSC-040',['dttl','filter'],'PASS','到期不可展示与TTL后台清理的机制差异清楚；直接给读取过滤动作。','未删过期项仍可被读出，不能把TTL当精确即时删除或访问控制；一个判断与原因。',None,None),
('GSC-041',['large','sqsjava','sqspayload','sqsref'],'PASS','数据库/消息接口共享同一正文外置规则；对象引用如何供消费者取回有明确说明。','Java库仅是可选实现，未列为自评必答；没有将单独S3 URL当作任意消费代码会自动下载。',None,None)
]
results=[]
for cid,ks,status,teaching,fact,fid,repair in rows:
 c=next(c for c in cards if c['ruleId']==cid);h=ch({k:c[k] for k in ['frontZH','answerZH','keyPointZH','watchOutZH'] if c.get(k)});gates={'FACT':status,'U1':'PASS','R1':'PASS','T1':'FAIL' if status=='FAIL' else 'PASS','S1':'PASS','P1':'PASS','B1':'N/A_chinese_stage'}
 results.append({'ruleId':cid,'bodySha256':h,'fullDraftSha256':ch(c),'status':status,'gates':gates,'factReason':fact,'teachingReason':teaching,'prerequisiteReason':'本次场景中的必要服务/结构在正文中说明用途；未要求先修卡才能补出答案。仅局部中文任务，非全题充分。','assessmentReason':'问面给定前提不列额外必答；可按可见答案的主要结论及考点原因自评。未提供私有mustAnswer，未凭空认定存在其验收。','factEvidenceIds':[E[k] for k in ks],'findings':[{'id':fid,'gate':'FACT/T1','severity':'P1','detail':fact,'requiredRepair':repair}] if fid else []})
transfers=[{'ruleId':'GSC-032','changedCondition':'Memcached采用ElastiCache Serverless，仍要求托管Multi-AZ容错。','result':'FAIL_current_scope','why':'当前正文仍会把它一概排除；必须增加node-based范围才能保住原判断。'},{'ruleId':'GSC-033','changedCondition':'数据库写入经DAX客户端，读取对应item cache。','result':'FAIL_current_scope','why':'DAX会维护该item cache；当前泛指缓存的绝对句没有容纳这个反例。'},{'ruleId':'GSC-037','changedCondition':'改成读取GSI。','result':'PASS','why':'watchOut已明确不能把强一致结论套到GSI；同一题面必须改访问路径或接受其一致性，不能仅打开强一致。'},{'ruleId':'GSC-038','changedCondition':'稳定平均流量中出现不可预测急剧突发，且不想管理容量。','result':'PASS','why':'前后条件比较及按需机制可以解释为何重新考虑on-demand，提醒也限制无限瞬时峰值。'}]
assert {r['ruleId'] for r in results}=={c['ruleId'] for c in cards} and len(results)==10
for e in evidence.values():
 d=rd(e['sourcePath']);assert sha(e['sourcePath'])==e['sourceFileSha256'];assert d['text'][e['startChar']:e['endChar']]==e['quote']
assert all(sha(p)==h for p,h in manifest.items())
report={'schemaVersion':1,'reviewer':'reuse-a independent actual-content review','batch':'batch04','reviewedAtUtc':datetime.now(timezone.utc).isoformat(),'inputManifestPath':str(OUT/'input/batch04.manifest.json'),'inputManifestSha256':sha(OUT/'input/batch04.manifest.json'),'inputHashes':manifest,'bodyHashContract':'SHA256 UTF8 canonical JSON frontZH/answerZH/keyPointZH/watchOutZH, absent empty omitted; ensure_ascii=False sort_keys=True separators=(comma,colon)','counts':dict(collections.Counter(r['status'] for r in results)),'status':'FAIL_requires_targeted_repair','results':results,'evidenceRegistry':evidence,'transferChecks':transfers,'allSnapshotQuoteOffsetHashChecksPassed':True,'acquisitionNotes':['4 initial Python urllib requests failed local trust-store validation and were not used; curl succeeded with normal TLS verification.','RedisUseCases.html redirected to a 18-character ElastiCache root landing stub; excluded as proof.','Additional official snapshots acquired only under review/reuse-a/sources, raw HTML retained.'],'limits':['10 frozen Chinese drafts only; B1 not applicable until bilingual authoring.','No original-question full sufficiency review performed in this batch.','No measured learner memory/accuracy or formal-card acceptance claim.','8 valid results remain usable without repeated semantic review if their exact bodies and dependencies are unchanged.'],'directCliApiCalls':0,'nativeUsage':'unknown'}
(OUT/'batch04.review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'counts':report['counts'],'failures':[r['ruleId'] for r in results if r['status']=='FAIL'],'evidence':len(evidence),'reviewSha256':sha(OUT/'batch04.review.json')},ensure_ascii=False))

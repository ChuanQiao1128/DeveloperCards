# -*- coding: utf-8 -*-
import pathlib, json, hashlib, collections, datetime, re

V = pathlib.Path(__file__).resolve().parents[3]
P = V / 'review/supplemental15/input'
O = V / 'review/reuse-a'
W = O / 'supplemental15-work'
FIELDS = ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']
def rd(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s): return hashlib.sha256(s.encode()).hexdigest()
def ch(x): return th(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
def body(c): return {f: c.get(f, '') for f in FIELDS}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest = rd(P/'manifest.json')
assert all(sha(p) == h for p, h in manifest.items())
base = {c['ruleId']: c for c in rd(P/'visible-pool.frozen.json')}
drafts = rd(P/'cards.json')
cards = dict(base)
for c in drafts:
    rid = c['ruleId']
    if c.get('repairOf') and c['repairOf'] != base[rid]['bodySha256']:
        assert rid == 'GSC-130' and c['priorAcceptedBodySha256'] == base[rid]['bodySha256']
        failed14 = json.loads((V/'review/reuse-a/supplemental14.review.json').read_text())
        failed_row = next(r for r in failed14['results'] if r['ruleId'] == rid)
        assert failed_row['status'] == 'FAIL' and failed_row['bodySha256'] == c['repairOf']
    elif c.get('repairOf'): assert c['repairOf'] == base[rid]['bodySha256']
    cards[rid] = {'ruleId': rid, 'visibleBody': body(c), 'bodySha256': ch(body(c)), 'prerequisiteRuleIds': c.get('prerequisiteRuleIds', base.get(rid, {}).get('prerequisiteRuleIds', []))}
assert len(base) == 362 and len(cards) == 362 and len(drafts) == 9
assert all(ch(c['visibleBody']) == c['bodySha256'] for c in cards.values())
index_path = V/'validation/current-card-review-index.json'
index_hash = sha(index_path)
index = {x['ruleId']: x for x in rd(index_path)['cards']}
legacy_path = V/'inputs/existing176.json'
legacy = {c['ruleId']: c for c in rd(legacy_path)}
proof_cache = {}
def bind_old(rid):
    if rid in proof_cache: return proof_cache[rid]
    c = base[rid]; ix = index[rid]
    assert ix['status'] == 'PASS' and ix['currentBodySha256'] == c['bodySha256']
    out = []
    for p in ix['proofs']:
        assert sha(p['path']) == p['sha256']
        d = rd(p['path']); rs = d.get('results', d.get('cards', []))
        if isinstance(rs, dict): rs = list(rs.values())
        matches = [x for x in rs if x.get('ruleId') == rid]
        assert matches, (rid, p['path'])
        r = matches[-1]; rh = r['bodySha256']
        contract = 'canonical four-field current visible body including empty values'
        if rh != c['bodySha256']:
            lb = body(legacy[rid]['body'])
            assert lb == c['visibleBody'] and ch({f: s for f, s in lb.items() if s}) == rh, rid
            contract = 'legacy omitted-empty hash; exact four visible fields reconstructed from hash-bound existing176 and matched'
        elif 'visibleBody' in r: assert r['visibleBody'] == c['visibleBody'], rid
        z = {'ruleId': rid, 'path': p['path'], 'sha256': p['sha256'], 'receiptBodySha256': rh, 'currentPriorBodySha256': c['bodySha256'], 'bodyBindingContract': contract}
        if r.get('proofs'):
            for pp in r['proofs']: assert sha(pp['path']) == pp['sha256']
            z['parentGateReceipts'] = r['proofs']
        out.append(z)
    proof_cache[rid] = out
    return out

registry = {}
def cite(p, needle, length, claim, occurrence=0):
    p = pathlib.Path(p)
    if not p.is_absolute(): p = V/p
    d = rd(p); s = d['text']; positions = [m.start() for m in re.finditer(re.escape(needle), s)]
    assert positions, (p, needle)
    start = positions[occurrence]; q = s[start:start+length]
    z = {'claim': claim, 'url': d['url'], 'sourcePath': str(p), 'sourceFileSha256': sha(p), 'sourceTextSha256': th(s), 'quote': q, 'startChar': start, 'endChar': start+len(q), 'quoteSha256': th(q)}
    if d.get('rawSha256') and p.with_suffix('.html').exists():
        z.update(rawHtmlPath=str(p.with_suffix('.html')), rawHtmlSha256=d['rawSha256'])
        assert sha(z['rawHtmlPath']) == z['rawHtmlSha256']
    if d.get('textSha256'): assert th(s) == d['textSha256']
    eid = ch(z); registry[eid] = z
    return eid

inputs = rd(P/'official-evidence.json'); input_validation = []
for i, e in enumerate(inputs):
    d = rd(e['snapshotPath']); s = d['text']
    assert sha(e['snapshotPath']) == e['snapshotSha256'] and th(s) == e['textSha256']
    assert s[e['quoteStart']:e['quoteEnd']] == e['quote'] and d['url'] == e['url']
    input_validation.append({'ordinal': i, 'url': e['url'], 'snapshotPath': e['snapshotPath'], 'snapshotSha256': e['snapshotSha256'], 'textSha256': e['textSha256'], 'quoteStart': e['quoteStart'], 'quoteEnd': e['quoteEnd'], 'quoteSha256': th(e['quote']), 'status': 'PASS_literal_hash_offset_validation'})
def src(i, needle, n, claim): return cite(inputs[i]['snapshotPath'], needle, n, claim)

overlay_ids={c['ruleId'] for c in drafts};drift=[];incremental=[]
for rid,c in list(base.items()):
    if index.get(rid,{}).get('currentBodySha256')==c['bodySha256']:continue
    drift.append({'ruleId':rid,'frozenBodySha256':c['bodySha256'],'currentBodySha256':index[rid]['currentBodySha256']})
    if rid!='GSC-073':continue
    found=None
    for p in index[rid]['proofs']:
        assert sha(p['path'])==p['sha256'];d=rd(p['path'])
        for r in d.get('results',d.get('cards',[])):
            if r.get('ruleId')==rid and r.get('bodySha256')==index[rid]['currentBodySha256'] and r.get('visibleBody'):found=(r,p)
    assert found and index[rid]['status']=='PASS';r,p=found;assert ch(r['visibleBody'])==r['bodySha256']
    nc=dict(c);nc.update(visibleBody=r['visibleBody'],bodySha256=r['bodySha256'],prerequisiteRuleIds=r.get('prerequisiteRuleIds',c.get('prerequisiteRuleIds',[])));base[rid]=nc;cards[rid]=nc
    incremental.append({'ruleId':rid,'frozenBodySha256':c['bodySha256'],'currentBodySha256':nc['bodySha256'],'visibleBody':nc['visibleBody'],'proofPath':p['path'],'proofSha256':p['sha256'],'frozenInputChanged':False})
E={}
E['multivalue']=src(9,'To route traffic roughly at random',1240,'Multivalue supports roughly random resource routing, up to8healthy records;<=8returns all healthy records, with client selection still relevant.')
E['weighted']=src(8,'Amazon Route 53 sends traffic to a resource',660,'Weighted routing sets relative traffic shares; equal weights provide equal DNS record selection shares.')
E['weighted-api']=cite(W/'sources/r53-record-api.json','Weight Weighted resource record sets only:',1900,'Route53 API defines response ratios and equal-probability handling; the card does not promise deterministic perHTTP request ratios.')
E['athena-distributed']=src(11,'Athena uses Trino, an open-source, in-memory, distributed SQL engine',335,'Athena SQL distributed execution supports parallel S3 processing, not only Spark mode.')
E['athena-s3']=src(6,'Amazon Athena is an interactive',650,'Athena queries S3 with SQL and is serverless.')
E['glue-serverless']=src(0,"It's also serverless, which means there's no infrastructure to manage.",520,'Glue manages ETL execution infrastructure.')
E['glue-spark']=src(0,'Apache Spark–based serverless ETL engine',430,'Glue can execute actual ETL on Spark.')
E['glue-workers']=src(3,'NumberOfWorkers – Number (integer).',460,'Glue allocates multiple defined workers to a job; Spark distributes processing among them.')
E['private-direction']=cite('review/corrected-variants09/work/sources/privatelink-third-party.json','However, it is limited to only TCP traffic and unidirectional communication.',355,'Provider workloads cannot initiate reverse communication through PrivateLink to consumer account.')
E['private-publish']=src(1,'As a service consumer',710,'Endpoint service is provider publication and interface endpoint is consumer connection.')
E['io1']=src(2,'io1 volumes can range in size',490,'io1 max64000IOPS,50:1IOPS/GiB,64000requires>=1280GiB; retain originalQ919 contradiction.')
E['peering-cost']=src(7,'There is no charge to create a VPC peering connection.',420,'Peering has no connection charge; sameAZ transfer free and crossAZ/Region transfer charges remain.')
E['tgw-cost']=cite('review/gap-b/evidence/tgw-price.json','For AWS VPN attachments',1550,'Transit Gateway attachments billed hourly; data processing charged separately. This is the actual TGW pricing source, not NAT pricing.')
E['tgw-example']=cite('review/gap-b/evidence/tgw-price.json','Transit Gateway data processing charge: 1 GB',450,'Published TGW example charges0.02USD per GB plus attachment hour fee; validate the extra fee categories independently.')
E['cf-key']=src(10,'CachingOptimized View this policy in the CloudFront console',1120,'CachingOptimized excludes query/cookies and only normalizesAccept-Encoding, so forwardedAuth/query does not isolate cache entries.')
E['cf-min-ttl']=src(10,'Minimum TTL: 1 second.',1060,'CachingOptimized minTTL1second can override no-cache/no-store/private; this belongs to TTL/freshness rule131.')
E['cf-ttl-combination']=src(4,'If you opt out of using a cache policy',1150,'Default TTL/max-age and min/max interplay; unchanged freshness mechanism remains within rule131.')
E['redshift-spark']=cite('review/final-core-closure01/a/official-evidence/catalogue-068.snapshot.json','This integration provides you with a Spark connector',760,'EMR/Glue can read and write Redshift; technical original nonuniqueness is separate from visible card support.')
E['lf-workflow']=cite('review/final-core-closure01/a/official-evidence/lakeformation-workflows.snapshot.json','A workflow encapsulates',640,'Lake Formation workflows generate realGlue ETL jobs, not just permission metadata.')
E['lf-redshift']=cite('review/final-core-closure01/a/official-evidence/lakeformation-redshift-glue-query.snapshot.json','After you grant permissions',425,'Redshift federation can be consumed byGlue/EMR/Athena.')
E['ssec-per-request']=cite('review/reuse-a/sources/1365ab42d2e9245bcd42.json','S3 never stores the encryption key',610,'SSE-C requires request-provided key; current acceptedVC013 teaches this.')
E['ssec-default-api']=cite('review/reuse-a/supplemental12-work/sources/s3-put-encryption.json','By default, all buckets have a default encryption configuration',800,'Default SSE-S3/KMS/DSSE does not injectSSE-C key; original unsupportedSSE-C default requirement remains a source defect.')
E['ssec-copy']=cite('review/reuse-a/sources/c5b37bd83a94a9925b77.json','When copying an object, if you want to use a different type of encryption setting',730,'Explicit per-object copy can select customer encryption; sourceSSE-C copy needs sourcekey. Conflicting defaultSSE-C paragraph is not used.')
E['http-products']=cite('review/supplemental11/evidence/http-compare.snapshot.json','Authorization options\nREST API\nHTTP API',360,'HTTP API lacks resource policy but supports Lambda custom authorization; do not replace it with REST silently.')
E['http-authorizer']=cite('review/reuse-a/sources/1b383afb20c04d33b7c6.json','You use a Lambda authorizer to use a Lambda function to control access',610,'HTTP API invokes the authorizer to decide access.')
E['http-sourceip']=cite('review/reuse-a/sources/1b383afb20c04d33b7c6.json','"http": { "method": "POST"',200,'Payload2.0 requestContext.http.sourceIp is supplied by API Gateway.')
E['http-cache']=cite('review/reuse-a/sources/1b383afb20c04d33b7c6.json','You can enable caching for a Lambda authorizer',940,'Authorizer cache keys are identity sources; cache TTL0 avoids crossIP sharing when sourceIP decisions differ.')

reason={
'GSC-128':'仍是多健康地址DNS回答与真正负载均衡代理的区别，补随机及8地址范围解释服务如何分流，不要求记整套健康检查部署。',
'GSC-127':'按权重概率选择补足同一个按比例发布机制；保留DNS缓存与逐HTTP请求比例不保证的边界。',
'CUR:CC03':'并行扫描说明Athena执行SQL的工作机制，不新增第二个任务；原加密兼容条件沿有效事实凭证精确复用。',
'GSC-095':'Spark多worker分担说明真实ETL执行，而crawler只是目录。批/流输入、无服务器执行与并行均服务同一“谁真正转换数据”判断，不要求记worker配额。',
'CUR:CMP-M04':'消费端发起及不能反向新建连接属于同一发布/消费接口机制；没有添加泛化双向VPC路由清单。',
'GSC-016':'单卷上限是何时需要聚合与实例余量检查的具体例子，保留“先看瓶颈在卷还是实例”的同一因果。',
'CUR:CB16':'直接两VPC peering不引入中转网关，也避免中转附件/处理费；同一拓扑选择的成本后果，仍保留实际传输与CIDR限制。',
'GSC-130':'本稿只解释哪些字段应进入缓存键及CachingOptimized具体遗漏项，移除了独立TTL任务；不同语言/身份是同一内容变体规则的迁移。',
'GSC-131':'最小TTL/no-store/CachingOptimized1秒均属于同一缓存寿命和新鲜度机制，未混入身份缓存键的独立任务。'}
keys={'GSC-128':['multivalue'],'GSC-127':['weighted','weighted-api'],'CUR:CC03':['athena-distributed','athena-s3'],'GSC-095':['glue-serverless','glue-spark','glue-workers'],'CUR:CMP-M04':['private-direction','private-publish'],'GSC-016':['io1'],'CUR:CB16':['peering-cost','tgw-cost','tgw-example'],'GSC-130':['cf-key'],'GSC-131':['cf-min-ttl','cf-ttl-combination']}
results=[]
for c in drafts:
    rid=c['ruleId'];results.append({'ruleId':rid,'status':'PASS','gates':dict({g:'PASS' for g in ['FACT','U1','R1','T1','S1','P1']},B1='N/A_chinese_stage'),'visibleBody':body(c),'bodySha256':ch(body(c)),
        'fieldSha256':{f:th(c.get(f,'')) for f in FIELDS},'fullDraftSha256':ch(c),'priorAcceptedBodySha256':base[rid]['bodySha256'],'repairOf':c.get('repairOf'),'namedValidPriorFACTProofs':bind_old(rid),'evidenceIds':[E[k] for k in keys[rid]],
        'teachingAndRecallTaskReason':reason[rid],'prerequisiteRuleIds':cards[rid]['prerequisiteRuleIds'],'assessmentCheck':'只评本卡主要判断和关键原因；不要求复述已给条件、提示数字或未问的配置。私有mustAnswer未提供，不据此验收正式评分或双语。','findings':[]})

qb={q['qid']:q['question'] for q in rd(P/'questions.json')};cvs=rd(P/'corrected-cases.json')
canonical_path=V.parent/'domain1-final-card-catalog-20261105/questions.all.json';canonical=rd(canonical_path)
def A(rid,fields=('answerZH','keyPointZH','watchOutZH')):
    c=cards[rid];return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'startChar':0,'endChar':len(c['visibleBody'][f]),'candidateOverlay':rid in overlay_ids} for f in fields if c['visibleBody'].get(f)]
def Q(qid,status,opts,ids,reason,q=None,missing=(),conditions=(),ev=(),source=None):
    aa=sum([A(r) for r in ids],[]);todo=list(ids);seen=set();pre=[]
    while todo:
        r=todo.pop()
        if r in seen:continue
        seen.add(r)
        if r not in overlay_ids:bind_old(r)
        for dep in cards[r].get('prerequisiteRuleIds',[]):pre.append({'from':r,'ruleId':dep,'bodySha256':cards[dep]['bodySha256'],'visibleBody':cards[dep]['visibleBody']});todo.append(dep)
    q=q or qb[qid]
    return {'qid':qid,'status':status,'selectedOptionOrdinals':opts if status=='SUPPORTED' else [],'candidateOptionOrdinals':opts,'questionSha256':ch(q),'stemUtf8Sha256':th(q['stem']),'optionsCanonicalSha256':ch(q['options']),
        'completeStemAndEveryOptionRead':True,'usedRuleIds':ids,'necessaryAnchors':aa,'recursiveUsedPrerequisiteBindings':pre,'reasoningAndClosestCompetitor':reason,'minimumRemainingJudgments':list(missing),'conditions':list(conditions),'officialEvidenceIds':[E[k] for k in ev],'sourceFinding':source,'noPrivateTargetsOrPrintedAnswersUsed':True,'noOfficialSourceSubstitutedForMissingVisibleCard':True}
qs=[]
qs.append(Q(224,'SOURCE_ISSUE',[2,3,4,5],['GSC-127','GSC-128','GSC-126','GSC-116'], '现在127明示权重随机选择，128明示随机健康多地址，B/C均可在适用DNS层面分流；126主备不是所有实例都参与。116要求剩余容量，不要求各AZ实例数必相等；D/E在剩余AZ容量足够时都可满足HA。原Choose two有多种路由/布局组合，不能因为卡句补齐就强选C/E。',ev=['weighted-api','multivalue'],source={'subtype':'non_unique_valid_combinations','confirmed':True,'validCombinations':[[2,4],[2,5],[3,4],[3,5]]}))
qs.append(Q(557,'SOURCE_ISSUE',[1,2,4],['CUR:CC03','GSC-095','GSC-097','CUR:XB010','GSC-102'], 'CC03现在明确Athena并行扫描S3，095明确Spark多worker并行ETL；097提供EMR分布式处理，XB010给出Glue JDBC/LakeFormation蓝图读取关系数据进S3湖，102给出RedshiftSQL API。A可Athena处理S3再由Glue读取Redshift富化，B可在分布式程序中取得Redshift结果，D可用LF蓝图生成的Glue摄取/ETL链路。C的数据流本身不自动完成既有S3数据与Redshift关系富化。现行A/B/D并非唯一单选。',ev=['athena-distributed','redshift-spark','lf-workflow','lf-redshift'],source={'subtype':'multiple_current_feasible_paths','confirmed':True,'validAlternatives':[1,2,4]}))
qs.append(Q(558,'SUPPORTED',[3],['CUR:CB16','GSC-075','CUR:NB01'], '两VPC无需中心转接，CB16给出直接peering及两侧路由，并新教连接本身无费、可避免TGW附件小时费和处理费，仍计AZ传输；500GB/月场景没有多网络中心拓扑收益去抵消新增中转收费，C。A引入TGW收费，B引入VPN路径/设备，D也不是两个同RegionVPC所需的本地数据中心专线入口。这里使用可见收费类别取舍，不把peering说成所有流量绝对免费。',conditions=['按正常兼容CIDR及实际子网路由实施；若实际CIDR重叠则peering不可用，不把该未给特殊障碍补入原题。'],ev=['peering-cost','tgw-cost','tgw-example']))
qs.append(Q(919,'SOURCE_ISSUE',[],['GSC-016'], '新016可解释单卷已满、实例仍有余量时用条带化聚合；但原文1TB io1已配64000IOPS违反官方50:1比例，64000至少1280GiB。B超过io1单卷64000上限；C增加容量不能使原基线成为真实已发生配置；D是否改善实例路径取决于真实瓶颈。未静默把源容量改成2TB后升级原题。',ev=['io1'],source={'subtype':'invalid_stated_configuration','confirmed':True,'detail':'1TB io1 with64000IOPS exceeds50IOPS/GiB; source original preserved.'}))
qs.append(Q(949,'SOURCE_ISSUE',[2,4],['CUR:CMP-M04','GSC-075','CUR:NB01'], 'CMPM04现已明确消费端发起且提供方不能沿端点反向新建连接，能解释D的服务私网路径；GSC075也允许供应商支持的TGW连接。原C在to establish.处截断，规范源也保留同一缺失，不能替原作者补a connection后直接把C当完整选项。供应商实际支持未给，也不能预设它不许TGW来强排B。',ev=['private-direction'],source={'subtype':'truncated_option_and_unstated_provider_paths','confirmed':True,'originalMissingWordsStillUnknown':True}))
qs.append(Q(1004,'SOURCE_ISSUE',[2,3],['CUR:CA13','CUR:NS02','GSC-130','GSC-131','GSC-073','CUR:NB01'], 'CA13提供HTTP边缘缓存/回源，NS02提供GA边缘到AWS网络路径。130说明CachingOptimized不按Auth/查询隔离，131说明其正最小TTL可覆盖no-store。原API若公共可共享则B有缓存收益，若身份相关且禁止共享则B不适用，可考虑C；原题未给这种决定性响应属性，不能从ERP名称推断。A把publicVIF和DXgateway用途混同，D普通InternetVPN不是同等全球加速路径。',ev=['cf-key','cf-min-ttl'],source={'subtype':'decisive_input_missing','confirmed':True,'examples':['Public shared cacheable responses permitB.','Identity-specific nonshareable responses invalidate statedCachingOptimizedB.']}))

cvrows=[]
for c in cvs:
    qid=c['originalQid'];orig=c['originalQuestion'];corr=c['correctedQuestion'];assert orig==canonical[str(qid)] and ch(orig)==c['originalQuestionCanonicalSha256'] and ch(corr)==c['correctedQuestionCanonicalSha256']
    if qid==224:
        r=Q(qid,'SUPPORTED',[2,3,4,5],['GSC-127','GSC-128','GSC-126','GSC-116'], '127/128补齐两种DNS随机分流，126排主备用；练习明确剩余AZ容量足够且布局为替代部署，116因此允许D/E。全选B/C/D/E，不把两布局同时部署或要求每个HTTP请求精确均分。',q=corr,ev=['weighted-api','multivalue']);m='只改为全部可行路由/布局并补必要剩余容量，保留原HA/随机目标。'
    elif qid==557:
        r=Q(qid,'SUPPORTED',[1,2,4],['CUR:CC03','GSC-095','GSC-097','CUR:XB010','GSC-102'], '当前卡组已经教会Athena/Glue/EMR并行执行、实际ETL/JDBC摄取和RedshiftSQL取数，能按所需机制解释A/B/D三条处理/富化链路。LF负责生成Glue工作流和治理，不把权限目录本身当计算；程序仍实现实际关联转换，C仅建数据流不等于完成富化。',q=corr,ev=['athena-distributed','redshift-spark','lf-workflow','lf-redshift']);m='仅把单选改为全部有效，S3半结构化、并行与Redshift富化目标不变。'
    elif qid==949:
        r=Q(qid,'SUPPORTED',[2,3,4],['CUR:CMP-M04','GSC-075','CUR:NB01'], '练习已明确供应商同时支持TGW附件及PrivateLink服务，075支撑B的VPC中心路由，CMPM04完整支撑C消费端发起/禁止该端点反向新连接与D的私网服务入口。A普通S2SVPN经公共互联网，不等于题设的直接AWS私网替代路径；不额外添未给的DX私有VPN底座来改写弱干扰项。',q=corr,ev=['private-direction']);m='明确练习条件并补全同一PrivateLink方向表述，未宣称恢复原C缺失文字；改全选保留多路径。'
    elif qid==1004:
        r=Q(qid,'SUPPORTED',[3],['CUR:CA13','CUR:NS02','GSC-130','GSC-131','GSC-073','CUR:NB01'], '身份相关且不可共享已经明确，130的键规则和131的TTL规则分别解释CachingOptimized不能安全处理B，而不是仅凭no-store假设它不会缓存。NS02给出GA网络加速且不共享业务缓存，C匹配。A错误混用publicVIF/DXgateway，D普通VPN不提供所需加速机制；不为此新练习改造原ERP事实。',q=corr,ev=['cf-key','cf-min-ttl']);m='只补决定性身份/共享缓存条件，保留最省费与响应加速目标。'
    elif qid==740:
        r=Q(qid,'SUPPORTED',[1],['VC-013','CUR:CMP-M03','CUR:CMP-M20'], 'VC013教会旧对象显式copy重写、后续逐请求SSE-C及允许写入设置；CMPM03给出清单驱动处理历史对象，CMPM20保留SSE-C服务器收到后加密的定义。修订A由Inventory定位后受控逐对象copy，按大小使用所需multipart，并让未来每次写入提供key，覆盖旧/新两阶段。B/C默认KMS不回写旧对象且不等于SSE-C，D仍要求不支持的默认SSE-C。multipart、权限和重试为普通落地，不据未列完整手册制造新卡门槛。',q=corr,ev=['ssec-per-request','ssec-default-api','ssec-copy']);m='仅把A不支持的原生BatchSSE-C/自动默认组合替为受支持逐对象copy+逐请求key，保留客户提供key及已有/未来对象目标。'
    else:
        assert qid==1019
        r=Q(qid,'SUPPORTED',[2],['CUR:XA053','CUR:CA19'], '当前XA053直接教HTTPAPI不支持REST资源策略，但可用Lambda authorizer读取可信requestContext.http.sourceIp并判断CIDR，且TTL0避免跨不同IP复用Allow。修订B逐项符合；A的private integration只接后端不构成调用者IP准入，C/D不能直接把受管HTTPAPI放私网子网/NACL或给它附SG来完成来源筛选。',q=corr,ev=['http-products','http-authorizer','http-sourceip','http-cache']);m='仅替换B为HTTPAPI真正支持的入口控制，保留HTTPAPI产品及可信来源IP限制；没有换成REST逃避原约束。'
    r.update(variantId=c['variantId'],originalQid=qid,originalQuestionCanonicalSha256=ch(orig),correctedQuestionCanonicalSha256=ch(corr),completeOriginalAndCorrectedEveryOptionRead=True,originalDefectIndependentlyConfirmed=True,minimalityVerdict='PASS',minimalityReview=m,standalonePracticeCardGroupStatus='SUPPORTED',closureEligibleUnderAcceptedCorrectionPolicy=True,originalStatusNotUpgraded=True)
    if qid==740:r['originalDefectEvidenceIds']=[E['ssec-default-api'],E['ssec-per-request']]
    if qid==1019:r['originalDefectEvidenceIds']=[E['http-products']]
    cvrows.append(r)

used={a['ruleId'] for q in qs+cvrows for a in q['necessaryAnchors']}|{d['ruleId'] for q in qs+cvrows for d in q['recursiveUsedPrerequisiteBindings']}
failed14_path=O/'supplemental14.review.json';failed14_receipt=next(r for r in rd(failed14_path)['results'] if r['ruleId']=='GSC-130');assert failed14_receipt['status']=='FAIL'
new130=next(r for r in results if r['ruleId']=='GSC-130')
report={'schemaVersion':1,'batch':'supplemental15','reviewer':'independent actual card/original/practice reviewer','status':'PASS_nine_local_Chinese_cards_and_six_corrected_practices_original_source_issues_preserved','reviewedAtUtc':now(),'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'inputHashes':manifest,
 'frozenVisiblePoolCount':362,'candidateOverlayCount':9,'newCards':0,'appliedToCurrent':False,'currentReviewIndexPath':str(index_path),'currentReviewIndexSha256':index_hash,'legacyBodyBindingSourcePath':str(legacy_path),'legacyBodyBindingSourceSha256':sha(legacy_path),
 'frozenToCurrentBodyDrift':drift,'explicitCurrentIncrementalDependencies':incremental,'usedIncrementalRuleIds':[r['ruleId'] for r in incremental if r['ruleId'] in used],
 'counts':{'cardPASS':9,'cardFAIL':0,'originalQuestionStatuses':dict(collections.Counter(q['status'] for q in qs)),'correctedPracticeStatuses':dict(collections.Counter(q['status'] for q in cvrows)),'correctedMinimalityPASS':6,'correctionClosureEligible':6},
 'results':results,'questionImpactReview':qs,'correctedVariantImpactReview':cvrows,'usedExistingCardProofBindings':dict(sorted(proof_cache.items())),'evidenceRegistry':registry,'officialInputRecordValidation':input_validation,
 'failureClosure':[{'findingId':'S14-GSC130-R1','status':'CLOSED_BY_TARGETED_REPAIR','priorReviewPath':str(failed14_path),'priorReviewSha256':sha(failed14_path),'priorFailedBodySha256':failed14_receipt['bodySha256'],'priorAcceptedBodySha256':base['GSC-130']['bodySha256'],'repairBodySha256':new130['bodySha256'],'repairAttempt':1,'reason':'130只保留内容缓存键，TTL1秒/no-store例子归131的同一寿命机制。','oldFailureRetained':True}],
 'transferChecks':[{'ruleId':'GSC-127','conditionChange':'新旧入口改相等权重','status':'PASS','reason':'得到相等DNS选择概率，不保证逐HTTP请求严格均分。'},{'ruleId':'GSC-128','conditionChange':'健康记录从4增至12','status':'PASS','reason':'单次最多8个回答，不等于代理全部连接；<=8仍可返回全部健康记录。'},{'ruleId':'CUR:CC03','conditionChange':'只登记表定义不实际执行SQL','status':'PASS','reason':'目录本身不会并行扫描/处理S3数据。'},{'ruleId':'GSC-095','conditionChange':'crawler改成受支持SparkETL多worker','status':'PASS','reason':'实际转换工作被执行并可并行分担，目录发现不等价。'},{'ruleId':'CUR:CMP-M04','conditionChange':'提供方尝试沿同端点新建反向连接','status':'PASS','reason':'消费入口不是反向通用VPC互联。'},{'ruleId':'GSC-016','conditionChange':'单卷有余量、实例EBS路径已满','status':'PASS','reason':'继续加卷不能突破实例瓶颈。'},{'ruleId':'CUR:CB16','conditionChange':'两VPC变大量互联网络','status':'PASS','reason':'应重比中心拓扑/管理收益与费用，不把两VPCpeering成本规则外推全部网络规模。'},{'ruleId':'GSC-130','conditionChange':'语言内容变体改身份/查询参数变体','status':'PASS','reason':'仍须把真正区分内容的值放入键；只转发不等于隔离。'},{'ruleId':'GSC-131','conditionChange':'源no-store但所选策略minTTL1秒','status':'PASS','reason':'不能据源头部假设零缓存，仍按最小TTL边界判断。'}],
 'minimumRepairScope':{'cardRuleIds':[],'affectedVariantsNowClosed':['Q224-CV09','Q557-CV09','Q949-CV09','Q1004-CV10','Q740-CV05','Q1019-CV05'],'Q764TargetRepairNotInThisPackage':True},
 'formalBilingualAcceptance':False,'privateGradingContractAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'originalQuestionStatusesAutomaticallyPromoted':False,'priorFailuresPreserved':True,'currentPointersChangedByReviewer':False,'authoringPerformed':False,'externalOfficialReadOnlyFetches':2,'directCliApiCalls':0,'nativeUsage':'unknown'}
rp=O/'supplemental15.review.json';rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
z=rd(rp)
for r in z['results']:assert ch(r['visibleBody'])==r['bodySha256'] and r['fieldSha256']=={f:th(r['visibleBody'][f]) for f in FIELDS}
assert len(qs)==6 and len(cvrows)==6
for q in qs+cvrows:
    for a in q['necessaryAnchors']:assert cards[a['ruleId']]['bodySha256']==a['bodySha256'] and cards[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
    for d in q['recursiveUsedPrerequisiteBindings']:assert cards[d['ruleId']]['bodySha256']==d['bodySha256'] and cards[d['ruleId']]['visibleBody']==d['visibleBody']
for eid,e in z['evidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256'] and s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256'] and ch(e)==eid
assert all(sha(p)==h for p,h in manifest.items()) and sha(index_path)==index_hash
rb={'status':'PASS_current_local_review_readback','reviewPath':str(rp),'reviewSha256':sha(rp),'inputManifestSha256':sha(P/'manifest.json'),'readBackAtUtc':now(),'counts':z['counts'],
 'checks':{'nineCanonicalFourFieldBodiesAndPerFieldHashes':True,'sixCompleteOriginalsEveryOption':True,'sixCompleteEmbeddedOriginalAndCorrectedEveryOption':True,'allExactNecessaryAnchorsAndRecursivePrerequisites':True,'allNamedCurrentPriorProofsAndExplicitVersionDeltas':True,'all12FrozenOfficialEvidenceRecordsValidated':True,'allOfficialFileTextQuoteOffsetsAndHashes':True,'failed14GSC130LineageAndSingleRepairRetained':True,'allFrozenInputsStillUnchanged':True,'originalAndPracticeStatusesSeparate':True,'noCurrentSourceProductionOrHistoryMutation':True},
 'formalBilingualAcceptance':False,'learnerEffectMeasured':False,'finalNVerified':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
(O/'supplemental15.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':str(rp),'sha256':sha(rp),'counts':z['counts']},ensure_ascii=False))


# -*- coding: utf-8 -*-
import pathlib, json, hashlib, collections, datetime, re

V = pathlib.Path(__file__).resolve().parents[3]
P = V / 'review/supplemental14/input'
O = V / 'review/reuse-a'
W = O / 'supplemental14-work'
FIELDS = ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']
def rd(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s): return hashlib.sha256(s.encode()).hexdigest()
def ch(x): return th(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
def body(c): return {f: c.get(f, '') for f in FIELDS}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest = rd(P/'manifest.json')
assert all(sha(p) == h for p, h in manifest.items())
base = {c['ruleId']: c for c in rd(P/'visible-pool.frozen.json')}
drafts = rd(P/'cards.json')
cards = dict(base)
for c in drafts:
    rid = c['ruleId']
    if c.get('repairOf'): assert c['repairOf'] == base[rid]['bodySha256']
    cards[rid] = {'ruleId': rid, 'visibleBody': body(c), 'bodySha256': ch(body(c)), 'prerequisiteRuleIds': c.get('prerequisiteRuleIds', base.get(rid, {}).get('prerequisiteRuleIds', []))}
assert len(base) == 362 and len(cards) == 362 and len(drafts) == 7
assert all(ch(c['visibleBody']) == c['bodySha256'] for c in cards.values())
index_path = V/'validation/current-card-review-index.json'
index_hash = sha(index_path)
index = {x['ruleId']: x for x in rd(index_path)['cards']}
legacy_path = V/'inputs/existing176.json'
legacy = {c['ruleId']: c for c in rd(legacy_path)}
proof_cache = {}
def bind_old(rid):
    if rid in proof_cache: return proof_cache[rid]
    c = base[rid]; ix = index[rid]
    assert ix['status'] == 'PASS' and ix['currentBodySha256'] == c['bodySha256']
    out = []
    for p in ix['proofs']:
        assert sha(p['path']) == p['sha256']
        d = rd(p['path']); rs = d.get('results', d.get('cards', []))
        if isinstance(rs, dict): rs = list(rs.values())
        matches = [x for x in rs if x.get('ruleId') == rid]
        assert matches, (rid, p['path'])
        r = matches[-1]; rh = r['bodySha256']
        contract = 'canonical four-field current visible body including empty values'
        if rh != c['bodySha256']:
            lb = body(legacy[rid]['body'])
            assert lb == c['visibleBody'] and ch({f: s for f, s in lb.items() if s}) == rh, rid
            contract = 'legacy omitted-empty hash; exact four visible fields reconstructed from hash-bound existing176 and matched'
        elif 'visibleBody' in r: assert r['visibleBody'] == c['visibleBody'], rid
        z = {'ruleId': rid, 'path': p['path'], 'sha256': p['sha256'], 'receiptBodySha256': rh, 'currentPriorBodySha256': c['bodySha256'], 'bodyBindingContract': contract}
        if r.get('proofs'):
            for pp in r['proofs']: assert sha(pp['path']) == pp['sha256']
            z['parentGateReceipts'] = r['proofs']
        out.append(z)
    proof_cache[rid] = out
    return out

registry = {}
def cite(p, needle, length, claim, occurrence=0):
    p = pathlib.Path(p)
    if not p.is_absolute(): p = V/p
    d = rd(p); s = d['text']; positions = [m.start() for m in re.finditer(re.escape(needle), s)]
    assert positions, (p, needle)
    start = positions[occurrence]; q = s[start:start+length]
    z = {'claim': claim, 'url': d['url'], 'sourcePath': str(p), 'sourceFileSha256': sha(p), 'sourceTextSha256': th(s), 'quote': q, 'startChar': start, 'endChar': start+len(q), 'quoteSha256': th(q)}
    if d.get('rawSha256') and p.with_suffix('.html').exists():
        z.update(rawHtmlPath=str(p.with_suffix('.html')), rawHtmlSha256=d['rawSha256'])
        assert sha(z['rawHtmlPath']) == z['rawHtmlSha256']
    if d.get('textSha256'): assert th(s) == d['textSha256']
    eid = ch(z); registry[eid] = z
    return eid

inputs = rd(P/'official-evidence.json'); input_validation = []
for i, e in enumerate(inputs):
    d = rd(e['snapshotPath']); s = d['text']
    assert sha(e['snapshotPath']) == e['snapshotSha256'] and th(s) == e['textSha256']
    assert s[e['quoteStart']:e['quoteEnd']] == e['quote'] and d['url'] == e['url']
    input_validation.append({'ordinal': i, 'url': e['url'], 'snapshotPath': e['snapshotPath'], 'snapshotSha256': e['snapshotSha256'], 'textSha256': e['textSha256'], 'quoteStart': e['quoteStart'], 'quoteEnd': e['quoteEnd'], 'quoteSha256': th(e['quote']), 'status': 'PASS_literal_hash_offset_validation'})
def src(i, needle, n, claim): return cite(inputs[i]['snapshotPath'], needle, n, claim)

incremental=[];frozen_hashes={r:c['bodySha256'] for r,c in base.items()};overlay_ids={c['ruleId'] for c in drafts}
for rid,c in list(base.items()):
    if index.get(rid,{}).get('currentBodySha256')==c['bodySha256']:continue
    assert rid not in overlay_ids and index[rid]['status']=='PASS',rid
    found=None
    for p in index[rid]['proofs']:
        assert sha(p['path'])==p['sha256'];d=rd(p['path'])
        for r in d.get('results',d.get('cards',[])):
            if r.get('ruleId')==rid and r.get('bodySha256')==index[rid]['currentBodySha256'] and r.get('visibleBody'):found=(r,p)
    assert found,rid
    r,p=found;assert ch(r['visibleBody'])==r['bodySha256'];nc=dict(c);nc.update(visibleBody=r['visibleBody'],bodySha256=r['bodySha256'],prerequisiteRuleIds=r.get('prerequisiteRuleIds',c.get('prerequisiteRuleIds',[])))
    base[rid]=nc;cards[rid]=nc;incremental.append({'ruleId':rid,'frozenBodySha256':frozen_hashes[rid],'currentBodySha256':nc['bodySha256'],'visibleBody':nc['visibleBody'],'proofPath':p['path'],'proofSha256':p['sha256'],'frozenInputMutated':False})

E={}
E['aurora-threshold']=src(0,'Aurora I/O-Optimized is the best choice when your I/O spending is',895,'Aurora official storage guide distinguishes I/O>=25% and<25% bill shares; large traffic alone is not this metric.')
E['aurora-pricing']=src(4,'Aurora I/O-Optimized delivers improved price performance',690,'Aurora I/O-Optimized has no read/write request fees and may save up to40% when I/O spending>25%.')
E['fgw-no-lock']=src(1,'S3 File Gateway does not support NFS file locking.',405,'Explicit prohibition of NFS locking; nolock is not merely inferred from an example mount command.')
E['efs-lock']=src(7,'NFS client applications can use NFS version 4 file locking',695,'EFS supports NFSv4 byte-range advisory locking; applications coordinate writes, locks are not mandatory enforcement.')
E['cachingoptimized']=src(5,'CachingOptimized View this policy in the CloudFront console',1700,'CachingOptimized key omits identity/query inputs and has minimumTTL1s overriding no-store/private. Two mechanisms are factually distinct.')
E['cost-tag']=src(12,'Tag A label that you can use to track the costs',420,'Cost Explorer tags are a supported business/entity grouping/filter dimension; identity attribution requires an actual mapping.')
E['cost-dimensions']=src(12,'With Cost Explorer, you can filter how you view your AWS costs',700,'Available cost dimensions include linked account/tag, not universal automatic per-IAM-user billing for every resource/service.')
E['sct-offline']=src(11,'For very large database migrations',1030,'SCT replication agent seeds data viaS3/Snowball while running with DMS; later data reaches target endpoint.')
E['dms-cdc']=src(10,'The task then applies the change data capture (CDC) logs',760,'After offline initial copy,DMS applies CDC then cuts over when source/target are at same transaction level.')
E['dx-vifs']=src(3,'Private virtual interface: A private virtual interface',700,'Private/public/transit VIF role and Direct Connect gateway/TGW linkage.')
E['dx-global']=src(6,'A Direct Connect gateway is a globally available resource.',565,'DX gateway is global and can connect different Regions subject to documented partitions.')
E['dx-nontransitive']=src(6,'A Direct Connect gateway does not allow gateway associations',1600,'VGW associations do not automatically exchange traffic; documented supernet/on-premises routing exception must not be hidden.')
E['sitelink']=src(3,"SiteLink If you're creating a private or transit virtual interface",655,'SiteLink is an optional feature enabling DC PoP-to-PoP paths; not automatically provided by creating aDXgateway.')
E['vg-cached']=src(13,'cache',1000,'Volume Gateway cached/stored concepts; online cache miss and local storage scope.')
E['vg-outbound']=src(2,'Data Transfer OUT from the AWS Storage Gateway service to your on-premises gateway appliance',850,'Gateway cloud-to-on-premises transport has its own pricing; online retrieval is not an archive restore job nor a promise ofzero transport cost.')
E['snow-current']=cite('review/reuse-a/supplemental12-work/sources/snow-faq.json','NOTICE: Effective November 7, 2025',360,'Snowball only existing customers; current qualification affects Q435 feasibility.')

reasons={
'GSC-059':'一个总费判断：按I/O费占比而不是流量或实例单价选计费模式。25%阈值与40%示例落实同一条件，不额外记存储卷配置。',
'GSC-012':'同一接口语义选择：普通NFS/SMB到S3与必须NFSv4共享锁区别；客户端用锁协调写入是机制，未声称EFS锁强制阻止所有冲突。',
'GSC-130':'主体只问语言变体缓存键。新增提醒先讲身份/查询参数是否入键，又讲最小TTL覆盖no-store，这两个独立机制不能从对方推出，构成额外回忆任务。',
'GSC-154':'仍是资源标签到可用账单维度的激活/归属机制，Owner只是同一业务标签的实例，不把IAM身份本身误当所有服务计费维度。',
'GSC-060':'一个初始状态与后续变化的迁移因果链，离线只改变初始大批数据的运输方式，CDC仍负责持续变化；不另考Snowball部署参数。',
'GSC-073':'VIF/网关决定地址和网络可达范围；跨RegionVGW及transitVIF是同一到达路径选择，非自动传递是作用边界，不要求背完整网络手册。',
'GSC-010':'仍以主数据在哪里决定stored/cached；未命中回源的等待/传输费是同一机制的后果，不能将在线读误当Glacier恢复或误称全免费。'}
keys={'GSC-059':['aurora-threshold','aurora-pricing'],'GSC-012':['fgw-no-lock','efs-lock'],'GSC-130':['cachingoptimized'],'GSC-154':['cost-tag','cost-dimensions'],'GSC-060':['sct-offline','dms-cdc'],'GSC-073':['dx-vifs','dx-global','dx-nontransitive','sitelink'],'GSC-010':['vg-cached','vg-outbound']}
results=[]
for c in drafts:
    rid=c['ruleId'];failed=rid=='GSC-130';gates={g:'PASS' for g in ['FACT','U1','R1','T1','S1','P1']};gates['B1']='N/A_chinese_stage'
    if failed:gates.update(U1='FAIL_two_independent_cache_mechanisms',R1='FAIL_extra_TTL_recall_task')
    results.append({'ruleId':rid,'status':'FAIL' if failed else 'PASS','gates':gates,'visibleBody':body(c),'bodySha256':ch(body(c)),'fieldSha256':{f:th(c.get(f,'')) for f in FIELDS},'fullDraftSha256':ch(c),
        'priorBodySha256':base[rid]['bodySha256'],'namedValidPriorFACTProofs':bind_old(rid),'evidenceIds':[E[k] for k in keys[rid]],'teachingAndRecallTaskReason':reasons[rid],
        'prerequisiteRuleIds':cards[rid]['prerequisiteRuleIds'],'assessmentCheck':'只评本卡主要所问判断和关键原因，给定条件与提醒不列为附加必答；不把Owner映射或私有制作信息当学习者已知。私有mustAnswer未提供，不验收正式评分/双语。',
        'findings':[{'id':'S14-GSC130-R1','priority':'P1','field':'watchOutZH','quote':'且其最小TTL为1秒，可覆盖源站no-store等要求',
            'reason':'语言/身份是否共用缓存键与缓存保留多久独立；TTL约束已有GSC131教学，不应为少卡压进此卡。',
            'minimumRepair':'保留CachingOptimized不含Authorization/查询参数的同一键隔离边界，移出新增最小TTL/no-store任务；如确有需要，复用GSC131相应机制，不默认新增卡。'}] if failed else []})

qb={x['qid']:x['question'] for x in rd(P/'questions.json')};corrected=rd(P/'corrected-cases.json')
def A(rid,fields=('answerZH','keyPointZH','watchOutZH')):
    c=cards[rid];return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'startChar':0,'endChar':len(c['visibleBody'][f]),'candidateOverlay':rid in overlay_ids} for f in fields if c['visibleBody'].get(f)]
def Q(qid,status,opts,ids,reason,missing=(),conditions=(),ev=(),source=None,q=None):
    aa=sum([A(r) for r in ids],[]);seen=set();todo=list(ids);pre=[]
    while todo:
        r=todo.pop()
        if r in seen:continue
        seen.add(r)
        if r not in overlay_ids:bind_old(r)
        for dep in cards[r].get('prerequisiteRuleIds',[]):pre.append({'from':r,'ruleId':dep,'bodySha256':cards[dep]['bodySha256'],'visibleBody':cards[dep]['visibleBody']});todo.append(dep)
    q=q or qb[qid];failed='GSC-130' in ids
    assert status!='SUPPORTED' or not failed
    return {'qid':qid,'status':status,'selectedOptionOrdinals':opts if status=='SUPPORTED' else [],'candidateOptionOrdinals':opts,'questionSha256':ch(q),'stemUtf8Sha256':th(q['stem']),'optionsCanonicalSha256':ch(q['options']),
        'completeStemAndEveryOptionRead':True,'usedRuleIds':ids,'necessaryAnchors':aa,'recursiveUsedPrerequisiteBindings':pre,'reasoningAndClosestCompetitor':reason,'minimumRemainingJudgments':list(missing),'conditions':list(conditions),'officialEvidenceIds':[E[k] for k in ev],'sourceFinding':source,'usesTeachingFailedCandidateOverlay':failed,'noPrivateTargetsOrPrintedAnswersUsed':True,'noSourceQuoteUsedAsExtraLearningCard':True}
qs=[]
qs.append(Q(284,'SOURCE_ISSUE',[2],['GSC-154','GSC-153'], 'Owner或部门已正确标记并激活时，新154支持Cost Explorer按该tag汇总导出，B效率高；但原题只说by user，并未说明user是成员账户、资源Owner还是实际调用者，也未给资源到人的归属数据。已激活Owner标签可汇总与没有归属记录的共享资源两种场景都符合原文，后者不能由下载Cost Explorer自动生成全服务真实用户成本。Athena也须有可查询的归属/账单数据；C账单不是自动用户映射，D预算告警不是该报表。',missing=['user/部门归属定义及已有记录方式；不能把卡片明确给定的Owner前提补入原题。'],ev=['cost-tag','cost-dimensions'],source={'subtype':'decisive_input_missing','confirmed':True,'examples':['Owner标签正确且已激活：B可直接按Owner汇总。','共享资源没有任何用户/部门归属记录：Cost Explorer不会凭IAM身份自动恢复全服务分摊。']}))
qs.append(Q(435,'SOURCE_ISSUE',[1],['GSC-060','GSC-077'], '新060正证给出SCT/Snowball初始副本+DMS持续CDC，支持A方向的低停机机制；只是全量拷贝不能追上仍写入源。当前Snowball仅限既有客户，原题未给资格，合格客户可比较A，而新客户不能按A订购。20TB两周期限还要比较既有带宽/新DX交付与实际费用，不能凭旧答案排除D的在线CDC；B/C的型号/价格不以猜测替代核验。',missing=['Snowball现行客户资格及实际迁移链路/交付成本；硬件C具体可订购性/费用本包未独立证实，不据此强排。'],ev=['snow-current','sct-offline','dms-cdc'],source={'subtype':'decisive_input_missing','confirmed':True,'examples':['既有合格客户可订购Snowball并用受支持seed+CDC流程。','新客户不能订购相同Snowball设备；同20TB/两周条件下A可行性改变。']}))
qs.append(Q(728,'SUPPORTED',[2],['GSC-010','CUR:CMP-M01','VC-006'], '新010明示cached以S3为主、热点留本地，缺失块在线回源而不是Glacier归档恢复，并将出站传输另计；B因此缓解本地容量、缓存减少重复带宽且无需额外归档取回过程。C/D仍要求完整数据留本地，不能解决本地容量耗尽；A归档加速取回仍有等待/费用。这里支持的是普通在线取回而非归档取回费，不声称所有云端传输/请求零账单。',conditions=['按题目“retrieval”通常指归档取回这一费用边界理解；若要求连所有云端出站传输也绝对零费，则需明确该更强条件，B不提供此保证。'],ev=['vg-outbound','vg-cached']))
qs.append(Q(734,'CONDITIONAL',[4],['GSC-073','GSC-075','CUR:CB16'], '073明确private VIF经全球DXgateway可到不同Region的VGW/VPC，D可减少逐VPC连接管理。A的peering不提供数据中心经对端VPC网关的传递路由，B没有D明确的跨Region网关聚合，C自管全mesh运维高。但题目“Regions and data centers”具体要哪些网络对互通没有展开；D默认并不自动把各VGW及两数据中心互连。官方还存在supernet经本地路由例外及可选SiteLink，不能把“非自动传递”误说成任何配置绝对不可能。',missing=['若明确需要DC↔DC/VPC↔VPC的全互通，当前卡尚未教SiteLink或相关受支持转接/路由例外的完整选型判断。'],conditions=['主要目标为各机房到跨RegionVPC的可扩展连接时D；完整任意两网络互通须先明确连接矩阵并安排相应受支持路径。'],ev=['dx-global','dx-nontransitive','sitelink']))
qs.append(Q(806,'SOURCE_ISSUE',[2,3,4],['GSC-012','GSC-001','GSC-002'], '新012正向区分普通NFS文件到S3与必须NFSv4字节锁：若应用只要普通文件接口、S3对象及缓存，B可行；若实际靠共享NFSv4锁协调，FileGateway明确不支持，EFS C/D才保留所需语义。原题只写NFS，未给锁/语义或AZ存活、冷热费用条件；不能强加多AZ排D，也不能自动把所有NFS等同FileGateway。A的块卷备份不是普通S3桶供Lifecycle管理的文件对象入口。',missing=['真正所需NFS锁/共享语义、AZ存活需求及冷热/访问费用输入。'],ev=['fgw-no-lock','efs-lock'],source={'subtype':'decisive_input_missing','confirmed':True,'examples':['普通文件上传到S3且不依赖NFS锁：FileGateway可保留接口。','应用依赖NFSv4共享字节锁：FileGateway不可行，EFS支持该语义。']}))
qs.append(Q(827,'SOURCE_ISSUE',[1,4],['GSC-059','GSC-057'], '059明确Aurora按Standard/IO-Optimized集群计费比较，B/C的普通RDS卷类型不适用。大流量不能推出I/O请求费占比：官方指出I/O费低于25%时Standard更合适，达到/超过25%时重点IO-Optimized。两种负载都可高流量但缓存/计算占比不同，原题没有决定性费用构成，不能强选D。',missing=['同负载Aurora Standard基线中的I/O请求费占总费用比例。'],ev=['aurora-threshold','aurora-pricing'],source={'subtype':'decisive_input_missing','confirmed':True,'examples':['I/O占总费10%的高流量负载：Standard更合适。','I/O占总费40%的高流量负载：IO-Optimized为官方建议范围。']}))
qs.append(Q(1004,'SOURCE_ISSUE',[2,3],['CUR:CA13','CUR:NS02','GSC-130','GSC-073','CUR:NB01'], 'CA13说明CloudFront边缘缓存/回源，NS02说明GA经边缘/AWS网络到端点。对公众相同且可缓存API响应，B有有效缓存路径；对按认证身份返回且不得共享缓存的数据，CachingOptimized不含身份键且有正最小TTL，不能直接采用B。GA加速网络不共享业务响应，可考虑C；A把public VIF与DXgateway混成同一到达路径，D的普通Internet VPN不是专用全球加速网络。原题没给响应可缓存性/身份边界，不能据ERP一词补私有响应，也不能一律当公共静态结果。GSC130教学FAIL不用于升级新卡接受。',missing=['API响应可缓存与身份隔离条件，以及比较网络/缓存的适用费用输入。'],ev=['cachingoptimized'],source={'subtype':'decisive_input_missing','confirmed':True,'examples':['可共享公共GET结果：CachingOptimized可复用边缘响应。','用户身份相关且禁止共享：同策略不按身份分键，不能直接使用。']}))

cv=[]
for c in corrected:
    qid=c['originalQid'];assert c['originalQuestion']==qb[qid] and ch(c['originalQuestion'])==c['originalQuestionCanonicalSha256'] and ch(c['correctedQuestion'])==c['correctedQuestionCanonicalSha256']
    if qid==806:
        z=Q(qid,'SUPPORTED',[3,4],['GSC-012','GSC-001','GSC-002'], '明确要求NFSv4字节锁后，012正证排FileGateway；EFS保持共享NFS语义并自动扩容量，Regional与OneZone都可在未要求AZ存活的练习里作候选，C/D。OneZone不是因为原题没说冗余就自动错误；要比较实际可用性、冷热访问和跨AZ传输费后才排名。A是块卷并非可按S3Lifecycle直接管理的文件对象存储。',q=c['correctedQuestion'],ev=['fgw-no-lock','efs-lock']);mr='仅补决定性共享锁事实，保留未给AZ存活约束，并把成本排名改为识别所需输入，未强塞多AZ偏好。'
    elif qid==827:
        z=Q(qid,'SUPPORTED',[4],['GSC-059','GSC-057'], '练习明确同负载Standard账单I/O占40%，超过059所教官方25%重点采用范围，D。不是由大流量直接推断，更没有把Aurora当普通RDS选gp3/io2。',q=c['correctedQuestion'],ev=['aurora-threshold']);mr='只补原题缺失的同负载I/O费用占比40%，保留性能和MOST cost-effective目标，选项不变。'
    else:
        z=Q(qid,'INSUFFICIENT_CARDS',[3],['CUR:CA13','CUR:NS02','GSC-130','GSC-073','CUR:NB01'], '身份相关且禁止共享响应已明确，CachingOptimized不能按Auth隔离的事实已查正；C网络加速方向成立，A/D不提供同等适用路径。但用于排B的新增130稿本次因独立TTL任务堆叠教学FAIL，不能把失败稿当已接受学习卡后宣称练习完成。仅定向收窄130并保留同一key隔离句后可回测本练习，不须重审全部题库。',missing=['GSC130需先成为一个可接受的缓存键回忆任务；其Auth/查询参数策略边界须以可接受正文绑定。'],q=c['correctedQuestion'],ev=['cachingoptimized']);mr='只补响应身份/共享边界作为明确练习设定，保留最省费目标；不把此条件倒写成ERP原题事实。'
    z.update(variantId=c['variantId'],originalQid=qid,originalQuestionCanonicalSha256=ch(c['originalQuestion']),correctedQuestionCanonicalSha256=ch(c['correctedQuestion']),completeOriginalAndCorrectedAllOptionsRead=True,originalDefectIndependentlyConfirmed=True,minimalityVerdict='PASS',minimalityReview=mr,standalonePracticeCardGroupStatus=z['status'],closureEligibleUnderAcceptedCorrectionPolicy=z['status']=='SUPPORTED',originalStatusNotUpgraded=True)
    cv.append(z)

used={a['ruleId'] for q in qs+cv for a in q['necessaryAnchors']}|{d['ruleId'] for q in qs+cv for d in q['recursiveUsedPrerequisiteBindings']}
report={'schemaVersion':1,'batch':'supplemental14','reviewer':'independent seven-card/full-original/affected-practice reviewer','status':'FAIL_one_card_requires_targeted_teaching_repair','reviewedAtUtc':now(),'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'inputHashes':manifest,
 'frozenVisiblePoolCount':362,'candidateOverlayCount':7,'newCards':0,'appliedToCurrent':False,'currentReviewIndexPath':str(index_path),'currentReviewIndexSha256':index_hash,'legacyBodyBindingSourcePath':str(legacy_path),'legacyBodyBindingSourceSha256':sha(legacy_path),
 'explicitCurrentVersionIncrementalContext':incremental,'incrementalUsedRuleIds':[r['ruleId'] for r in incremental if r['ruleId'] in used],
 'counts':{'cardPASS':6,'cardFAIL':1,'originalQuestionStatuses':dict(collections.Counter(q['status'] for q in qs)),'correctedPracticeStatuses':dict(collections.Counter(q['status'] for q in cv)),'correctedMinimalityPASS':3,'correctionClosureEligible':sum(q['closureEligibleUnderAcceptedCorrectionPolicy'] for q in cv)},
 'results':results,'questionImpactReview':qs,'correctedVariantImpactReview':cv,'usedExistingCardProofBindings':dict(sorted(proof_cache.items())),'evidenceRegistry':registry,'officialInputRecordValidation':input_validation,
 'transferChecks':[{'ruleId':'GSC-059','conditionChange':'I/O账单占比40%变为10%','status':'PASS','reason':'应重比Standard而非仍套I/O-Optimized；高流量本身不足。'},{'ruleId':'GSC-012','conditionChange':'不使用共享锁变为必须NFSv4字节锁','status':'PASS','reason':'FileGateway的nolock不再适用，转EFS等支持语义的文件系统。'},{'ruleId':'GSC-130','conditionChange':'只转发语言头，改成只转发Authorization但key仍相同','status':'PASS_local_mechanism_overall_teaching_FAIL','reason':'仍可能共享不同身份内容；这一key机制可复用，不能再夹入独立TTL任务。'},{'ruleId':'GSC-154','conditionChange':'Owner标签已加但未激活','status':'PASS','reason':'不能直接当可用账单维度，也不能补造历史归属。'},{'ruleId':'GSC-060','conditionChange':'全量副本用离线设备运入，源仍写入','status':'PASS','reason':'仍须持续CDC追赶；离线初始副本不替后续变化。'},{'ruleId':'GSC-073','conditionChange':'跨RegionVPC目的地址变为两个机房互通','status':'PASS','reason':'不能把全球DXgateway自动当任意网络传递路由，需另看实际受支持路径。'},{'ruleId':'GSC-010','conditionChange':'缓存命中变为未命中','status':'PASS','reason':'会在线回源，不需Glacier恢复，但可能发生出站传输费。'}],
 'minimumRepairScope':{'cardRuleIds':['GSC-130'],'findingIds':['S14-GSC130-R1'],'affectedOriginalQuestionIds':[1004],'affectedVariantIds':['Q1004-CV10'],'otherSixCardResultsReusableWithExactHashes':True,'otherTwoVariantResultsReusableWithExactDependencies':True},
 'sourceBoundaryNotes':['DX gateway非自动传递并非绝对不能互通：官方有supernet/on-premises例外和可选SiteLink，本审查未隐藏。','Owner/身份、Snowball资格、NFS锁、Aurora费用占比、API缓存身份条件均不得反写原题。','Q728的no additional retrieval cost未扩成所有请求/出站传输绝对免费。'],
 'formalBilingualAcceptance':False,'privateGradingContractAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'originalQuestionStatusesAutomaticallyPromoted':False,'priorFailuresPreserved':True,'currentPointersChangedByReviewer':False,'authoringPerformed':False,'externalOfficialReadOnlyFetches':0,'directCliApiCalls':0,'nativeUsage':'unknown'}
rp=O/'supplemental14.review.json';rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
z=rd(rp)
for r in z['results']:assert ch(r['visibleBody'])==r['bodySha256'] and r['fieldSha256']=={f:th(r['visibleBody'][f]) for f in FIELDS}
for q in z['questionImpactReview']+z['correctedVariantImpactReview']:
    for a in q['necessaryAnchors']:assert cards[a['ruleId']]['bodySha256']==a['bodySha256'] and cards[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
    for d in q['recursiveUsedPrerequisiteBindings']:assert cards[d['ruleId']]['bodySha256']==d['bodySha256'] and cards[d['ruleId']]['visibleBody']==d['visibleBody']
for eid,e in z['evidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256'] and s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256'] and ch(e)==eid
assert all(sha(p)==h for p,h in manifest.items()) and sha(index_path)==index_hash
rb={'status':'PASS_serialization_and_bindings_one_content_FAIL_remains','reviewPath':str(rp),'reviewSha256':sha(rp),'readBackAtUtc':now(),'counts':z['counts'],'checks':{'sevenCurrentFourFieldBodiesAndHashes':True,'sevenFullOriginalsAndEveryOption':len(qs)==7,'threeFullOriginalAndCorrectedAllOptions':len(cv)==3,'exactAnchorsAndRecursiveDependencies':True,'namedCurrentValidReceiptsAndExplicitVersionDeltas':True,'all14OfficialInputSnapshotsAndUsedQuotesHashesOffsets':True,'allFrozenInputsUnchanged':True,'noSUPPORTEDPracticeUsesFailedGSC130':all(not q['usesTeachingFailedCandidateOverlay'] for q in cv if q['status']=='SUPPORTED'),'originalAndPracticeStatusesSeparate':True,'noCurrentSourceOrProductionMutation':True},'remainingContentFailures':['S14-GSC130-R1'],'formalBilingualAcceptance':False,'learnerEffectMeasured':False,'finalNVerified':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
(O/'supplemental14.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':str(rp),'sha256':sha(rp),'counts':z['counts']},ensure_ascii=False))


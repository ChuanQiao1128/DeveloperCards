import pathlib, json, hashlib, collections, datetime, re

V = pathlib.Path(__file__).resolve().parents[3]
P = V / 'review/supplemental09/input'
O = V / 'review/reuse-a'
W = O / 'supplemental09-work'
FIELDS = ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']
def rd(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s): return hashlib.sha256(s.encode()).hexdigest()
def ch(x): return th(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
def body(c): return {f: c.get(f, '') for f in FIELDS}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest = rd(P/'manifest.json')
assert all(sha(p) == h for p, h in manifest.items())
base = {c['ruleId']: c for c in rd(P/'visible-pool.frozen.json')}
drafts = rd(P/'cards.json')
cards = dict(base)
for c in drafts:
    rid = c['ruleId']
    if c.get('repairOf'): assert c['repairOf'] == base[rid]['bodySha256']
    cards[rid] = {'ruleId': rid, 'visibleBody': body(c), 'bodySha256': ch(body(c)), 'prerequisiteRuleIds': c.get('prerequisiteRuleIds', base.get(rid, {}).get('prerequisiteRuleIds', []))}
assert len(base) == 358 and len(cards) == 359 and len(drafts) == 10
assert all(ch(c['visibleBody']) == c['bodySha256'] for c in cards.values())
index_path = V/'validation/current-card-review-index.json'
index_hash = sha(index_path)
index = {x['ruleId']: x for x in rd(index_path)['cards']}
legacy_path = V/'inputs/existing176.json'
legacy = {c['ruleId']: c for c in rd(legacy_path)}
proof_cache = {}
def bind_old(rid):
    if rid in proof_cache: return proof_cache[rid]
    c = base[rid]; ix = index[rid]
    assert ix['status'] == 'PASS' and ix['currentBodySha256'] == c['bodySha256']
    out = []
    for p in ix['proofs']:
        assert sha(p['path']) == p['sha256']
        d = rd(p['path']); rs = d.get('results', d.get('cards', []))
        if isinstance(rs, dict): rs = list(rs.values())
        matches = [x for x in rs if x.get('ruleId') == rid]
        assert matches, (rid, p['path'])
        r = matches[-1]; rh = r['bodySha256']
        contract = 'canonical four-field current visible body including empty values'
        if rh != c['bodySha256']:
            lb = body(legacy[rid]['body'])
            assert lb == c['visibleBody'] and ch({f: s for f, s in lb.items() if s}) == rh, rid
            contract = 'legacy omitted-empty hash; exact four visible fields reconstructed from hash-bound existing176 and matched'
        elif 'visibleBody' in r: assert r['visibleBody'] == c['visibleBody'], rid
        z = {'ruleId': rid, 'path': p['path'], 'sha256': p['sha256'], 'receiptBodySha256': rh, 'currentPriorBodySha256': c['bodySha256'], 'bodyBindingContract': contract}
        if r.get('proofs'):
            for pp in r['proofs']: assert sha(pp['path']) == pp['sha256']
            z['parentGateReceipts'] = r['proofs']
        out.append(z)
    proof_cache[rid] = out
    return out

registry = {}
def cite(p, needle, length, claim, occurrence=0):
    p = pathlib.Path(p)
    if not p.is_absolute(): p = V/p
    d = rd(p); s = d['text']; positions = [m.start() for m in re.finditer(re.escape(needle), s)]
    assert positions, (p, needle)
    start = positions[occurrence]; q = s[start:start+length]
    z = {'claim': claim, 'url': d['url'], 'sourcePath': str(p), 'sourceFileSha256': sha(p), 'sourceTextSha256': th(s), 'quote': q, 'startChar': start, 'endChar': start+len(q), 'quoteSha256': th(q)}
    if d.get('rawSha256') and p.with_suffix('.html').exists():
        z.update(rawHtmlPath=str(p.with_suffix('.html')), rawHtmlSha256=d['rawSha256'])
        assert sha(z['rawHtmlPath']) == z['rawHtmlSha256']
    if d.get('textSha256'): assert th(s) == d['textSha256']
    eid = ch(z); registry[eid] = z
    return eid

inputs = rd(P/'official-evidence.json'); input_validation = []
for i, e in enumerate(inputs):
    d = rd(e['snapshotPath']); s = d['text']
    assert sha(e['snapshotPath']) == e['snapshotSha256'] and th(s) == e['textSha256']
    assert s[e['quoteStart']:e['quoteEnd']] == e['quote'] and d['url'] == e['url']
    input_validation.append({'ordinal': i, 'url': e['url'], 'snapshotPath': e['snapshotPath'], 'snapshotSha256': e['snapshotSha256'], 'textSha256': e['textSha256'], 'quoteStart': e['quoteStart'], 'quoteEnd': e['quoteEnd'], 'quoteSha256': th(e['quote']), 'status': 'PASS_literal_hash_offset_validation'})
def src(i, needle, n, claim): return cite(inputs[i]['snapshotPath'], needle, n, claim)

E = {}
E['transfer'] = src(3, 'AWS Transfer Family offers fully managed support', 1050, 'Transfer Family supports FTP/FTPS/SFTP with S3/EFS storage.')
E['transfer-az'] = src(3, 'supports up to 3 Availability Zones', 180, 'Managed transfer endpoint supports up to three AZs and automatic scaling/redundancy.')
E['ftp'] = cite(W/'sources/transfer-ftp.json', 'FTP uses clear text', 385, 'FTP is unencrypted and requires internal VPC-hosted access; public-network transport requires SFTP/FTPS.')
E['ftp-backends'] = cite(W/'sources/transfer-ftp.json', 'On the Choose domain page', 445, 'FTP explicitly supports S3 object or EFS file storage, not EBS storage.')
E['windows-batch'] = src(13, 'This parameter must be set to X86_64', 690, 'Batch Fargate Windows uses X86_64, no Windows Fargate Spot, and supported 2019/2022 OS families.')
E['windows-ecs'] = cite('review/reuse-a/sources/d3675cbbef4bc6fe2727.json', 'Windows containers on AWS Fargate supports the following operating systems:', 234, 'ECS/Fargate supports Windows Server 2019/2022 Full/Core; arbitrary Windows images are not implied.')
E['batch-max'] = src(9, 'value = 32 MEMORY =', 56, 'Current Batch Fargate maximum combination is 32 vCPU and 249856 MiB = 244 GiB.')
E['batch-pairs'] = src(9, 'For jobs that are running on Fargate resources, then value must match', 1460, 'Fargate allowed CPU/memory pairs; 64 vCPU and 512 GiB are unsupported per job.')
E['batch-ec2'] = src(9, 'For Amazon EC2 resources, you must specify at least one vCPU.', 223, 'EC2 resource selection differs from the fixed Fargate CPU/memory pairs.')
E['dlm-scope'] = src(8, 'You can use Amazon Data Lifecycle Manager to automate', 705, 'DLM automates EBS snapshots and EBS-backed AMIs and disaster-recovery backups.')
E['dlm-ami-copy'] = src(6, 'Example 2: Count-based retention and AMI deprecation with cross-Region copy', 620, 'Positive AMI policy example selects tagged instances, schedules AMIs, and automatically copies them to another Region.')
E['gp3'] = src(0, 'It also helps you to scale volume performance independently', 420, 'EC2 gp3 independent performance and 20 percent lower storage price per GiB than gp2; the price scope is EC2/EBS.')
E['gp3-perf'] = src(0, 'gp3 volumes deliver a consistent baseline IOPS performance', 515, 'EC2 gp3 supports provisioned IOPS including 15000 within capacity constraints; no obsolete 16000 general cap is asserted.')
E['rds-gp2'] = src(1, 'Baseline I/O performance for gp2 storage is', 472, 'RDS gp2 baseline 3 IOPS/GiB and 1000 GiB example gives 3000 IOPS.')
E['rds-gp3'] = src(1, 'By using General Purpose gp3 storage volumes', 815, 'RDS gp3 has independent performance with DB-engine and size thresholds; EC2 prices/limits cannot be copied into RDS.')
E['acu'] = src(11, "That's because each ACU corresponds", 85, 'Approximately 2 GiB memory per ACU.')
E['acu-cpu'] = src(11, 'amount of CPU currently being used divided by the CPU capacity', 460, 'CPU capacity follows maximum ACU capacity; capacity is more than an arbitrary instance count.')
E['acu-network'] = src(11, 'Typically, most scaling up', 700, 'Scaling follows memory/CPU and in some cases network/local-storage activity.')
E['transcode'] = cite(W/'sources/mediaconvert.json', 'A job does the work of transcoding.', 260, 'MediaConvert jobs transform input media into output files.')
E['ec2-transcode'] = cite('review/source-unknown02/a/evidence/instance-store-performance-capacity.snapshot.json', 'Compute optimized instances are ideal', 300, 'EC2 compute workloads explicitly include media transcoding; self-managed encoding is a viable alternative.')
E['elastic-retired'] = cite('review/gap-b/evidence/elastic-transcoder.json', 'Aviso de fim do suporte:', 348, 'Official Portuguese legacy guide says Elastic Transcoder resources are inaccessible after 13 November 2025; this is only retirement evidence, not a replacement learning card.')
E['memcached-snap'] = src(15, 'Amazon ElastiCache caches running', 382, 'Serverless Memcached, Redis OSS, and Valkey can snapshot/restore.')
E['cache-az'] = src(12, 'ElastiCache Serverless automatically stores', 158, 'Serverless ElastiCache stores redundant data across three AZs.')
E['acm-rule'] = src(7, 'Checks if AWS Certificate Manager Certificates', 850, 'Config expiration rule covers imported certificates; daysToExpiration is configurable, default 14 is not fixed.')
E['config-events'] = cite(W/'sources/config-events.json', 'Choose Config Rules Compliance Change', 395, 'EventBridge can notify on Config noncompliance; no new resource modification is implied by evaluation/notification.')
E['default-s3'] = src(5, 'Amazon S3 buckets have bucket encryption enabled by default', 686, 'New S3 objects use automatic SSE-S3 unless another configuration is selected; KMS offers more key control.')
E['s3-kms-control'] = cite('review/reuse-a/sources/e1e1c91f80b421c7dc9f.json', 'Centrally create, view, edit, monitor', 340, 'KMS supports key policies and key-use auditing.')
E['s3-customer-key'] = cite('review/reuse-a/sources/e1e1c91f80b421c7dc9f.json', 'If you want to use a customer managed key for SSE-KMS', 691, 'SSE-KMS must explicitly select the requested customer key; unspecified SSE-KMS can use an AWS managed key.')
E['s3-copy-encryption'] = src(2, 'If objects in the source bucket are encrypted by using server-side encryption', 550, 'SSE-S3 source objects retain encryption type in replicated objects.')
E['pinpoint-retired'] = cite('review/gap-b/evidence/cache-831518447be032759187.json', 'Support for Amazon Pinpoint ended on October 30, 2026.', 325, 'Pinpoint journeys and engagement features no longer available at this review date.')
E['domain'] = cite(O/'supplemental04-work/sources/saa-c03-guide.json', 'Task 1.3: Determine appropriate data security controls\nKnowledge of:', 730, 'Official SAA-C03 task 1.3 covers encryption/key management and encryption-key access policies.')

teaching = {
'CUR:CMP-M19': '协议保留、后台对象/文件语义为同一个选择；FTP扩范围不新增独立部署清单。POSIX是共享文件访问身份，旧有效事实依据精确复用。',
'GSC-133': '按程序实际操作系统/受支持运行时判断能否运行；Windows平台是同一兼容性判断的具体去向，并没有把短任务误等同Lambda。',
'VC-002': '作业实际资源需求决定Fargate是否可用；Batch调度职责与执行环境资源能力构成同一因果判断。32/244只为解释边界，不能把旧服务器规格当实际作业需求。',
'CUR:NS03': '仍是备份周期/保留及管理对象决定工具；AMI扩展属于同一生命周期范围。跨Region是备份去向，不要求背另套部署。已有冷层提醒不列入本卡必答。',
'GSC-015': '围绕容量已够而性能不足这一取舍，对比gp2容量耦合与gp3性能独立；RDS例子和EC2价格都标清适用产品，没有独立多任务配置清单。',
'GSC-057': '扩单实例容量与扩reader数为同一扩展维度辨析；2GiB/ACU解释容量单位用途，不另设孤立数字题。',
'GSC-110': '一个机制：格式问题要转码，缓存不改变格式；EC2编码仅作为同一任务的维护责任竞争项。',
'GSC-032': '一个按部署模式及复制/接管要求选择缓存引擎的判断；Serverless提醒防止把node-based结论外推。',
'CUR:CC10': '正面问EBS/标签配置评估与自动整改，答案用Config+Automation闭合；新考点却要求额外记ACM证书30天阈值和EventBridge通知链，且通知并不整改。这是为匹配另一题添加的独立回忆任务。',
'VC-011': '普通静态加密与客户控制KMS key要求改变加密方式，为一个key控制判断；当前默认SSE-S3解释普通要求为何已满足。复制句只限定同一加密能力，不列额外复制步骤。'
}
results = []
for c in drafts:
    rid = c['ruleId']; failed = rid == 'CUR:CC10'
    relevant = {
    'CUR:CMP-M19':['transfer','transfer-az','ftp','ftp-backends'], 'GSC-133':['windows-batch','windows-ecs'],
    'VC-002':['batch-max','batch-pairs','batch-ec2'], 'CUR:NS03':['dlm-scope','dlm-ami-copy'],
    'GSC-015':['gp3','gp3-perf','rds-gp2','rds-gp3'], 'GSC-057':['acu','acu-cpu','acu-network'],
    'GSC-110':['transcode','ec2-transcode'], 'GSC-032':['memcached-snap','cache-az'],
    'CUR:CC10':['acm-rule','config-events'], 'VC-011':['default-s3','s3-kms-control','s3-customer-key','s3-copy-encryption']}[rid]
    gates = {g:'PASS' for g in ['FACT','U1','R1','T1','S1','P1']}; gates['B1'] = 'N/A_chinese_stage'
    if failed: gates.update(U1='FAIL_independent_topic_added', R1='FAIL_memory_task_stacking')
    results.append({'ruleId':rid,'status':'FAIL' if failed else 'PASS','gates':gates,'visibleBody':body(c),'bodySha256':ch(body(c)),
        'fieldSha256':{f:th(c.get(f,'')) for f in FIELDS},'bodyHashContract':'canonical sorted JSON UTF-8 of four named Chinese fields including empty values',
        'fullDraftSha256':ch(c),'priorBodySha256':base.get(rid,{}).get('bodySha256'), 'namedValidPriorFACTProofs':bind_old(rid) if rid in base else [],
        'unchangedFactReuseScope':'Only unchanged mechanism from exact prior body; each newly asserted fact is separately bound below. No prior teaching PASS substitutes for this full-card teaching review.',
        'evidenceIds':[E[k] for k in relevant], 'teachingAndRecallTaskReason':teaching[rid], 'prerequisiteRuleIds':cards[rid]['prerequisiteRuleIds'],
        'assessmentCheck':'Only answer the visible principal question and explain its causal reason; given premises and incidental reminders are not extra mustAnswer. Private grading contract was not supplied and is not accepted here.',
        'findings':[{'id':'S09-CC10-R1','priority':'P1','field':'keyPointZH','quote':'例如受管ACM证书到期规则可把阈值设30天，再以合规变化触发EventBridge通知','reason':'ACM时限和通知链并非本卡所问的EBS/标签评估及自动整改；FACT正确不能抵扣第二个回忆任务。','minimumRepair':'仅定向删除/迁移这段独立ACM例子，保留Config评估与Automation整改机制。可复用已有CUR:XA005的证书通知知识，不默认新开卡。'}] if failed else []})

qb = {q['qid']:q['question'] for q in rd(P/'questions.json')}
def anchors(rid, fields=('answerZH','keyPointZH')):
    c=cards[rid]
    return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'startChar':0,'endChar':len(c['visibleBody'][f]),'candidateOverlay':rid in {x['ruleId'] for x in drafts}} for f in fields if c['visibleBody'].get(f)]
def Q(qid,status,opts,ids,reason,missing=(),conditions=(),implementation=(),ev=(),issues=()):
    aa=[]
    for x in ids:
        aa += anchors(x[0],x[1]) if isinstance(x,tuple) else anchors(x)
    used=sorted({a['ruleId'] for a in aa});todo=list(used);seen=set();pre=[]
    while todo:
        rid=todo.pop()
        if rid in seen:continue
        seen.add(rid)
        for dep in cards[rid].get('prerequisiteRuleIds',[]):
            assert dep in cards
            pre.append({'from':rid,'ruleId':dep,'bodySha256':cards[dep]['bodySha256'],'visibleBody':cards[dep]['visibleBody']});todo.append(dep)
    for rid in seen:
        if rid in base and rid not in {x['ruleId'] for x in drafts}:bind_old(rid)
    failed_used=bool({'CUR:CC10'}&set(used))
    assert status!='SUPPORTED' or not failed_used
    q=qb[qid]
    return {'qid':qid,'status':status,'selectedOptionOrdinals':opts if status=='SUPPORTED' else [],'candidateOptionOrdinals':opts,
        'questionSha256':ch(q),'originalStemUtf8Sha256':th(q['stem']),'originalOptionsCanonicalSha256':ch(q['options']),
        'completeStemAndEveryOptionRead':True,'usedRuleIds':used,'necessaryAnchors':aa,'recursiveUsedPrerequisiteBindings':pre,
        'reasoningAndClosestCompetitor':reason,'minimumRemainingJudgments':list(missing),'conditions':list(conditions),
        'implementationChecksNotNewCards':list(implementation),'officialEvidenceIds':[E[k] for k in ev], 'sourceIssues':list(issues),
        'usesTeachingFailedCandidateOverlay':failed_used,'candidateOverlayAcceptanceDoesNotPromoteQuestion':True,'noPrivateTargetsOrPrintedAnswersUsed':True}

questions=[]
questions.append(Q(78,'SUPPORTED',[2],['CUR:NS03','CUR:NB04'], '需要多年历史留存和自动计划/保留，NS03周期恢复点及长期保留机制支持B。A的近期连续PITR不能代替长期恢复点；C一次手工备份无自动计划且把托管备份任意当客户S3对象，D重复自建调度/备份代码，增加运营动作。',implementation=['按DynamoDB受支持备份能力配置七年保留；不是要求学习者背整套备份参数。']))
questions.append(Q(82,'SOURCE_ISSUE',[2,4],['CUR:CC10','CUR:XA005'], '候选CC10给出Config到期阈值/合规变化通知，XA005给出活动导入证书ACM临期事件/DaysToExpiry及EventBridge路径，B和D当前都可实现30天通知。题目未要求排除Lambda或选最省运维，不能强选B；A虚构ACM直接SNS自定义规则，C并无当前卡句支撑。CC10教学FAIL不计新接受，来源并列由官方正证保留。',ev=['acm-rule','config-events'],issues=['B与D均为可行通知路径，题面没有决定唯一性的附加条件。']))
questions.append(Q(134,'SUPPORTED',[3],['VC-011','CUR:CC03','CUR:NEW04','CUR:XA004'], 'S3已有数据偶发SQL且无服务器，CC03支持Athena，B/D的RDS增加迁移和数据库维护。普通静态加密不要求自定义key，VC011说明SSE-S3已满足；C沿用现桶而A额外新桶与KMS配置，C运营动作更少。NEW04保留历史对象补复制义务；题目已写Load the data，可按正确顺序/重写或Batch复制处理原有对象，不把未列所有操作参数直接定源错。',implementation=['保留原文SL及kays字样，按其SQL分析语境理解；原文未改。','CRR配置须覆盖既有/新版本，正确安排重新写入或Batch Replication；不得只开live规则就声称历史对象已复制。'],ev=['default-s3','s3-copy-encryption']))
questions.append(Q(201,'SOURCE_ISSUE',[],['GCL-003','GSC-091','CUR:NS01'], 'GCL003教会双向SMS需入站路径，GSC091说明流保留可到365天，NS01区分流与落地交付。旧B依赖Pinpoint journey，当前已退役；A没有卡句/官方正证证明Connect contact flow直接实现题中双向SMS，C把SQS当SMS发送服务，D把SNS FIFO当双向SMS入站方案均不足。不能把新的End User Messaging路径写回原选项。',missing=['当前给定选项中没有完整可用的双向SMS发送、接收入站与一年留存路径。'],ev=['pinpoint-retired'],issues=['Pinpoint journeys在2026-10-30后已不可用；保留原题不改。']))
questions.append(Q(302,'SUPPORTED',[1,5],['CUR:CA13','GSC-110','CUR:XB019'], '可见卡把边缘缓存交付与实际转码分开：A改善交付，E在EC2执行编码可产生适合移动播放的输出。C的Elastic Transcoder当前已不可访问，不能继续当现行托管选项；给定仍可行方案中A+E满足两个职责，虽比MediaConvert维护多，但MediaConvert未在原选项中。B复制不改格式，D自建交付层比A增加运维且不解决原格式。',implementation=['为EC2编码程序/ASG配置作业调度、输出与伸缩属于选项E落地实现，不要求新增完整部署清单。'],ev=['ec2-transcode','elastic-retired'],issues=['历史常见A+C组合受Elastic Transcoder退役影响；当前支持A+E，不静默替换原选项C。']))
questions.append(Q(321,'SOURCE_ISSUE',[1,2,3,4],[('VC-011',('answerZH','keyPointZH')),'CUR:CMP-M11'], 'VC011说明当前新上传对象已经自动静态加密。ACL头影响ACL，SecureTransport限制传输，D拒绝缺加密头会额外限制客户端，但不再是保证所有上传静态加密的必要条件；即使A/B/C不检查静态加密头，成功上传对象仍有S3基础加密。不能用当前要求唯一推出D。',ev=['default-s3'],issues=['当前S3默认加密使题目失去原有唯一判别条件；若另要求特定客户KMS key或显式请求头，必须由原题明确。']))
questions.append(Q(353,'SUPPORTED',[2],['CUR:CC22','CUR:CB01','GSC-051','GSC-015'], 'CC22解释关系库迁RDS减少维护，CB01提供跨AZ接管；GSC051要求按实际I/O瓶颈选择足够存储而非一律最贵。GSC015明确RDS 1000GiB gp2约3000IOPS，高于1000峰值的两倍2000，因此B的通用SSD足够，A额外Provisioned IOPS非必要。C对象存储改变关系库接口，D仍自管EC2且维护更多。',implementation=['按RDS MySQL产品核对实际容量与实例I/O能力；没有把EC2 gp3单价或上限用来证明RDS成本。'],ev=['rds-gp2']))
questions.append(Q(355,'CONDITIONAL',[2,4],['VC-002','GSC-133','CUR:XB019','GSC-089'], '若作业实际需要64vCPU/512GiB，VC002的32/244边界排除Fargate，Batch在合适EC2计算环境是D方向；A标准Lambda还受900秒及资源限制，C也没有对应托管批处理证据。但原题仅写旧服务器规格，并未写作业实际占用；原卡特别说明不能将二者相等。若任务可在Fargate规格内完成，B也可能更少主机维护，无法据旧服务器配置证明唯一D。',missing=['作业真实CPU/内存需求及在候选环境达到15分钟的可行性，而不是旧主机规格。'],conditions=['确认实际作业资源确超Fargate范围且所选EC2规格可满足目标时，D成立；若实际需求在Fargate内，则须比较B。'],ev=['batch-max','batch-pairs']))
questions.append(Q(369,'SUPPORTED',[1],['VC-002','GSC-133','GSC-089','GCL-002'], 'GSC089按时钟触发，VC002说明Batch排队调度、可用匹配Fargate环境减少维护；GCL002解释容器封装既有运行环境，不要求任务共用一种语言。GSC133的标准Lambda900秒排除一小时任务C。B以App Runner服务代替批任务按需队列，D复制整机仍需自管容量与作业协调，A最贴合。',implementation=['为每项任务构造兼容镜像及EventBridge定时提交Batch作业；这是正常实现，不把未列命令当知识缺口。']))
questions.append(Q(463,'INSUFFICIENT_CARDS',[3],['GSC-133','GSC-029','GSC-136','GSC-095','GSC-097'], 'GSC133已证明受支持Python/1GB/30秒能用Lambda，GSC029能按S3写入触发，C是合理候选。但原题问最具成本效益；GSC136只教Lambda资源×时长取舍，GSC095/097只教ETL/分布式能力，尚未提供与Glue Scala/PySpark或EMR的最小计费/执行资源取舍。不能仅凭短任务能运行即宣称C在费用上已被卡组唯一推出。',missing=['小而短的逐对象处理在Lambda与Glue/EMR之间的费用/最低资源因果比较，或足够可见的定性成本规则。']))
questions.append(Q(475,'SUPPORTED',[3],['GSC-001','GSC-002','GCL-021','CUR:NS03','GSC-070'], 'GSC001/002给出NFS共享、Regional多AZ存储与挂载路径，GCL021明确各AZ网络入口是mount target；NS03给出EFS由AWS Backup安排跨Region副本，C吻合。其他FSx方案即便能共享/复制，题目每AZ mount target的入口模型与已教EFS一致。GSC070保留目标Region实际可用恢复点决定RPO，不把源备份频率当已达8小时。',implementation=['把备份/复制计划及监测留出复制耗时，验证目标恢复点满足8小时；不把普通计划参数和SLA实测额外立为新卡门槛。']))
questions.append(Q(483,'SOURCE_ISSUE',[2,3],['GSC-133','GSC-089','CUR:XB019','VC-002'], '当前GSC133明确支持对应Windows版本的ECS/Fargate与Batch Windows环境；GSC089支持固定时间外部调度，B和C均可按10分钟提交短任务。Lambda Linux环境不能直接吃现成Windows镜像；D要依赖已运行Windows容器里的计划器，不能据此比按时启动任务更省费。没有成本证据在B/C之间得出唯一C，AWS Batch本身也不是额外收费的编排服务。',conditions=['Windows镜像须符合受支持版本、X86_64及资源/运行特性；不能概括任意Windows镜像均可运行。'],ev=['windows-batch','windows-ecs'],issues=['B和C当前均可行；原文.NET 6 Framework命名不严谨但不单凭该词判源错。']))
questions.append(Q(508,'SUPPORTED',[2,4],['CUR:NS03','GSC-070'], 'NS03新正文给出DLM管理EBS-backed AMI并自动跨Region复制，以及AWS Backup的计划/保留/复制。B与D都自动每天两次备份并复制到us-west-2；A/E仍按需复制，灾难前目标可能没有新恢复点，C另写Lambda复制非最少管理。GSC070保留实际目标恢复点核对24小时的数据损失窗口。',implementation=['原选项EC2-backed AMI用词保留，按其EC2实例EBS-backed镜像生命周期语境核对资源类型，不改变原题。','目标副本实际完成时间纳入RPO校验；twice daily本身不是零复制延迟保证。'],ev=['dlm-scope','dlm-ami-copy']))
questions.append(Q(528,'SUPPORTED',[4],['CUR:CMP-M19','GSC-029','GSC-133','CUR:CMP-M06'], 'M19新增FTP支持和S3/EFS后台，GSC029对象创建事件即触发处理，GSC133标准Lambda支持3–8分钟范围，M06给函数访问S3的执行身份路径。D保留FTP客户端、把新对象到达后立即交给函数处理并由代码在成功后删除；A/B仍等夜间且自管FTP，C虚构Transfer EBS后端及EBS文件触发S3事件。',implementation=['FTP使用受支持VPC内部访问路径，题面未要求公网明文FTP；按真实客户网络验证访问，不额外假定不存在可行网络。','代码只在成功处理后DeleteObject，并配置相应执行权限；这些是题目给定动作的普通实现。'],ev=['ftp','ftp-backends']))
questions.append(Q(572,'SOURCE_ISSUE',[2,3],['GSC-057','CUR:CC22'], 'GSC057说明Aurora兼容MySQL、Serverless v2按ACU改变单实例算力、1ACU约2GiB；C明确满足。A键值模型与现有MySQL兼容关系模型不同，D固定2GiB没有所需计算弹性。但B只写Aurora database并明确最小1ACU，没有写provisioned；它可被解释为同一Aurora Serverless配置，无法凭可见卡把B可靠排除。',ev=['acu','acu-cpu'],issues=['B未限定为非Serverless，ACU最小容量语义与C重叠；若出题原意B=provisioned，应修订题面后另验。']))
questions.append(Q(580,'SUPPORTED',[4],['GSC-015','GSC-014','GSC-005','GSC-006'], '本地磁盘接口lift-and-shift到EC2块卷，无需为单机应用引入Lustre并行共享文件层。GSC015给出EBS gp3性能与容量分离，且EC2 gp3基础GiB价格低于gp2；在都满足此题未量化的普通块存储需求时D比B省容量单价，A/C引入文件系统和ASG改变存储/运行方式。GSC014还区分持久EBS与可丢临时盘，没有把本地attached自动推成必须instance store。',implementation=['具体实际IOPS/吞吐需在支持范围内；原题没有硬性亚毫秒或本机NVMe限定，不添加这些条件。'],ev=['gp3']))
questions.append(Q(776,'SOURCE_ISSUE',[3,4],['GSC-032','CUR:NB04'], 'GSC032的内存命中因果解释亚毫秒缓存，NB04给出Redis/Valkey快照；新增watchOut明确Serverless Memcached也有跨AZ冗余和快照。原题没有限定node-based，不能把本卡正面限定代入原题排除D；C及适当Serverless模式的D均可满足所列能力，A/B未给DAX等额外亚毫秒层。',ev=['memcached-snap','cache-az'],issues=['C/D在当前部署能力下非唯一；须明确node-based或其他真正有区别的条件才能排除D。']))
questions.append(Q(989,'INSUFFICIENT_CARDS',[3],['VC-010','GSC-047','CUR:NS03'], 'VC010明确自动保留期不清手工快照，且不能靠关闭自动备份保留原恢复点，C的30天自动保留+手工删除旧快照在行为上完整。B/D禁用自动备份不能满足保留现有<30天恢复点；A增加AWS Backup管理，但现有卡没有教AWS Backup对该Multi-AZ DB cluster/现有备份的计费与保留差异，无法只凭多一个服务名字证明C为MOST cost-effective。',missing=['C与A在保留既有备份条件下的实际费用/重复备份/免费额度取舍依据；不需要额外部署参数。'],implementation=['Multi-AZ DB cluster本身有自动备份保留限制，不能把DB instance可禁用步骤无条件套用；本题推荐C无需禁用。']))
questions.append(Q(1014,'SUPPORTED',[2],['VC-002','GSC-088','CUR:NA05','GSC-041','CUR:XB019'], 'VC002给出Batch队列调度与匹配Fargate执行环境免主机维护，GSC088解释Step Functions管步骤进度/重试，NA05/GSC041把大文件正文放S3。B分别满足批任务、工作流及大文件职责；A用SQS代替完整流程编排且EC2主机自管，C混入EC2 Spot且没有流程状态编排，D也自管EC2且EBS绑定单AZ/块卷。',implementation=['选择符合实际作业资源与功能的Fargate环境，Step Functions接Batch并传递对象引用；未给硬性超限条件，不凭缺完整部署表直接降级。']))

assert len(questions)==19 and {q['qid'] for q in questions}==set(qb)
near=[]
for c in base.values():
    if re.search(r'S3|SSE|KMS|密钥|静态加密|默认加密', json.dumps(c['visibleBody'],ensure_ascii=False), re.I):near.append(c)
nearest=['CUR:CC05','CUR:NS04','CUR:aws-rb2-domain1-normal-batch07-20261105-s3-bucket-key-request-cost','CUR:CMP-M20','CUR:SC01','CUR:XA004','CUR:CMP-M03','CUR:NEW04','CUR:CC09']
for rid in nearest:bind_old(rid)
sub={'ruleId':'VC-011','status':'INDEPENDENT_NECESSARY_LOCAL_RULE_CANDIDATE_FINAL_ADMISSION_DEFERRED','entireFrozenPoolCountChecked':358,
    'method':'Scanned all 358 frozen four-field bodies for storage/encryption/key-control alternatives, then semantically compared the relevant matched bodies. Existing broader KMS/client-side/replication rules are not assumed to teach SSE-S3 defaults.',
    'scannedPoolSha256':sha(P/'visible-pool.frozen.json'),'candidateRuleIdsExamined':[c['ruleId'] for c in near],
    'nearestRuleIds':nearest,'visibleNearestCards':[{'ruleId':r,'bodySha256':base[r]['bodySha256'],'visibleBody':base[r]['visibleBody']} for r in nearest],
    'reason':'CC05区分AWS/customer managed KMS key；NS04已教S3目标选择客户key的SSE-KMS，Bucket Key卡已教SSE-KMS减请求费用，因此新卡客户KMS分支存在可复用教学。CMP-M20解释客户端加密/SSE-C，SC01解释用钥授权，XA004解释multi-Region客户端密文，NEW04解释复制新旧范围；这些卡仍不能推出当前S3自动SSE-S3这一新增必要事实。不能用任一旧卡直接替代默认SSE-S3缺口，但不能把已教KMS控制分支虚计为另一全新核心知识。',
    'questionUse':[{'qid':134,'necessaryUse':'普通静态加密可直接用SSE-S3，额外KMS与新桶不是此题必需；与Athena/CRR卡组组合。'},{'qid':321,'necessaryUse':'解释旧题当前已无唯一答案；不计为新增完整题覆盖。'}],
    'onlyOneUnambiguousSupportedQuestionInThisReview':True,'lowFrequencyAdmission':'独立知识缺口成立，但当前给定19题中仅Q134形成无歧义完整卡组支撑，Q321是源问题。按约300全库目标暂不批准最终核心包纳入/最终N；不得靠source-issue题号增加有效复用率。',
    'coreSelectionRefinementAdvice':'若后续纳入核心包，可将已有NS04/CC05的KMS控制分支作为复用关系，并评估精炼本卡；本轮不改作者正文、不自动新增卡数。',
    'noExistingRuleDeleted':True}

transfers=[
 {'ruleId':'CUR:CMP-M19','changedCondition':'同一FTP/SFTP入口，后台从只需对象变为Linux共享文件与用户/组权限','status':'PASS','reason':'选择S3变EFS/POSIX，变化由数据访问语义而非协议名字决定。'},
 {'ruleId':'VC-002','changedCondition':'实际作业由64vCPU/512GiB变为落在支持CPU/内存组合内，且不需宿主机控制','status':'PASS','reason':'Fargate从被硬上限排除变为可考虑；旧服务器规格本身不决定选择。'},
 {'ruleId':'GSC-015','changedCondition':'容量从已够改为本来就要更大，同时IOPS提高','status':'PASS','reason':'gp2基线可随容量提高，但不能据此认为gp3也必须为IOPS多买空间；仍按目标数据库产品范围定价/限额。'},
 {'ruleId':'VC-011','changedCondition':'普通S3静态加密变成必须用指定客户KMS key','status':'PASS','reason':'默认SSE-S3不再满足key控制要求，应明确选择该客户key的SSE-KMS。'},
 {'ruleId':'GSC-032','changedCondition':'原node-based限定去掉，并允许Memcached Serverless','status':'PASS','reason':'不能继续排除Memcached快照/跨AZ能力；这正是Q776当前非唯一的原因。'}]

used_old={r['ruleId'] for q in questions for r in q['recursiveUsedPrerequisiteBindings'] if r['ruleId'] not in {d['ruleId'] for d in drafts}}
used_old |= {r for q in questions for r in q['usedRuleIds'] if r not in {d['ruleId'] for d in drafts}}
for rid in used_old:bind_old(rid)
report={'schemaVersion':1,'batch':'supplemental09','reviewer':'supplemental09 independent actual-content reviewer; no authoring performed','status':'FAIL_one_card_requires_targeted_teaching_repair',
    'reviewedAtUtc':now(),'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'inputHashes':manifest,
    'priorReviewIndexPath':str(index_path),'priorReviewIndexSha256':index_hash,'legacyBodyBindingSourcePath':str(legacy_path),'legacyBodyBindingSourceSha256':sha(legacy_path),
    'frozenVisiblePoolCount':358,'candidateOverlayCount':10,'proposedNewCards':1,'revisedExistingCards':9,'appliedToCurrent':False,
    'counts':{'cardPASS':9,'cardFAIL':1,'questionStatuses':dict(collections.Counter(q['status'] for q in questions))},
    'results':results,'questionImpactReview':questions,'usedExistingCardProofBindings':dict(sorted(proof_cache.items())),
    'evidenceRegistry':registry,'officialInputRecordValidation':input_validation,'newCardSubstitutionTests':[sub],
    'newCardDomainMetadataReview':[{'ruleId':'VC-011','status':'PASS','proposedPrimaryDomain':'1','proposedPrimaryTask':'1.3','recommendedPrimaryDomain':'1','recommendedPrimaryTask':'1.3','reason':'本卡决定静态加密与客户密钥控制要求，直接对应1.3 encryption/key management与encryption-key policies；跨Region句是同一加密能力的范围，不把复制维度作为主归。','evidenceIds':[E['domain']]}],
    'transferChecks':transfers,'minimumRepairScope':{'ruleIds':['CUR:CC10'],'findingIds':['S09-CC10-R1'],'affectedOriginalQuestionIds':[82],'otherNineCardResultsReusableOnlyWithExactBodyHashes':True,'authoringRequiredByRoot':True},
    'sourceMetadataAdvice':[{'qid':302,'advice':'保留旧Elastic Transcoder选项与退役事实；当前可见卡支撑A+E，历史A+C不能继续作为唯一现行答案。'},{'qid':572,'advice':'B如意图指provisioned Aurora须明确，不能靠审查者自行加字排除。'}],
    'externalOfficialReadOnlyFetches':{'attemptedUrls':6,'usableNewSnapshots':['transfer-ftp','config-events','mediaconvert','aurora-serverless-overview'],'unusableOrFailed':['ecs-windows redirected to 32-character index; not cited','English Elastic Transcoder introduction returned404; official cached Portuguese retirement source used'],'pythonTlsFailuresRetriedUsingSystemCurl':True},
    'additionalSourceBinding':{'path':str(O/'sources/e1e1c91f80b421c7dc9f.json'),'sha256':sha(O/'sources/e1e1c91f80b421c7dc9f.json'),'frozenManifestChanged':False},
    'formalBilingualAcceptance':False,'privateGradingContractAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'originalQuestionStatusesAutomaticallyPromoted':False,'finalCardCountVerified':False,
    'priorFailuresPreserved':True,'currentPointersChangedByReviewer':False,'authoringPerformed':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
review_path=O/'supplemental09.review.json'
review_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')

# Serialized readback checks literal card anchors, source offsets, and exact frozen bindings.
z=rd(review_path)
for r in z['results']:
    assert ch(r['visibleBody'])==r['bodySha256'] and r['fieldSha256']=={f:th(r['visibleBody'][f]) for f in FIELDS}
    assert r['fullDraftSha256']==ch(next(c for c in drafts if c['ruleId']==r['ruleId']))
for q in z['questionImpactReview']:
    assert q['questionSha256']==ch(qb[q['qid']])
    for a in q['necessaryAnchors']:
        c=cards[a['ruleId']];assert c['bodySha256']==a['bodySha256'] and c['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
    for d in q['recursiveUsedPrerequisiteBindings']:
        assert cards[d['ruleId']]['bodySha256']==d['bodySha256'] and cards[d['ruleId']]['visibleBody']==d['visibleBody']
for eid,e in z['evidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256']
    assert s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256']
    assert ch(e)==eid
assert all(sha(p)==h for p,h in manifest.items()) and sha(index_path)==index_hash
readback={'status':'PASS_review_serialization_and_bindings_not_all_content_PASS','reviewPath':str(review_path),'reviewSha256':sha(review_path),'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'readBackAtUtc':now(),
    'counts':z['counts'],'checks':{'tenFourFieldBodiesAndPerFieldHashes':True,'all19UniqueFullOriginalsAndExactFrozenSet':True,'allLiteralVisibleAnchorsAndRecursivePrerequisites':True,'allUsedOldCardsExactNamedProofBindings':True,'allOfficialSourceFileTextQuoteOffsetsAndHashes':True,'all17FrozenOfficialInputRecordsValidated':True,'allFrozenInputsAndCurrentReviewIndexUnchanged':True,'noSupportedQuestionUsesFailedCC10Overlay':True,'noCurrentCatalogueProductionOrQuestionMutation':True},
    'contentFailuresRemain':['S09-CC10-R1'],'newVC011FinalCoreAdmission':'DEFERRED_low_frequency','formalBilingualAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
(O/'supplemental09.readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':str(review_path),'sha256':sha(review_path),'counts':z['counts'],'readback':str(O/'supplemental09.readback.json')},ensure_ascii=False))

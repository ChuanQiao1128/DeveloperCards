import datetime, hashlib, json, pathlib

V=pathlib.Path(__file__).resolve().parents[3]
P=V/'review/supplemental19/input';O=V/'review/reuse-a'
F=['frontZH','answerZH','keyPointZH','watchOutZH']
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s):return hashlib.sha256(s.encode()).hexdigest()
def ch(x):return th(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def body(c):return {f:c.get(f,'') for f in F}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest=rd(P/'manifest.json');assert all(sha(p)==h for p,h in manifest.items())
base={c['ruleId']:c for c in rd(P/'visible-pool.frozen.json')};drafts=rd(P/'cards.json')
assert len(base)==362 and len(drafts)==1
c=drafts[0];rid=c['ruleId'];assert rid=='VC-015' and rid not in base
b=body(c);bh=ch(b);pool=dict(base);pool[rid]=dict(ruleId=rid,visibleBody=b,bodySha256=bh,prerequisiteRuleIds=[])
assert all(ch(x['visibleBody'])==x['bodySha256'] for x in base.values())
index_path=V/'validation/current-card-review-index.json';index_hash=sha(index_path)
index={r['ruleId']:r for r in rd(index_path)['cards']}
assert all(index[r]['currentBodySha256']==x['bodySha256'] for r,x in base.items())
proofs={}
def bind(rid):
    if rid in proofs:return proofs[rid]
    x=base[rid];ix=index[rid];assert ix['status']=='PASS' and ix['currentBodySha256']==x['bodySha256']
    out=[]
    for pp in ix['proofs']:
        assert sha(pp['path'])==pp['sha256'];d=rd(pp['path']);r=next(r for r in d.get('results',d.get('cards',[])) if r['ruleId']==rid)
        assert r['bodySha256']==x['bodySha256']
        if r.get('visibleBody'):assert r['visibleBody']==x['visibleBody']
        out.append(dict(ruleId=rid,path=pp['path'],sha256=pp['sha256'],bodySha256=x['bodySha256']))
    proofs[rid]=out;return out
for r in ['GCL-011','GSC-127','CUR:CA17']:bind(r)

inputs=rd(P/'official-evidence.json');assert len(inputs)==2
validation=[];registry={}
for i,e in enumerate(inputs):
    p=pathlib.Path(e['snapshotPath']);d=rd(p)
    assert sha(p)==e['snapshotSha256']==p.stem and th(d['text'])==e['textSha256']
    assert d['url']==e['url'] and d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
    validation.append(dict(ordinal=i,status='PASS_immutable_file_text_quote_hash_binding',snapshotPath=str(p),snapshotSha256=sha(p),textSha256=th(d['text']),quoteStart=e['quoteStart'],quoteEnd=e['quoteEnd'],quoteSha256=th(e['quote'])))
def cite(i,needle,end,claim):
    e=inputs[i];d=rd(e['snapshotPath']);s=d['text'];lo=s.index(needle);hi=s.index(end,lo)+len(end);q=s[lo:hi]
    z=dict(claim=claim,url=d['url'],sourcePath=e['snapshotPath'],sourceFileSha256=sha(e['snapshotPath']),sourceTextSha256=th(s),quote=q,startChar=lo,endChar=hi,quoteSha256=th(q));key=ch(z);registry[key]=z;return key
e_ratio=cite(0,'In a canary release deployment, total API traffic is separated at random','the production release takes up the rest.','Native API Gateway canary divides requests by a configured percentage while base production continues.')
e_risk=cite(0,'By keeping canary traffic small and the selection random','no single user is adversely affected all the time.','Small randomly selected traffic limits the population exposed to new-version bugs; no business-data rollback claim.')
e_stage=cite(0,'In API Gateway, a canary release deployment uses the deployment stage','the stage represents the production release of the API within this deployment.','Canary settings attach new deployment testing to the production stage, the API release entry configuration.')
e_promote=cite(1,'When you promote a canary release, the canary release replaces the current stage settings.','making the test version the production release as well.','Promotion replaces stage deployment with tested deployment. It does not automatically remove canary settings; card makes no such claim.')

query_terms=['canary','金丝雀','灰度','蓝绿','weighted','API Gateway','stage']
hits={term:[dict(ruleId=r,bodySha256=x['bodySha256'],matchedFields=[f for f in F if term.lower() in x['visibleBody'].get(f,'').lower()]) for r,x in base.items() if any(term.lower() in x['visibleBody'].get(f,'').lower() for f in F)] for term in query_terms}
assert not hits['canary'] and not hits['金丝雀']
alternatives=[]
for r,why in [('GSC-127','仅明示DNS记录权重概率及缓存边界，不能推出API Gateway stage具有原生canary设置/提升能力。'),('GCL-011','并行新环境验证后切入口，兼顾状态同步；未明示同一REST API stage内部真实请求比例分流的原生能力。'),('CUR:CA17','HTTP入口在业务计算与直接服务集成间选择，不承担发布验证机制；塞入canary会另添独立回忆任务。')]:
    alternatives.append(dict(ruleId=r,bodySha256=base[r]['bodySha256'],visibleBody=base[r]['visibleBody'],currentProofs=bind(r),whyNotACompleteSubstitute=why))

result=dict(ruleId=rid,status='PASS',gates=dict({g:'PASS' for g in ['FACT','U1','R1','T1','S1','P1']},B1='N/A_chinese_stage'),visibleBody=b,bodySha256=bh,fieldSha256={f:th(b[f]) for f in F},fullDraftSha256=ch(c),newCandidate=True,prerequisiteRuleIds=[],evidenceIds=[e_ratio,e_risk,e_stage,e_promote],gateReasons=dict(FACT='两个当前官方原句支持stage内生产/金丝雀按比例随机分流、通过验证后提升。提醒把单一DNS alias替换作为整体入口切换理解，不宣称DNS在所有客户端原子即时切换，也没有说promote自动禁用canary。',U1='stage随文解释为API发布入口配置；受控比例让潜在bug只影响部分真实请求，因果直接。',R1='只问REST API如何少量真实流量验证后推广及为何风险较小；不附带缓存、变量、回滚命令、数据迁移清单。',T1='新版本比例从1%提高到50%，受影响群体扩大；若直接100%则失去小流量限暴露效果。仅改DNS目标不是同stage的受控比例测试。',S1='答原生stage canary、小比例验证后提升及减少暴露范围即可；不要求复述已给REST条件或未问阶段变量与清理命令。',P1='API Gateway/REST已经给定，stage在卡内解释，核心分流路径完整；没有把私有来源或部署手册当隐藏先修。'),assessmentCheck='仅审可见问答对齐；未提供mustAnswer，不宣称正式评分契约、双语及学习效果通过。',findings=[])
qs=rd(P/'questions.json');assert len(qs)==1 and qs[0]['qid']==544;q=qs[0]['question']
canonical_path=V.parent/'domain1-final-card-catalog-20261105/questions.all.json';assert q==rd(canonical_path)['544']
prior_path=V/'review/current-impact02/b/results.json';prior_sha=sha(prior_path)
prior_row=next(x for x in rd(prior_path)['results'] if x['qid']==544)
assert prior_row['status']=='INSUFFICIENT_CARDS' and prior_row['questionSha256']==ch(q)
def A(rid):
    x=pool[rid]
    return [dict(ruleId=rid,bodySha256=x['bodySha256'],field=f,quote=x['visibleBody'][f],startChar=0,endChar=len(x['visibleBody'][f]),candidateOverlay=(rid=='VC-015')) for f in F if x['visibleBody'].get(f)]
qrow=dict(qid=544,status='SUPPORTED',selectedOptionOrdinals=[1],questionSha256=ch(q),stemUtf8Sha256=th(q['stem']),optionsCanonicalSha256=ch(q['options']),completeStemAndEveryOptionRead=True,usedRuleIds=['VC-015','GCL-011'],necessaryAnchors=A('VC-015')+A('GCL-011'),recursivePrerequisiteBindings=[],reasoningAndClosestCompetitor='A：当前新增正文明确REST API native stage canary保留旧部署处理大部分请求，新版少量真实请求验证后提升。B/C是把导入定义直接部署生产，D仅换DNS入口，均未给同等可控小比例验证。minimal effects/minimal data loss按变更暴露范围较小、正常兼容的应用发布理解；canary不是自动撤销已写业务数据，状态应用的一般同步/兼容仍沿GCL011层次处理，不为本题加完整数据库部署清单。',minimumRemainingJudgments=[],sourceIssueConfirmed=False,noPrivateTargetsOrPrintedAnswersUsed=True,noOfficialSourceSubstitutedForMissingVisibleCard=True,originalModified=False,cardGroupSupportAccepted=True,officialEvidenceIds=[e_ratio,e_risk,e_stage,e_promote])
catalog_path=V/'inputs/supplemental-catalogue19.proposed.json';catalog=rd(catalog_path);assert len(catalog)==1
meta=catalog[0];assert meta['ruleId']==rid and meta['primaryDomain']=='2' and meta['primaryTask']=='2.2' and meta['questionIds']==[544] and not meta['prerequisiteRuleIds']
report=dict(schemaVersion=1,batch='supplemental19',reviewer='independent actual card necessity/fact/teaching/question reviewer',reviewedAtUtc=now(),status='PASS_one_necessary_local_candidate_and_Q544_not_final_inventory_count',inputManifestPath=str(P/'manifest.json'),inputManifestSha256=sha(P/'manifest.json'),inputHashes=manifest,currentReviewIndexPath=str(index_path),currentReviewIndexSha256=index_hash,frozenVisiblePoolCount=362,newCandidateCount=1,candidateOverlayPoolCount=363,appliedToCurrent=False,counts=dict(cardPASS=1,cardFAIL=0,originalQuestionStatuses={'SUPPORTED':1}),results=[result],questionImpactReview=[qrow],officialInputRecordValidation=validation,evidenceRegistry=registry,usedExistingCardProofBindings=proofs,
            necessityReview=dict(verdict='NECESSARY_CURRENT_KNOWLEDGE_JUDGMENT_STANDALONE_CANDIDATE_JUSTIFIED',currentPoolCount=362,fullPoolSearchQueries=query_terms,actualFullPoolSearchHits=hits,existingAlternatives=alternatives,lowFrequencyQuestionCount=1,lowFrequencyDefaultHoldOverriddenByActualNecessaryGap=True,reason='去掉原生REST stage canary能力后，现有规则只能说应谨慎发布，不能确认原题A所称API Gateway机制真实可用。该能力不是普通路由/授权配置，也不是弱干扰项功能表。当前短卡保留一个发布判断，比把独立机制附在DNS或HTTP后端选择卡中更符合单任务标准。',scopeLimit='只证明当前接受池中必须补明这一知识判断及本候选的局部必要性；不证明全库数学最少卡数，也不要求最终核心包固定363或自动保留每张旧卡。'),
            metadataReview=dict(status='PASS',proposedCataloguePath=str(catalog_path),proposedCatalogueSha256=sha(catalog_path),primaryDomain='2',primaryTask='2.2',reason='控制发布故障影响范围、旧版本继续服务并验证后推广，主任务属于高可用/容错架构的2.2；未把DNS配置或成本优化作为主目标。',prerequisiteRuleIds=[],actualMetadataMutated=False),
            gapClosure=[dict(qid=544,priorStatus='INSUFFICIENT_CARDS',priorReviewPath=str(prior_path),priorReviewSha256=prior_sha,priorQuestionSha256=prior_row['questionSha256'],status='CLOSED_BY_NEW_VISIBLE_NATIVE_CANARY_RULE',newRuleId=rid,newBodySha256=bh,oldGapAndEvidenceRetained=True)],
            transferChecks=[dict(ruleId=rid,status='PASS',conditionChange='canary比例1%改50%',reason='新版暴露范围扩大，限影响机制仍可解释。'),dict(ruleId=rid,status='PASS',conditionChange='使用单一DNS别名直接指向新API',reason='改变入口目标不等于API内部受控比例真实流量验证；DNS缓存过渡也不是该stage机制。')],minimumRepairScope=dict(cardRuleIds=[],questionIds=[]),formalBilingualAcceptance=False,privateGradingContractAcceptance=False,learnerMemoryOrAccuracyMeasured=False,finalCardCountVerified=False,currentPointersChangedByReviewer=False,productionOrInventoryChanged=False,authoringPerformed=False,externalOfficialReadOnlyFetches=0,directCliApiCalls=0,nativeUsage='unknown')
rp=O/'supplemental19.review.json';rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
z=rd(rp);rr=z['results'][0];assert ch(rr['visibleBody'])==rr['bodySha256'] and {f:th(rr['visibleBody'][f]) for f in F}==rr['fieldSha256']
for a in z['questionImpactReview'][0]['necessaryAnchors']:
    assert pool[a['ruleId']]['bodySha256']==a['bodySha256'] and pool[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
for k,e in z['evidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256'] and s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256'] and ch(e)==k
assert all(sha(p)==h for p,h in manifest.items()) and sha(index_path)==index_hash
rb=dict(status='PASS_candidate_necessity_and_question_readback',reviewPath=str(rp),reviewSha256=sha(rp),inputManifestSha256=sha(P/'manifest.json'),readBackAtUtc=now(),counts=z['counts'],checks=dict(newCandidateNotIn362Pool=True,canonicalBodyAndPerFieldHashes=True,full362PoolAlternativesRecorded=True,original544CompleteEveryOptionHashBound=True,allExactCurrentNecessaryAnchorsAndPriorProofs=True,bothImmutableOfficialSnapshotsTextQuoteHashMatch=True,sameSingleRecallTaskAndSelfAssessment=True,primaryDomain2Task22Validated=True,noCanaryBusinessDataRollbackGuarantee=True,noPromotionAutomaticallyDisablesCanaryClaim=True,notFinalCardCountAcceptance=True,allFrozenInputsStillUnchanged=True,noCurrentProductionOrInventoryMutation=True),directCliApiCalls=0,nativeUsage='unknown',learnerEffectMeasured=False,finalNVerified=False)
(O/'supplemental19.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(review=str(rp),sha256=sha(rp),counts=z['counts'],necessity=z['necessityReview']['verdict']),ensure_ascii=False))

# -*- coding: utf-8 -*-
import pathlib,json,hashlib,datetime,collections,re
D=pathlib.Path(__file__).resolve().parent;V=D.parents[2];I=V/'review/supplemental07-and05repair01/input';O=V/'review/reuse-a'
sha=lambda b:hashlib.sha256(b).hexdigest();canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode();read=lambda p:json.loads(pathlib.Path(p).read_text())
M=read(I/'manifest.json');draft=read(I/'cards.json');pool=read(I/'visible-pool.frozen.json');C={x['ruleId']:x for x in pool};Q={x['qid']:x['question'] for x in read(I/'questions.json')};AE=read(I/'official-evidence.json');IXP=V/'validation/current-card-review-index.json';IX={x['ruleId']:x for x in read(IXP)['cards']};F=['frontZH','answerZH','keyPointZH','watchOutZH'];E={};old05=O/'supplemental05.review.json';old05hash=sha(old05.read_bytes());old05r=read(old05)
for p,h in M.items():assert sha(pathlib.Path(p).read_bytes())==h,p
for c in pool:assert sha(canon(c['visibleBody']))==c['bodySha256']
AP=O/'supplemental04.review.json';AH='0dc72ffc38679e10226afd540b18a35a684f4be25a5525b323ca109e5562e001';assert sha(AP.read_bytes())==AH
AR=next(x for x in read(AP)['results'] if x['ruleId']=='CUR:NB04');assert AR['status']=='PASS' and sha(canon(AR['visibleBody']))==AR['bodySha256']
ADD=dict(ruleId='CUR:NB04',visibleBody=AR['visibleBody'],bodySha256=AR['bodySha256'],prerequisiteRuleIds=AR.get('prerequisiteRuleIds',[]),receiptPath=str(AP),receiptSha256=AH,scope='Root explicitly authorized this adopted visible NB04 receipt as narrow additional context for Q390 only; not private official facts and not a re-review of supplemental04.')
ADDP=D/'additional-context.CUR-NB04.json';ADDP.write_text(json.dumps(ADD,ensure_ascii=False,indent=2)+'\n')
for e in AE:
 p=pathlib.Path(e.get('snapshotPath') or e['sourcePath']);d=read(p);assert sha(p.read_bytes())==(e.get('snapshotSha256') or e['sourceFileSha256']);assert sha(d['text'].encode())==e['textSha256'];assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
def ev(n,start,end,supports):
 e=AE[n];p=pathlib.Path(e.get('snapshotPath') or e['sourcePath']);d=read(p);t=d['text'];a=t.index(start);b=t.index(end,a)+len(end);x=dict(sourcePath=str(p),sourceFileSha256=sha(p.read_bytes()),textSha256=sha(t.encode()),url=e['url'],quote=t[a:b],quoteStart=a,quoteEnd=b,supports=supports);k=sha(canon(x));E[k]=x;return k
def own(n,start,end,supports):
 p=D/(n+'.json');d=read(p);t=d['text'];a=t.index(start);b=t.index(end,a)+len(end);x=dict(sourcePath=str(p),sourceFileSha256=sha(p.read_bytes()),textSha256=sha(t.encode()),url=d['url'],quote=t[a:b],quoteStart=a,quoteEnd=b,supports=supports);k=sha(canon(x));E[k]=x;return k
transfer=ev(8,'Transfer data to and from the acceleration-enabled','Amazon S3 Transfer Acceleration does not support cross-Region copies using CopyObject.','GSC023: accelerate endpoint supports upload/download; not download caching')
transcost=ev(5,'When you use Transfer Acceleration','additional data transfer charges might apply.','GSC023: extra transfer charges remain')
tls=ev(11,'API Gateway enforces a security policy','policy accepts TLS 1.2 and TLS 1.3 traffic and rejects TLS 1.0 traffic.','CB13: negotiate TLS1.3 is supported, not TLS1.3-only minimum enforcement')
smapi=ev(0,'You replace hard-coded credentials','retrieve credentials dynamically when you need them.','CMP-M07: runtime API retrieval of managed secrets')
smenc=ev(2,'Secrets Manager uses envelope encryption','in AWS KMS.','CMP-M07: KMS envelope protection and controlled decryption')
smsla=ev(1,'Service Commitment AWS will use commercially reasonable efforts','Less than 99.99% but greater than or equal to 99.0% 10%','Q100: service-specific availability SLA; no inference of a specific AZ topology')
smtype=own('sm-secret-type','Secrets Manager enables you to store a JSON document','64 KB or smaller.','CMP-M07/Q100: arbitrary supported small text secret, not generic Regions boilerplate')
ebt=ev(4,'AWS services You can have EventBridge send events','SageMaker AI Pipeline','GSC029: SageMaker Pipeline is an EventBridge service target')
s3reason=ev(3,'reason – For Object Created events','or CompleteMultipartUpload .','Q139: Object Created reason API range')
s3crr=ev(3,'aws-generated-tags –','This field is not present for cross-Region replication events.','Q139: CRR event mention is a field exception, not positive proof of replica-created ObjectCreated delivery')
s3mapping=own('s3-mapping','The following table describes how Amazon S3 event types','Object Created','Q139: Put/Post/Copy/CompleteMultipartUpload map to Object Created')
s3event=own('s3-eventbridge-scope','Object Created\nAn object was created.','Object, CopyObject, or CompleteMultipartUpload.','Q139: supported ObjectCreated operation scope')
local=ev(10,'Every route table contains','route is added by default to all route tables.','VC008: same-VPC default local route')
nacl=ev(9,'Your virtual private cloud','subnets with which it is associated.','VC008: default NACL allows both directions')
newsg=ev(7,'When you first create a security group','until you add inbound rules to the security group.','VC008: newly-created SG has no inbound rules')
defsg=ev(6,'The following table describes the default inbound rules','ID of this security group.','VC008: VPC default SG self-reference is a different default')
budget=ev(25,'For Monitor my spend against','email and/or Amazon SNS topic.','GSC155: utilization/coverage denominators and below-target notifications')
bdaily=ev(25,'For Period , choose','All budget times are in UTC.','Q715: Savings Plans budget supports Daily')
sns=ev(18,'A dead-letter queue is an Amazon SQS queue','held in the dead-letter queue for further analysis or reprocessing.','VC009: SNS subscription delivery failures target SQS')
lam=ev(17,'Lambda can send records of asynchronous invocations','events that fail all processing attempts.','VC009: Lambda async on-failure may use SQS')
ret=ev(16,'Message retention','The maximum is 1,209,600 seconds (14 days).','VC009: retention can be set to requested 14d; no eternal retention claim')
long=ev(33,'With continuous backups, you can restore','Snapshots can be copied\nfor full or incremental backups.','NS03: finite continuous PITR versus long-retained periodic snapshots')
ddb=ev(32,'AWS Backup supports additional, advanced features','features enabled by default.','Q78: AWS Backup supports DynamoDB; feature qualifications remain')
feat=ev(22,'Automated backup schedules and retention management','Encrypted backups','NS03: automatic schedules/retention for supported resources')
dom1=own('exam-domain1','Task 1.2: Design secure workloads and applications\nKnowledge of:','Determining network segmentation strategies (for example, using public subnets and private subnets)','VC008 primaryTask belongs to 1.2, which explicitly lists SG/route/NACL security architecture')
dom2=own('exam-domain2','Queuing and messaging concepts','Determining when to use serverless technologies and patterns','VC009 Task2.1 covers pub/sub, event-driven and serverless queue boundaries; cross-reference 2.2 resilience possible')
def receipt(k):
 x=IX[k];c=ADD if k=='CUR:NB04' else C[k]
 if x['currentBodySha256']!=c['bodySha256']:
  parent=next(z for z in read(AP)['results'] if z['ruleId']==k);assert parent['priorBodySha256']==c['bodySha256'],k
  ps=[z for z in parent['namedValidPriorFACTProofs'] if z['receiptBodySha256']==c['bodySha256']];assert ps,k
  for z in ps:
   pp=pathlib.Path(z['path']);assert sha(pp.read_bytes())==z['sha256'];dd=read(pp);rr=next(r for r in dd.get('cards',dd.get('results',[])) if r['ruleId']==k);assert rr.get('status',rr.get('verdict'))=='PASS' and rr['bodySha256']==c['bodySha256']
   gates=rr.get('gates',{});assert all(gates[g].startswith('PASS') for g in ['FACT','U1','R1','T1','S1','P1'])
  return dict(ruleId=k,priorBodySha256=c['bodySha256'],proofs=ps,scope='Exact frozen prior-body PASS receipt retained through adopted supplemental04; no re-review or borrowing changed body.',laterRevisionReceiptPath=str(AP),laterRevisionReceiptSha256=AH)
 assert x['status']=='PASS',k
 for pp in x['proofs']:assert sha(pathlib.Path(pp['path']).read_bytes())==pp['sha256'],pp['path']
 return dict(ruleId=k,priorBodySha256=c['bodySha256'],indexPath=str(IXP),indexSha256=sha(IXP.read_bytes()),proofs=x['proofs'])
notes={
'GSC-023':('一个双向大对象传输路径选择；上传和下载是同一网络路径规则的两方向，不是叠两套配置。','把独有大文件改为多人反复下载相同静态对象时，缓存复用会改变CloudFront的价值；本卡没有把TA说成缓存或总会更便宜。',[transfer,transcost]),
'CUR:CB13':('新增句只是已有“证书CA与TLS策略分工”边界的现行HTTP API例子，不新增必背的密码套件或版本清单。','更换CA不会改变最低TLS策略；HTTP API能协商1.3不代表它拒绝1.2，不能拿本句自动验收强制TLS1.3-only。',[tls]),
'CUR:CMP-M07':('旧凭据读取/轮换/副本任务按有效收据复用；新增KMS托管存储解释原服务的作用机制，没有增加一套配置动作。','数据库轮换需改真实密码；小型受支持敏感值也可受控读取，不能把KMS密钥轮换当密码更新或把复制同一secret当不同数据库同时轮换。',[smapi,smenc,smsla,smtype]),
'GSC-029':('SageMaker Pipeline是同一个S3事件路由规则的目标例子，不要求回忆ML训练或整套pipeline部署。','对象创建触发与定时扫描不同；需要复制完成后处理时仍必须核实际写入操作/目标桶事件，不能由新增目标能力推导复制语义。',[ebt,s3reason]),
'VC-008':('所有前提指向一个判断：默认路径已通，新SG没有入站许可，应打开接收端门。三个默认事实是该因果链前提，不是三套独立操作。','若两端实际共用VPC自带default SG，同组自引用已放行，不能把本卡的新建SG场景直接套上去。',[local,nacl,newsg,defsg,dom1]),
'GSC-155':('正面现在明确问监控/通知的预算指标；两个分母沿同一监控选择轴，背面没有新增未问的购买或另一任务。','覆盖不足用coverage预算；承诺闲置用utilization预算。两者低于目标时提醒，不将告警自动等同必须购买。',[budget,bdaily]),
'VC-009':('一个真实的失败阶段辨析：SNS交付与Lambda已接收后的业务处理。仅比较两种失败发生点，未重加SQS毒消息阈值任务。14天已在题面给定，不把重述数字列成额外必答。','从SNS→Lambda改成SNS→HTTPS时仍在订阅投递层放SQS DLQ；交付已成功而函数业务失败时只加SNS重试无效。',[sns,lam,ret,dom2]),
'CUR:NS03':('正面本就问备份周期与到期保留；新增长期周期恢复点/PITR窗口区别解释保留的含义，不要求记新数字、完整部署或第二套步骤。','多年留存用计划周期恢复点；近期任意时间恢复与长期某张恢复点不同。支持跨Region/EFS和DDB冷层资格原证据复用。',[long,feat,ddb])}
Ovl=dict(C);cards=[]
for c in draft:
 k=c['ruleId'];body={f:c[f] for f in F};new=k not in C;h=sha(canon(body));n,t,eids=notes[k]
 if not new:assert c['repairOf']==C[k]['bodySha256'];r=receipt(k)
 else:r=None
 if c.get('failedVersionBodySha256'):
  old=next(x for x in old05r['cards'] if x['ruleId']==k);assert old['verdict']=='FAIL' and old['bodySha256']==c['failedVersionBodySha256']
 checks={key:dict(status='PASS',reason=why) for key,why in [('FACT','新增原句有正向官方证据；旧机制只按绑定有效收据复用，不借官方事实当额外学习卡。'),('U1',n),('R1',n),('T1',t),('S1','自评对应正面实际一个判断及机制，不追加前提、提示或未问的实施事项。'),('P1','先修来自351保留池；新卡另做全池替代及必要性检查。')]};checks['B1']=dict(status='NOT_APPLICABLE',reason='只审冻结中文正文，不作双语/导入/手机/发布验收。')
 cr=dict(ruleId=k,verdict='PASS',bodySha256=h,priorBodySha256=C[k]['bodySha256'] if not new else None,inputCardSha256=sha(canon(c)),visibleBody=body,changedFields=[f for f in F if new or body[f]!=C[k]['visibleBody'][f]],newIdentity=new,reusedMechanismReceipt=r,checks=checks,evidenceIds=eids,transferProbe=t,formalBilingualAcceptance=False)
 cards.append(cr);Ovl[k]=dict(C[k],visibleBody=body,bodySha256=h) if not new else dict(ruleId=k,visibleBody=body,bodySha256=h,prerequisiteRuleIds=c.get('prerequisiteRuleIds',[]))
# All retained pool bodies are searched; only relevant governing rules are semantically compared.
search_terms={'VC-008':['默认','local','路由','NACL','安全组'],'VC-009':['失败','DLQ','死信','投递','异步']}
for cr in cards:
 if cr['ruleId'] not in search_terms:continue
 k=cr['ruleId'];hits=[x['ruleId'] for x in pool if any(t.lower() in json.dumps(x['visibleBody'],ensure_ascii=False).lower() for t in search_terms[k])]
 if k=='VC-008':
  comparisons=[('CUR:CMP-M10','能教接收端准入与上一跳/端口，不能推出默认路由、默认NACL及default/new SG初始状态。'),('CUR:CB15','有状态/无状态回程规则不推出默认许可。'),('CUR:CB16','不同VPC peering及两端路由不等于同VPC默认local route。')]
  domain=dict(primaryDomain='1',proposedPrimaryTask='1.3',recommendedPrimaryTask='1.2',verdict='FAIL_METADATA',reason='官方Task1.2的技能项明确写security groups, route tables, network ACLs；1.3偏数据恢复/保留/加密控制。正文不因此重写。',evidenceIds=[dom1])
  reuse=[388]
 else:
  comparisons=[('GSC-083','只教队列持续失败的阈值DLQ；上次扩成三机制已R1/S1 FAIL，不能用失败版本替代。'),('GSC-079','持久队列成功后确认不指定SNS redrive或Lambda异步destination。'),('GSC-080','独立订阅路径提供基础，不教投递失败去向。'),('VC-001','教SQS→Lambda消费，不教SNS→Lambda异步失败留存。'),('CUR:NC04','投递不等于业务成功已有原则，但无两种实际失败接线。'),('GCL-024','EventBridge匹配/目标交付的监控判断，不替代SNS投递与Lambda业务失败两层机制。')]
  domain=dict(primaryDomain='2',proposedPrimaryTask='2.1',recommendedPrimaryTask='2.1',crossReferenceTasks=['2.2'],verdict='PASS',reason='事件驱动/发布订阅/队列与serverless解耦属于2.1；失败保留也可交叉引用2.2，不复制卡正文。',evidenceIds=[dom2]);reuse=[148,489]
 for rid,_ in comparisons:assert rid in C;receipt(rid)
 cr['wholePoolAlternativeAssessment']=dict(poolCount=351,poolSha256=sha((I/'visible-pool.frozen.json').read_bytes()),scan='Deterministic search across all 351 visible bodies; semantic comparison of governing rules below. This is not a proof of the global minimum core set.',searchTerms=search_terms[k],matchedRuleIds=hits,comparedRetainedRules=[dict(ruleId=rid,visibleBody=C[rid]['visibleBody'],bodySha256=C[rid]['bodySha256'],finding=finding) for rid,finding in comparisons],substitutionVerdict='NO_COMPLETE_SUBSTITUTE_IN_RETAINED_POOL',separateTaskNecessity='PASS',whySeparate='新增的是一个不能由旧卡推出的必要判断；不把它附加到已有多边界卡上造成记忆过载。',candidateQuestionIds=reuse,coreSelectionStatus='DEFER_LOW_REUSE_CANDIDATE_ONLY',coreSelectionReason='目前只证明1题/2题用途；按全库共享核心目标仍须证明更广真题必要复用或做取舍，不因通过正文就批准计入最终N。',newCardApproved=False)
 cr['domainTaskAssessment']=domain
Ovl['CUR:NB04']=dict(C['CUR:NB04'],visibleBody=ADD['visibleBody'],bodySha256=ADD['bodySha256'],prerequisiteRuleIds=ADD['prerequisiteRuleIds'])
questions=[]
def anchor(k,f,why):
 c=Ovl[k];return dict(ruleId=k,cardId=k,bodySha256=c['bodySha256'],field=f,quote=c['visibleBody'][f],quoteStart=0,quoteEnd=len(c['visibleBody'][f]),supports=why,origin=('Adopted supplemental04 narrow visible context for Q390' if k=='CUR:NB04' else ('proposed 07/05repair overlay' if k in notes else 'frozen retained351')))
def add(q,status,choice,ids,anchors,reason,opts,missing=None,conditions=None,impl=None,extra=None):
 seen=set();g=[]
 def visit(k,active):
  assert k in Ovl and k not in active,k
  if k in seen:return
  seen.add(k);c=Ovl[k];g.append(dict(ruleId=k,visibleBody=c['visibleBody'],bodySha256=c['bodySha256'],prerequisiteRuleIds=c['prerequisiteRuleIds']))
  if k in C:receipt(k)
  for p in c['prerequisiteRuleIds']:visit(p,active|{k})
 for k in ids:visit(k,set())
 questions.append(dict(qid=q,status=status,selectedOptionOrdinals=choice if status=='SUPPORTED' else [],candidateOptionOrdinals=choice if status!='SUPPORTED' else [],questionSha256=sha(canon(Q[q])),originalQuestion=Q[q],fullStemAndAllOptionsRead=True,usedRuleIds=ids,necessaryAnchors=anchors,learnerVisibleGroup=g,reasoning=reason,allOptions=opts,missingJudgments=missing or [],conditionsAndSourceIssues=conditions or [],implementationValidationNotNewKnowledge=impl or [],additionalDependencyContext=extra,scope='Original-question design support under proposed overlay, not approval/application/learner outcomes.'))
add(78,'SUPPORTED',[2],['CUR:NS03','GSC-047'],[anchor('CUR:NS03','answerZH','AWSBackup统一周期与保留'),anchor('CUR:NS03','keyPointZH','长期周期恢复点与有限PITR不同'),anchor('GSC-047','watchOutZH','长期快照不是多年任意秒PITR')],'B用受支持的AWS Backup计划及长期保留保存恢复点。七年不是近期PITR窗口，长期周期恢复点规则可从已有RDS例子与NS03公共备份机制迁移；无需新增DDB数字配额卡。',{1:'PITR是有限近期窗口，不是七年历史保留。',2:'托管计划/保留策略匹配长期保留，最少手工。',3:'手工on-demand非持续计划，且DDB backup不等同可把原生备份任意当普通S3对象。',4:'自写Lambda备份/上传需要维护，较托管Backup复杂。'},impl=['设置与数据保留目标相符的周期与七年保留；题目未要求不可变/任意秒回溯，不额外添加。'])
add(100,'SUPPORTED',[1],['CUR:CMP-M07','CUR:CMP-M06','CUR:SC01','CUR:NA05'],[anchor('CUR:CMP-M07','answerZH','managed secret runtime retrieval'),anchor('CUR:CMP-M07','keyPointZH','KMS保护及托管存储/取值解密'),anchor('CUR:CMP-M06','answerZH','EC2运行角色受限授权')],'A对普通受支持大小证书值可使用受控秘密库的自动加密、存储与运行时读取，避免自行拼KMS与对象取值流程；无需原题未问的AZ具体拓扑。服务专属Secrets Manager SLA正证验证服务可用性，并未用通用AWS Region/AZ模板冒充存储设计。手动更换证书不违反原题，因为原文未要求证书自动续期。',{1:'managed vault加密/受控API读取满足安全证书小载荷场景，最少应用编排。',2:'只说把函数代码存在S3，没有定义证书密文数据的HA存储。',3:'可用KMS+S3存密文，但由应用承担加解密和数据获取编排，操作较多。',4:'单AZ EBS卷不直接提供所需存储可用性范围。'},impl=['受支持secret载荷与IAM/key授权；不把服务SLA百分比或AZ拓扑列为本题额外必背。','官方建议证书生命周期可用ACM不等于SecretsManager不能保存受支持大小的证书值；题中无ACM选项也无自动续期要求。'])
add(139,'UNKNOWN',[2,4],['CUR:NEW04','GSC-029','GSC-030','CUR:CC17'],[anchor('CUR:NEW04','keyPointZH','native live replication applies eligible new versions'),anchor('GSC-029','answerZH','EventBridge supports Pipeline target'),anchor('GSC-030','answerZH','Copy/CompleteMultipartUpload不是Put'),anchor('CUR:CC17','keyPointZH','事件路由不等于实际资源动作')],'新增SageMaker目标能力已经闭合，A/C还受原生S3通知不支持Pipeline及只匹配Put漏Copy/CompleteMultipartUpload影响。B的Lambda复制后可用ObjectCreated的Copy/CompleteMultipartUpload事件走EventBridge，技术方向正向成立。D以托管复制降低代码运维，但目标桶副本写入是否产生它指定的ObjectCreated事件尚未得到所给官方文档的正向确认。官方列出API事件范围，且只提“CRR事件缺少某tags字段”，后者不能偷换成每个复制到达都产生同类ObjectCreated的承诺；也不由未列出就断言D绝不支持。',{1:'native S3 notification不能直接把SageMaker Pipeline当普通目标，Put事件也漏复制函数可能采用的Copy/Multipart。',2:'EventBridge支持Lambda及Pipeline；API copy/completion事件有明示范围，仍要配置初始桶触发复制函数。',3:'同样native通知目标及Put范围不对；另含replication目标事件范围问题。',4:'目标服务支持无误，但replica写入→目标ObjectCreated这一必要中段未有正证，不能只看target清单就全链PASS。'},missing=['若D要成为最少运维答案，需官方正证确认replication目的对象产生题述ObjectCreated事件及范围；这不是额外制卡或生产实测任务。'],conditions=['保留B/D而不凭旧答案选D，也不凭缺文给D定错。'])
add(148,'CONDITIONAL',[4],['VC-009','GSC-079','GSC-080','VC-001'],[anchor('VC-009','answerZH','失败留存须按SNS/Lambda发生点'),anchor('VC-009','keyPointZH','交付不等于处理'),anchor('VC-001','answerZH','受管队列消费确认')],'D保留失败工作并重新消费的设计方向已教；VC009新题面现在只比较两种阶段且14天是给定条件，原GSC083不扩写。但原题没有说明network failure发生于SNS交付还是Lambda内访问存储，必须把配置接到实际失败层才声称捕获。',{1:'Lambda可用性部署不是持久失败留存。',2:'CPU/内存增加不替代网络故障留存。',3:'仅增加SNS投递重试不捕获已交给Lambda后的业务失败。',4:'SQS作为相应失败路径并重放可达目标；若只配Lambda on-failure，不能捕获SNS从未交付的事件。'},conditions=['先确认实际失败边界或同时保护所需路径；原文不能仅凭network connectivity强定一个层。'],impl=['解析失败记录、修复与幂等重放不是新的卡片机制义务。'])
add(388,'CONDITIONAL',[4],['VC-008','CUR:CMP-M10','CUR:CB15'],[anchor('VC-008','answerZH','default local/NACL与newSG入站'),anchor('VC-008','watchOutZH','defaultSG自引用不同'),anchor('CUR:CMP-M10','answerZH','接收端按source/port准入')],'新增VC008已教缺少的默认规则。若题中Web/DB各用新建tier SG，则D正确：local路径/NACL默认已通，DB入站未放行。原文仍只说default states，没有像新教学卡明确“分别新建的SG”；若共用VPC自带default SG，自引用已经允许同组，D不能被强作根因修复。不能拿收窄教学场景替换原题后宣称无条件充分。',{1:'默认NACL本已放行，非需新增允许。',2:'同VPC local route本已存在。',3:'peering引入不必要结构且不替代SG准入。',4:'在独立新tier SG情形下打开RDS接收端许可；同default SG情形则不能重复该假设。'},conditions=['原题需明确两tier关联的SG类型/分离关系；卡片已解释两分支，原题条件没有因此变更。'])
add(390,'SUPPORTED',[2,4],['CUR:NB08','GSC-032','CUR:XB013','CUR:NB04'],[anchor('CUR:NB08','answerZH','外置DynamoDB/Redis会话'),anchor('GSC-032','keyPointZH','复制/接管是HA'),anchor('CUR:NB04','answerZH','已正式PASS并采用的NB04教Redis快照恢复'),anchor('CUR:NB04','watchOutZH','快照后的新增数据仍可能丢失')],'B/D的外置会话与Redis持久化/恢复知识现在均来自有效可见正文。原冻结包仍是旧NB04；root明确授权并提供正式supplemental04收据后，本轮只为Q390附加该同UID正文，精确绑定receipt与新body hash，不把私有backup事实补成学习内容。durably按题目普通持久化/恢复能力理解，未擅自提升为零RPO/每次写同步落盘。',{1:'粘滞不持久化实例本地会话。',2:'DynamoDB符合在线共享会话记录。',3:'用户身份/令牌系统不是任意购物会话状态的共享仓库。',4:'Redis可按已教快照备份恢复机制外置会话，复制与快照职责分开；不保证快照后每一条写入不丢。',5:'ApplicationManager不是应用会话存储。'},impl=['配置适合业务的持久化备份/恢复和副本，不把只创建裸内存缓存自动当作全部已配置。'],extra=dict(ruleId='CUR:NB04',state='ADOPTED_PASS_RECEIPT_ADDITIONAL_VISIBLE_CONTEXT',path=str(ADDP),sha256=sha(ADDP.read_bytes()),receiptPath=str(AP),receiptSha256=AH,bodySha256=ADD['bodySha256'],usedOnlyForQuestionIds=[390],privateOfficialFactsBorrowed=False))
add(443,'SUPPORTED',[1],['GSC-023','CUR:CA16','CUR:CA13'],[anchor('GSC-023','answerZH','TA双向支持操作'),anchor('GSC-023','keyPointZH','双向网络路径非重复缓存'),anchor('CUR:CA16','keyPointZH','未要求服务端代码时静态托管可用')],'A的双向大对象传输缺口已由GSC023修订闭合。原题未要求服务端运算，不能自己添加动态后端需求来排除S3；独有对象降低共享缓存复用价值。',{1:'直接对象托管与远距离上传/下载路径匹配，按来源评估加速费用。',2:'Cache-Control只调缓存，不建立对象上传加速路径。',3:'能构成Web设计，但多出未要求的EC2主机/计算维护，独有大对象仍需双向路径。',4:'应用后端缓存不能代替全球用户对象传输加速。'},impl=['评估来源地收益及费用、支持的请求/桶；不用原题未问的绝对最低账单或吞吐测试阻止架构选择。'])
add(489,'SUPPORTED',[3],['VC-009','GSC-080','GSC-079'],[anchor('VC-009','answerZH','SNS订阅投递失败接SQS DLQ'),anchor('VC-009','keyPointZH','14d保留能力'),anchor('GSC-080','keyPointZH','HTTP订阅独立交付路径')],'C在明确的HTTPS订阅投递失败层保留SQS消息14天。VC009的SNS失败路径可从Lambda示例迁移到HTTPS订阅，不要求另背一套服务组合。',{1:'Kinesis不是SNS订阅DLQ目标。',2:'队列放SNS之前不能捕获后续HTTPS投递失败。',3:'受支持SQS DLQ及14天保留。',4:'DynamoDB不作为SNS subscription DLQ，TTL不代替失败投递路径。'})
add(571,'CONDITIONAL',[1],['CUR:CB13'],[anchor('CUR:CB13','answerZH','第三方CA证书导入实际TLS入口'),anchor('CUR:CB13','watchOutZH','能协商1.3与最低版本策略分开')],'A的第三方签发→ACM导入→HTTP API custom domain路径正确，现行HTTP API确实能协商TLS1.3；不能再按旧TLS1.2-only认知排它。但官方明确HTTP API固定TLS_1_2策略同时接受1.2/1.3，原题写strict requirements/requiresTLS1.3，如其含义是最低只允许1.3，则A未能强制拒绝1.2。当前卡句只说可协商且准确，不等于原题安全要求已无条件闭合。',{1:'正确外部CA导入与custom domain路径；可使用1.3，不提供1.3-only最低版本强制。',2:'ACM不能代表指定第三方公信CA为你签发所述请求，应在外部取得后导入。',3:'先要求ACM代指定第三方公信CA签发，已不满足所述外部签发/导入流程，无需额外借函数URL特性排除此项。',4:'同样要求ACM代指定第三方公信CA签发，来源流程本身不符。'},conditions=['明确原题TLS1.3是连接能力还是禁止低版本的硬策略。若只要求客户端能用1.3，A可行；若要求最低1.3，不能静默放宽为支持1.3。'])
add(715,'SUPPORTED',[1],['GSC-155','GSC-152'],[anchor('GSC-155','answerZH','coverage预算阈值通知'),anchor('GSC-155','keyPointZH','coverage分母及低于目标提醒')],'A直接监控coverage并在低于阈值时通知，Daily周期有官方正证。修订卡现在明确问选哪类预算指标并自动通知，原S1/R1失配闭合。',{1:'托管coverage budget阈值通知，最少自写维护。',2:'Lambda/SES自写报告比托管预算复杂。',3:'定时报告不等同覆盖率跌破阈值的条件告警。',4:'泛计划告警订阅不是指定coverage预算配置。'})
# Final immutable binding checks, including FAIL lineage preservation and no omitted-card borrowing.
assert len(cards)==8 and len(questions)==10;assert len(Ovl)==353;assert Ovl['GSC-083']['bodySha256']==C['GSC-083']['bodySha256']
omitted={'CUR:XB039','GSC-019','GCL-017','GSC-072','GSC-098','GSC-108','GSC-084','GCL-020'}
for q in questions:
 assert len(q['allOptions'])==len(Q[q['qid']]['options']);assert not omitted&{x['ruleId'] for x in q['learnerVisibleGroup']}
 for a in q['necessaryAnchors']:
  c=Ovl[a['ruleId']];assert c['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']]==a['quote']
for p,h in M.items():assert sha(pathlib.Path(p).read_bytes())==h,p
assert sha(old05.read_bytes())==old05hash
for e in E.values():
 p=pathlib.Path(e['sourcePath']);d=read(p);assert sha(p.read_bytes())==e['sourceFileSha256'];assert sha(d['text'].encode())==e['textSha256'];assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
now=datetime.datetime.now(datetime.timezone.utc).isoformat();qc=dict(collections.Counter(x['status'] for x in questions));summary=dict(cardCount=8,cardPass=8,cardFail=0,cardUnknown=0,newMechanismCandidatePass=2,newMechanismsApproved=0,metadataFail=1,questionCount=10,**qc)
metadata=[dict(ruleId='VC-008',field='primaryTask',proposed='1.3',required='1.2',reason='Network workloads/application security is Task1.2 by official exam guide.',bodyChangeRequired=False)]
out=dict(schemaVersion=1,reviewer='actual_gap_review independent supplemental07-and05repair01',reviewedAtUtc=now,authorVersion='Frozen combined 8-candidate overlay only; no application or approval',inputManifestPath=str(I/'manifest.json'),inputManifestSha256=sha((I/'manifest.json').read_bytes()),inputFiles=M,bodyHashContract='SHA256 canonical UTF8 JSON of four Chinese fields sorted keys compact separators',summary=summary,cards=cards,evidenceRegistry=E,affectedQuestions=questions,metadataRepairRequests=metadata,contentRepairRequests=[],overlayPoolBinding=dict(path=str(I/'visible-pool.frozen.json'),sha256=sha((I/'visible-pool.frozen.json').read_bytes()),retainedCount=351,revisedIdentities=6,newCandidateIdentities=2,proposedOverlayCount=353,finalN=None),additionalFrozenVisibleContext=dict(path=str(ADDP),sha256=sha(ADDP.read_bytes()),receiptPath=str(AP),receiptSha256=AH,usedOnlyForQuestionIds=[390]),originalReviewHistoryPreserved=True,priorFailedReview=dict(path=str(old05),sha256=old05hash,preservedFailedRules=['GSC-083','GSC-155'],GSC083FailedVersionAdopted=False),scope='Chinese FACT/teaching, separate-task necessity and original-question design support only. Metadata correction and final core selection remain pending. No bilingual/export/learner performance acceptance.',modelCliApiCalls=0,nativeUsage='unknown',currentPointersChangedByReviewer=False,authoringPerformed=False)
p=O/'supplemental07-and05repair01.review.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
rb=dict(schemaVersion=1,status='PASS',scope='Deterministic artifact bindings only; conditional/unknown/gap and metadata failure are not upgraded.',checkedAtUtc=now,reviewPath=str(p),reviewSha256=sha(p.read_bytes()),inputManifestSha256=sha((I/'manifest.json').read_bytes()),frozenInputsChecked=len(M),retainedCardBodiesChecked=351,reviewedCandidates=8,revisionRepairOfBindings=6,newCandidateCount=2,newCandidatesApproved=0,wholePoolAlternativeSearches=2,metadataFailureCount=1,questionCount=10,allOriginalOptionsRetained=True,officialExactExcerpts=len(E),proofAnchorsExact=True,missingPrerequisites=0,omittedSevenAndGCL020Used=0,oldGSC083BodyUnchanged=True,priorFAILReviewSha256=old05hash,unappliedSupplemental04BodyBorrowed=False,adoptedSupplemental04VisibleContextQuestionIds=[390],additionalNB04BodySha256=ADD['bodySha256'],currentPointersChanged=False,modelCliApiCalls=0,nativeUsage='unknown',finalN=None)
(O/'supplemental07-and05repair01.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False));print('EVIDENCE',len(E))

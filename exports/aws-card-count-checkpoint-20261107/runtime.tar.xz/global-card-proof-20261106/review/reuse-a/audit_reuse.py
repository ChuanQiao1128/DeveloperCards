import json,hashlib,collections
from pathlib import Path
from urllib.parse import urlparse
V=Path(__file__).resolve().parents[2]; C=V.parent/'domain1-compression80-20261106';O=V.parent/'domain1-final-card-catalog-20261105';P=V.parent/'domain1-card-backtest-20261105'; OUT=V/'review/reuse-a'
cache={}; hashes={}
def rd(p):
 p=Path(p)
 if str(p) not in cache:cache[str(p)]=json.loads(p.read_text())
 return cache[str(p)]
def sha(p):
 p=Path(p)
 if str(p) not in hashes:hashes[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 return hashes[str(p)]
def ch(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sh(s):return hashlib.sha256(s.encode()).hexdigest()
BODY=['frontZH','answerZH','keyPointZH','watchOutZH'];ASSESS=['id','title','difficulty']+BODY+['mustAnswer','prerequisiteIds']
def body(c):return {k:c[k] for k in BODY if c.get(k)}
def walk(v):
 if isinstance(v,dict):
  yield v
  for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
def nodes(v,cid):return [x for x in walk(v) if cid in [x.get('cardId'),x.get('targetCoreId'),x.get('coreId'),x.get('ruleId'),x.get('id'),x.get('stableUid')]]
def same_body_nodes(v,cid,h):return [x for x in walk(v) if x.get('bodySha256')==h or x.get('reviewedTextSha256')==h or all(k in x for k in ['frontZH','answerZH','keyPointZH']) and ch(body(x))==h]
def pinned_inputs(d):
 m=d.get('inputHashes',d.get('inputSha256',{}));m=m.copy() if isinstance(m,dict) else {}
 for e in d.get('inputFiles',[]):m[e['path']]=e['sha256']
 if isinstance(d.get('input'),dict) and d['input'].get('path'):m[d['input']['path']]=d['input']['sha256']
 if d.get('proposalPath'):m[d['proposalPath']]=d['proposalSha256']
 return m
def ref(p):return {'path':str(p),'sha256':sha(p)}
def resolve(parent,n):
 p=Path(n)
 if p.is_absolute():return p
 choices=[parent/n,parent/'input'/n,parent.parent/n,P/n,O/n]
 return next((x for x in choices if x.is_file()),choices[0])
def inputcheck(p):
 d=rd(p);m=pinned_inputs(d);out=[]
 if isinstance(m,dict):
  for n,h in m.items():
   q=resolve(Path(p).parent,n)
   if not q.is_file() or sha(q)!=h:out.append({'code':'INPUT_BINDING_MISMATCH','path':str(q),'expected':h,'actual':sha(q) if q.is_file() else None})
 return out
sourcecat={}
for f in [P/'facts/sources.catalog.json',P/'facts/supplemental-sources.catalog.json']:
 for e in rd(f):sourcecat[e['sourceKey']]=e
sourcechecks={}
sourceall=rd(O/'official-sources.catalog.json')+list(sourcecat.values())
sourceindex={(e.get('url'),e.get('textSha256')):e for e in sourceall}
def evidencecheck(e):
 if 'quote' not in e and 'text' in e:
  e={**e,'quote':e['text'],'quoteSha256':e.get('textSha256'),'startChar':e.get('charStart'),'endChar':e.get('charEnd')}
  e.pop('textSha256',None)
 key=ch(e)
 if key in sourcechecks:return sourcechecks[key]
 errors=[];n=e.get('sourcePath');meta=sourcecat.get(e.get('sourceKey'),{})
 if not n:
  meta=sourceindex.get((e.get('url'),e.get('sourceTextSha256')),meta);n=meta.get('sourcePath')
 if not n or not Path(n).is_file():res={'errors':[{'code':'SOURCE_SNAPSHOT_MISSING','sourcePath':n,'sourceKey':e.get('sourceKey')}],'sourcePath':n};sourcechecks[key]=res;return res
 p=Path(n);d=rd(p);txt=d.get('text',d.get('content',''));q=e.get('quote','');url=e.get('url');host=urlparse(url or '').hostname or ''
 if not (host=='aws.amazon.com' or host.endswith('.aws.amazon.com') or host=='pricing.us-east-1.amazonaws.com'):errors.append({'code':'NON_OFFICIAL_URL','url':url})
 if url not in [d.get('url'),d.get('finalUrl'),d.get('requestedUrl'),meta.get('url')]:errors.append({'code':'SOURCE_URL_MISMATCH','url':url})
 if not q or q not in txt:errors.append({'code':'QUOTE_NOT_IN_FULL_SNAPSHOT'})
 expected=e.get('sourceTextSha256') or e.get('textSha256') or meta.get('textSha256')
 if expected and sh(txt)!=expected:errors.append({'code':'SOURCE_TEXT_HASH_MISMATCH','expected':expected,'actual':sh(txt)})
 if e.get('quoteSha256') and sh(q)!=e['quoteSha256']:errors.append({'code':'QUOTE_HASH_MISMATCH'})
 if isinstance(e.get('startChar'),int) and isinstance(e.get('endChar'),int) and txt[e['startChar']:e['endChar']]!=q:errors.append({'code':'QUOTE_OFFSET_MISMATCH'})
 expectedfile=e.get('sourceFileSha256') or meta.get('fileSha256')
 if expectedfile and sha(p)!=expectedfile:errors.append({'code':'SOURCE_FILE_HASH_MISMATCH'})
 res={'sourcePath':str(p),'fileSha256':sha(p),'sourceTextSha256':sh(txt),'quoteSha256':sh(q),'quote':q,'url':url,'errors':errors};sourcechecks[key]=res;return res
cards=rd(V/'inputs/existing176.json');by={x['body']['id']:x['body'] for x in cards};outer={x['body']['id']:x for x in cards};bindings=rd(V/'inputs/prior-card-review-bindings.json');scope={x['body']['id'] for x in cards if x['scopeDecisions']};oldcomp={x['id']:x for x in rd(C/'deliverables/catalogue.compressed.json')};oldfull={x['id']:x for x in rd(O/'deliverables/catalogue.final.json')};routing={x['oldId']:x['currentCardIds'] for x in rd(C/'candidate/routing197.json')}
def closure(cid,pool):
 seen=set();stack=[cid]
 while stack:
  a=stack.pop()
  if a in seen:continue
  seen.add(a)
  if a in pool:stack+=pool[a].get('prerequisiteIds',[])
 return seen
def assess(c):return {'mustAnswer':c.get('mustAnswer',[]),'prerequisiteIds':c.get('prerequisiteIds',[])}
def proofstatus(row,gate):
 if gate=='FACT':return row.get('FACT')=='PASS' or str(row.get('checks',{}).get('FACT','')).startswith('PASS') or row.get('status')=='SUPPORTED' or row.get('factStatus')=='SUPPORTED'
 return all(row.get(k)=='PASS' or str(row.get('checks',{}).get(k,'')).startswith('PASS') for k in ['U1','R1','T1','S1'])
# All initial input bytes pinned, before inspecting claims.
frozen=rd(OUT/'input/manifest.json');assert all(Path(p).is_file() and sha(p)==h for p,h in frozen.items())
result=[];issues=[]
for x in cards:
 c=x['body'];cid=c['id'];h=ch(body(c));bind=bindings[cid];errs=[];facterrs=[];teacherrs=[];proofs=[];quotes=[];orig_specs=[];deps=sorted(closure(cid,by)-{cid});changedDeps=sorted(set(deps)&scope)
 assert h==c['bodySha256'];assert ch({'body':body(c),'mustAnswer':c.get('mustAnswer',[]),'prerequisiteIds':c.get('prerequisiteIds',[])})==c['learningSha256'];assert ch(body(oldcomp[cid]))==h and assess(oldcomp[cid])==assess(c)
 if 'priorBinding' in bind:
  pb=bind['priorBinding'];assert pb['bodySha256']==h
  f=pb['FACT'];t=pb['TEACHING']
  for label,rece in [('FACT',f),('TEACHING',t)]:
   p=Path(rece['path']);assert p.is_file() and sha(p)==rece['sha256'];proofs.append({'gate':label,**ref(p)})
  fp=Path(f['path']);fd=rd(fp)
  if f['kind']=='unchanged_prior_prototype_fact_review':
   rr=[r for r in fd['allCurrentFactProofs'] if r['coreId']==cid and r['bodySha256']==h];assert len(rr)==1 and rr[0].get('factStatus',rr[0].get('FACT'))=='PASS';nm=f['originalProof'];opts=list(P.rglob(nm));assert len(opts)==1;fp=opts[0];fd=rd(fp);proofs.append({'gate':'FACT_original',**ref(fp)});facterrs+=inputcheck(fp)
   if nm=='fact-results.json':
    rows=[r for r in fd['rules'] if r['ruleId']==cid];orig_specs+=nodes(rd(P/'cards.visible.json'),cid)
   else:rows=same_body_nodes(fd,cid,h)
   rows=[r for r in rows if proofstatus(r,'FACT')]
   if not rows:facterrs.append({'code':'ORIGINAL_FACT_ROW_NOT_BOUND'})
   for r in rows:
    for e in walk(r):
     if e.get('quote') and e.get('url'):quotes.append(evidencecheck(e))
   # Original full visible body must be reconstructed from pinned input files, not the derived PASS list.
   for name,ih in pinned_inputs(fd).items():
    ip=resolve(fp.parent,name)
    if ip.is_file() and ip.suffix=='.json':orig_specs+=same_body_nodes(rd(ip),cid,h)
   if nm!='fact-results.json':
    for r in rows:
     if isinstance(r.get('reviewedText'),dict) and ch(body(r['reviewedText']))==h:orig_specs.append(r['reviewedText'])
  elif f['kind']=='unchanged_accepted_card_fact_review':
   req=rd(fp.parent/'request.json');ap=Path(req['artifactPath']);ip=Path(req['inputPath']);proofs += [{'gate':'FACT_artifact',**ref(ap)},{'gate':'FACT_input',**ref(ip)}]
   assert sha(ap)==req['artifactSha256']==fd['artifactSha256'] and sha(ip)==req['inputSha256']==fd['inputSha256'];rows=[r for r in fd['cards'] if r['stableUid']==cid];assert len(rows)==1 and rows[0]['rules']['FACT']=='PASS'
   z=next((z for z in rd(ap)['cards'] if z.get('stableUid')==cid),None)
   if z:
    zh={k:z.get(k[:-2]+'Zh','') for k in BODY};zh={k:v for k,v in zh.items() if v};
    if ch(zh)!=h:facterrs.append({'code':'FORMAL_ARTIFACT_BODY_MISMATCH'})
   else:facterrs.append({'code':'FORMAL_CARD_NOT_FOUND'})
   target=next(z for z in rd(ip)['cards'] if z.get('stableUid')==cid)
   eids={k for z in target.get('citations',[]) for k in z.get('evidenceIds',[])}
   for e in walk(rd(ip).get('officialEvidence',{})):
    if e.get('evidenceId') in eids and e.get('url'):quotes.append(evidencecheck(e))
  else:
   reviewid=f.get('reviewedCardId',cid)
   rows=[r for r in fd['cards'] if r['id']==reviewid and r['bodySha256']==h]
   if len(rows)!=1:facterrs.append({'code':'ORIGINAL_FACT_ROW_NOT_BOUND','path':str(fp)})
   elif not proofstatus(rows[0],'FACT'):facterrs.append({'code':'ORIGINAL_FACT_NOT_PASS'})
   facterrs+=inputcheck(fp);sp=fp.parent/'spec.json';orig_specs+=same_body_nodes(rd(sp),cid,h)
   if not orig_specs:facterrs.append({'code':'REVIEWED_SPEC_BODY_MISMATCH'})
   for spec in orig_specs:
    for e in spec.get('factEvidence',[]):quotes.append(evidencecheck(e))
  tp=Path(t['path']);td=rd(tp);teacherrs+=inputcheck(tp);tr=[r for r in td['cards'] if r.get('id')==t.get('reviewedCardId',cid) and r.get('bodySha256')==h]
  if len(tr)!=1 or not proofstatus(tr[0],'TEACHING'):teacherrs.append({'code':'ORIGINAL_TEACHING_NOT_ALL_PASS'})
  tspec=tp.parent/'spec.json';ts=next((s for s in rd(tspec).get('cards',[]) if s.get('id')==t.get('reviewedCardId',cid)),None)
  if not ts or ch(body(ts))!=h:teacherrs.append({'code':'TEACHING_SPEC_BODY_MISMATCH'})
  elif ts.get('mustAnswer',[])!=c.get('mustAnswer',[]):teacherrs.append({'code':'ASSESSMENT_CHANGED'})
  if bind['resolvedPrerequisiteIds']!=c.get('prerequisiteIds',[]):teacherrs.append({'code':'RESOLVED_PREREQUISITES_MISMATCH'})
  # Exact alias resolution is checked against the full original 197-card specification.
  olds=oldfull.get(cid,ts or {})
  rp=sorted({v for d in olds.get('prerequisiteIds',[]) for v in routing.get(d,[d]) if v!=cid})
  if rp!=sorted(c.get('prerequisiteIds',[])):teacherrs.append({'code':'PREREQUISITE_ALIAS_MISMATCH','expected':rp,'actual':c.get('prerequisiteIds',[])})
 else:
  fp=Path(bind['reviewPath']);assert fp.is_file() and sha(fp)==bind['reviewSha256'];fd=rd(fp);proofs.append({'gate':'FACT_TEACHING',**ref(fp)});rows=[r for r in fd['results'] if r.get('cardId')==cid and r.get('bodySha256')==h];assert len(rows)==1;row=rows[0]
  if not proofstatus(row,'FACT'):facterrs.append({'code':'ORIGINAL_FACT_NOT_PASS'})
  if not proofstatus(row,'TEACHING'):teacherrs.append({'code':'ORIGINAL_TEACHING_NOT_ALL_PASS'})
  inp=inputcheck(fp);facterrs+=inp;teacherrs+=inp
  for n,ih in fd['inputHashes'].items():
   ip=resolve(fp.parent,n)
   if ip.is_file() and ip.suffix=='.json':orig_specs+=same_body_nodes(rd(ip),cid,h)
  specs=[s for s in orig_specs if 'frontZH'in s and 'mustAnswer'in s]
  if not specs:facterrs.append({'code':'REVIEWED_SPEC_BODY_NOT_FOUND'});teacherrs.append({'code':'REVIEWED_SPEC_BODY_NOT_FOUND'})
  else:
   candidates=[s for s in specs if ch({k:s[k] for k in ASSESS if k in s})==bind['reviewedAssessmentSha256'] or ch(assess(s))==bind['reviewedAssessmentSha256']]
   if not candidates:teacherrs.append({'code':'ORIGINAL_ASSESSMENT_BINDING_MISMATCH'})
   else:
    s=candidates[0];rp=sorted({v for d in s.get('prerequisiteIds',[]) for v in routing.get(d,[d]) if v!=cid})
    if rp!=sorted(c.get('prerequisiteIds',[])) or c.get('mustAnswer',[])!=s.get('mustAnswer',[]):teacherrs.append({'code':'CURRENT_ASSESSMENT_NOT_EQUIVALENT'})
   for s in specs:
    for e in walk({k:v for k,v in s.items() if k in ['factEvidence','inheritedOfficialCitations']}):
     if e.get('quote') and e.get('url'):quotes.append(evidencecheck(e))
  if bind['currentAssessmentSha256']!=ch(assess(c)):teacherrs.append({'code':'CURRENT_ASSESSMENT_HASH_MISMATCH'})
 # All source snippets bound to this claim chain are integrity checked. No URL-only acceptance.
 uniq={ch(q):q for q in quotes};quotes=list(uniq.values())
 for q in quotes:
  for e in q['errors']:facterrs.append({**e,'sourcePath':q['sourcePath']})
 if not quotes:facterrs.append({'code':'NO_VERIFIABLE_QUOTED_FACT_EVIDENCE'})
 if not orig_specs and 'priorBinding' in bind and bind['priorBinding']['FACT']['kind']!='unchanged_accepted_card_fact_review':facterrs.append({'code':'ORIGINAL_FULL_BODY_NOT_LOCATED'})
 # Exact local claims can keep FACT receipts when a prerequisite is being rewritten, but teaching cannot.
 if changedDeps:teacherrs.append({'code':'DEPENDENCY_SCOPE_CHANGED','cardIds':changedDeps})
 ef=not facterrs and not x['scopeDecisions'];et=not teacherrs and not x['scopeDecisions']
 status='needs_new_review' if x['scopeDecisions'] else 'eligible_reuse' if ef and et else 'needs_targeted_review'
 result.append({'ruleId':x['ruleId'],'cardId':cid,'bodySha256':h,'learningSha256':c['learningSha256'],'eligibleFACT':ef,'eligibleTEACHING':et,'status':status,'scopeDecisions':x['scopeDecisions'],'dependencyIds':deps,'changedScopeDependencyIds':changedDeps,'proofs':proofs,'factEvidence':[{k:v for k,v in q.items() if k!='errors'} for q in quotes],'FACTLimitations':facterrs,'TEACHINGLimitations':teacherrs,'limits':['Chinese current local task only; no formal bilingual or learner-effect acceptance.']})
issues=[{'ruleId':r['ruleId'],'gate':gate,'issues':r[key]} for r in result for gate,key in [('FACT','FACTLimitations'),('TEACHING','TEACHINGLimitations')] if r[key]]
pre={'schemaVersion':1,'reviewer':'reuse-a independent eligibility audit','frozenInputChecks':{p:{'expected':h,'actual':sha(p),'matches':sha(p)==h} for p,h in frozen.items()},'counts':{'cards':len(cards),'unchangedScope':len(cards)-len(scope),'scopeChanged':len(scope),'eligibleFACT':sum(r['eligibleFACT'] for r in result),'eligibleTEACHING':sum(r['eligibleTEACHING'] for r in result),'fullyEligible':sum(r['eligibleFACT'] and r['eligibleTEACHING'] for r in result)},'results':result,'issues':issues,'verificationScope':'Receipts/actual per-card proof rows/pinned full body and learning task/input and source quote integrity; no new whole-question semantic review or learner measurement.','directCliApiCalls':0,'nativeUsage':'unknown'}
(OUT/'reuse-results.preliminary.json').write_text(json.dumps(pre,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(pre['counts'],ensure_ascii=False));print('issue codes',collections.Counter(e['code'] for x in issues for e in x['issues']));print('cards with fact errors',[(r['cardId'],[e['code'] for e in r['FACTLimitations']]) for r in result if r['FACTLimitations']]);print('teaching errors',[(r['cardId'],[e['code'] for e in r['TEACHINGLimitations']]) for r in result if r['TEACHINGLimitations']])

import json,pathlib,hashlib,collections
from datetime import datetime,timezone
V=pathlib.Path(__file__).resolve().parents[2];OUT=V/'review/reuse-a';O=V.parent/'domain1-final-card-catalog-20261105'
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
cat={e['sourceKey']:e for e in rd(O/'official-sources.catalog.json')};byurl={e['url']:pathlib.Path(e['sourcePath']) for e in cat.values()}
for p in (OUT/'sources').glob('*.json'):
 d=rd(p)
 if d.get('url'):byurl[d['url']]=p
prior_sources=rd(OUT/'reuse-results.json')['sourceEvidenceRegistry']
for e in prior_sources.values():
 assert sha(e['sourcePath'])==e['fileSha256']
 byurl.setdefault(e['url'],pathlib.Path(e['sourcePath']))
registry={}
def cite(src,needle,length=350,claim='',occ=0):
 p=pathlib.Path(cat[src]['sourcePath']) if src in cat else byurl.get(src,OUT/'sources'/src);d=rd(p);s=d['text'];starts=[];i=0
 while needle in s[i:]:
  j=s.index(needle,i);starts.append(j);i=j+1
 assert starts,(src,needle);st=starts[occ];quote=s[st:st+length];e={'claim':claim,'url':d['url'],'sourcePath':str(p),'sourceFileSha256':sha(p),'sourceTextSha256':hashlib.sha256(s.encode()).hexdigest(),'quote':quote,'startChar':st,'endChar':st+len(quote),'quoteSha256':hashlib.sha256(quote.encode()).hexdigest()}
 if p.parent==OUT/'sources':assert sha(p.with_suffix('.html'))==d['rawSha256'];e['rawHtmlPath']=str(p.with_suffix('.html'));e['rawHtmlSha256']=d['rawSha256']
 elif src in cat:
  if cat[src].get('fileSha256'):assert sha(p)==cat[src]['fileSha256']
  if cat[src].get('textSha256'):assert e['sourceTextSha256']==cat[src]['textSha256']
 eid=ch(e);registry[eid]=e;return eid

def write(batch,decisions,transfers=None):
 mp=OUT/'input'/f'{batch}.manifest.json';m=rd(mp);assert all(sha(p)==h for p,h in m.items());cp=next(pathlib.Path(p) for p in m if p.endswith('.json') and ('/drafts/' in p or '.cards.json' in p));cards=rd(cp);assert {c['ruleId'] for c in cards}=={d['ruleId'] for d in decisions} and len(cards)==len(decisions)
 used=set()
 for d in decisions:
  c=next(c for c in cards if c['ruleId']==d['ruleId']);d['bodySha256']=ch({k:c[k] for k in ['frontZH','answerZH','keyPointZH','watchOutZH'] if c.get(k)});d['fullDraftSha256']=ch(c);d.setdefault('status','PASS');d.setdefault('gates',{'FACT':'PASS','U1':'PASS','R1':'PASS','T1':'PASS','S1':'PASS','P1':'PASS','B1':'N/A_chinese_stage'});d.setdefault('findings',[]);used.update(d['evidenceIds']);d.setdefault('assessment','以主要结论和考点原因自评；不要求复述已给前提或未问提醒。私有mustAnswer未提供，未据此声明正式自评契约验收。');d.setdefault('prerequisites','必要术语用途已由卡面场景与原因解释；局部任务未要求从私有资料补答案。')
 for eid in used:
  e=registry[eid];s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and s[e['startChar']:e['endChar']]==e['quote']
 assert all(sha(p)==h for p,h in m.items())
 report={'schemaVersion':1,'batch':batch,'reviewer':'reuse-a independent actual content reviewer','reviewedAtUtc':datetime.now(timezone.utc).isoformat(),'inputManifestPath':str(mp),'inputManifestSha256':sha(mp),'inputHashes':m,'status':'PASS' if all(d['status']=='PASS' for d in decisions) else 'FAIL_requires_targeted_repair','counts':dict(collections.Counter(d['status'] for d in decisions)),'results':decisions,'evidenceRegistry':{k:registry[k] for k in sorted(used)},'transferChecks':transfers or [],'allSnapshotQuoteOffsetHashChecksPassed':True,'limits':['Frozen Chinese local teaching tasks only; no original-question full sufficiency or formal bilingual acceptance.','No learner memory/accuracy measurement.','Only changed cards and affected dependencies require further review; valid unchanged entries stay bound to current hashes.'],'directCliApiCalls':0,'nativeUsage':'unknown'}
 op=OUT/f'{batch}.review.json';op.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(batch,report['counts'],sha(op))

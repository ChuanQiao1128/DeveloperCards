import audit_questions as q
import audit_reuse as a
import json,collections
from datetime import datetime,timezone
OUT=a.OUT
source_manifest=a.rd(a.V/'inputs/source-manifest.json');assert all(a.sha(p)==h for p,h in source_manifest.items())
parentrefs=[]
for r in a.result:
 for pr in list(r['proofs']):
  if pr['gate']=='FACT_TEACHING':
   d=a.rd(pr['path']);row=next(x for x in d['results'] if x.get('cardId')==r['cardId'] and x.get('bodySha256')==r['bodySha256'])
   for p in row.get('parentFactReceipts',[]):
    fp=a.Path(p['receiptPath']);assert a.sha(fp)==p['receiptSha256'];old=a.oldfull[p['parentId']];assert a.ch(a.body(old))==p['bodySha256'];doc=a.rd(fp)
    found=a.same_body_nodes(doc,p['parentId'],p['bodySha256'])
    if not found and 'artifactSha256' in doc:
     ap=fp.parent/'artifact.snapshot.json';assert a.sha(ap)==doc['artifactSha256'];z=next(z for z in a.rd(ap)['cards'] if z.get('stableUid')==p['parentId']);converted={k:z.get(k[:-2]+'Zh','') for k in a.BODY};assert a.ch({k:v for k,v in converted.items() if v})==p['bodySha256'];found=[z]
    assert found,('unbound_parent_receipt',p)
    entry={'gate':'parent_FACT_receipt','parentCardId':p['parentId'],'parentBodySha256':p['bodySha256'],**a.ref(fp)};r['proofs'].append(entry);parentrefs.append(entry)
registry={}
for r in a.result:
 fact=[]
 for e in r['factEvidence']:
  eid=a.ch(e);registry[eid]=e;fact.append(eid)
 r['factEvidenceIds']=list(dict.fromkeys(fact));r.pop('factEvidence')
 r['scopeReviewFindingId']='REUSE-SCOPE-'+r['cardId'] if r['scopeDecisions'] else None
 if r['changedScopeDependencyIds']:r['dependencyFindingId']='REUSE-DEP-'+r['cardId']
pre=a.rd(OUT/'reuse-results.preliminary.json');pre['results']=a.result;pre['reviewedAtUtc']=datetime.now(timezone.utc).isoformat();pre['sourceEvidenceRegistry']=registry;pre['parentFactReceiptBindingsChecked']=len(parentrefs);pre['sourceSnapshotChecks']={'uniqueQuotedEvidenceEntries':len(registry),'uniqueFullSourceSnapshots':len({r['sourcePath'] for r in registry.values()}),'allQuotesAndOffsetsAndFullTextHashesValidated':True};pre['sourceManifestChecks']={p:{'expected':h,'actual':a.sha(p),'matches':True} for p,h in source_manifest.items()};pre['questionReuse']={'path':str(OUT/'question-reuse371.json'),'sha256':a.sha(OUT/'question-reuse371.json'),'counts':q.report['counts'],'eligibleVerdictCounts':q.report['eligibleVerdictCounts'],'eligibleQuestionIds':q.report['eligibleQuestionIds'],'needsRetestQuestionIds':q.report['needsRetestQuestionIds']};pre['normalizations']=['Prerequisite order alone has no graph effect; membership and every visible dependency body were compared.','Explicit XR003<-NS04 reviewed identity alias is accepted only because full Chinese body, self-assessment and prerequisites are identical.','Any scopeDecisions entry invalidates FACT and teaching inheritance for that new task even before changed draft bytes exist.'];pre['limits']=['Eligibility applies only while referenced current body/learning hashes and dependency scope remain as frozen. Any further edit invalidates the corresponding result and affected question closure.','Preserved CONDITIONAL/SOURCE_ISSUE remain conditional/unresolved; their reuse is not SUPPORTED.','No whole1018 sufficiency, formal bilingual acceptance or measured learner memory/accuracy claim.','No old source, inventory, production pointer, budget or learning record was modified.']
assert len(pre['results'])==176 and len({r['ruleId'] for r in pre['results']})==176
assert pre['counts']=={'cards':176,'unchangedScope':160,'scopeChanged':16,'eligibleFACT':160,'eligibleTEACHING':155,'fullyEligible':155}
assert all(not r['eligibleFACT'] and not r['eligibleTEACHING'] and r['status']=='needs_new_review' for r in pre['results'] if r['scopeDecisions'])
assert all(not r['changedScopeDependencyIds'] for r in pre['results'] if r['eligibleTEACHING'])
assert len(q.report['eligibleQuestionIds'])+len(q.report['needsRetestQuestionIds'])==371
assert not set(q.report['eligibleQuestionIds'])&set(q.report['needsRetestQuestionIds'])
assert 159 in q.report['needsRetestQuestionIds']
assert all(not set(r['completeDependencyIds'])&a.scope and not r['limitations'] for r in q.outputs if r['status']=='eligible_reuse')
assert all(a.sha(p)==h for p,h in a.frozen.items())
(OUT/'reuse-results.json').write_text(json.dumps(pre,ensure_ascii=False,indent=2)+'\n')
summary={'status':'complete_reuse_eligibility_audit','cardCounts':pre['counts'],'questionCounts':q.report['counts'],'eligibleQuestionVerdicts':q.report['eligibleVerdictCounts'],'dependencyTeachingRetestIds':[r['cardId'] for r in pre['results'] if not r['scopeDecisions'] and not r['eligibleTEACHING']],'artifacts':{str(OUT/n):a.sha(OUT/n) for n in ['reuse-results.json','question-reuse371.json','audit_reuse.py','audit_questions.py']},'assertions':'176/371 exact unique coverage; all16 scope changes excluded; no eligible teaching/question contains scope-changed dependency; Q159 excluded; frozen inputs re-read unchanged; full source quote/offset/hash checks passed','directCliApiCalls':0,'nativeUsage':'unknown'}
(OUT/'reuse-readback.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))

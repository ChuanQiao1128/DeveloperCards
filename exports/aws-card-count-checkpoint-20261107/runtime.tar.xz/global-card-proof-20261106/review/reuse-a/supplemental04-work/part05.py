# -*- coding: utf-8 -*-
from common import *
r=[]
r.append(Q(823,'SUPPORTED',[3],['CUR:XB041','CUR:CB13'],'query string属于HTTP请求字段，ALB规则分流并由HTTPS监听器/ACM证书终止TLS，C。NLB的传输层能力不解析HTTP查询字段，GWLB不是此应用内容路由。',implementation=['实际建立query-string条件规则、HTTPS监听器及ACM证书；若要求后端一段也加密，另配HTTPS目标，不把客户端TLS自动延伸全链路。']))
r.append(Q(840,'SUPPORTED',[2],['CUR:NS02','CUR:CA13'],'题目要加速上传RTMP的TCP连接，GA让传输从附近AWS边缘进全球网络，B；CloudFront是HTTP内容分发，VPN/普通EIP不提供相同全球TCP加速机制。'))
r.append(Q(863,'SUPPORTED',[2],['GSC-047','CUR:NB04'],'RDS原生自动备份窗口可设30天、包含快照与日志，直接改retention的B比另写每日Lambda/CLI/维护窗口更少运维。30天在已教35天上限内。',implementation=['使用数据库自身的日常备份窗口；核对原有最近恢复点状态，不能追溯生成过去未留存的备份。']))
r.append(Q(876,'SUPPORTED',[2,4],['CUR:XB041','CUR:CB03','GSC-115'],'传输层NLB分流，跨AZ ASG维持容量并消费应用健康结果，B+D。单靠DNS/加另一个HTTP LB或重启停止实例不提供同样自动跨AZ补容机制。'))
r.append(Q(896,'SUPPORTED',[2],['GSC-056','GSC-067'],'Aurora Global原生跨Region低延迟复制和受管failover/global writer减少提升及连接改动，B最适配5分钟RPO/20分钟RTO目标。单独副本/DMS自拼链路需更多手工配置。',implementation=['次Region准备适当计算、权限与应用切流，验证实际恢复过程；典型复制和受管流程不是任意事故绝对20分钟保证。']))
r.append(Q(900,'UNKNOWN',[1,2],['GSC-140','CUR:XB019','CUR:XB041'],'A的云Fargate+机房ECS Anywhere外部实例成立，D/E错误地把Fargate搬进机房。HTTP内容规则可选ALB，普通HTTP也能作为TCP经NLB转发；原题未给path/host路由或明确比较目标，因此B/C不能只因HTTP一词唯一判定。',missing=['需明确HTTP内容路由/应用层功能，或给能区分ALB与NLB的成本/协议条件；不新增“HTTP必用ALB”错误口诀。']))
r.append(Q(905,'SUPPORTED',[1,4],['CUR:NS02','CUR:XB041','GSC-124'],'GA前置多个Region的传输层入口；TCP实例和机房UDP都用NLB，机房服务按支持的私有IP目标可达，A+D。ALB不承载UDP，CloudFront不是该原生协议入口。',implementation=['为机房IP建立私网路由、目标注册及健康检查；状态型TCP的会话状态不由GA复制，按应用本身状态契约处理。']))
r.append(Q(915,'SUPPORTED',[3],['GSC-034','GSC-032','CUR:NB04'],'Redis内存及sorted set用于快速更新排名；NB04教快照保留磁盘/持久备份恢复点，应用重启仍可使用外部状态或按需恢复，C。CloudFront缓存不维护实时排名，自管多区EC2更费运维；Memcached没有该排序结构。',implementation=['配置需要的快照/恢复流程；题述应用重启不等同所有缓存节点损坏且每次写必须零RPO，不能额外加入后者，也不承诺快照后新写无损。']))
r.append(Q(917,'SUPPORTED',[4],['CUR:XB041','CUR:CB03','GSC-079','GSC-081','GSC-083','CUR:CB01','CUR:CC22'],'ALB+ASG扩缩请求处理，SQS持久保留未确认订单，RDS Multi-AZ保存已处理订单并提供接管，D。NAT/GWLB不是订单队列，Redshift分析仓库也不是此事务处理目标。',implementation=['处理成功并持久提交后才删除SQS消息，按订单ID幂等处理重试，合理设置visibility/retention和死信处置；ASG配置实际负载伸缩。']))
r.append(Q(955,'SUPPORTED',[1],['GSC-056','GSC-068','GSC-126','CUR:CB03'],'准备第二Region ALB/独立ASG与GlobalDB，平时小容量不承载顾客，故A的active-passive最匹配。B/C同一ASG跨Region且active-active不合条件，D把AWS Backup当任意基础配置恢复器。',implementation=['A初始max设小值后，灾备切换时须提高max/desired以承载流量，并执行受管数据库切换；将这些动作纳入30分钟目标，不认为小max会自行扩到生产容量。']))
r.append(Q(976,'SUPPORTED',[2],['CUR:XB032','CUR:XB041','CUR:CB03'],'题目要地理最近而非来源国家或任意比例，geoproximity选择Region，再用区域NLB跨AZ目标分流，B。geolocation按国家分段、multivalue和weighted均不直接优化距离。',implementation=['使用支持的geoproximity记录/Traffic Flow配置实际资源位置和所需bias；距离不是网络延迟保证。']))
r.append(Q(987,'SUPPORTED',[1,2],['CUR:XB041','CUR:CB03'],'普通TCP应用需要NLB加跨AZ ASG自动补容/伸缩，A+B；ALB需要HTTP语义，手工加机非自动，GWLB偏设备链。'))
r.append(Q(989,'INSUFFICIENT_CARDS',[3],['GSC-047','CUR:NS03'],'自动保留期30天在35天窗口内，直接RDS配置比另加计划更直接，C方向合适。但现有卡只分近期PITR/长期快照，未明确manual snapshot独立保留到手工删除，以及关闭自动备份对已存自动备份的影响；不能用私有记忆证明B/D违反保留现有<30天备份的硬条件。',missing=['手动快照生命周期不随自动保留期清理；关闭自动备份会怎样处理既有自动备份。优先补现有备份规则而不自动单独出卡。']))
r.append(Q(997,'SUPPORTED',[3],['GSC-057','CUR:CC22','CUR:NB04'],'结构化事务关系数据适合托管Aurora，Serverless按负载变计算并有持续备份，C比固定自管Spot数据库更直接满足随流量伸缩与备份。B的RDS按需购买实例不等于Serverless计算弹性；NoSQL还改变数据/事务模型。',implementation=['选择支持的Serverless版本/范围并按实际负载比较总价；不宣称任何稳定高利用负载必然Serverless最便宜。']))
r.append(Q(999,'SUPPORTED',[2],['GSC-032',('GSC-033',('frontZH','answerZH','keyPointZH'))],'目录少改且重复读导致DB CPU高，Redis cache-aside/lazy loading在miss时读库、后续命中绕过重复SQL，B。加Web实例不减少DB读，Multi-AZ instance备用也不扩读，Redshift搬表为此过重。',implementation=['应用填充miss结果并在目录更新时失效/更新缓存；缓存不是数据库写入后自动同步。']))
write(5,r)

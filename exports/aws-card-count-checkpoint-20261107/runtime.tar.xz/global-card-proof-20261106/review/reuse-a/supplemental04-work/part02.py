# -*- coding: utf-8 -*-
from common import *
r=[]
r.append(Q(268,'SUPPORTED',[1],['GSC-032','GSC-033','CUR:CB18'],'重复查询的相同数据可由内存缓存命中直接返回，A减少实际RDS读取且改动局部。Proxy池化连接不缓存查询结果；换计算/数据库技术比插入缓存更大。'))
r.append(Q(273,'SUPPORTED',[2],['GSC-056','GSC-068'],'Aurora Global低延迟异地存储复制配缩容运行的warm standby，B匹配分钟级接管和低于主区运行成本。Pilot还要准备更多计算，Multi-AZ不提供跨Region灾备；不把典型复制时延写成绝对RPO保证。'))
r.append(Q(338,'SUPPORTED',[2],['GCL-005','GSC-056'],'已教兼容版本Aurora global headless secondary只有存储复制、删除次区DB实例免运行计算，B最少常驻计算。A/D继续支付实例，DMS没有可直接接收写入的headless数据库执行器。',implementation=['确认引擎版本支持headless次区；灾难恢复先补DB实例，不承诺无实例即刻接管。']))
r.append(Q(343,'SUPPORTED',[3],['GSC-056','CUR:CC22','GSC-068'],'Aurora Global把主写及异地副本作为托管关系库灾备路径，C比EC2自管/快照重建少维护且复制更快。同Region Multi-AZ无法独立承担Region灾难。'))
r.append(Q(365,'SUPPORTED',[3],['GSC-047','CUR:NB04'],'RDS自动备份和事务日志的PITR可在保留窗口选择误改前时点，C。当前副本跟随误删；每日手动快照不能选择任意五分钟前，导出本身不提供连续日志恢复。',implementation=['配置覆盖30天的备份窗口并恢复新实例、切换应用；最近可恢复点与日志上传存在约分钟级差距。']))
r.append(Q(367,'SUPPORTED',[1],['CUR:NS02','CUR:XB041','GSC-124'],'UDP使用NLB，GA改善到区域入口的全局路径，远端本地服务器用可达且受支持的私有IP注册，A。计算仍留本地；ALB不接原生UDP，CloudFront不成为该UDP入口。',implementation=['落实本地与NLB目标的私网可达、允许的IP范围及健康检查，不注册任意公网IP。']))
r.append(Q(378,'SUPPORTED',[2],['CUR:XB041','CUR:XB013','GSC-038'],'UDP入口需NLB；非关系型键文档数据配DynamoDB on-demand按请求管理容量，B。ALB不满足UDP，关系型或自管数据库不符合题示无需维护扩缩容量的选择。'))
r.append(Q(386,'SUPPORTED',[2],['GSC-032','GSC-033'],'相同数据的重复查询由缓存返回，B减少实际后端读取。SNS/Firehose处理消息或交付，副本仍执行数据库读，均不是该结果复用路径。'))
r.append(Q(390,'SUPPORTED',[2,4],['CUR:NB08','CUR:NB04','GSC-032'],'DynamoDB或Redis把事务会话外置到共享存储，实例伸缩/退出不再带走唯一会话副本，B+D。NB04还教Redis快照保留可恢复状态；普通durably并没有明确要求每次确认写入零RPO，不能擅自加这个绝对条件来阻断选型。Sticky只路由；Cognito身份会话和SSM应用管理不保存这里的应用事务会话。',implementation=['为Redis落实所需Multi-AZ/备份和恢复策略；新快照前的变化仍有已教损失边界，不承诺每次写均持久。']))
r.append(Q(391,'SUPPORTED',[3],['GCL-014','GSC-047','CUR:XA031'],'应用明确无本地业务数据，保留可启动的最新AMI而非不断备份无状态盘；数据库用RDS备份/PITR满足两小时恢复点，C最少冗余存储。A把RDS当EBS卷快照对象；B/D额外反复保存不变应用盘，不能胜过最新AMI+数据库恢复点。',implementation=['AMI包含最新部署配置；RDS设置合适保留窗口、恢复新实例及应用重连。']))
r.append(Q(400,'SUPPORTED',[3],['GSC-042','GSC-080'],'DynamoDB Streams记录业务数据变更，异步处理再向SNS多订阅者扇出，C将通知从同步订单路径剥离。直接改每个客户端/接收者耦合更高；管理事件不代替订单记录变化。',implementation=['配置真正读取Stream并发布SNS的处理函数；Stream记录不会自行发布通知。']))
r.append(Q(408,'SUPPORTED',[2],['CUR:NS02','CUR:XB041','GSC-137'],'原生UDP全球入口走GA→NLB→ECS Fargate容器，B。ALB不能接UDP，NLB→Lambda不成为所需长运行UDP处理服务。题中NLProcess拼写不清但上下文唯一指向NLB，不修改原文。'))
r.append(Q(431,'SUPPORTED',[2],['GSC-034','CUR:NB04'],'Redis sorted set直接维护分数排序，按活动结束停止写入/取快照再恢复即可保留当时排行榜，B。缓存前端不能维护排名；关系库副本不是按排名操作的最贴切结构，Memcached不提供已教sorted set。',implementation=['需要保留最终比分时先完成写入再取所需快照并验证恢复；不以旧快照承诺保住其后每一次写。']))
r.append(Q(440,'SUPPORTED',[1,3],['GCL-019','GSC-048'],'A用兼容RDS MySQL原生快照迁Aurora；C可将SQL dump放S3作暂存，再以SQL客户端逻辑导入Aurora。不能将逻辑SQL dump当成原生restore-from-S3物理备份；B把RDS快照当普通S3文件，D/E把DMS与两种备份格式混同。',implementation=['C的generic import落实为下载/读取暂存SQL并由客户端执行，非Aurora物理备份S3恢复接口；检查兼容版本及导入权限。']))
r.append(Q(458,'SUPPORTED',[2,3],['VC-004','GSC-133','CUR:CA17','CUR:CC22'],'Python 1GB内存的API处理可交Lambda；2GB只是临时计算空间，可独立配置/tmp，不因此强制EC2。API Gateway→Lambda+托管关系库满足B+C；持久业务结果放RDS等外部存储，临时空间不是数据库。',implementation=['使用支持的Python runtime，确认实际调用时长和其他资源限制；配置至少2GB/tmp并在结束前保存业务结果。']))
write(2,r)

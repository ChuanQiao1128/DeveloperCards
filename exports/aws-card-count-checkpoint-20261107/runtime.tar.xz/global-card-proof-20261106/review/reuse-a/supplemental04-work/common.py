# -*- coding: utf-8 -*-
import pathlib,json,hashlib,collections,datetime
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106');O=V/'review/reuse-a/supplemental04-work';P=V/'review/supplemental04/input'
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def b(c):return {f:c.get(f,'') for f in ['frontZH','answerZH','keyPointZH','watchOutZH']}
manifest=rd(P/'manifest.json')
for p,h in manifest.items():assert sha(p)==h,(p,h)
base={c['ruleId']:c for c in rd(P/'visible-pool.frozen.json')};drafts=rd(P/'cards.json');cards={k:dict(x) for k,x in base.items()};forbidden={'CUR:XB039','GCL-017','GSC-019','GSC-072','GSC-084','GSC-098','GSC-108','GCL-020'}
assert not set(base)&forbidden
for c in drafts:
 rid=c['ruleId']
 if c.get('repairOf'):assert c['repairOf']==base[rid]['bodySha256']
 cards[rid]={'ruleId':rid,'visibleBody':b(c),'bodySha256':ch(b(c)),'prerequisiteRuleIds':c.get('prerequisiteRuleIds',base.get(rid,{}).get('prerequisiteRuleIds',[]))}
for c in cards.values():assert ch(c['visibleBody'])==c['bodySha256']
qs=rd(P/'questions.json');qb={x['qid']:x['question'] for x in qs};reg={}
def cite(p,needle,n,claim):
 p=pathlib.Path(p);j=rd(p);s=j['text'];st=s.index(needle);q=s[st:st+n];e={'claim':claim,'url':j['url'],'sourcePath':str(p),'sourceFileSha256':sha(p),'sourceTextSha256':hashlib.sha256(s.encode()).hexdigest(),'quote':q,'startChar':st,'endChar':st+len(q),'quoteSha256':hashlib.sha256(q.encode()).hexdigest()};eid=ch(e);reg[eid]=e;return eid
RDS=cite(O/'sources/rds-events-overview.json','You can subscribe to an event category for the following resources:',870,'RDS notifications describe DB resource categories and configuration changes, not business row CDC.')
MCHA=cite(V/'review/reuse-a/sources/2d10ae623baa69279c7e.json','Serverless caches automatically mitigate node failures',180,'Official Memcached serverless subsection: replicated Multi-AZ node-failure handling.')
def A(rid,fields=('answerZH','keyPointZH')):
 if isinstance(rid,tuple):rid,fields=rid
 assert rid not in forbidden
 c=cards[rid];return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'startChar':0,'endChar':len(c['visibleBody'][f]),'candidateOverlay':rid in {x['ruleId'] for x in drafts}} for f in fields if c['visibleBody'].get(f)]
def Q(qid,status,choices,ids,reason,missing=None,conditions=None,implementation=None,evidence=None,source=None):
 aa=sum([A(r) for r in ids],[]);used=sorted({a['ruleId'] for a in aa});pre=[];todo=list(used);seen=set()
 while todo:
  k=todo.pop()
  if k in seen:continue
  seen.add(k)
  for z in cards[k].get('prerequisiteRuleIds',[]):
   assert z in cards and z not in forbidden;pre.append({'from':k,'ruleId':z,'bodySha256':cards[z]['bodySha256'],'visibleBody':cards[z]['visibleBody']});todo.append(z)
 return {'qid':qid,'status':status,'selectedOptionOrdinals':choices if status=='SUPPORTED' else [],'candidateOptionOrdinals':choices,'questionSha256':ch(qb[qid]),'originalStemUtf8Sha256':hashlib.sha256(qb[qid]['stem'].encode()).hexdigest(),'originalOptionsCanonicalSha256':ch(qb[qid]['options']),'completeStemAndEveryOptionRead':True,'usedRuleIds':used,'necessaryAnchors':aa,'recursiveUsedPrerequisiteBindings':pre,'reasoningAndClosestCompetitor':reason,'minimumRemainingJudgments':missing or [],'conditions':conditions or [],'implementationChecksNotNewCards':implementation or [],'officialEvidenceIds':evidence or [],'sourceIssues':source or [],'forbiddenDeletedOrQuarantinedCardsUsed':False,'noPrivateTargetsOrPrintedAnswersUsed':True}
def write(i,rows):
 assert len({r['qid'] for r in rows})==len(rows)
 used={e for r in rows for e in r['officialEvidenceIds']}
 for r in rows:
  for a in r['necessaryAnchors']:assert cards[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
 for p,h in manifest.items():assert sha(p)==h
 out={'part':i,'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'counts':dict(collections.Counter(r['status'] for r in rows)),'results':rows,'officialEvidenceRegistry':{e:reg[e] for e in sorted(used)},'currentMutation':False,'directCliApiCalls':0,'nativeUsage':'unknown'};p=O/f'questions-part{i:02}.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(i,len(rows),out['counts'],sha(p))

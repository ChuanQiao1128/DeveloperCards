# -*- coding: utf-8 -*-
from common import *
mp=P/'manifest.json';ixp=V/'validation/current-card-review-index.json';ixsha=sha(ixp);ix={r['ruleId']:r for r in rd(ixp)['cards']};ip=V/'inputs/existing176.json';initial={r['ruleId']:r['body'] for r in rd(ip)}
parts=[rd(O/('questions-part%02d.json'%i)) for i in range(1,6)];qrows=sum([p['results'] for p in parts],[])
assert len(qrows)==75 and len(set(r['qid'] for r in qrows))==75 and {r['qid'] for r in qrows}==set(qb)
assert len(base)==351 and len(cards)==353 and len(drafts)==9
# Exact visible-body/contract binding of valid existing receipts, for both revisions and every reused question/prerequisite card.
proofcache={};recordcache={}
def prior_for(rid):
 if rid in proofcache:return proofcache[rid]
 old=base[rid];x=ix[rid];assert x['status']=='PASS' and x['currentBodySha256']==old['bodySha256'];out=[];records=[]
 for p in x['proofs']:
  assert sha(p['path'])==p['sha256'],p['path'];j=rd(p['path']);matches=[r for r in j.get('results',j.get('cards',[])) if r.get('ruleId')==rid]
  r=next((r for r in matches if r.get('bodySha256')==old['bodySha256']),None);contract='canonical four-field current visible body'
  if r is None:
   assert rid in initial and b(initial[rid])==old['visibleBody'],rid
   legacy=ch({k:v for k,v in old['visibleBody'].items() if v});r=next(r for r in matches if r.get('bodySha256')==legacy);assert initial[rid]['bodySha256']==legacy
   contract='legacy omitted-empty watchOutZH hash, exact visible body reconstructed from existing176 and matched to current four fields'
  assert r.get('status',r.get('verdict'))=='PASS' or (r.get('eligibleFACT') and r.get('eligibleTEACHING')),(rid,r)
  pp={'path':p['path'],'sha256':p['sha256'],'ruleId':rid,'receiptBodySha256':r['bodySha256'],'currentPriorBodySha256':old['bodySha256'],'bodyBindingContract':contract}
  if r.get('proofs'):
   for pp2 in r['proofs']:assert sha(pp2['path'])==pp2['sha256']
   pp['parentGateReceipts']=r['proofs']
  out.append(pp);records.append((j,r))
 proofcache[rid]=out;recordcache[rid]=records;return out
for c in drafts:
 if c.get('repairOf'):assert c['repairOf']==base[c['ruleId']]['bodySha256'];prior_for(c['ruleId'])
used=set()
for r in qrows:
 assert ch(qb[r['qid']])==r['questionSha256']
 for a in r['necessaryAnchors']:
  c=cards[a['ruleId']];assert c['bodySha256']==a['bodySha256'] and c['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote'];used.add(a['ruleId'])
 for a in r['recursiveUsedPrerequisiteBindings']:
  assert cards[a['ruleId']]['visibleBody']==a['visibleBody'] and ch(a['visibleBody'])==a['bodySha256'];used.add(a['ruleId'])
for rid in sorted(used & set(base)):prior_for(rid)
# Validate every advertised official input; dedupe actual identical source/quote records rather than counting duplicates as facts.
es=rd(P/'official-evidence.json');inputchecks=[];packedrefs={};unique=set()
for e in es:
 p=pathlib.Path(e['snapshotPath']);j=rd(p);s=j['text'];assert sha(p)==e['snapshotSha256'];assert hashlib.sha256(s.encode()).hexdigest()==e['textSha256'];assert s[e['quoteStart']:e['quoteEnd']]==e['quote'];assert j['url']==e['url']
 key=(str(p),e['quoteStart'],e['quoteEnd'],e['quote']);dup=key in unique;unique.add(key)
 eid=cite(p,e['quote'],len(e['quote']),'Validated supplemental04 official input: '+e.get('evidenceKey',e['url']))
 packedrefs.setdefault(e.get('evidenceKey',e['url']),[]).append(eid);inputchecks.append({'snapshotPath':str(p),'snapshotSha256':sha(p),'sourceTextSha256':e['textSha256'],'quoteStart':e['quoteStart'],'quoteEnd':e['quoteEnd'],'quoteSha256':hashlib.sha256(e['quote'].encode()).hexdigest(),'evidenceId':eid,'identicalPriorInputRecord':dup})
# Resolve retained unchanged claim proofs to literal official text. No source-directory association is accepted as proof.
oldrefs={}
for c in drafts:
 rid=c['ruleId']
 if rid not in recordcache:continue
 refs=[]
 for j,r in recordcache[rid]:
  er=j.get('evidenceRegistry',j.get('sourceEvidenceRegistry',{}))
  for eid in r.get('evidenceIds',r.get('factEvidenceIds',[])):
   e=er[eid];p=pathlib.Path(e['sourcePath']);s=rd(p)['text'];assert sha(p)==e.get('sourceFileSha256',e.get('fileSha256'));assert hashlib.sha256(s.encode()).hexdigest()==e['sourceTextSha256'];assert hashlib.sha256(e['quote'].encode()).hexdigest()==e['quoteSha256'];assert e['quote'] in s
   refs.append(cite(p,e['quote'],len(e['quote']),'Unchanged retained mechanism for '+rid+'; valid named prior receipt '+eid))
 oldrefs[rid]=refs
# New capabilities plus independent official supplements.
def bykey(k):return list(dict.fromkeys(packedrefs[k]))
def E(part,needle,n,claim):return cite(next(e['snapshotPath'] for e in es if part in e['url']),needle,n,claim)
refs={rid:list(v) for rid,v in oldrefs.items()}
refs['GCL-019']+=bykey('aurora-mysql-snapshot')
refs['GSC-042']+=bykey('neptune')
refs['GSC-056']+=bykey('aurora-global-lag')+[E('aurora-global-database.html','Aurora Global Database writer endpoint',285,'Global writer endpoint follows current primary after switchover/failover.'),E('aurora-global-database.html','To recover your Aurora Global Database after an outage',375,'Managed global failover is an explicitly supported recovery action.'),E('aurora-global-database.html','with no data loss',210,'Planned healthy-cluster switchover has different data risk from outage failover.')]
refs['CUR:XB012']+=bykey('function-none')+bykey('https://docs.aws.amazon.com/lambda/latest/dg/urls-webhook-tutorial.html')
refs['CUR:XB041']+=bykey('nlb')
refs['CUR:NB04']+=bykey('redis-backup')+bykey('https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/Aurora.Managing.Backups.html')
refs['GSC-032']+=bykey('https://docs.aws.amazon.com/AmazonElastiCache/latest/dg/elasticache-use-cases.html')
refs['VC-004']=bykey('lambda-storage')+[E('configuration-ephemeral-storage','Lambda provides ephemeral storage',325,'Temporary /tmp is unique to each execution environment; range/configuration is distinct from persistence.'),E('configuration-ephemeral-storage','MemorySize: 128',165,'Official SAM example independently sets128MB memory and10240MB ephemeral disk.'),cite(O/'sources/lambda-storage-api.json','The size of the function\'s',202,'Independent API reference explicitly confirms default512MB and allowed range.')]
refs['VC-005']=bykey('eks-connector')
# Read-only contextual evidence that changed preliminary Q390 reasoning, not a private fact injection into card teaching.
redis_p=cite(V/'review/source-unknown02/a/evidence/redis-persistence-with-loss-boundary.snapshot.json','Redis supports persistence, including backup and recovery.',1041,'Official persistence/backup/recovery exists, while asynchronous replication retains failure-loss boundary; general durable does not mean every-write zero-RPO.')
for p in parts:
 reg.update(p['officialEvidenceRegistry'])
guide=O/'sources/saa-c03-guide.json';g=rd(guide);assert sha(g['sourcePdfPath'])==g['sourcePdfSha256']
g22=cite(guide,'Workload visibility',58,'SAA-C03 task2.2 explicitly includes workload visibility; best current primary mapping for external cluster viewing.')
g32=cite(guide,'Selecting the appropriate resource type and size',180,'Task3.2 includes choosing compute resource type/size, including Lambda resources.')
domains=[{'ruleId':'VC-004','proposedPrimaryDomain':'3','proposedPrimaryTask':'3.2','status':'PASS','recommendedPrimaryDomain':'3','recommendedPrimaryTask':'3.2','reason':'资源工作空间改变Lambda/EC2计算选型，3.2资源类型/规格最直接。','evidenceIds':[g32]},{'ruleId':'VC-005','proposedPrimaryDomain':'2','proposedPrimaryTask':'2.1','status':'CORRECTION_RECOMMENDED','recommendedPrimaryDomain':'2','recommendedPrimaryTask':'2.2','reason':'实际任务是集中查看集群与workload，2.2官方显式workload visibility比2.1编排/解耦更贴近；本评审不修改候选表。','evidenceIds':[g22]}]
notes={
'GCL-019':('按可理解备份格式选择恢复接口，一个格式→动作判断；三种输入服务于同一机制，而非三套部署清单。','保留逻辑SQL需客户端执行与物理备份格式受限；新增兼容MySQL快照正例，不将任意S3文件当快照。'),
'GSC-042':('管理状态与业务数据变化按用途辨析一个任务；DynamoDB/Neptune两种名字是同一业务CDC规则的具体实例。','保留流只记录变更、处理代码仍须接入；未让学习者背所有事件源配置。'),
'GSC-056':('围绕复制→更换主区→writer入口恢复写入，一条灾备因果链；不是完整DR部署审计。','新正面以少手工切换为决定条件；全局writer跟随当前primary，典型延迟与非零损失边界均解释适用范围。'),
'CUR:XB012':('用调用方能提供的身份材料选择URL认证层，AWS_IAM与第三方签名是同一个入口认证决策。','NONE只取消IAM入口认证，函数验证约定签名承担业务可信性；不把公开URL当已认证。'),
'CUR:XB041':('传输层与HTTP内容层是一个LB选型轴，UDP/高吞吐是传输层触发，不多考三张孤立数字卡。','百万级仅定位不硬SLA；保留ALB内容规则和TLS需配置，不误教只有ALB可承载HTTP字节。'),
'CUR:NB04':('仍是“当前副本能否替代过去状态”一个机制判断。RDS/Aurora/DynamoDB的各自恢复能力及缓存快照是该规则例证，不要求逐项部署或背多个窗口数值。','答先否定替代，原因讲当前复制随误改、旧备份留历史；缓存只恢复快照时状态，不宣称每次写同步落盘。未将普通durable偷换成零RPO。'),
'GSC-032':('一个重复读缓存+node-basedHA选型，亚毫秒解释内存用途；不另考数字、分片或部署清单。','保留node-based限定与Memcached Serverless反例，缓存命中为何减DB工作完整。'),
'VC-004':('一个因2GB临时空间是否必须换平台的判断；默认值随场景给定，范围用于理解可配置资源，不是独立数字默写。','/tmp的用途、独立内存配置与临时/持久边界在正文，无需私有先修；只要求不必换EC2及调整工作盘原因。'),
'VC-005':('保持现有机房Kubernetes管理同时统一查看，选注册连接而非迁移/重建，一个用途判断。','状态/配置/workload可视化说明工具用途；查看不接管管理是会改变选择的单一边界。')}
rows=[]
for c in drafts:
 rid=c['ruleId'];teach,retain=notes[rid]
 rows.append({'ruleId':rid,'status':'PASS','gates':{'FACT':'PASS','U1':'PASS','R1':'PASS','T1':'PASS','S1':'PASS_visible_question_alignment','P1':'PASS','B1':'N/A_chinese_stage'},'visibleBody':b(c),'bodySha256':ch(b(c)),'bodyHashContract':'canonical sorted JSON UTF-8 of frontZH/answerZH/keyPointZH/watchOutZH including empty values','fullDraftSha256':ch(c),'priorBodySha256':c.get('repairOf'),'namedValidPriorFACTProofs':proofcache.get(rid,[]),'evidenceIds':list(dict.fromkeys(refs[rid])),'teachingAndRecallTaskReason':teach,'oldNecessaryMechanismPreservation':retain,'prerequisiteRuleIds':cards[rid].get('prerequisiteRuleIds',[]),'assessmentCheck':'按题面主要结论与关键原因自评；给定前提/未问提醒不额外列为mustAnswer。私有mustAnswer未提供，未宣称正式评分契约验收。','findings':[]})
substitution=[{'ruleId':'VC-004','status':'INDEPENDENT_MINIMUM_RULE_CANDIDATE','questionIds':[458],'entireFrozenPoolCountChecked':351,'nearestRuleIds':['GSC-133','CUR:XB019','GSC-001','GSC-009','GSC-010'],'reason':'Lambda兼容性/时长内存只解释能否运行，EC2临时盘及EFS共享盘规则不能推出Lambda/tmp可单独配置为2GB；用这些卡仍欠真正容量能力判断。','visibleNearestCards':[{'ruleId':k,'bodySha256':cards[k]['bodySha256'],'visibleBody':cards[k]['visibleBody']} for k in ['GSC-133','CUR:XB019','GSC-001','GSC-009','GSC-010']],'onlyOneCurrentQuestion':True,'lowFrequencyAdmission':'可作为本次实际缺口的必要候选，仍需由supervisor按全库总复习负担确认最终核心包纳入；本审查不把一题必要性自动升级最终N/无上限扩卡。'}, {'ruleId':'VC-005','status':'INDEPENDENT_MINIMUM_RULE_CANDIDATE','questionIds':[563],'entireFrozenPoolCountChecked':351,'nearestRuleIds':['GSC-139','GSC-143','CUR:XB029','CUR:CA18','CUR:XB044'],'reason':'保留Kubernetes运行接口、性能指标采集、Outposts本地控制面、IRSA权限或CNI网络都不能推出外部集群注册到EKS控制台看对象的工具；独立必要能力是Connector查看边界。','visibleNearestCards':[{'ruleId':k,'bodySha256':cards[k]['bodySha256'],'visibleBody':cards[k]['visibleBody']} for k in ['GSC-139','GSC-143','CUR:XB029','CUR:CA18','CUR:XB044']],'onlyOneCurrentQuestion':True,'lowFrequencyAdmission':'同为单题必要候选；不能因主题相关或已写出正文而强制纳入最终核心包。'}]
transfers=[{'ruleId':'GCL-019','changedCondition':'S3文件从SQL文本变成引擎支持的物理备份','status':'PASS','reason':'恢复路径随格式由客户端逻辑导入变为对应物理恢复；S3位置不决定方式。'}, {'ruleId':'GSC-042','changedCondition':'要处理图记录变化而非数据库实例状态','status':'PASS','reason':'明确Neptune Streams而非资源状态通知，处理消费者仍须接入。'}, {'ruleId':'GSC-056','changedCondition':'主区健康计划搬迁与主区故障','status':'PASS','reason':'两者都走受支持受管流程/global writer，但卡面明确数据风险不同，不承诺故障零损失。'}, {'ruleId':'CUR:XB012','changedCondition':'第三方变成能签AWS请求的IAM调用方','status':'PASS','reason':'认证从函数内约定签名切至AWS_IAM与调用授权；公开可达和可信性有清楚因果。'}, {'ruleId':'CUR:XB041','changedCondition':'只传UDP改为按HTTP查询/路径路由','status':'PASS','reason':'由传输层NLB转向ALB请求字段规则；并不反推所有HTTP都只能ALB。'}, {'ruleId':'CUR:NB04','changedCondition':'故障是误写复制到副本而非单实例停机','status':'PASS','reason':'现有副本不能恢复旧值，需适用恢复点；快照后的写入可能不在恢复点。'}, {'ruleId':'GSC-032','changedCondition':'node-based Memcached改为Memcached Serverless','status':'PASS','reason':'正文警示不能沿node-based比较排除ServerlessHA，源问题保持而不人为修题。'}, {'ruleId':'VC-004','changedCondition':'本地临时空间改为跨环境共享持久结果','status':'PASS','reason':'/tmp不再满足；结果需写外部持久服务，增加内存/临时盘均不改变这一边界。'}, {'ruleId':'VC-005','changedCondition':'从只查看改为通过EKS管理外部集群','status':'PASS','reason':'watchOut明确Connector不能接管管理，不能把注册当迁移/管理。'}]
# Validate all assembled evidence and all question/prerequisite anchors after writing inputs unchanged.
for eid,e in reg.items():
 p=pathlib.Path(e['sourcePath']);s=rd(p)['text'];assert sha(p)==e['sourceFileSha256'];assert hashlib.sha256(s.encode()).hexdigest()==e['sourceTextSha256'];assert s[e['startChar']:e['endChar']]==e['quote'];assert hashlib.sha256(e['quote'].encode()).hexdigest()==e['quoteSha256']
for p,h in manifest.items():assert sha(p)==h
assert sha(ixp)==ixsha
out={'schemaVersion':1,'reviewer':'actual_reuse_review independent reviewer','batch':'supplemental04','status':'PASS_nine_current_chinese_cards_METADATA_CORRECTION_RECOMMENDED','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(mp),'inputManifestSha256':sha(mp),'inputHashes':manifest,'priorReviewIndexPath':str(ixp),'priorReviewIndexSha256':ixsha,'legacyEmptyFieldBindingSourcePath':str(ip),'legacyEmptyFieldBindingSourceSha256':sha(ip),'frozenVisiblePoolCount':351,'newCards':2,'revisedCards':7,'appliedToCurrent':False,'counts':{'cardPASS':9,'questionStatuses':dict(collections.Counter(r['status'] for r in qrows))},'results':rows,'evidenceRegistry':reg,'officialInputRecordValidation':{'inputRecords':len(es),'uniqueSourceQuoteRecords':len(unique),'records':inputchecks},'usedExistingQuestionAndPrerequisiteCardProofBindings':{rid:proofcache[rid] for rid in sorted(used&set(base))},'questionImpactReview':qrows,'questionPartReceipts':[{'path':str(O/('questions-part%02d.json'%i)),'sha256':sha(O/('questions-part%02d.json'%i))} for i in range(1,6)],'questionJudgmentNotes':[{'qid':390,'preliminaryStatus':'UNKNOWN','finalStatus':'SUPPORTED','retainedPreliminaryPath':str(O/'questions-part02.preliminary.json'),'retainedPreliminarySha256':sha(O/'questions-part02.preliminary.json'),'reason':'完整原题仅一般durably，不等同未声明每次写零RPO；已教共享会话加快照恢复足以说明B+D普通持久路径。官方白皮书正证及最新备份正文共同确认，不使用printed答案。','contextualOfficialEvidenceIds':[redis_p]}],'newCardSubstitutionTests':substitution,'newCardDomainMetadataReview':domains,'examGuidePdfBinding':{'path':g['sourcePdfPath'],'sha256':g['sourcePdfSha256'],'extractionPath':str(guide),'extractionSha256':sha(guide),'task22PdfPage':11,'task32PdfPage':13,'task22VisualReadPath':str(O/'sources/task22.png'),'task22VisualReadSha256':sha(O/'sources/task22.png')},'transferChecks':transfers,'sourceMetadataAdvice':'When approved, merge all prior valid source URLs with added URLs; the drafts list only additions for several repairs and must not discard existing physical/logical restore, DynamoDB stream, IAM, ALB/UDP or node-basedHA evidence. VC005 proposed primaryTask2.1 should be corrected to2.2 if adopting this recommendation.','allSnapshotOffsetAndHashChecksPassed':True,'allCanonicalFourFieldBodyAndQuestionAnchorChecksPassed':True,'formalBilingualAcceptance':False,'privateGradingContractAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'originalQuestionStatusesAutomaticallyPromoted':False,'finalCardCountVerified':False,'priorFailuresPreserved':True,'deletedOrQuarantinedCardsUsed':False,'directCliApiCalls':0,'nativeUsage':'unknown','externalOfficialReadOnlySourceFetches':'Earlier in this same review: public AWS Lambda default-storage API reference, full official SAA-C03 guide PDF, and RDS event-resource docs. No external model calls or service mutation.'}
p=V/'review/reuse-a/supplemental04.review.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('REVIEW',sha(p),out['counts'],len(reg),'sources',len(proofcache),'old card proof bindings')
# Actual readback, freshly parsed after disk serialization.
z=rd(p);assert z['counts']['cardPASS']==9 and len(z['questionImpactReview'])==75
for rr in z['results']:assert rr['bodySha256']==ch(rr['visibleBody']) and rr['fullDraftSha256']==ch(next(c for c in drafts if c['ruleId']==rr['ruleId']))
for rr in z['questionImpactReview']:
 assert rr['questionSha256']==ch(qb[rr['qid']])
 for aa in rr['necessaryAnchors']:assert aa['quote']==cards[aa['ruleId']]['visibleBody'][aa['field']][aa['startChar']:aa['endChar']]
for x,h in z['inputHashes'].items():assert sha(x)==h
rb={'status':'PASS','scope':'Serialized nine-card independent FACT/teaching review, two new-rule substitution/domain checks, and75 full original-question rechecks only','reviewPath':str(p),'reviewSha256':sha(p),'inputManifestPath':str(mp),'inputManifestSha256':sha(mp),'checks':{'nineCanonicalFourFieldBodiesAndFullDrafts':True,'all75UniqueOriginalQuestionsAndExactFrozenSet':True,'allLiteralVisibleAnchorsAndRecursivePrerequisites':True,'everyUsedExistingCardNamedReceiptAndBodyContract':True,'allOfficialSourceOffsetsFileTextQuoteHashes':True,'all17InputEvidenceRecordsValidatedAndDuplicatesNotCountedAsNewFacts':True,'fullOfficialExamGuidePdfHashAndTask22VisualRead':True,'noDeletedSevenOrQuarantinedGCL020':True,'allFrozenInputsStillUnchanged':True,'noCurrentInventoryApprovedTableCatalogueOrSourceMutation':True},'counts':z['counts'],'metadataCorrectionRecommended':{'ruleId':'VC-005','proposed':'2.1','recommended':'2.2','applied':False},'formalBilingualAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'directCliApiCalls':0,'nativeUsage':'unknown','readBackAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()};rp=V/'review/reuse-a/supplemental04.readback.json';rp.write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n');print('READBACK',sha(rp))

# -*- coding: utf-8 -*-
from common import *
r=[]
r.append(Q(29,'SUPPORTED',[1],['CUR:XB041','CUR:NS02','CUR:CA13'],'UDP需要NLB传输层入口，NS02的Global Accelerator全球边缘/健康选路覆盖多个Region，A。B/D的ALB不接原生UDP，C/D CloudFront属于已教HTTP内容入口而非VoIP UDP。'))
r.append(Q(69,'SUPPORTED',[2],['CUR:CB03','VC-003','CUR:CB18'],'跨AZ ASG避免计算层单AZ故障；Aurora跨AZ存储和适用reader可接管，Proxy减少客户端连接对writer切换的耦合，B。A/D额外跨Region及自写链路，C单AZ快照重建停机/损失更多。NB04只补历史恢复概念，不把备份替代本题HA。'))
r.append(Q(71,'SUPPORTED',[2],['CUR:NB04','GSC-067'],'腐败会随当前副本复制，NB04给数据库支持的PITR回到误改前，B；A换Region当前副本不是历史恢复，C每日Glacier远粗于15分钟，D把托管表当EBS卷。RTO1小时应在适用表规模与恢复操作上落实，不因为未做生产演练另造一张卡。',implementation=['启用目标表PITR、按误改时点恢复/切应用，确认实际恢复规模可在1小时目标内；不声称服务对任意表硬保1小时。']))
r.append(Q(78,'INSUFFICIENT_CARDS',[2],['CUR:NS03','CUR:NB04','GSC-047'],'NS03教AWS Backup统一生命周期且明确DynamoDB高级备份范围，B适合七年计划，C/D自建导出维护更高。但GSC047的35天明确只属RDS，不能私自扩成DynamoDB PITR上限；NB04仅说各自支持窗口，没有教为何A持续PITR不能七年。',missing=['DynamoDB PITR实际最大恢复窗口与AWS Backup长保留范围的对应；是现有备份卡补服务边界，不自动新卡。']))
r.append(Q(108,'SOURCE_ISSUE',[],['GSC-042','GSC-080'],'每次售出是业务行变化，管理状态通知不能替代。D虽SNS→多个SQS扇出方向正确，却以RDS资源事件为输入；C还颠倒队列/主题扇出。A/B可设想自定义数据库触发调用，但单个竞争队列不给每个不同目标各一份，未给完整广播设计。原题没有一项同时明确业务变更检测与每目标投递。',evidence=[RDS],source=['官方RDS事件订阅资源/类别属于实例等管理状态，不能据其通知业务记录售出；原D输入源不满足硬业务触发。']))
r.append(Q(120,'SUPPORTED',[2],['CUR:NS02','CUR:XB041','CUR:CA13'],'DNS是传输层服务，保留各Region NLB并作为Global Accelerator健康端点，B。其它项把HTTP CloudFront放DNS协议前，或换成ALB，不能保留所需DNS传输。'))
r.append(Q(142,'SUPPORTED',[3],['CUR:XB019','CUR:NS02','CUR:XB041'],'自改Linux内核需要可自管OS的EC2；UDP走NLB，边缘固定IP/健康选路由GA承担，C一次匹配三个硬条件。Lambda路径收回OS控制，ALB/HTTP API路径不满足UDP。'))
r.append(Q(143,'SUPPORTED',[4],['GCL-002','CUR:XB019','GSC-137','CUR:XB041'],'保留旧执行模型又按团队拆独立服务，GCL002的容器封装/边界拆分比直接函数重构合适；ECS承担编排、ALB把HTTP交给对应任务，D。C只ASG复制整机未提供服务边界；A/B更改原代码模型。原“ECS作为target”按服务任务注册目标理解，不当API TargetType字面。',implementation=['选择支持需求的ECS承载方式和服务伸缩，ALB注册实际任务IP/实例；不是把ECS控制面注册为后端。']))
r.append(Q(193,'SOURCE_ISSUE',[],[('GSC-032',('answerZH','keyPointZH','watchOutZH')),'GSC-033'],'缓存命中减少实际后端读，Redis复制组可HA；但原题未限定node-based，官方Memcached Serverless也有复制Multi-AZ自动缓解节点故障，D同样可满足已述减少读与HA。A仅分担读到其它数据库不等于减少总读取，C DNS缓存不缓存业务查询。不能沿旧node-based差异排除所有Memcached。',evidence=[MCHA],source=['现行B Redis和D Memcached Serverless均可满足；需要另行限定部署模式才可唯一排除D。']))
r.append(Q(194,'SUPPORTED',[1],['GCL-012','CUR:CB03','GSC-118'],'跨AZ数据库复制+集群故障检测/接管才是真正自动数据库HA，A。AMI/EC2自动恢复处理重建或底层硬件而非任意数据库集群自动切换，C只有跨Region复制/一般failover陈述，没有同样自动集群机制。'))
r.append(Q(209,'SUPPORTED',[1],['CUR:NB08','GSC-032'],'NB08明确会话外置到共享Redis等存储，实例随时缩放仍按会话ID读取同份状态，A。粘滞只路由不复制本机状态；SSM与STS的session是别的身份/管理概念，不存Web会话。'))
r.append(Q(217,'SUPPORTED',[1],['GSC-068','GSC-056','GSC-126','GSC-067'],'备用准备所需基础和数据、平时不承载请求，故active-passive配异地副本的A。B/C用active-active不符主区健康时不处理，C/D还走事后快照/基础重建，难与已准备副本比较恢复操作。新056保留副本须提升和切writer，A所需恢复动作可由该规则落实。',implementation=['按RPO/RTO准备目标计算与数据，执行受支持提升/端点流程；30分钟是设计目标，不把DR名称当绝对SLA。']))
r.append(Q(239,'SUPPORTED',[2],['CUR:XB012','CUR:CMP-M06'],'单函数HTTPS+IAM入口由function URL AWS_IAM直接承担，B比完整API管理层少配置；边缘函数并非带AWS_IAM的同类单函数URL入口。Go1.x按语言表述读，题没有给runtime=go1.x API字段，不擅自把它等同已退役托管运行时以判源坏。',implementation=['用现行支持方式构建/运行Go函数；这是前提已有Lambda函数的实施支持检查，不改变入口认证判断。']))
r.append(Q(244,'SUPPORTED',[3],['VC-003','CUR:CB03','GSC-112'],'Aurora跨AZ共享存储并由异AZreader接管，加跨AZ ALB/ASG，C兼顾数据库与Web HA和伸缩。A/B把Web或reader留同AZ，D仍数据库单机只靠备份，不等价。',implementation=['ASG配置反映实际负载的伸缩策略，而非只设上下限。']))
r.append(Q(261,'SUPPORTED',[1,3],['CUR:XA013','CUR:CA13','GSC-130','CUR:XB041'],'边缘函数按User-Agent选适用内容，CloudFront缓存区分真实版本，A+C。NLB不解析HTTP host/path，D/E即使套GA也不会获得ALB内容规则；130已教需把影响版本的值放适用缓存键。'))
write(1,r)

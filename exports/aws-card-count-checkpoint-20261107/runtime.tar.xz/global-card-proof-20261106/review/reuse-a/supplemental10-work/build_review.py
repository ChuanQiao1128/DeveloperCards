import pathlib, json, hashlib, collections, datetime, re

V = pathlib.Path(__file__).resolve().parents[3]
P = V / 'review/supplemental10/input'
O = V / 'review/reuse-a'
W = O / 'supplemental10-work'
FIELDS = ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']
def rd(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s): return hashlib.sha256(s.encode()).hexdigest()
def ch(x): return th(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
def body(c): return {f: c.get(f, '') for f in FIELDS}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest = rd(P/'manifest.json')
assert all(sha(p) == h for p, h in manifest.items())
base = {c['ruleId']: c for c in rd(P/'visible-pool.frozen.json')}
drafts = rd(P/'cards.json')
cards = dict(base)
for c in drafts:
    rid = c['ruleId']
    if c.get('repairOf'): assert c['repairOf'] == base[rid]['bodySha256']
    cards[rid] = {'ruleId': rid, 'visibleBody': body(c), 'bodySha256': ch(body(c)), 'prerequisiteRuleIds': c.get('prerequisiteRuleIds', base.get(rid, {}).get('prerequisiteRuleIds', []))}
assert len(base) == 359 and len(cards) == 360 and len(drafts) == 8
assert all(ch(c['visibleBody']) == c['bodySha256'] for c in cards.values())
index_path = V/'validation/current-card-review-index.json'
index_hash = sha(index_path)
index = {x['ruleId']: x for x in rd(index_path)['cards']}
legacy_path = V/'inputs/existing176.json'
legacy = {c['ruleId']: c for c in rd(legacy_path)}
proof_cache = {}
def bind_old(rid):
    if rid in proof_cache: return proof_cache[rid]
    c = base[rid]; ix = index[rid]
    assert ix['status'] == 'PASS' and ix['currentBodySha256'] == c['bodySha256']
    out = []
    for p in ix['proofs']:
        assert sha(p['path']) == p['sha256']
        d = rd(p['path']); rs = d.get('results', d.get('cards', []))
        if isinstance(rs, dict): rs = list(rs.values())
        matches = [x for x in rs if x.get('ruleId') == rid]
        assert matches, (rid, p['path'])
        r = matches[-1]; rh = r['bodySha256']
        contract = 'canonical four-field current visible body including empty values'
        if rh != c['bodySha256']:
            lb = body(legacy[rid]['body'])
            assert lb == c['visibleBody'] and ch({f: s for f, s in lb.items() if s}) == rh, rid
            contract = 'legacy omitted-empty hash; exact four visible fields reconstructed from hash-bound existing176 and matched'
        elif 'visibleBody' in r: assert r['visibleBody'] == c['visibleBody'], rid
        z = {'ruleId': rid, 'path': p['path'], 'sha256': p['sha256'], 'receiptBodySha256': rh, 'currentPriorBodySha256': c['bodySha256'], 'bodyBindingContract': contract}
        if r.get('proofs'):
            for pp in r['proofs']: assert sha(pp['path']) == pp['sha256']
            z['parentGateReceipts'] = r['proofs']
        out.append(z)
    proof_cache[rid] = out
    return out

registry = {}
def cite(p, needle, length, claim, occurrence=0):
    p = pathlib.Path(p)
    if not p.is_absolute(): p = V/p
    d = rd(p); s = d['text']; positions = [m.start() for m in re.finditer(re.escape(needle), s)]
    assert positions, (p, needle)
    start = positions[occurrence]; q = s[start:start+length]
    z = {'claim': claim, 'url': d['url'], 'sourcePath': str(p), 'sourceFileSha256': sha(p), 'sourceTextSha256': th(s), 'quote': q, 'startChar': start, 'endChar': start+len(q), 'quoteSha256': th(q)}
    if d.get('rawSha256') and p.with_suffix('.html').exists():
        z.update(rawHtmlPath=str(p.with_suffix('.html')), rawHtmlSha256=d['rawSha256'])
        assert sha(z['rawHtmlPath']) == z['rawHtmlSha256']
    if d.get('textSha256'): assert th(s) == d['textSha256']
    eid = ch(z); registry[eid] = z
    return eid

inputs = rd(P/'official-evidence.json'); input_validation = []
for i, e in enumerate(inputs):
    d = rd(e['snapshotPath']); s = d['text']
    assert sha(e['snapshotPath']) == e['snapshotSha256'] and th(s) == e['textSha256']
    assert s[e['quoteStart']:e['quoteEnd']] == e['quote'] and d['url'] == e['url']
    input_validation.append({'ordinal': i, 'url': e['url'], 'snapshotPath': e['snapshotPath'], 'snapshotSha256': e['snapshotSha256'], 'textSha256': e['textSha256'], 'quoteStart': e['quoteStart'], 'quoteEnd': e['quoteEnd'], 'quoteSha256': th(e['quote']), 'status': 'PASS_literal_hash_offset_validation'})
def src(i, needle, n, claim): return cite(inputs[i]['snapshotPath'], needle, n, claim)

E={}
E['deep-lowest']=src(1,'choose S3 Glacier Deep Archive',190,'Deep Archive has the lowest archival storage price and a longer retrieval wait; this is unit storage price, not a universal total-cost ranking.')
E['retrieval-times']=src(1,'standard retrievals that typically complete in',420,'Flexible standard retrieval is typically 3–5 hours; Deep Archive retrieval options start at 12 hours. Private official fact cannot fill an absent visible learning premise.')
E['small-ia']=src(4,'S3 Standard-IA and S3 One Zone-IA storage have a minimum billable object size',215,'IA minimum billable size is 128 KB.')
E['small-archive']=src(4,'For each object that is stored in the S3 Glacier Flexible Retrieval',750,'Flexible/Deep Archive adds 40KB metadata; Glacier Instant Retrieval minimum billable size is 128KB.')
E['small-lifecycle']=src(9,'Objects smaller than 128 KB will not transition by default',700,'New Lifecycle default prevents transitions below128KB; per-object transition requests can exceed savings.')
E['small-override']=src(9,'To allow smaller objects to transition',385,'Explicit size-based filter may override the small-object transition default.')
E['duration-ia']=src(4,'S3 Standard-IA, and S3 One Zone-IA storage are charged',645,'IA has30-day minimum charge; early deletion or transition incurs remaining minimum charge.')
E['duration-archive']=src(4,'Objects that are archived to S3 Glacier Instant Retrieval',940,'Glacier Instant/Flexible minimum90days, Deep Archive180days; deletion/overwrite/transition before minimum does not avoid remaining storage charge.')
E['it-monitor']=src(10,'For a low monthly object monitoring and automation charge',545,'Intelligent-Tiering has monitoring fees and moves objects by inactivity; cost superiority is not unconditional.')
E['it-small']=src(10,'If the size of an object is less than 128 KB',233,'Sub128KB objects remain frequent tier and are not monitored/automatically tiered.')
E['rds-gp3']=src(7,'Db2, MariaDB, MySQL, and PostgreSQL 400–65,536 GiB 12,000 IOPS/500 MiB/s',190,'RDS MySQL/PostgreSQL gp3 at400GiB+ has12000baseline, configurable12000–64000IOPS.')
E['rds-independent']=src(7,'By using General Purpose gp3 storage volumes',372,'RDS gp3 separates storage performance configuration from storage capacity within product limits.')
E['rds-modify']=src(3,'You can modify the settings for a DB instance',490,'RDS gp3 IOPS/throughput can be modified without replacing with io2.')
E['rds-io2']=src(7,'For a production application that requires fast and consistent I/O performance',480,'Provisioned IOPS is an alternative for consistent performance/latency; no blanket gp3 total-cost winner is established.')
E['optimizer-ec2-asg']=src(2,'Amazon EC2 instances and EC2 Auto Scaling groups both require',500,'Compute Optimizer supports EC2 and EC2 Auto Scaling groups subject to metrics/eligibility.')
E['optimizer-fargate']=src(2,'To generate recommendations for Amazon ECS services on Fargate',950,'Fargate service recommendations are supported with resource-specific metrics/scaling/run-state conditions.')
E['host-reservations']=src(5,'Dedicated Host Reservations provide a billing discount',1150,'Host reservations offer one/three-year terms and payment options; all-upfront has the lowest effective price.')
E['host-liability']=src(5,"When a reservation is associated with a Dedicated Host",175,'A reserved Host cannot be released until its reservation term ends; short usage does not cancel the commitment.')
E['sp-payments']=src(0,'You can pay for your commitment using',125,'Savings Plans has All/Partial/No Upfront payment options; exact valid prior contract/discount proofs are reused.')
E['acm-rule']=src(8,'Checks if AWS Certificate Manager Certificates',850,'Config expiration managed rule covers imported certs and accepts a configurable daysToExpiration threshold.')
E['acm-events']=cite('review/source-current-final/a/evidence/acm-expiration-events.snapshot.json','ACM sends daily expiration events for all active certificates',725,'Imported ACM certificates have approaching-expiration events and require separate reissue/reimport.')
E['acm-days']=cite('review/source-current-final/a/evidence/acm-expiration-events.snapshot.json','"DaysToExpiry":',160,'ACM event payload exposes DaysToExpiry for event filtering.')
E['config-events']=cite('review/reuse-a/supplemental09-work/sources/config-events.json','Choose Config Rules Compliance Change',395,'Config noncompliance may trigger EventBridge notification; evaluation does not renew an imported certificate.')
E['io1-limit']=cite('review/remaining-source10/evidence/ebs-io1.json','io1 volumes can range in size',475,'EC2 io1 maximum64000IOPS and50:1IOPS/GiB;64000IOPS requires1280GiB+, contradicting Q9191TB baseline.')
E['domain']=cite('review/reuse-a/supplemental04-work/sources/saa-c03-guide.json','Task 4.1: Design cost-optimized storage solutions\nKnowledge of:',1780,'SAA-C03 task4.1 includes storage cost, lifecycle, tier selection and archival strategies.')

reason={
'CUR:CMP-M01':'仍是取回等待和多AZ约束决定即时/异步存储层；新增Deep Archive最低存储单价解释长期冷数据选择，并以总费用提醒限制外推。',
'GSC-024':'前面问50KB对象是否省钱且能完成自动转换；后面同时训练最小计费/元数据费用机制及Lifecycle默认尺寸过滤机制。两者不能互相推出，答、考点都要求回忆两套独立规则，超过一个主要回忆任务。',
'GSC-025':'按冷热是否可预测选择自动跟踪或固定生命周期，监控费用是同一取舍的代价；可选异步层提醒仍保留。',
'VC-012':'一个有用途的计费判断：提前删除是否免除最低计费；30/90/180天是把60天场景落实为费用后果的必要边界，没有把计费期误写成禁止删除。',
'GSC-051':'已知存储IOPS瓶颈，先评估现gp3能力再换昂贵类型，容量/12000基线/64000上限解释15000与超过20000并非必然需io2。保留实例I/O与计算/存储分层机制。',
'GSC-151':'一个工具用途判断：监控数据与分析后的规格建议不同。新增ASG与Fargate是同一分析服务的适用范围，不要求回忆部署参数。',
'VC-007':'Dedicated Host预留纳入同一承诺期限/付款换折扣机制，不新增主机部署清单；客户仍须判断长期用量能否履行。',
'CUR:XA005':'现在正面明确问同一30天提醒任务的两种信号来源，答案均须答出；ACM/Config两个入口共同通向通知，不再把证书知识塞入EBS整改任务。提醒与续期的责任边界是本题直接所问。'}
eids={
'CUR:CMP-M01':['deep-lowest'], 'GSC-024':['small-ia','small-archive','small-lifecycle','small-override'],
'GSC-025':['it-monitor','it-small'],'VC-012':['duration-ia','duration-archive'],
'GSC-051':['rds-gp3','rds-independent','rds-modify','rds-io2'],'GSC-151':['optimizer-ec2-asg','optimizer-fargate'],
'VC-007':['host-reservations','host-liability','sp-payments'],'CUR:XA005':['acm-rule','acm-events','acm-days','config-events']}
results=[]
for c in drafts:
    rid=c['ruleId']; fail=rid=='GSC-024'; gates={g:'PASS' for g in ['FACT','U1','R1','T1','S1','P1']};gates['B1']='N/A_chinese_stage'
    if fail:gates.update(U1='FAIL_two_independent_mechanisms',R1='FAIL_two_recall_tasks')
    results.append({'ruleId':rid,'status':'FAIL' if fail else 'PASS','gates':gates,'visibleBody':body(c),'bodySha256':ch(body(c)),
        'fieldSha256':{f:th(c.get(f,'')) for f in FIELDS},'fullDraftSha256':ch(c),'bodyHashContract':'canonical sorted JSON UTF8 of four named fields including empty values',
        'priorBodySha256':base.get(rid,{}).get('bodySha256'),'namedValidPriorFACTProofs':bind_old(rid) if rid in base else [],
        'unchangedFactReuseScope':'Exact valid prior mechanism only; all newly asserted facts are linked to official positive evidence below. This review independently assesses the entire current recall task.',
        'evidenceIds':[E[k] for k in eids[rid]],'teachingAndRecallTaskReason':reason[rid],
        'prerequisiteRuleIds':cards[rid]['prerequisiteRuleIds'],'prerequisiteBodyBindings':{r:cards[r]['bodySha256'] for r in cards[rid]['prerequisiteRuleIds']},
        'assessmentCheck':'Only the principal visible question and causal explanation are assessed. XA005 explicitly asks both methods, so both are answers; warnings/given premises are not extra required answers. Private mustAnswer contract was not provided.',
        'findings':[{'id':'S10-GSC024-R1','priority':'P1','fields':['frontZH','answerZH','keyPointZH'],
            'quote':'只看每GiB单价并设Lifecycle转归档，就能保证省钱且完成转换吗？',
            'reason':'费用是否划算与Lifecycle是否默认允许迁移是独立判断。相同128KB数值并不能把两种机制合成一个回忆任务。',
            'minimumRepair':'只收窄本卡到小对象费用判断或小对象转层资格之一；另一事项不作为本次主要问题和必答。可复用同组卡和私有题解保留义务，不默认再新增一张卡。'}] if fail else []})

qb={q['qid']:q['question'] for q in rd(P/'questions.json')}
overlay_ids={c['ruleId'] for c in drafts}
def A(rid,fields=('answerZH','keyPointZH')):
    c=cards[rid]
    return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'startChar':0,'endChar':len(c['visibleBody'][f]),'candidateOverlay':rid in overlay_ids} for f in fields if c['visibleBody'].get(f)]
def Q(qid,status,opts,ids,reason,missing=(),conditions=(),implementation=(),ev=(),issues=()):
    aa=[]
    for x in ids:aa+=A(x[0],x[1]) if isinstance(x,tuple) else A(x)
    used=sorted({a['ruleId'] for a in aa});todo=list(used);seen=set();pre=[]
    while todo:
        rid=todo.pop()
        if rid in seen:continue
        seen.add(rid)
        for dep in cards[rid].get('prerequisiteRuleIds',[]):
            assert dep in cards;pre.append({'from':rid,'ruleId':dep,'bodySha256':cards[dep]['bodySha256'],'visibleBody':cards[dep]['visibleBody']});todo.append(dep)
    for r in seen:
        if r not in overlay_ids:bind_old(r)
    failused='GSC-024' in used
    assert status!='SUPPORTED' or not failused
    q=qb[qid]
    return {'qid':qid,'status':status,'selectedOptionOrdinals':opts if status=='SUPPORTED' else [],'candidateOptionOrdinals':opts,'questionSha256':ch(q),
        'originalStemUtf8Sha256':th(q['stem']),'originalOptionsCanonicalSha256':ch(q['options']),'completeStemAndEveryOptionRead':True,
        'usedRuleIds':used,'necessaryAnchors':aa,'recursiveUsedPrerequisiteBindings':pre,'reasoningAndClosestCompetitor':reason,
        'minimumRemainingJudgments':list(missing),'conditions':list(conditions),'implementationChecksNotNewCards':list(implementation),
        'officialEvidenceIds':[E[k] for k in ev],'sourceIssues':list(issues),'usesTeachingFailedCandidateOverlay':failused,
        'officialEvidenceNotSubstitutedForMissingVisibleLearningPremise':True,'noPrivateTargetsOrPrintedAnswersUsed':True}

questions=[]
questions.append(Q(23,'SUPPORTED',[2],['CUR:CMP-M01','GSC-025','VC-012'], '首月频繁、之后不再访问、无限期保留，是已知生命周期；M01的Deep Archive长期极冷最低存储单价及Lifecycle转换支持B。C/D仍留在即时IA，A增加访问监控且没有此题需要的未知冷热判断；VC012最低计费期并不妨碍无限保留。',implementation=['按正常Lifecycle能力安排首月后转层；大小/权限等未给特殊硬限制，不补出额外部署门槛。']))
questions.append(Q(49,'SUPPORTED',[4],['GSC-031','CUR:CMP-M01','GSC-025'], 'GSC031明确对象存储/标签不等于查询索引，给出RDS元数据查找后按对象位置取文件；M01允许旧文件延迟恢复并用Deep Archive降低长期冷存储单价。D将快检索索引与旧正文归档分开。A仅查标签不能替索引；C仍把元数据本身放S3而没有已教可查询索引；B使用更复杂查询/归档路径，且一年后冷正文没有利用更低的Deep Archive单价。',implementation=['D的query files from RDS按上下文指查询文件元数据，正文仍从S3取回，不宣称RDS保存原文件。']))
questions.append(Q(82,'SOURCE_ISSUE',[2,4],['CUR:XA005'], '新XA005在同一题面清楚教会Config到期规则阈值与ACM临期事件两条通知信号；B与D均可提醒导入证书。A虚构ACM直接发布SNS规则；C未给足适用Trusted Advisor到期检查依据。原题无最省运维或禁止Lambda条件，不能强选B。',ev=['acm-rule','acm-events','config-events'],issues=['B与D当前均可实现；此新卡修复教学归位，不改变原题非唯一事实。']))
questions.append(Q(153,'CONDITIONAL',[2,4],['CUR:CMP-M01','GSC-025'], 'D用明确90天年龄边界转Standard-IA，维持即时访问并避免额外监控，是合理候选；A一开始就IA不对应初期访问，C把inventory当执行转层。B的Intelligent-Tiering也维持即时访问并随真实冷热转层，新GSC025明确有监控费用但不保证一定更贵。仅有文件至少128KB和旧文件少读，不能计算B与D的最低总费用。',missing=['B与D的对象大小分布、真实读取/保留模式与监控/取回费之间的必要成本比较。'],conditions=['已知90天边界且自动跟踪节省不足以抵消监控时，D；若真实冷热分布使自动分层减少存储/读取费用更多，B也可能有竞争力。']))
questions.append(Q(353,'SUPPORTED',[2],['CUR:CC22','CUR:CB01','GSC-015',('GSC-051',('frontZH','answerZH','keyPointZH'))], 'CC22支持保留MySQL关系引擎迁RDS以减维护，CB01提供跨AZ接管；GSC015明示RDS1000GiB gp2约3000IOPS，超过双倍峰值2000。GSC051的先比较足够General Purpose而非直接换最贵类型可迁到B，A的io2不是此IOPS数值所必需。C改变数据库模型，D仍自管EC2。',implementation=['没有把EC2 gp3价格/上限照搬RDS；本题gp2能力由GSC015具体RDS句给出。']))
questions.append(Q(383,'CONDITIONAL',[1],['GSC-149','VC-007'], 'GSC149将按物理socket/core计量及主机可见控制对应到Dedicated Host，C/D的Dedicated Instance不等价；VC007新增Host预留折扣给出A相对B的长期承诺路径。原题只给容量和uptime可预测，没有明确可承诺的一/三年期限与利用率，许可证今年购买也不证明可迁入条款。',missing=['许可证允许该Host BYOL，以及承诺期限内利用率足以使预留比On-Demand更经济。'],conditions=['若授权适用且使用覆盖匹配预留承诺期，则A；不能把可预测自动改写为稳定三年。'],ev=['host-reservations']))
questions.append(Q(394,'SOURCE_ISSUE',[2,3],['GSC-051'], '新GSC051教会MySQL2000GB gp3不是20000IOPS硬上限，可在64000范围增加IOPS，B可行。原题只问改善性能，没有最低成本/最小改动条件；io2提供持续低延迟/更高IOPS的路径，C也可能改善。原题未给实际峰值是否在64000内，不能用当前卡强排C或把超过20000判为必须io2。A磁盘退代且不改善该I/O需求；D不能把RDS受管存储随意当两块自管EC2卷处理。',conditions=['确认现gp3IOPS确不足且实例有I/O余量时B有效；更高或更稳定I/O要求可能选择C。'],ev=['rds-gp3','rds-modify','rds-io2'],issues=['B与C都存在可行改善情形，题面缺少足以唯一选择的优化目标/性能范围。']))
questions.append(Q(463,'INSUFFICIENT_CARDS',[3],['GSC-133','GSC-029','GSC-136','GSC-095','GSC-097'], 'GSC133支持Python/1GB/30秒的标准Lambda，GSC029支持S3写入触发；C可运行。当前卡仍没教小而短的逐对象处理相对Glue Scala/PySpark和EMR的计费/最低资源代价；不能因能运行就自动证明MOST cost-effective。VC012的S3存储最低计费期与计算选型无关。',missing=['Lambda与Glue/EMR在此小文件短处理的费用机制比较；无需补所有弱干扰项部署手册。']))
questions.append(Q(534,'INSUFFICIENT_CARDS',[3],['CUR:CMP-M01','VC-012'], 'M01允许首月后归档，VC012说明在Flexible只待60天会按90天最低存储计费，且不是禁止60天删除。于是不能以提前删就必然不划算排C，也不能只凭归档单价低判C最省：卡面没有足以把Flexible90天有效费用与IA60天费用、转换/对象开销相比较的相对量。A仍热层；B/D把90天转Glacier与删除放同一天也不能拿来证明更优费用。',missing=['在原30+60天条件下，Flexible90天计费与IA60天及对象/转换开销的有效费用比较。'],implementation=['需正确处理同天到期/转层，属于正常Lifecycle配置；本审查不凭未列SLA测试降级。'],ev=['duration-archive']))
questions.append(Q(551,'INSUFFICIENT_CARDS',[1],['CUR:CMP-M01','GSC-024','VC-006','GSC-025'], '50KB是原题硬条件，候选GSC024给出128KB最低计费/默认不转层和40KB元数据，但该稿教学FAIL不计接受。VC006已教Deep Archive Standard通常12小时、Flexible Expedited小对象通常1–5分钟，故可识别D不适合6小时、A可用更快档位；当前卡却没教Flexible较便宜Standard通常3–5小时，不能从卡面选择满足6小时且最省的恢复档位。IA的最早转层等边界也不能混同其最低计费期。C对50KB不适用自动分层。',missing=['Flexible Retrieval Standard通常3–5小时及其在6小时预算内相对Expedited的费用/等待选择。','GSC024须先收窄为一个教学任务；小对象转层允许条件与费用判断仍分别保留义务。'],implementation=['显式覆盖小于128KB的Lifecycle默认行为可作为正确实现，不把原选项缺该参数直接判源错。','不要求实测硬SLA；缺的是可见卡中必要取回档位知识。'],ev=['retrieval-times','it-small','small-lifecycle']))
questions.append(Q(606,'SUPPORTED',[2],['CUR:CMP-M01','GSC-025'], '原题已知前30天频繁、之后少读，且随时可读/最大耐久；M01的Standard-IA即时多AZ路径与Lifecycle支持B。A的传统Glacier需先恢复，C单AZ不符合最大耐久设计；D在已知频繁阶段引入Intelligent-Tiering监控后仍转同一Standard-IA，GSC025说明已知冷热分界可直接Lifecycle且监控有费用。',implementation=['没有把任意小对象/未知读取模式额外加入原题；本题采用其已给已知冷热边界。']))
questions.append(Q(649,'INSUFFICIENT_CARDS',[3],['GSC-051','GSC-015','CUR:CC22'], 'GSC051正向证明RDS PostgreSQL容量到400GiB后可单独配置15000IOPS，GSC015排除gp2把IOPS与容量独立配置的说法，C是可行候选。B的io1也能提供独立IOPS；新卡仅说先评估gp3并警告不能保证所有RDS场景最便宜，没有教此处gp3与io1的费用比较，原题也未给实际存储容量。',missing=['此PostgreSQL15000IOPS配置中gp3对io1的存储/额外IOPS费用比较，保留400GiB门槛与实际容量约束。'],implementation=['原文on-premises同时提EBS予以保留，不单凭部署用词自动定源错；目标选型仍按RDS产品。'],ev=['rds-gp3','rds-independent']))
questions.append(Q(728,'INSUFFICIENT_CARDS',[2],['GSC-010','CUR:CMP-M01','VC-006'], 'GSC010说明cached以S3为主、本地仅保热点，能减少全量本地容量；stored保全量本地，C/D不能直接解决本地容量不足。A归档先恢复且有取回档位费用。B方向合理，但当前卡没有提供cached普通云端回源的取回收费/带宽费用边界，不能证明题目no additional cost的费用目标。不能把cached未命中走网络直接当异步归档等待，也不要求额外SLA实测。',missing=['Storage Gateway cached读回S3的取回/传输费用边界，以及缓存如何影响带宽成本；解释no additional cost的具体费用范围。']))
questions.append(Q(919,'SOURCE_ISSUE',[],['GSC-016'], 'GSC016允许在实例EBS路径尚有余量时以多卷条带化提高聚合性能，A是修正源配置后可考虑的路径；原题却说单1TB io1已配64000IOPS。官方io1最大50IOPS/GiB，64000至少1280GiB，1000GB或1024GiB都不满足，因此不能在不改原条件下验收整题。B又超过io1单卷64000上限；C变2TB不能抵扣原基线错误；D是否改善实例EBS路径要看真实瓶颈。',ev=['io1-limit'],issues=['1TB/64000IOPS的io1配置违反50:1约束；保留原题，任何容量纠正另立变体，未把A升级原题充分。']))
questions.append(Q(926,'CONDITIONAL',[2,4],['GSC-151','GSC-146','GSC-137','CUR:XB019'], 'GSC151已明确Compute Optimizer支持适用ECS Fargate服务，所以不能按旧知识把D排除；它给出规格优化建议。GSC146说明Spot节省以容忍回收为条件，B若仅用于可恢复的增量突发也可能省费，C把关键基线压Spot风险更直接。原题未说明是否过配、突发容量是否允许回收以及最低服务基线，不能从卡面唯一比较B与D的总费用/高可用取舍；A把CloudWatch观察当成直接规格建议，缺同等托管分析机制。',missing=['突发任务回收容忍度/必要稳定容量，以及现有任务规格是否存在可优化余量。'],conditions=['D适用于符合Optimizer条件、按建议维持性能和HA的规格优化；B须基线可靠且增量任务能恢复/重调度，不能把24×7直接等同可用任意Spot。'],ev=['optimizer-fargate']))
questions.append(Q(937,'SUPPORTED',[3],['GSC-151','GSC-153'], 'GSC151新增正文明确涵盖EC2、EC2 Auto Scaling组和EBS的规格/配置建议，完整对应C。GSC153把CUR定义为原始账单明细供自定义查询，账单及CloudWatch告警不是这些资源的现成优化建议，A/B不符；D只把EC2交Optimizer，另用CUR查ASG/EBS建议的分工也不符。',ev=['optimizer-ec2-asg']))
questions.append(Q(940,'CONDITIONAL',[4],['VC-007','GSC-054','CUR:CB02'], 'GSC054/CB02说明RDS实例不能由Compute SP抵扣，RDS预留加EC2 SP是正确分工；VC007在稳定三年且能承担预付的前提下支持D更深折扣。原题仅说long-running，不能自动等同稳定使用三年或预付现金条件已满足；若实际只承诺一年，C/B的总成本可能更合适。',missing=['稳定利用率能够覆盖三年承诺及全额预付可承担；否则须按真实期限比较一年选项。'],conditions=['原题业务确可履行三年稳定承诺及预付时，D；不把卡面的三年教学前提补写成原题事实。']))
questions.append(Q(953,'SUPPORTED',[1],['CUR:CMP-M01','VC-012'], '原始上传图后续每年只训练两次，可在初次生成完成后放长期极冷Deep Archive，并提前安排训练恢复；M01支持这一低频长保留层。premium生成图随时下载必须即时层，A/C满足而B/D将所有生成图放Flexible无法直接满足premium随时取用。A与C的生成图分层相同，上传原件的长期极少读取由M01最低归档单价支持Deep Archive，A更匹配。VC012提醒最低计费期而不把它误当不能提前操作。',implementation=['原题每6小时允许下载描述资格/频次，绝不据此推断非premium能等待6小时恢复。','先完成用上传图生成，再归档冷原件；不是把刚上传待处理数据先冻住，训练可计划预恢复。']))
questions.append(Q(989,'INSUFFICIENT_CARDS',[3],['VC-010','GSC-047','CUR:NS03'], 'VC010区分自动30天窗口与另删手工快照，并保留禁用自动备份会损害已有恢复点的边界，C行为完整；B/D禁用不满足保留所有近30天恢复点。A也包含所需保留/手工清理动作，当前卡仍未教AWS Backup管理此拓扑时与原生RDS保留的计费、重复备份或免费额度差异，不能只凭多一个服务名就验收C最低费用。VC012是S3存储最低计费期，与该比较无关。',missing=['A与C在保留既有RDS自动/手工备份的实际费用取舍；无需新增完整部署手册。']))
assert len(questions)==19 and {q['qid'] for q in questions}==set(qb)

near=[c for c in base.values() if re.search(r'Glacier|最低|最短|计费期|保留|归档|Lifecycle|生命周期',json.dumps(c['visibleBody'],ensure_ascii=False))]
nearest=['CUR:CMP-M01','GSC-024','VC-006','GSC-025','GSC-026','GSC-047','VC-010']
for r in nearest:bind_old(r)
sub={'ruleId':'VC-012','status':'INDEPENDENT_MINIMUM_CHARGE_RULE_CANDIDATE_FINAL_CORE_ADMISSION_DEFERRED','entireFrozenPoolCountChecked':359,
    'scannedPoolSha256':sha(P/'visible-pool.frozen.json'),'method':'Scanned all frozen four-field bodies for storage/lifecycle/minimum billing/retention alternatives, then compared the matching nearest visible rules; no source-only fact was treated as a learned rule.',
    'candidateRuleIdsExamined':[c['ruleId'] for c in near],'nearestRuleIds':nearest,'visibleNearestCards':[{'ruleId':r,'bodySha256':base[r]['bodySha256'],'visibleBody':base[r]['visibleBody']} for r in nearest],
    'reason':'M01和GSC024只说应考虑最低保留/费用，没有30/90/180天或提前删仍计剩余费用；VC006是取回等待而非存储最低计费；GSC047/VC010管理RDS备份留存，不是S3最低收费。现池无法推出60天停留Flexible仍按90天计费，存在真正独立知识缺口。',
    'proposedQuestionIds':[534,551,463,989],'questionNecessityChecks':[{'qid':534,'verdict':'NECESSARY_PARTIAL_JUDGMENT','reason':'补早删最低计费后果，但卡组仍缺有效总费用比较，未充分。'},{'qid':551,'verdict':'NOT_DECISIVE_FOR_THIS_ORIGINAL','reason':'正文要求存数年，没有提前删除条件；取回6小时及50KB费用/资格才是当前缺口。'},{'qid':463,'verdict':'UNRELATED','reason':'Lambda/Glue/EMR处理费用，不涉及S3提前删除最低计费。'},{'qid':989,'verdict':'UNRELATED','reason':'RDS自动/手工备份生命周期及费用，不等于S3最低存储计费。'}],
    'actualUniqueNecessaryQuestionIds':[534],'lowFrequencyAdmission':'一题内真实必要性成立，不能把四个候选标签当跨题复用证明。按全库约300目标暂缓最终核心包纳入/N，继续保留该义务并寻找真实复用或合并机会；本轮不擅自添卡或删卡。','noExistingRuleDeleted':True}

transfers=[
 {'ruleId':'CUR:CMP-M01','changedCondition':'相同长期少读，从必须立即读取改为可先恢复','status':'PASS','reason':'可从即时层转到异步归档；最低单价不免除取回与保留约束。'},
 {'ruleId':'GSC-024','changedCondition':'同样50KB对象，显式允许Lifecycle迁移','status':'PASS_local_transfer_NOT_overall_teaching_PASS','reason':'覆盖过滤只解决能否迁移，不会消除最低计费大小/40KB费用；反证两条机制独立。'},
 {'ruleId':'VC-012','changedCondition':'Flexible保留60天改为120天','status':'PASS','reason':'60天按90天最低计费；120天超过最低期，不再补不足90天的剩余费用，但仍按真实120天存储收费。'},
 {'ruleId':'GSC-051','changedCondition':'MySQL gp3从400GiB以上改为200GiB，却仍需15000IOPS','status':'PASS','reason':'卡面400GiB门槛不再满足，不能把15000–64000能力无条件外推给较小容量；需重配或比较其他存储。'},
 {'ruleId':'VC-007','changedCondition':'稳定三年改为只运行三个月','status':'PASS','reason':'不能继续直接选择三年全预付；更深小时折扣不保证更低总账单。'},
 {'ruleId':'CUR:XA005','changedCondition':'采用Config到期通知替代ACM临期事件','status':'PASS','reason':'信号来源改变但仍需通知链；两者均不会代替外部CA重签/重新导入。'}]
used_old={d['ruleId'] for q in questions for d in q['recursiveUsedPrerequisiteBindings'] if d['ruleId'] not in overlay_ids}
used_old|={r for q in questions for r in q['usedRuleIds'] if r not in overlay_ids}
for r in used_old:bind_old(r)
report={'schemaVersion':1,'batch':'supplemental10','reviewer':'independent current-content and full-original reviewer; no authoring performed','status':'FAIL_one_card_teaching_repair_and_VC012_relation_metadata_correction_required','reviewedAtUtc':now(),
    'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'inputHashes':manifest,'priorReviewIndexPath':str(index_path),'priorReviewIndexSha256':index_hash,
    'legacyBodyBindingSourcePath':str(legacy_path),'legacyBodyBindingSourceSha256':sha(legacy_path),'frozenVisiblePoolCount':359,'candidateOverlayCount':8,'revisedExistingCards':7,'proposedNewCards':1,'appliedToCurrent':False,
    'counts':{'cardPASS':7,'cardFAIL':1,'questionStatuses':dict(collections.Counter(q['status'] for q in questions))},'results':results,'questionImpactReview':questions,
    'usedExistingCardProofBindings':dict(sorted(proof_cache.items())),'evidenceRegistry':registry,'officialInputRecordValidation':input_validation,
    'newCardSubstitutionTests':[sub],'newCardDomainMetadataReview':[{'ruleId':'VC-012','status':'PASS_primary_task_only','proposedPrimaryDomain':'4','proposedPrimaryTask':'4.1','recommendedPrimaryDomain':'4','recommendedPrimaryTask':'4.1','reason':'核心是存储生命周期动作与最低计费后果，属于成本优化存储4.1；候选逐题关系仍须按下项纠正。','evidenceIds':[E['domain']]}],
    'metadataRepairRequests':[{'ruleId':'VC-012','findingId':'S10-VC012-MAP','field':'questionIds','proposed':[534,551,463,989],'verifiedNecessary':[534],'removeUnrelated':[463,989],'doNotCountAsDecisive':[551],'reason':'不得以计算成本/RDS备份费用题或无提前删除场景来虚增最低S3计费规则的复用。','applied':False}],
    'transferChecks':transfers,'minimumRepairScope':{'ruleIds':['GSC-024'],'findingIds':['S10-GSC024-R1'],'semanticAffectedOriginalQuestionIds':[551],'metadataOnlyRuleIds':['VC-012'],'metadataFindingIds':['S10-VC012-MAP'],'otherSevenCardResultsReusableOnlyWithExactHashes':True,'authoringRequiredByRoot':True},
    'unchangedFailedCC10DraftReReviewed':False,'priorFailureLineage':{'path':str(O/'supplemental09.review.json'),'sha256':sha(O/'supplemental09.review.json'),'oldCC10BodyRetainedPerFrozenPool':True,'noPreviousFailureOverwritten':True},
    'questionGapSummary':{'costLearningPremiseMissing':[463,534,649,728,989],'retrievalTierAndSmallObjectTeaching':[551],'commitmentOrWorkloadConditionsMissing':[153,383,926,940],'nonUniqueOrInvalidOriginal':[82,394,919]},
    'formalBilingualAcceptance':False,'privateGradingContractAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'originalQuestionStatusesAutomaticallyPromoted':False,
    'priorFailuresPreserved':True,'currentPointersChangedByReviewer':False,'authoringPerformed':False,'externalOfficialReadOnlyFetches':0,'directCliApiCalls':0,'nativeUsage':'unknown'}
review_path=O/'supplemental10.review.json';review_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
z=rd(review_path)
for r in z['results']:
    assert ch(r['visibleBody'])==r['bodySha256'] and r['fieldSha256']=={f:th(r['visibleBody'][f]) for f in FIELDS}
    assert r['fullDraftSha256']==ch(next(c for c in drafts if c['ruleId']==r['ruleId']))
for q in z['questionImpactReview']:
    assert q['questionSha256']==ch(qb[q['qid']])
    for a in q['necessaryAnchors']:
        c=cards[a['ruleId']];assert c['bodySha256']==a['bodySha256'] and c['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
    for d in q['recursiveUsedPrerequisiteBindings']:assert cards[d['ruleId']]['bodySha256']==d['bodySha256'] and cards[d['ruleId']]['visibleBody']==d['visibleBody']
for eid,e in z['evidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256']
    assert s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256'] and ch(e)==eid
assert all(sha(p)==h for p,h in manifest.items()) and sha(index_path)==index_hash
rb={'status':'PASS_review_serialization_and_bindings_content_FAIL_remains','readBackAtUtc':now(),'reviewPath':str(review_path),'reviewSha256':sha(review_path),'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'counts':z['counts'],
    'checks':{'eightFourFieldBodiesAndPerFieldHashes':True,'all19UniqueFullOriginalsAndExactFrozenSet':True,'allLiteralVisibleAnchorsAndRecursivePrerequisites':True,'everyUsedExistingCardExactNamedReceipt':True,'allOfficialFileTextQuoteOffsetsAndHashes':True,'all11FrozenOfficialInputRecordsValidated':True,'newVC012Full359PoolSubstitutionAndPrimaryTaskChecked':True,'irrelevantVC012QuestionTagsNotCountedAsReuse':True,'noSupportedQuestionUsesTeachingFailedGSC024Overlay':True,'allFrozenInputsAndIndexStillUnchanged':True,'noCurrentCatalogueSourceQuestionOrProductionMutation':True},
    'remainingFailures':['S10-GSC024-R1','S10-VC012-MAP'],'directCliApiCalls':0,'nativeUsage':'unknown','formalBilingualAcceptance':False,'learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False}
(O/'supplemental10.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':str(review_path),'sha256':sha(review_path),'counts':z['counts'],'readback':str(O/'supplemental10.readback.json')},ensure_ascii=False))


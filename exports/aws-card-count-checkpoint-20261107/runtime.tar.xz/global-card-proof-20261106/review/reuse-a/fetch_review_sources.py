import subprocess,pathlib,json,hashlib,re,html,datetime,concurrent.futures
V=pathlib.Path(__file__).resolve().parents[2];out=V/'review/reuse-a/sources';cat=json.loads((V.parent/'domain1-final-card-catalog-20261105/official-sources.catalog.json').read_text());known={e['url'] for e in cat};urls=set()
for batch in ['batch05','batch06','batch07','batch08']:
 for c in json.loads((V/'drafts'/f'{batch}.json').read_text()):urls.update(c.get('sourceUrls',[]))
import sys
urls=sys.argv[1:] if len(sys.argv)>1 else sorted(urls-known)
def fetch(u):
 key=hashlib.sha256(u.encode()).hexdigest()[:20];rawp=out/(key+'.html');p=out/(key+'.json')
 if p.is_file():return {'url':u,'path':str(p),'length':len(json.loads(p.read_text())['text']),'reused':True}
 try:
  r=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','25','--output',str(rawp),'--write-out','%{url_effective}\n%{http_code}',u],capture_output=True,check=True);final,status=r.stdout.decode().splitlines();raw=rawp.read_bytes();h=raw.decode('utf-8');s=re.sub(r'<(script|style)\b.*?</\1\s*>','',h,flags=re.I|re.S);s=re.sub(r'<[^>]+>',' ',s);s=html.unescape(s);s=re.sub(r'\s+',' ',s).strip();p.write_text(json.dumps({'url':u,'finalUrl':final,'httpStatus':int(status),'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'textExtraction':'HTML scripts/styles removed, tags replaced by spaces, entities unescaped, whitespace collapsed; raw HTML retained.','text':s,'textSha256':hashlib.sha256(s.encode()).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest()},ensure_ascii=False,indent=2)+'\n');return {'url':u,'finalUrl':final,'path':str(p),'length':len(s)}
 except Exception as e:return {'url':u,'error':str(e)}
for r in concurrent.futures.ThreadPoolExecutor(4).map(fetch,urls):print(json.dumps(r))

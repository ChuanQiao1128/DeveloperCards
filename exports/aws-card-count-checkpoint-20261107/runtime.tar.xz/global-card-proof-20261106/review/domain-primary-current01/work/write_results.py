import collections,datetime,hashlib,json
from pathlib import Path
V=Path.cwd(); R=V/'review/domain-primary-current01'; inp=R/'input'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((inp/'manifest.json').read_text())
assert all(sha(p)==d for p,d in manifest.items())
cards=json.loads((inp/'cards.frozen.json').read_text())
jud={}
for line in (R/'work/judgments.tsv').read_text().splitlines():
 i,t,r=line.split('|',2); jud[int(i)]=(None if t=='null' else t,r)
assert set(jud)==set(range(1,len(cards)+1))
guide=json.loads((inp/'official-exam-guide-reference.json').read_text())
extraction=json.loads(Path(guide['extractionPath']).read_text()); text=extraction['text']
assert sha(guide['path'])==guide['sha256'] and sha(guide['extractionPath'])==guide['extractionSha256']
quotes={
 '1.1':('Design secure access to AWS resources', ['Designing a role-based access control strategy', 'Designing a security strategy for multiple AWS accounts', 'Determining the appropriate use of resource policies for AWS services']),
 '1.2':('Design secure workloads and applications', ['Application conﬁguration and credentials security', 'Designing VPC architectures with security components', 'Integrating AWS services to secure applications']),
 '1.3':('Determine appropriate data security controls', ['Data access and governance', 'Encryption and appropriate key management', 'Implementing policies for data access, lifecycle, and protection']),
 '2.1':('Design scalable and loosely coupled architectures', ['Event-driven architectures', 'Queuing and messaging concepts (for example, publish/subscribe)', 'Workﬂow orchestration (for example, AWS Step Functions)', 'Determining when to use serverless technologies and patterns']),
 '2.2':('Design highly available and/or fault-tolerant architectures', ['Workload visibility (for example, AWS X-Ray)', 'Determining automation strategies to ensure infrastructure integrity', 'Implementing strategies to ensure the durability and availability of data (for example, backups)']),
 '3.1':('Determine high-performing and/or scalable storage solutions', ['Hybrid storage solutions to meet business requirements', 'Storage services with appropriate use cases', 'Storage types with associated characteristics (for example, object, ﬁle, block)']),
 '3.2':('Design high-performing and elastic compute solutions', ['The orchestration of containers (for example, Amazon ECS, Amazon EKS)', 'Identifying metrics and conditions to perform scaling actions', 'Selecting the appropriate compute options and features', 'Selecting the appropriate resource type and size']),
 '3.3':('Determine high-performing database solutions', ['Data access patterns (for example, read-intensive compared with write-intensive)', 'Database capacity planning', 'Database connections and proxies', 'Designing database architectures']),
 '3.4':('Determine high-performing and/or scalable network architectures', ['Creating a network topology for various architectures', 'Selecting the appropriate load balancing strategy', 'Network connection options']),
 '3.5':('Determine high-performing data ingestion and transformation solutions', ['Designing data streaming architectures', 'Designing data transfer solutions', 'Implementing visualization strategies', 'Transforming data between formats']),
 '4.1':('Design cost-optimized storage solutions', ['Managing S3 object lifecycles', 'Selecting the appropriate storage tier', 'Selecting the most cost-eﬀective storage service for a workload']),
 '4.2':('Design cost-optimized compute solutions', ['AWS purchasing options (for example, Spot Instances, Reserved Instances, Savings Plans)', 'Selecting the appropriate instance family for a workload', 'Selecting the appropriate instance size for a workload']),
 '4.3':('Design cost-optimized database solutions', ['Designing appropriate backup and retention policies (for example, snapshot frequency)', 'Determining cost-eﬀective AWS database services with appropriate use cases']),
 '4.4':('Design cost-optimized network architectures', ['Network routing, topology, and peering', 'Reviewing existing workloads for network optimizations', 'Selecting the appropriate bandwidth allocation for a network device'])
}
refs={}
for task,(title,qs) in quotes.items():
 for q in qs: assert q in text,(task,q)
 refs['SAA-C03:'+task]={'primaryTask':task,'title':title,'verbatimExcerptFragments':qs,'sourceRef':'official-saa-c03-guide','fragmentsAreScopeEvidenceNotServiceFactProof':True}
for d,title in [('1','Design Secure Architectures'),('2','Design Resilient Architectures'),('3','Design High-Performing Architectures'),('4','Design Cost-Optimized Architectures')]:
 assert title in text
 refs['SAA-C03:D'+d]={'domain':d,'title':title,'sourceRef':'official-saa-c03-guide','use':'Domain-only navigation; no exact task asserted for rows with null primaryTask.'}
cross={
 'CUR:CA19':['1.1'],'CUR:CB13':['1.2'],'CUR:CC10':['1.3'],'CUR:CMP-M02':['3.4','4.4'],'CUR:CMP-M04':['3.4'],'CUR:CMP-M16':['2.2'],
 'CUR:CMP-M25':['3.4'],'CUR:NA03':['2.2'],'CUR:XA030':['1.2'],'CUR:XA054':['1.1'],'CUR:XB023':['3.5'],'CUR:XB045':['1.2'],
 'CUR:CB01':['3.3'],'CUR:NB05':['1.3'],'CUR:NB08':['2.1'],'CUR:CA16':['2.1'],'CUR:CB18':['2.2'],'CUR:NA02':['1.3'],
 'CUR:XA013':['1.2'],'CUR:XB020':['2.1'],'CUR:XB038':['2.1'],'CUR:XR003':['1.2'],
 'GSC-014':['2.2'],'GSC-032':['2.2'],'GSC-039':['2.2'],'GSC-048':['3.5'],'GSC-053':['2.2'],'GSC-063':['3.5'],
 'GSC-119':['2.2'],'GSC-139':['4.2'],'GSC-147':['4.2'],'GSC-043':['3.5'],'GCL-031':['2.2'],'GCL-005':['2.2'],'GCL-026':['2.1'],
 'VC-003':['3.3'],'VC-007':['4.2','4.3']
}
null_limits={
 58:'账户联系人治理可留领域1；指南14任务没有联系人分发列表这一独立任务，不强挂1.1。',
 82:'软件/配置清单可作领域1治理导航；当前未明确安全检测或可用性目标，精确task保持null。',
 83:'已从只看Versioning扩展为多类Storage Lens指标；保留领域1保护状态导航，但不能把全部指标用途等同1.3。',
 145:'按标签发现资源没有明确性能、可用性或安全目标；保留既有领域3功能导航，精确task不作确认。',
 171:'通用预算动作不局限存储、计算、数据库或网络；不为凑task指定一种资源。',
 279:'当前训练业务邮件与事件通知的投递能力差异；指南没有独立邮件任务，不强称性能或解耦目标。',
 280:'当前训练双向短信接收能力；指南没有独立短信任务，不强称性能或解耦目标。',
 319:'通用费用告警不专属任一资源成本任务，primaryTask保持null。',
 320:'通用账单工具比较横跨4.1至4.4，primaryTask保持null。',
 327:'通用成本分配标签横跨4.1至4.4，primaryTask保持null。',
 329:'通用建议权限范围横跨资源类型，RDS只是考点例子，primaryTask保持null。',
 357:'题面共同考EC2及RDS承诺付款原则，横跨4.2和4.3，不虚设唯一子任务。'
}
results=[]
for i,c in enumerate(cards,1):
 body=c['visibleBody']; bodysha=hashlib.sha256(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 assert bodysha==c['bodySha256'],c['ruleId']
 task,reason=jud[i]; domain=task[0] if task else c['proposedPrimaryDomain']; kept=domain==c['proposedPrimaryDomain']
 unchanged=body['frontZH']==c['previousDesignRecallTask']
 if not kept:
  recommendation=f"唯一主归由领域{c['proposedPrimaryDomain']}调整为领域{domain}，primaryTask记为{task}；可保留其他领域交叉导航，不复制卡片。"
 elif task is None: recommendation=null_limits[i]
 else: recommendation=None
 results.append({
  'ruleId':c['ruleId'],'bodySha256':bodysha,'acceptedPrimaryDomain':domain,'primaryTask':task,
  'primaryReason':reason,'originalPrimaryDomain':c['proposedPrimaryDomain'],'originalPrimaryDomainRetained':kept,
  'suggestedCorrection':recommendation,'crossDomainTasks':cross.get(c['ruleId'],[]),
  'officialGuideBasisRefs':['SAA-C03:'+task] if task else ['SAA-C03:D'+domain],
  'classificationStatus':'REASSIGN_PRIMARY' if not kept else ('DOMAIN_ONLY_TASK_NOT_UNIQUELY_ASSERTED' if task is None else 'KEEP_PRIMARY'),
  'reviewMode':'CURRENT_TASK_RECLASSIFICATION' if not kept else ('PRIOR_INDEPENDENT_DOMAIN_REUSED_WITH_CURRENT_FRONT_ANSWER_CHECK' if unchanged else 'CURRENT_REWRITTEN_FRONT_ANSWER_TASK_CHECK'),
  'frontExactlyMatchesPreviousDesignTask':unchanged,
  'lexicalDifferenceIsNotClaimOfChangedRecallAxis':True
 })
counts=collections.Counter(r['acceptedPrimaryDomain'] for r in results)
changes=[r['ruleId'] for r in results if not r['originalPrimaryDomainRetained']]
meta={
 'schema':'current-visible-card-primary-domain-independent-review-v1',
 'reviewer':'/root/domain_primary_audit','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'COMPLETE_WITH_RECLASSIFICATION_RECOMMENDATIONS_AND_TASK_LIMITS',
 'scope':'unique_primary_domain_of_actual_visible_chinese_cards_only',
 'poolStatus':'358 frozen current candidate cards; neither final package size nor final N accepted by this review.',
 'independence':{'authoringPerformed':False,'sourceQuestionsUsedForDomainVoting':False,'awsServiceFactsReaudited':False,'questionSupportReaudited':False,'externalModelCliApiCalls':0,'subagentsSpawned':0,'nativeUsage':'unknown'},
 'inputManifest':{'path':str((inp/'manifest.json').resolve()),'sha256':sha(inp/'manifest.json'),'allBindingsVerified':True},
 'officialGuide':{'sourceId':'official-saa-c03-guide','url':extraction['url'],**guide},
 'officialGuideTaskReferences':refs,
 'decisionRules':[
  'One acceptedPrimaryDomain per ruleId; crossDomainTasks are navigation only, never copies or extra cards.',
  'Decide from the learner-visible principal judgment in the current front and answer; use key point for ambiguous or rewritten scope. Service names and question-majority/domain labels are not votes.',
  'Use 2.1 for event-driven routing, messaging contracts, fanout and loosely coupled composition when those are the principal recall task; use 3.2/3.3/3.5 when actual compute, database or stream performance/capacity is the principal task.',
  'Use 2.2 for operational visibility, repeatable infrastructure automation and recovery/reliability tasks explicitly in the guide; a service also being listed elsewhere does not determine the domain.',
  'Where current ordinary function/governance cards do not uniquely imply one of the 14 guide tasks, keep domain navigation with primaryTask=null and record its limit; do not invent precise guide alignment.',
  'Reuse old independently reviewed domain classification only after checking the current task; identical or different wording alone is not proof of an identical or changed axis.',
  'Changes to an unchanged old task are taxonomy corrections recommended by this reviewer, not evidence that the author changed the task.'
 ],
 'coverage':{'frozenRows':len(cards),'uniqueRuleIds':len({r['ruleId'] for r in results}),'resultRows':len(results),'frontExactlySameAsOldTask':sum(r['frontExactlyMatchesPreviousDesignTask'] for r in results),'frontWordingDifferentFromOldTask':sum(not r['frontExactlyMatchesPreviousDesignTask'] for r in results),'retainedPrimaryDomain':sum(r['originalPrimaryDomainRetained'] for r in results),'primaryDomainAdjustmentRecommendations':len(changes),'exactPrimaryTaskAssigned':sum(r['primaryTask'] is not None for r in results),'domainOnlyPrimaryTaskNull':sum(r['primaryTask'] is None for r in results),'candidatePrimaryDomainCounts':dict(sorted(counts.items()))},
 'changedRuleIds':changes,'results':results,
 'limits':[
  'This is classification review only. It does not accept AWS facts, teaching quality, original-question support, learner performance, minimality, final N, release or publication.',
  'The prior independent review is a permitted reference, not an immutable taxonomy: current-task corrections are explicitly listed.',
  '358 is the input candidate pool, which may later lose cards or receive body changes. Each result is valid only for its bound current bodySha256.',
  'Null exact tasks are an explicit mapping limit; domain-only rows must not be counted as exact 14-task coverage.'
 ]
}
meta['resultsSha256Canonical']=hashlib.sha256(json.dumps(results,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
(R/'results.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
# One-line-per-card readable readback.
out=['# 当前可见卡片唯一主归独立核对','',f"冻结候选池：{len(cards)}条。保留主归330条，建议调整28条；346条定位精确任务，12条仅保留领域导航并记录任务边界。以上不是最终卡数或正式内容接受。",'',
 '依据：AWS官方SAA-C03考试指南（本目录results.json绑定PDF/提取文本及共享任务原句）；按实际主回忆任务判断，未读原题主归投票。', '',
 '| ruleId | 当前正文 SHA-256 | 主归 | 主任务 | 保留原主归 | 主归理由 | 修正或限制 |', '|---|---|---|---|---|---|---|']
for r in results:
 out.append('| '+' | '.join([r['ruleId'],r['bodySha256'],'D'+r['acceptedPrimaryDomain'],r['primaryTask'] or '未唯一确认','是' if r['originalPrimaryDomainRetained'] else '否',r['primaryReason'],r['suggestedCorrection'] or '无需主归修正'])+' |')
(R/'readback.md').write_text('\n'.join(out)+'\n')
# Independent mechanical reconstruction from outputs and original frozen bindings.
roundtrip=json.loads((R/'results.json').read_text()); rr=roundtrip['results']; byid={x['ruleId']:x for x in cards}
checks={
 'allInputManifestHashesStillMatch':all(sha(p)==d for p,d in manifest.items()),
 'resultRowsEqualFrozenRows':len(rr)==len(cards),
 'ruleIdSetExact':set(byid)=={r['ruleId'] for r in rr},
 'ruleIdsUnique':len({r['ruleId'] for r in rr})==len(rr),
 'allCurrentBodyHashesMatch':all(r['bodySha256']==byid[r['ruleId']]['bodySha256'] for r in rr),
 'exactlyOneDomainPerRow':all(isinstance(r['acceptedPrimaryDomain'],str) and r['acceptedPrimaryDomain'] in {'1','2','3','4'} for r in rr),
 'primaryTaskConsistentWithDomain':all(r['primaryTask'] is None or r['primaryTask'][0]==r['acceptedPrimaryDomain'] for r in rr),
 'originalDomainRetainedFlagCorrect':all(r['originalPrimaryDomainRetained']==(r['acceptedPrimaryDomain']==r['originalPrimaryDomain']) for r in rr),
 'allTaskRefsResolvable':all(ref in refs for r in rr for ref in r['officialGuideBasisRefs']),
 'allCrossTasksValid':all('SAA-C03:'+t in refs for r in rr for t in r['crossDomainTasks']),
 'allChangesHaveConcreteSuggestion':all(r['suggestedCorrection'] for r in rr if not r['originalPrimaryDomainRetained']),
 'nullTaskLimitsExplicit':all(r['suggestedCorrection'] and r['classificationStatus']=='DOMAIN_ONLY_TASK_NOT_UNIQUELY_ASSERTED' for r in rr if r['primaryTask'] is None),
 'perCardMarkdownReadbackRows':sum(line.startswith('| ') for line in (R/'readback.md').read_text().splitlines())==len(cards)+1
}
assert all(checks.values()),checks
readback={'schema':'current-primary-domain-review-mechanical-readback-v1','reviewer':'/root/domain_primary_audit','status':'PASS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resultsPath':str((R/'results.json').resolve()),'resultsFileSha256':sha(R/'results.json'),'readableReadbackPath':str((R/'readback.md').resolve()),'readableReadbackSha256':sha(R/'readback.md'),'checks':checks,'coverage':roundtrip['coverage'],'notFinalN':True,'productionCatalogueOrCurrentPointerModified':False,'externalModelCliApiCalls':0,'nativeUsage':'unknown'}
(R/'readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':readback['status'],'coverage':roundtrip['coverage'],'outputs':['results.json','readback.json','readback.md'],'resultsSha256':sha(R/'results.json')},ensure_ascii=False,indent=2))

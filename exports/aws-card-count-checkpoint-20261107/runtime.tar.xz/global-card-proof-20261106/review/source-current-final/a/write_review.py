# -*- coding: utf-8 -*-
import pathlib,json,hashlib,datetime,collections
D=pathlib.Path(__file__).resolve().parent;V=D.parents[2];I=D.parent/'input'
sha=lambda b:hashlib.sha256(b).hexdigest()
Q={x['qid']:x for x in json.loads((I/'cases1.json').read_text())};C={x['ruleId']:x for x in json.loads((I/'core-visible.frozen.json').read_text())}
def write(part,specs):
 out=[]
 for q,status,opts,ids,reason,missing,conditions,impl,facts,correction in specs:
  init=[x['ruleId'] for x in Q[q]['visibleCards']]
  out.append(dict(qid=q,status=status,selectedOptionOrdinals=opts if status=='SUPPORTED' else [],candidateOptionOrdinals=opts if status!='SUPPORTED' else [],usedRuleIds=ids,reasoningAndClosestCompetitor=reason,missingJudgments=missing,conditions=conditions,implementationChecks=impl,officialFactKeys=facts,correctionProposal=correction,originalQuestionSha256=sha(json.dumps(Q[q]['originalQuestion'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),initialRuleIds=init,necessaryAnchors=[dict(ruleId=k,field=f,quote=C[k]['visibleBody'][f],bodySha256=C[k]['bodySha256'],additionalToInitialGroup=k not in init) for k in ids for f in ('frontZH','answerZH','keyPointZH','watchOutZH') if C[k]['visibleBody'].get(f)]))
 p=D/f'results-part{part:02}.json';p.write_text(json.dumps(dict(schemaVersion=1,reviewer='actual_gap_review',manifestPath=str(I/'manifest1.json'),manifestSha256=sha((I/'manifest1.json').read_bytes()),reviewedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),counts=dict(collections.Counter(x['status'] for x in out)),results=out),ensure_ascii=False,indent=2)+'\n');print(p,len(out))

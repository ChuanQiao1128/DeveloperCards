# -*- coding: utf-8 -*-
import pathlib,json,hashlib,collections,datetime,re
D=pathlib.Path(__file__).resolve().parent;I=D.parent/'input';V=D.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
read=lambda p:json.loads(pathlib.Path(p).read_text())
def save(n,x):
 p=D/n;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return p
manifest=read(I/'manifest1.json');qs=read(I/'cases1.json');cs=read(I/'core-visible.frozen.json');Q={x['qid']:x for x in qs};C={x['ruleId']:x for x in cs};ev=read(D/'official-evidence.json');facts=ev['facts']
parts=[read(D/('results-part%02d.json'%n)) for n in (1,2,3)];rows=sum([x['results'] for x in parts],[])
assert len(rows)==len(Q)==33 and len(C)==351
assert len(set(x['qid'] for x in rows))==33
assert {x['qid'] for x in rows}==set(Q)
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,p
assert sha((I/'manifest1.json').read_bytes())==read(D/'input-binding.json')['manifestSha256']
for c in cs:assert sha(canon(c['visibleBody']))==c['bodySha256'],c['ruleId']
omitted={'CUR:XB039','GSC-019','GCL-017','GSC-072','GSC-098','GSC-108','GSC-084'}
assert not omitted&set(C)

def closure(ids):
 out=[];vis=set()
 def visit(k,active):
  assert k in C,k
  assert k not in active,('cycle',k)
  if k in vis:return
  vis.add(k);out.append(k)
  for p in C[k]['prerequisiteRuleIds']:visit(p,active|{k})
 for k in ids:visit(k,set())
 return out
for row in rows:
 q=Q[row['qid']];assert row['originalQuestionSha256']==sha(canon(q['originalQuestion']))
 assert set(row['officialFactKeys'])<=set(facts)
 assert row['manifestSha256']==sha((I/'manifest1.json').read_bytes()) if 'manifestSha256' in row else True
 for a in row['necessaryAnchors']:
  c=C[a['ruleId']];assert a['quote']==c['visibleBody'][a['field']];assert a['bodySha256']==c['bodySha256']
 ids=closure(row['usedRuleIds']);assert not omitted&set(ids)
 row['prerequisiteClosureRuleIds']=ids
 row['prerequisiteOnlyRuleIds']=[k for k in ids if k not in row['usedRuleIds']]
 row['learnerVisibleGroup']=[dict(ruleId=k,visibleBody=C[k]['visibleBody'],bodySha256=C[k]['bodySha256'],prerequisiteRuleIds=C[k]['prerequisiteRuleIds']) for k in ids]
 row['officialFactReferences']=[dict(key=k,url=facts[k]['url'],registryPath=str(D/'official-evidence.json')) for k in row['officialFactKeys']]
 row['reviewScope']='Full original stem and every original option, using only the frozen current 351-card provisional pool and its current visible prerequisite closure.'
 row['variantSupportUpgradesOriginal']=False
 if row['status']=='SUPPORTED':assert row['selectedOptionOrdinals'] and not row['missingJudgments']
 else:assert not row['selectedOptionOrdinals']

checked=0
for k,x in facts.items():
 for y in [x]+x.get('supportingQuotes',[]):
  p=pathlib.Path(y['snapshotPath']);d=read(p);t=d['text'];assert sha(p.read_bytes())==y['snapshotSha256'],k
  assert sha(t.encode())==y['textSha256'],k
  assert t[y['quoteStart']:y['quoteEnd']]==y['quote'],k
  u=y['url'];assert re.match(r'https://(?:docs\.)?aws\.amazon\.com/',u),u
  checked+=1
assert set(k for row in rows for k in row['officialFactKeys'])==set(facts)
counts=dict(collections.Counter(x['status'] for x in rows));now=datetime.datetime.now(datetime.timezone.utc).isoformat()
base=dict(schemaVersion=1,reviewer='actual_gap_review',completedAtUtc=now,manifestPath=str(I/'manifest1.json'),manifestSha256=sha((I/'manifest1.json').read_bytes()),provisionalCorePoolCount=351,globalFinalCardCount=None,originalQuestionCount=33,counts=counts,externalModelCliApiCalls=0,nativeUsage='unknown',officialEvidencePath=str(D/'official-evidence.json'),noPublicationOrCardMutation=True)
save('results.json',dict(base,results=sorted(rows,key=lambda x:x['qid']),limits=['351 is a provisional frozen pool, not verified final N.','SUPPORTED is design-level current-card support, not measured learner performance.','Official evidence is review evidence, not extra learner-visible teaching.','Corrected exercise proposals are untested and do not upgrade originals.']))
source=[]
for r in rows:
 if r['status']=='SOURCE_ISSUE':source.append(dict(qid=r['qid'],originalQuestion=Q[r['qid']]['originalQuestion'],originalQuestionSha256=r['originalQuestionSha256'],originalStatus='SOURCE_ISSUE',finding=r['reasoningAndClosestCompetitor'],officialFactKeys=r['officialFactKeys'],proposal=r['correctionProposal'],proposalState='PROPOSED_UNTESTED_NEW_EXERCISE',correctedQuestion=None,requires=['Separately freeze exact minimally changed new exercise.','Retain complete original and all options unchanged.','Independent verification against actual current visible cards.'],originalNeverUpgradedByVariant=True,knowledgeObligationRetained=True))
save('source-findings.json',dict(base,confirmedOriginalSourceIssueCount=len(source),findings=source))
requests=[]
for r in rows:
 if r['status']=='INSUFFICIENT_CARDS':requests.append(dict(qid=r['qid'],necessaryJudgments=r['missingJudgments'],candidateOptionOrdinals=r['candidateOptionOrdinals'],currentRuleIds=r['usedRuleIds'],officialFactKeys=r['officialFactKeys'],disposition='MINIMAL_KNOWLEDGE_REQUEST_NOT_CARD_COUNT',requestCountDoesNotImplyNewCardCount=True,conditions=r['conditions']))
save('minimal-requests.json',dict(schemaVersion=1,requests=requests,requestCount=len(requests),newCardsRequired=None,globalFinalCardCount=None,limits=['Search for genuine shared-rule transfer/revision before deciding on new cards.','Q100 service-specific HA remains evidence-needed; do not treat general AWS AZ wording as a verified Secrets Manager HA guarantee.','Q201 retains the one-year response archive obligation; two-way SMS facts alone do not close it.']))
unknowns=[dict(qid=r['qid'],status=r['status'],candidateOptionOrdinals=r['candidateOptionOrdinals'],conditions=r['conditions'],reasoning=r['reasoningAndClosestCompetitor'],officialFactKeys=r['officialFactKeys'],notExempted=True) for r in rows if r['status']=='UNKNOWN']
save('unknown-register.json',dict(schemaVersion=1,questions=unknowns,count=len(unknowns),notSourceExemptions=True))
allused=set(k for r in rows for k in r['usedRuleIds']);allclosure=set(k for r in rows for k in r['prerequisiteClosureRuleIds'])
checks=dict(schemaVersion=1,status='PASS',scope='Deterministic artifact bindings only; not an additional semantic pass.',checkedAtUtc=now,inputManifestBindings=len(manifest),originalQuestionsUnchanged=33,allOriginalOptionsRetained=33,coreCardsFrozenAndHashMatched=len(C),usedCurrentCards=len(allused),currentCardsIncludingPrerequisiteClosure=len(allclosure),missingPrerequisites=0,omittedSevenBorrowed=0,officialFactKeys=len(facts),officialQuotesChecked=checked,exactExcerptOffsetAndSnapshotHashes='PASS',allResultEvidenceKeysBound=True,sourceIssueOriginalsNotUpgraded=len(source),untestedCorrectionProposals=len(source),globalFinalCardCount=None,externalModelCliApiCalls=0,nativeUsage='unknown')
save('readback.json',checks)
outputs=['results.json','official-evidence.json','source-findings.json','minimal-requests.json','unknown-register.json','readback.json']
save('output-manifest.json',dict(schemaVersion=1,completedAtUtc=now,inputManifestPath=str(I/'manifest1.json'),inputManifestSha256=sha((I/'manifest1.json').read_bytes()),files={str(D/n):sha((D/n).read_bytes()) for n in outputs},counts=counts,externalModelCliApiCalls=0,nativeUsage='unknown',globalFinalCardCount=None))
print(json.dumps(dict(counts=counts,readback=checks),ensure_ascii=False,indent=2))

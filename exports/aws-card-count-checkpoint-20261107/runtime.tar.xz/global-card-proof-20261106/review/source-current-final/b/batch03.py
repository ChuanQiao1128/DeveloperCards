from review_lib import *
priv=ev('private-link','services and resources in other VPCs using private IP addresses,','PrivateLink的私有IP服务连接')
visibility=ev('sqs-visibility',"If you don't delete it before\nthe timeout expires, the message becomes visible again in the queue",'FIFO消费者处理后未确认也可再次出现，不等于业务一次')
ipsec=ev('vpn-network','Site-to-Site VPN supports Internet Protocol security (IPsec) VPN connections.','VPN提供IPsec网络隧道，不自动配置各应用TLS')
linux=ev('app2-linux','ASP.NET applications (Windows, Linux)','当前App2Container确实支持Linux ASP.NET，否定旧平台不支持疑点')
linuxruntime=ev('app2-linux','For ASP.NET applications running on Linux, App2Container detects the .NET runtime\nversion','Linux .NET需匹配支持运行时')
qualified=ev('app2-linux','no longer open to new customers.','App2Container有既有客户资格限制，不是整体退役')
ecsmetric=ev('ecs-autoscale','You can use these and other CloudWatch metrics to\nscale out your service (add more tasks)','ECS Service Auto Scaling确实可按CloudWatch指标伸缩')
rdscert=ev('rds-tls','manages the DB server certificate on the database. RDS rotates the DB server\ncertificate automatically before it expires.','RDS管理数据库服务器证书')
proxycert=ev('rds-tls','certificates from the AWS Certificate Manager (ACM).','RDS Proxy另有ACM证书路径，不能泛称ACM不能用于任何数据库相关传输')
roles=ev('rolesanywhere','obtain temporary security credentials in\nIAM for workloads','Roles Anywhere获得的是IAM角色临时凭据')
gateway=ev('s3-endpoint','Amazon S3 public IP addresses, which\nroutes traffic to the gateway endpoint.','gateway路径保留S3公有地址，但路由经过gateway endpoint')
route=ev('gateway-route','Gateway VPC endpoints provide reliable connectivity to Amazon S3 and DynamoDB without requiring an\ninternet gateway or a NAT device','gateway endpoint确实绕过IGW/NAT')
globalboth=ev('global-tables','For global tables using provisioned mode, auto scaling settings for both read and write capacities\nare synchronized between replicas.','global tables支持预置配自动伸缩')
globaldemand=ev('global-tables','For global tables configured for on-demand mode, write capacity is automatically synchronized\nacross all replicas.','global tables也支持按需')
cfkey=ev('cache-optimized','Headers included in the cache key: None\nare explicitly included.','CachingOptimized不区分任意业务请求头')
cfttl=ev('cache-optimized','Minimum TTL: 1 second.','CachingOptimized有正最小TTL')
ga=ev('ga-endpoints','Amazon EC2 instances, or Elastic IP addresses.','GA支持EC2/EIP API后端')
asg=ev('asg-spot','In your launch template, you can optionally request Spot Instances with no end\ndate or duration.','ASG的文档化Spot选择是实例购买方式')
fleet=ev('spot-request','If you want to include On-Demand Instances in your fleet, you must specify a launch template in\nyour request','Spot Fleet请求引用launch template，而不是在ASG模板内启动Fleet')
http=ev('http-iam',"Resource policies aren't currently supported for HTTP APIs.",'HTTP API原选项B不支持资源策略')
authorizer=ev('http-auth','You use a Lambda authorizer to use a Lambda function to control access to your\nHTTP API.','保留HTTP API目标的可行纠错机制')
idempotence=[
 ('GSC-082','用稳定的业务ID做幂等检查，让已完成的同一笔操作返回已有结果，而非再次扣款。','稳定业务ID幂等'),
 ('GSC-082','检查和执行必须避免并发竞态；','并发安全执行门禁')]

add(949,'SOURCE_ISSUE',[4],[
 ('CUR:CMP-M04','供应商自建TCP服务，供应商先在服务前配置NLB并发布endpoint service，客户再建interface endpoint连接它。','D的消费端/发布端服务连接')],
 [priv],
 'D是私有访问供应商服务的有证路径，但C在原PDF本身以establish.结束，缺少宾语。不同补尾可能与D同时成立；不能猜补inbound connections再把C判假或忽略C后宣布唯一答案。',
 {'1':'VPN不自动形成题目供应商私有服务发布，且需要供应商配合完整VPN配置。','2':'TGW是VPC路由枢纽，未给供应商接入及路由。','3':'原文残句，含义不能可靠判定。','4':'PrivateLink私有服务连接方向正确。'},
 source={'status':'CONFIRMED_ORIGINAL_PDF_DEFECT','reason':'独立双引擎整页转录及整页视觉回读已确认C原文缺词，不是规范化漏字。'},
 proposal={'target':'option C only','text':"C. Create an Amazon S3 gateway VPC endpoint in the application's VPC and use it to call the third-party SaaS API.",
  'kind':'replace malformed distractor; do not claim recovery of missing original words','preserves':'原题第三方SaaS私网连接目标与原干/A/B/D','notTested':True})
receipt_path=pathlib.Path(by[949]['q949TranscriptReviewPath']);receipt=json.loads(receipt_path.read_text())
assert receipt['status']=='CONFIRMED_ORIGINAL_PDF_OPTION_C_TRUNCATED'
assert receipt['normalizedOptionC']==by[949]['originalQuestion']['options'][2]['text']
for extraction in receipt['independentExtractionChecks']:
 p=pathlib.Path(extraction['pageTextPath']);assert sha(p.read_bytes())==extraction['pageTextFileSha256']
 assert p.read_text()[extraction['startChar']:extraction['endChar']]==extraction['exactRawOptionC']
vp=pathlib.Path(receipt['visualEvidence']['fullPagePngPath']);assert sha(vp.read_bytes())==receipt['visualEvidence']['fullPagePngSha256']
rows[-1]['sourceDisposition']['transcriptProof']={'path':str(receipt_path),'sha256':sha(receipt_path.read_bytes()),
 'originalPdfSha256':receipt['originalPdfSha256'],'pdfPageOneBased':1868,
 'twoIndependentFullPageTranscriptsHashVerified':True,'fullPageImageHashVerified':True,
 'visualReviewReusedFromIndependentReceiptNotClaimedAsNew':True}

add(950,'SOURCE_ISSUE',[],[
 ('CUR:CMP-M11','网络层IPsec也不会自动替应用连接启用TLS。','VPN与会话/应用连接加密不同'),
 ('CUR:CMP-M10','在接收端只放行实际上一跳和目标服务端口；支持引用时用上一跳的安全组。','限制真实来源及服务端口'),
 ('CUR:CB15','安全组有状态，记住连接；NACL逐方向检查。','网络限制控制')],
 [ipsec],
 'C提供IPsec网络层隧道及SG/NACL，但原题明确同时要求network layer和session layer加密。网络VPN不自动为实际应用会话建立TLS。其他项也未给两层加密加网络访问限制，不能删掉session layer条件后通过C。',
 {'1':'DX不自动加密，路由也不是Allow/Deny安全规则。','2':'控制台IAM来源限制不实现网络与会话加密。','3':'网络加密和访问控制方向正确，但没有会话TLS。','4':'TGW路由不自动加密两层。'},
 source={'status':'CONFIRMED_MISSING_EXPLICIT_ENCRYPTION_LAYER','reason':'IPsec与TLS职责有明确正证，原选项未建立题面要求的会话加密。'},
 proposal={'target':'option C','text':'保留Site-to-Site VPN、路由、SG/NACL；同时在实际客户端—服务端连接启用适用TLS并验证服务端证书。','preserves':'网络与会话两层加密及受限访问','notTested':True})
add(967,'SOURCE_ISSUE',[1],idempotence, [visibility],
 'FIFO持久保存并减少发送重复，但消费者完成业务后在删除确认前失败，消息可在可见性超时后重现。仅队列选型不使表单副作用恰好一次；原A没有并发安全幂等，其他项也没有完整的持久存取和业务一次保障。',
 {'1':'最强队列候选，仍缺业务幂等执行协议。','2':'HTTP API不是持久工作队列。','3':'Standard允许重复，仍需幂等。','4':'同步工作流描述本身没有外部业务效果一次和失败恢复协议。'},
 source={'status':'CONFIRMED_BUSINESS_EXACTLY_ONCE_NOT_ESTABLISHED','reason':'官方可见性超时后重投说明FIFO不是业务副作用恰好一次。'},
 proposal={'target':'option A','text':'使用SQS FIFO，并在worker以稳定form ID实现持久、原子的幂等检查与结果记录；成功后确认消息，重复投递复用已有结果。','preserves':'不丢工作且每个表单只产生一次业务效果','notTested':True})
add(969,'INSUFFICIENT_CARDS',[1],[
 ('GCL-032','App2Container分析、容器化并生成适用部署工件；ECS/EKS承担容器的实际编排运行。','打包工具与运行平台分工'),
 ('GCL-032','App2Container不再向新客户开放；既有资格也不表示任意程序都能自动改成微服务。','资格与运行环境必须核对'),
 ('CUR:XB019','少维护宿主机可选Fargate；','减少主机运维'),
 ('GSC-137','服务伸缩增加任务副本需求，底层容量伸缩提供实际CPU、内存等资源，任务数量不会自动创造主机容量。','服务需求与主机容量不同')],
 [linux,linuxruntime,qualified,ecsmetric],
 'A在已有App2Container资格且具体.NET运行时受支持时是最少宿主机维护方向。现行官方明确支持Linux ASP.NET，不能把旧兼容疑点升成SOURCE_ISSUE。当前核心卡只教工件/运行和ECS容量两层，未教用ECS Service Auto Scaling把CloudWatch负载指标连接到task count；题目明确要求这一步。',
 {'1':'适用环境中可行方向，但卡面缺CloudWatch→ECS服务任务数的实际伸缩机制。','2':'增加EC2系统/容量维护。','3':'App Runner不是把应用交由客户ECS/Fargate部署的容器化工具。','4':'同样混淆App Runner和EKS运行。'},
 source={'status':'NO_CONFIRMED_LINUX_COMPATIBILITY_ERROR','reason':'官方Linux ASP.NET支持正证否定旧疑点；保留资格和具体版本前提。'},
 gaps=['ECS Service Auto Scaling使用CloudWatch指标增减服务任务副本的必要判断未在当前核心卡面教出。'],
 conditions=['不将新客户限制泛化为所有客户不可用；不自动假定当前公司已有资格或指定.NET版本。'])
add(977,'UNKNOWN',[1],[
 ('CUR:CC08','新建库启用KMS静态加密。','RDS静态加密'),
 ('CUR:CMP-M11','仍须启用数据库客户端TLS，并使用AWS提供的RDS CA证书包验证服务端证书。','真实数据库连接TLS与服务端验证')],
 [rdscert,proxycert],
 '已教的低维护数据库路径是KMS静态加密加客户端TLS/RDS CA验证。A只写配置ACM证书，没有写证书终止在哪个实际连接：不能把它自动当成可更换原生RDS服务器证书，也不能声称ACM绝不用于数据库相关连接，因为RDS Proxy确实用ACM。原文未给Proxy/其他TLS入口，无法独立完成唯一选项的当前事实绑定。',
 {'1':'最接近静态加TLS方向，但ACM目标与数据库连接的具体动作不清。','2':'IPsec网络隧道未建立端到端数据库TLS，且增加维护。','3':'另加应用级加密并没有解决证书目标缺失，维护也更重。','4':'私网VPN不自动启用实际SQL客户端TLS。'},
 source={'status':'UNKNOWN_CERTIFICATE_TERMINATION_TARGET','reason':'证书服务的正证指出原生RDS与Proxy两条路径不同；没有用搜索缺失证明不支持。'},
 conditions=['不将ACM三个字机械替换成RDS CA后冒称原题通过；未给出已确证错误的纠错提案。'])
rid='CUR:aws-rb2-domain1-normal-batch06-20261105-roles-anywhere-workload-identity'
add(982,'SOURCE_ISSUE',[],[
 (rid,'使用IAM Roles Anywhere，让应用用证书验证身份，换取有相应S3权限的IAM角色临时凭据。','机房工作负载证书换角色凭据'),
 (rid,'已有Identity Center供员工登录，不等于机房应用已经获得这种机器身份。','机器身份与员工登录不同'),
 ('CUR:CA10','用IAM Identity Center管理人员和团队组，为组分配permission set及目标账户，并接入既有身份源。','Identity Center的人员用途')],
 [roles],
 'B把Roles Anywhere获得的IAM角色临时凭据写成in IAM Identity Center，混淆机器证书认证与员工身份中心。A只按公网来源允许而不建立应用临时身份；C/D仍为IAM用户长期密钥。四项没有准确写出所需外部工作负载临时角色认证。',
 {'1':'来源CIDR不是应用临时凭据机制。','2':'Roles Anywhere方向正确，凭据所属服务错误。','3':'长期用户密钥。','4':'把长期用户密钥存Secrets Manager没有变成临时角色身份。'},
 source={'status':'CONFIRMED_CREDENTIAL_AUTHORITY_MISMATCH','reason':'官方明确Roles Anywhere取得IAM工作负载临时凭据，非Identity Center中的凭据。'},
 proposal={'target':'option B phrase only','text':'将“obtain security credentials in IAM Identity Center”改为“use a trusted X.509 workload certificate to obtain temporary IAM role credentials through IAM Roles Anywhere”。','preserves':'机房应用安全取得临时S3权限，不改变原工作负载目标','notTested':True})
add(998,'CONDITIONAL',[1],[
 ('CUR:CMP-M02','本VPC可用对应服务的gateway endpoint，关联实际调用子网的路由表；','A的gateway路由'),
 ('CUR:CMP-M02','gateway按本VPC路由接走服务流量，没有额外端点费，仍使用服务公有地址；','不经互联网路径与私有地址不是同一概念')],
 [gateway,route],
 'A明确能把S3流量从IGW/NAT改走gateway endpoint；AWS也把gateway endpoint路径与public service endpoint经IGW路径作比较。但S3 DNS仍解析服务公有地址。若题目public endpoint意为公有互联网承载，A可答；若要求私有IP/interface端点，A不满足。原文没有private IP字样，不能强行用后一解释确证源错，也不能偷偷把原文改为no internet。',
 {'1':'私有路由路径有效，但保留S3公有地址。','2':'桶不是能搬入客户子网的资源。','3':'Access Point本身是命名授权入口，不自动建私有路由/网卡端点。','4':'DX连接路径也不自动变成S3私有地址端点。'},
 source={'status':'UNKNOWN_PUBLIC_ENDPOINT_MEANING','reason':'保留公有地址不等于流量必经公网；官方正证支持私网gateway路径，原要求有术语歧义。'},
 conditions=['未把public endpoint自动等同private-IP要求；未将A无条件升为充分。'])
add(1002,'UNKNOWN',[1,4],[
 ('GSC-039','global tables管理跨Region复制，应用可以访问所在Region的副本，减少每次回到单一Region。','托管多Region复制'),
 ('GSC-038','难预测的负载考虑on-demand；稳定且可规划时比较provisioned配合自动伸缩。','容量模式按负载选择')],
 [globalboth,globaldemand],
 'A可先在一Region创建再用global tables增加其他Region副本；D也使用受支持的global tables配预置自动伸缩。growing user base不等于不可预测尖峰或长期稳定高利用；题面没有请求曲线/利用率/读写比例，不能独立确认两种模式哪个most cost-effective。',
 {'1':'起始单Region再增加副本不自相矛盾；按需受支持。','2':'手工复制增加管理且DAX不是跨Region数据一致性方案。','3':'自建Streams复制不如已给global tables直接满足托管复制。','4':'预置自动伸缩同样受支持，成本取决于利用率。'},
 source={'status':'UNKNOWN_COST_WORKLOAD_PROFILE','reason':'两种容量模式均有官方支持正证；缺负载数据，不把growing改成unpredictable。'},
 conditions=['不擅自补“稳定高利用”或“经常归零突增”来制造唯一答案。'])
add(1004,'UNKNOWN',[2,3],[
 ('CUR:CA13','边缘位置就近承接连接，适用内容可从缓存返回，未命中或动态请求再到源站，减少远距离访问的影响。','CloudFront也可加速HTTP'),
 ('CUR:NS02','Global Accelerator让TCP/UDP流量从附近AWS边缘进入全球网络，再按网络性能与健康状态选择适用区域端点。','GA优化非缓存连接路径'),
 ('GSC-130','键必须区分实际内容变体。','缓存键须匹配API数据变体')],
 [cfkey,cfttl,ga],
 'B/C均有改善国际访问的合理路径。CachingOptimized具有最小TTL且不区分任意业务请求头/查询参数，能否用于该ERP API取决于缓存性、身份/参数变化和时效；C支持EC2/EIP且不依赖HTTP缓存。原题没有流量、可缓存响应比例、正确性条件或费用档，不能以评审假定API必定不可缓存或可缓存来证明most cost-effective。',
 {'1':'每客户DX涉及新连接及网关/VIF路径，题面不提供适用条件。','2':'可能可行，但不能假定ERP所有响应可共用优化缓存键。','3':'可改善全球路径；没有成本负载数据仍不能证明最便宜。','4':'VPN不是专线，未给路径提升与成本证据。'},
 source={'status':'UNKNOWN_CACHEABILITY_AND_COST','reason':'存在已证不同加速机制，缺决定性业务条件；不把缺少测试等同不支持。'})
add(1008,'SOURCE_ISSUE',[4],[
 ('GSC-112','上下限限定允许的容量范围，目标追踪才根据选定负载指标调整desired capacity。','真正动态伸缩策略'),
 ('GSC-146','Spot价格优惠伴随容量被回收的风险，是否能重做或续跑决定适用性，不能只看工作负载运行多久。','已给无状态高恢复应用适合比较Spot')],
 [asg,fleet],
 'D是动态水平伸缩和Spot降费的方向，但把Spot Fleet作为ASG launch template中的承载对象，混合了独立容量控制器。官方给出的ASG做法是在launch template请求Spot实例（或ASG混合实例策略）；Spot Fleet则是自己引用launch template的请求。A/B固定两实例不实现随负载持续伸缩，C停机改规格不seamless。原D需明确修正对象关系及实际动态策略。',
 {'1':'固定增加到两台。','2':'同样固定两台，DNS权重不提供容量策略。','3':'停止实例再垂直改型会中断单实例服务。','4':'ASG和Spot Fleet对象关系写反/混合，且须配置实际动态伸缩策略。'},
 source={'status':'CONFIRMED_CAPACITY_CONTROLLER_MIXUP','reason':'官方分别定义ASG请求Spot实例与Spot Fleet请求引用launch template的模型；不是以未检索到能力当负证。'},
 proposal={'target':'option D','text':'用AMI建立launch template并在其中请求Spot Instances，创建使用该模板的ASG、配置适用CloudWatch目标追踪策略并关联ALB目标组；为Spot回收保留恢复/重试能力。','preserves':'无状态高恢复应用随负载动态扩缩并降费','notTested':True})
add(1019,'SOURCE_ISSUE',[],[
 ('CUR:XA053','不能；先确认产品支持必需能力，不能把REST API的资源策略配置直接套到HTTP API。','产品能力边界'),
 ('CUR:XB020','VPC link解决API Gateway到私网后端这一段；interface endpoint解决客户端到private API这一段，方向和被连接对象不同。','private integration不限制客户端来源')],
 [http,authorizer],
 '按AWS产品HTTP API理解，B的resource policy明确不支持。A只配置到后端的private integration不限制谁能调用入口；C/D也不是HTTP API可直接放入子网并挂SG的入口模型。原选项没有所需IP来源门禁。',
 {'1':'控制后端连接方向，不是调用方来源门禁。','2':'HTTP API明确不支持resource policy。','3':'托管API不是客户子网中的EC2。','4':'没有可如此附加给HTTP API的入站SG。'},
 source={'status':'CONFIRMED_HTTP_API_FEATURE_MISMATCH','reason':'官方明确Resource policies are not currently supported，非能力检索缺失。'},
 proposal={'target':'option B; retain HTTP API product and original IP-restriction goal',
  'text':'为HTTP API配置Lambda authorizer，在每次请求中按API Gateway提供的真实sourceIp检查批准CIDR，拒绝其余来源，并禁用会跨不同来源复用结果的authorizer缓存。',
  'preserves':'HTTP API仅允许可信IP；不为省卡把产品改成REST API','notTested':True},
 conditions=['若HTTP API只是泛指HTTP协议API而不是AWS命名产品，须另行明确；本次不偷偷改成REST。'])
save('batch03')

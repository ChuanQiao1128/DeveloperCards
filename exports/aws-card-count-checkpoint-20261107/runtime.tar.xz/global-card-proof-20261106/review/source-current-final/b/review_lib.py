import pathlib,json,hashlib,datetime,subprocess,concurrent.futures
from html.parser import HTMLParser
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106')
I=V/'review/source-current-final/input'
R=V/'review/source-current-final/b'
E=R/'evidence'
E.mkdir(parents=True,exist_ok=True)
def ca(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
M=json.loads((I/'manifest2.json').read_text())
for p,h in M.items():assert sha(pathlib.Path(p).read_bytes())==h,(p,h)
cases=json.loads((I/'cases2.json').read_text())
by={c['qid']:c for c in cases}
pool={c['ruleId']:c for c in json.loads((I/'core-visible.frozen.json').read_text())}
assert len(pool)==351
for c in pool.values():assert sha(ca(c['visibleBody']))==c['bodySha256']
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.hidden=0
 def handle_starttag(self,tag,attrs):
  if tag in ['script','style','noscript']:self.hidden+=1
  if not self.hidden and tag in ['p','div','li','tr','h1','h2','h3','h4','td','th','br']:self.parts.append('\n')
 def handle_endtag(self,tag):
  if tag in ['script','style','noscript']:self.hidden=max(0,self.hidden-1)
  if not self.hidden and tag in ['p','div','li','tr','h1','h2','h3','h4','td','th']:self.parts.append('\n')
 def handle_data(self,s):
  if not self.hidden:self.parts.append(s)
def fetch(item):
 name,url=item;p=E/(name+'.json')
 if p.exists():return name,'cached'
 try:
  raw=subprocess.run(['curl','-fLSs','--max-time','35',url],capture_output=True,check=True).stdout
  final=url
  parser=Text();parser.feed(raw.decode('utf-8','replace'))
  text='\n'.join(' '.join(s.split()) for s in ''.join(parser.parts).splitlines() if s.strip())
  d={'url':url,'finalUrl':final,'fetchedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'rawSha256':sha(raw),'text':text,'textSha256':sha(text.encode()),'extraction':'stdlib HTMLParser; whitespace-normalized visible text'}
  assert len(text)>200
  p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
  return name,'saved',len(text)
 except Exception as ex:return name,'ERROR',str(ex)
registry={}
def ev(name,quote,support):
 p=E/(name+'.json') if not str(name).startswith('/') else pathlib.Path(name)
 d=json.loads(p.read_text());t=d['text'];i=t.index(quote)
 k=sha(ca([str(p),quote,support]))
 registry[k]={'sourcePath':str(p),'sourceFileSha256':sha(p.read_bytes()),'textSha256':sha(t.encode()),'url':d['url'],
  'quote':quote,'quoteStart':i,'quoteEnd':i+len(quote),'supports':support}
 return k
def card(rid,quote,support):
 c=pool[rid];hits=[(f,t.index(quote)) for f,t in c['visibleBody'].items() if quote in t];assert hits,(rid,quote)
 f,i=hits[0]
 return {'cardId':rid,'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':quote,'quoteStart':i,'quoteEnd':i+len(quote),'supports':support}
rows=[]
def add(q,status,options,anchors,evidence,reason,comparison,source=None,gaps=None,proposal=None,conditions=None):
 rows.append({'qid':q,'status':status,'questionSha256':sha(ca(by[q]['originalQuestion'])),
  'fullStemAndAllOptionsRead':True,'selectedOptionOrdinals':options if status=='SUPPORTED' else [],
  'candidateOptionOrdinals':options if status!='SUPPORTED' else [],
  'necessaryCardAnchors':[card(*a) for a in anchors],'officialEvidenceIds':evidence,
  'reasoning':reason,'optionComparison':comparison,
  'sourceDisposition':source or {'status':'NO_CONFIRMED_SOURCE_ERROR','reason':'No independently confirmed defect; do not infer absence from search failure.'},
  'necessaryCardFactGaps':gaps or [],'minimalCorrectionProposal':proposal,
  'conditionsAndUnresolved':conditions or [],'originalQuestionUnchanged':True,
  'correctedExerciseTested':False,'learnerPerformanceMeasured':False})
def save(name):
 out=R/(name+'.review.json');assert not out.exists()
 ids=sorted(set(k for r in rows for k in r['officialEvidenceIds']))
 from collections import Counter
 result={'schemaVersion':1,'reviewer':'actual_cards_review independent source-current-final group b',
  'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'inputManifestPath':str(I/'manifest2.json'),'inputManifestSha256':sha((I/'manifest2.json').read_bytes()),
  'frozenInputFiles':M,'corePool':{'path':str(I/'core-visible.frozen.json'),'sha256':M[str(I/'core-visible.frozen.json')],'count':351,'provisionalNotFinalN':True},
  'questionCount':len(rows),'statusCounts':dict(Counter(r['status'] for r in rows)),
  'results':rows,'evidenceRegistry':{k:registry[k] for k in ids},
  'userPoliciesActuallyReadAndBound':True,'allOriginalsPreserved':True,
  'sourceAbsenceNotUsedAsDisproof':True,'cardsAuthored':False,'currentPointersChanged':False,
  'modelCliApiCalls':0,'nativeUsage':'unknown','priorFailuresAndCountsPreserved':True}
 out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 for r in result['results']:
  assert r['questionSha256']==sha(ca(by[r['qid']]['originalQuestion']))
  for a in r['necessaryCardAnchors']:
   c=pool[a['ruleId']];assert c['bodySha256']==a['bodySha256']
   assert c['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']]==a['quote']
 for e in result['evidenceRegistry'].values():
  p=pathlib.Path(e['sourcePath']);d=json.loads(p.read_text())
  assert sha(p.read_bytes())==e['sourceFileSha256']
  assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
 (R/(name+'.readback.json')).write_text(json.dumps({'status':'PASS','reviewPath':str(out),'reviewSha256':sha(out.read_bytes()),'questionCount':len(rows),'allOriginalAndCoreHashesMatch':True,'allLiteralOffsetsMatch':True,'allOfficialEvidenceSnapshotsMatch':True},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'path':str(out),'questionCount':len(rows),'counts':result['statusCounts'],'readback':'PASS'},ensure_ascii=False))

from review_lib import *
def candidate(q,n,quote,why):return ev(by[q]['existingOfficialEvidenceCandidates'][n]['sourcePath'],quote,why)
parallel=ev('athena-parallel','Athena automatically executes queries in parallel,','Athena满足并行处理，不能据parallel一词排除A')
spark=ev('redshift-spark','This integration is automatically included in Amazon EMR and AWS Glue,','EMR与Glue均有Redshift Spark集成')
sparkread=ev('redshift-spark','applications that read from and write to data in Amazon Redshift and Amazon Redshift Serverless.','Redshift数据可供Spark富集')
tls=ev('tls-http','policy accepts TLS 1.2 and TLS 1.3 traffic and rejects TLS 1.0 traffic.','支持协商TLS1.3不等于仅允许TLS1.3')
tape=ev('snowball-history','Tape Gateway functionality is no longer available on Snowball Edge devices.','原选项C所需Snowball上的Tape Gateway已退役')
snow=ev('snowball-history','Effective November 7, 2025, AWS Snowball Edge will only be available to existing customers.','Snowball资格条件而非全体客户不可用')
redis=ev('redis-replication','Due to replication latency,\nsome data may be','Redis副本复制存在延迟与数据损失窗口')
redis2=ev('redis-replication','replica nodes asynchronously, there may be some data loss due to latency in updating the\nreplica nodes.','普通Redis异步副本不是零丢失保证')
vpn=ev('vpn-options','1.25 Gbps per tunnel, while large supports up to 5 Gbps per tunnel.','90%利用率不能单独推出剩余绝对带宽')
task=candidate(663,0,'The task role is\nrequired when your application accesses other AWS services, such as Amazon S3.','容器应用S3访问需要task role')
rds=ev('rds-api-endpoint','All RDS API operations relevant to managing Amazon RDS\nresources are available from your VPC using AWS PrivateLink.','RDS interface endpoint提供管理API')
tag=candidate(668,0,"Untagged\nresources or tags that aren't defined in the tag policy aren't evaluated for compliance\nwith the tag policy.",'tag policy不强制资源必须有标签')
gd=candidate(733,0,'successful, failed, or incomplete login attempts, GuardDuty generates one or more','RDS Protection异常登录检测产生finding')
response=ev('guardduty-response','The following sections describe the recommended remediation\nsteps for these scenarios.','检测finding后仍有独立整改职责')
ssec=ev('s3-default','Server-side encryption with customer-provided keys (SSE-C) is not supported for default\nencryption.','SSE-C不能成为自动应用的桶默认加密')
batch=candidate(740,0,'All \nCopyObject\n options are supported except for conditional checks on\n          entity tags (ETags) and server-side encryption with customer-provided encryption keys (SSE-C).','S3 Batch Copy不支持SSE-C')
aur=ev('aurora-mysql','Aurora MySQL is a drop-in replacement for\nMySQL','不能仅因名称Aurora推定必需大幅改造')
pitr=ev('aurora-pitr','You can restore a DB cluster to a specific point in time, creating a new DB cluster.','Aurora也支持PITR')
add(557,'SOURCE_ISSUE',[1,2],[
 ('GSC-097','分布式任务把可拆分数据和计算分给多个节点，同时处理，适合相应的大规模数据作业。','分布式并行原理'),
 ('CUR:CC19','不应；用适用的Lake Formation细粒度授权或数据过滤，按身份提供允许的数据范围。','Lake Formation治理不是自动富集运算')],
 [parallel,spark,sparkread],
 '原题没有Spark指定、单一工具、最少维护或避免落地等额外约束。官方正证表明Athena可并行处理S3，Glue可访问Redshift进行转换；EMR Spark同样可读取Redshift。因此A与B均可构造满足两项要求的处理，不能把parallel当EMR专属关键词。',
 {'1':'Athena并行处理加Glue/Redshift转换具有正证。','2':'EMR分布式处理及Redshift连接具有正证。','3':'Kinesis不是把既存S3数据自动导入并完成Redshift富集的步骤。','4':'Lake Formation治理本身不替代富集代码。'},
 source={'status':'CONFIRMED_MULTIPLE_VIABLE_OPTIONS','reason':'A/B在原题未给附加约束下都具有官方能力正证。'},
 gaps=['冻结核心卡未教EMR/Glue到Redshift的实际集成；此缺口与原题多解分别记录。'])
add(571,'UNKNOWN',[1],[
 ('CUR:CB13','最低TLS版本另由入口支持的安全策略决定；换证书签发CA，不会改变入口允许的TLS版本。','签发CA与最低TLS能力不同'),
 ('CUR:NEW02','ACM不能代替外部CA签发新证书','指定外部CA需外部签发再导入')],
 [tls],
 'A在“支持客户端以TLS1.3连接”的解释下可行，不能沿用“HTTP API不支持TLS1.3”的旧疑点。若strict requires意为拒绝TLS1.2，则当前HTTP API固定策略仍接受1.2，A不能强制最低1.3。原文未写only或minimum，两个解释不能擅自择一。',
 {'1':'外部签发后导入正确；支持1.3但也接受1.2。','2':'ACM不能代指定第三方CA签发。','3':'同样错误混合外部CA签发和函数URL自定义证书。','4':'同C。'},
 source={'status':'UNKNOWN_REQUIREMENT_INTERPRETATION','reason':'TLS1.3支持与强制最低TLS1.3是不同要求；官方证实支持，原文未清楚限定。'},
 gaps=['当前核心卡只提醒核对安全策略，未教HTTP API当前可协商TLS1.3且最低策略为TLS_1_2。'],
 conditions=['不提出把1.3改成1.2的纠错；这可能改变有效原目标。'])
add(583,'SOURCE_ISSUE',[],[
 ('GSC-077','先用数据量÷实际可用传输速率估算在线下限；窗口不够时，比较适用的离线设备方案。','带宽与期限下限'),
 ('GSC-077','须核对设备现行可用资格、可用容量和交付窗口，不能用退役设备或忽略运输时间证明可行。','离线设备现行支持')],
 [tape],
 '5PB按十进制计为40×10^15 bit；1Gbps连续满速也需40,000,000秒≈463天，大于6个月，A/B/D在线路径均不满足期限。唯一离线选项C要求Snowball上运行Tape Gateway，而官方明确该集成已退役。不是因未搜到设备能力判错。',
 {'1':'受1Gbps瓶颈。','2':'受同一瓶颈。','3':'明确退役的Tape Gateway集成。','4':'虚拟磁带上传仍受同一链路瓶颈。'},
 source={'status':'CONFIRMED_OBSOLETE_REQUIRED_INTEGRATION','reason':'C需要的Tape Gateway on Snowball已不再可用；其他方案由保留原数字直接排除。'},
 conditions=['没有用普通Snowball复制对象替换虚拟磁带集成；未猜造最小迁移流程。'])
add(593,'SOURCE_ISSUE',[1,3],[
 ('GSC-032','选满足要求的Redis OSS/Valkey复制组，并配置副本和适用的接管。','副本与接管'),
 ('GSC-116','故障发生时要用还在运行的容量承接流量，故障域分散与容量余量缺一不可。','多节点不等于零性能退化'),
 ('CUR:CB03','同Region跨AZ不能替代Region级灾备；单AZ内多台实例仍共享AZ故障风险。','AZ与Region故障范围区别')],
 [redis,redis2],
 'A/C均能提供跨AZ复制组的HA方向，但题面要求故障不丢数据、无性能下降并称Region level。普通Redis OSS异步复制存在已确认的数据丢失窗口；题目也未限定各AZ容量余量。不能用当前Valkey另有的同步耐久功能替换原Redis目标。',
 {'1':'跨AZ多节点能提高HA，不能推出零丢失/零性能退化。','2':'AOF不是Region故障冗余，且不消除异步复制窗口。','3':'与A重叠的跨AZ副本方案，仍不能满足硬保证。','4':'未来伸缩不等于故障当下容量和持久性。'},
 source={'status':'CONFIRMED_UNSATISFIED_HARD_REQUIREMENT','reason':'官方异步复制数据损失正证与题面零损失要求冲突；A/C也未唯一化。'})
add(659,'UNKNOWN',[1,3],[
 ('GSC-077','链路总带宽不等于迁移可占用带宽；离线运输可避开持续占用链路，但也需准备、运输及导入时间。','须知道实际剩余速率与离线窗口')],
 [vpn,snow],
 '50TB/14天需约330.7Mbps净传输速率。90%利用率未给绝对带宽：现行VPN既有1.25Gbps也有5Gbps规格，剩余10%可分别小于或大于该门槛。C另取决于既有客户资格和运输排期。不能只凭90%给C无条件充分。',
 {'1':'剩余实际速率足够时可行，原文未给出。','2':'部署时间和现有条件未给出，不应臆定两周内可交付。','3':'离线方向合理但资格/交付窗口须确认。','4':'接口服务本身不扩大底层带宽。'},
 source={'status':'UNKNOWN_MISSING_DECISIVE_PARAMETERS','reason':'原文缺绝对净带宽及可用离线交付窗口，尚不能独立确证唯一方案。'},
 conditions=['Snowball只对新客户不可用；原文没有客户资格，不能断言全体不可用。'])
add(663,'SOURCE_ISSUE',[],[
 ('CUR:XB033','任务角色的凭据交给容器应用调用AWS；task execution role供ECS/Fargate Agent拉镜像、写日志等运行任务操作，不直接把凭据交给应用代码。','应用角色与执行角色不同'),
 ('CUR:CMP-M25','RDS interface endpoint用于创建、修改等管理API，不承载MySQL等数据库SQL连接。','管理端点与SQL路径不同'),
 ('CUR:SC01','资源授权与用钥授权是两道检查。','仅KMS允许不能替代数据授权')],
 [task,rds],
 'A/B/C把应用S3访问身份写为task execution role；A还只给用钥权限，不能证明资源访问仅限该应用。C/D将RDS管理API端点当数据库访问限制，子网/CIDR也不能单独识别ECS应用。没有一项完整建立应用身份授权加数据库实际连接边界。',
 {'1':'用钥权限与资源授权分开，执行角色也不是应用角色。','2':'执行角色错，且AWS managed key不提供任意客户修改策略。','3':'执行角色错，RDS端点不是SQL限制。','4':'S3端点来源不等于唯一ECS身份，RDS SQL路径仍未解决。'},
 source={'status':'CONFIRMED_NO_COMPLETE_OPTION','reason':'task role/执行角色与RDS管理端点的已证职责直接冲突原方案。'},
 proposal={'target':'replace one defective option, separately identified exercise only','text':'使用ECS task role授予受限S3访问，并以桶策略限制允许身份；RDS保持私有，数据库安全组仅放行任务实际来源安全组的MySQL端口，另满足数据库用户授权。','preserves':'仅应用访问S3/RDS的原目标','notTested':True})
add(668,'SOURCE_ISSUE',[],[
 ('CUR:XA032','tag policy校验已提交标签的合规值，不评估未标记资源；SCP在相应请求发生时拒绝，才能补上缺失和删除这两个入口。','标签值合规与强制标签存在不同')],
 [tag],
 '原要求只有应用名为批准值才可创建。D仅tag policy不检查无标签资源，不能满足only if；A只要求给出标签而没有批准值条件，也不作用于Identity Center已分配角色的组授权。B反向拒绝有标签资源，C是查资源而非创建时强制。',
 {'1':'未限制批准值。','2':'拒绝所有带该标签请求反向于目标。','3':'资源查找/验证不是创建请求门禁。','4':'无标签资源不受tag policy评估。'},
 source={'status':'CONFIRMED_NO_COMPLETE_OPTION','reason':'D遗漏标签存在条件有官方明确正证；其余选项也未规定批准值门禁。'},
 proposal={'target':'option D','text':'对支持创建时标签条件的相关资源操作，用SCP拒绝缺少应用名标签或值不在批准列表的创建请求；tag policy规范受支持资源的标签值。','preserves':'创建时必须存在且值已批准','notTested':True})
add(733,'CONDITIONAL',[2],[
 ('CUR:CC02','例如启用RDS Protection后，可分析受支持Aurora/RDS数据库的成功、失败或未完成登录模式，发现异常登录。','异常登录检测'),
 ('CUR:CC02','威胁发现不等于已经阻断登录；RDS Protection会生成发现，响应控制仍须另行配置。','检测不自动阻断')],
 [gd,response],
 'B准确支撑题目具体的异常失败/未完成登录识别，且比单纯收集日志少维护。题干还写prevent malicious activity；若这是要求方案本身自动阻断，则B仅检测不完整，原选项未给独立响应控制。此处保留为要求边界，不把“发现”改称“已防止”。',
 {'1':'SCP是权限上限，不分析DB登录模式。','2':'异常登录检测匹配。','3':'保存日志不自动进行异常检测。','4':'管理API审计不是全部数据库登录/查询事件。'},
 source={'status':'UNKNOWN_PREVENTION_SCOPE','reason':'具体识别任务有明确可答项；prevent是否要求自动阻断未清晰说明，不能据一句广义目标直接判全题错误。'},
 conditions=['只有把本题目标限定为异常登录识别才记B充分；若要求主动阻断，需另外设计响应控制，不自动计SUPPORTED。'])
add(740,'SOURCE_ISSUE',[],[
 ('CUR:CMP-M03','默认配置影响后续适用写入，不会回写全部历史对象；批作业按清单逐个执行受支持的修改。','新默认不处理历史对象'),
 ('CUR:CMP-M20','SSE-C虽由客户逐请求提供key，仍是S3收到数据后加密；','客户逐请求提供密钥')],
 [ssec,batch],
 'A将两个明确不支持SSE-C的动作组合：Batch Copy及桶默认SSE-C。B只设新默认，不能回写历史对象；C/D把usage report当逐对象清单，D仍有默认SSE-C错误。当前不能把customer-provided悄悄改成customer-managed KMS来接受A。',
 {'1':'SSE-C既不能作桶默认，也不支持该Batch Copy。','2':'未覆盖已有对象。','3':'usage report不是所需逐对象加密清单，且不能将SSE-C目标改为KMS。','4':'默认SSE-C不支持且未处理历史对象。'},
 source={'status':'CONFIRMED_UNSUPPORTED_CONFIGURATIONS','reason':'官方明确不支持所列SSE-C动作，而非检索未发现。'},
 proposal={'target':'replace option A while preserving customer-provided-key goal','text':'根据S3 Inventory清单用受控程序逐对象执行支持SSE-C的CopyObject请求，并对未来写入逐请求提供SSE-C所需密钥头；启用允许SSE-C的桶设置。','preserves':'已有及未来对象均用客户逐请求提供的密钥','notTested':True})
add(763,'CONDITIONAL',[2],[
 ('GSC-077','先用数据量÷实际可用传输速率估算在线下限；窗口不够时，比较适用的离线设备方案。','原数字排除在线期限'),
 ('GSC-077','须核对设备现行可用资格、可用容量和交付窗口，不能用退役设备或忽略运输时间证明可行。','当前资格和交付前提')],
 [snow],
 '150TB在100Mbps下即使全天连续上传也需约138.9天，夜间更慢；Transfer Acceleration或VPN不增加这一给定上传上限。B是适合的离线方向，但现行Snowball仅既有客户可用，原题没有给资格/设备交付窗口，不能无条件充分。',
 {'1':'旧Snowmobile不可当现行通用备选。','2':'现行符合资格且窗口内交付时可行。','3':'不能突破给定本地上传上限。','4':'不扩大给定上传带宽。'},
 source={'status':'CONDITIONAL_CURRENT_AVAILABILITY','reason':'既有客户仍可使用；没有将新客户限制泛化为所有客户退役。'},
 conditions=['应确认已有客户资格、当地可用设备容量与一个月内运输导入；不据此自动纠错或新增卡。'])
add(764,'UNKNOWN',[1,2,3],[
 ('CUR:CC22','在引擎和功能兼容的前提下迁移到相应RDS。','保留关系模型降低改造'),
 ('CUR:NB04','不能；启用该数据库支持的自动备份/point-in-time recovery，恢复到需要时刻的目标，再按计划切换。','PITR'),
 ('CUR:CB04','入口是否面向公网取决于访问者范围；VPN提供办公室到私网的路径，不必把后端公开。','web层公网需求不能无中生有')],
 [aur,pitr],
 'RDS MySQL与适用Aurora MySQL都支持关系迁移及PITR；原文没有web访问者是否互联网，也没有影响Aurora兼容/改造量的功能细节。不能仅凭“三层”强制web EC2公有子网，或据Aurora名称认定一定改造更多。保持有条件的架构候选，未确证唯一least-overhead。',
 {'1':'私有web可服务私网客户或置于公有入口后；原文未排除。','2':'Aurora MySQL兼容及PITR有正证，实际最少改造须看功能。','3':'互联网直接web拓扑下合理，但原文没给这个前提。','4':'公开数据库无必要，且不减少相同VM迁移工作。'},
 source={'status':'UNKNOWN_UNDERSPECIFIED_ACCESS_AND_COMPATIBILITY','reason':'没有唯一性的充分条件，不宣称原题已被官方判定错误。'},
 conditions=['不提出擅加互联网访问或虚构不兼容功能的纠错。'])
save('batch01')

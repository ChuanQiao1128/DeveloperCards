from review_lib import *
shut=ev('shutdown','Amazon Quantum Ledger Database (Amazon QLDB)\nJuly 31, 2025','QLDB已整体停止服务')
duplicate=ev('lambda-sqs','Lambda event source mappings process each event at least once, and duplicate processing of records can occur.','SQS包括FIFO接Lambda仍可能重复执行')
deletion=ev('kms-delete-event','After the specified waiting period expires,\nAWS KMS deletes the KMS key','DeleteKey记录等待期后实际删除，不是可取消的计划阶段')
eventexists=ev('kms-delete-event','These examples show the AWS CloudTrail log entry that is generated when a KMS key is deleted.','DeleteKey CloudTrail事件真实存在')
archive=ev('ebs-archive','When you archive a snapshot, the incremental snapshot is converted to a full snapshot,','归档转换为完整快照')
cost=ev('ebs-guidelines','In most cases, archiving these snapshots will not reduce storage\ncosts.','增量谱系共享块影响实际节省，不能只比较单价')
pause=ev('aurora-pause','you set the minimum capacity value\nfor the cluster to zero ACUs.','自动暂停需明确最小0ACU')
nlb=ev('ecs-nlb-http','Port: The port your application listens on (typically 80 for HTTP)','NLB实际可承载ECS HTTP应用，无L7要求时不能排除')
target=ev('alb-targets','instance\nThe targets are specified by instance ID.\nip\nThe targets are IP addresses.\nlambda\nThe target is a Lambda function.','ALB目标是实例/IP/Lambda，不是ASG对象')
transform=ev('event-transform','The transformed event is sent to a target instead of the original event.','EventBridge可以向目标发送裁剪后的事件')
sqsmapping=ev('lambda-sqs','Lambda\nsupports both\nstandard queues and\nfirst-in, first-out (FIFO) queues for event source mappings.','SQS消息可以实际连接函数消费者')
xks=ev('xks','AWS services\nthat support customer managed keys for symmetric\nencryption also support KMS keys in an external key store.','SSE-KMS客户管理key可通过XKS将实际密钥置于AWS外部')
peer_path=by[810]['existingOfficialEvidenceCandidates'][0]['sourcePath']
peer=ev(peer_path,'To enable the flow of traffic between the VPCs using private IP addresses,','VPC peering可建立VPC间私有IP路径')
peeraccounts=ev(peer_path,'The accepter VPC can be owned by you, or another AWS account,','跨账户VPC peering有效')
private=ev('private-link','Consumers create VPC endpoints to connect to endpoint services and resources that\nare hosted by providers.','PrivateLink提供消费侧私有端点连接供应商')
idem=[
 ('GSC-082','用稳定的业务ID做幂等检查，让已完成的同一笔操作返回已有结果，而非再次扣款。','业务级幂等'),
 ('GSC-082','检查和执行必须避免并发竞态；换一个新业务ID的重复提交不会自动被消息去重识别。','并发幂等边界')]
add(783,'SOURCE_ISSUE',[],[],[shut],
 '满足不可变且可密码验证账本用途的原D选项已在2025-07-31整体停止服务。当前不能选用QLDB新建该应用；其他三个选项只说复制记录，并未建立不可变、密码可验证变更账本。',
 {'1':'分析仓库本身不是所述密码可验证账本方案。','2':'图数据库复制记录不建立所需账本。','3':'时序数据库同样未建立密码验证日志。','4':'明确整体停服的QLDB。'},
 source={'status':'CONFIRMED_SERVICE_SHUTDOWN','reason':'AWS整体停服列表直接列明QLDB日期。'},
 conditions=['未为退役产品补卡；未将其他数据库加上原选项没有的定制账本逻辑后冒称原题成立。'])
add(785,'SOURCE_ISSUE',[3],idem,[duplicate],
 'C的FIFO解决队列发送去重/顺序，不能自动保证支付业务不会执行两次。官方明确SQS到Lambda映射至少一次且可重复；其他事件路径同样没有声明稳定业务ID的原子幂等支付动作，四项都没有完整落实硬要求。',
 {'1':'对象事件不提供支付业务幂等。','2':'Standard队列同样可能重复。','3':'FIFO不把Lambda副作用变成恰好一次。','4':'数据库流也未给支付幂等控制。'},
 source={'status':'CONFIRMED_MISSING_BUSINESS_EXACTLY_ONCE_GUARANTEE','reason':'官方至少一次函数执行语义直接否定FIFO自动消除重复扣款的推论。'},
 proposal={'target':'option C','text':'使用SQS FIFO及Lambda事件源映射，并以稳定payment ID在持久状态中原子认领/记录结果；重复请求返回已有结果，处理与外部支付副作用采用适用幂等协议。','preserves':'同一笔业务不重复付款','notTested':True})
add(793,'SOURCE_ISSUE',[],[
 ('CUR:XA041','ScheduleKeyDeletion先把key置于待删除状态，等待期结束才销毁；取消针对尚存在的key。','计划、等待与实际删除阶段'),
 ('CUR:XA041','等待期内执行CancelKeyDeletion；真正删除后不能再靠取消恢复。','取消仅在实际删除前有效'),
 ('CUR:XB011','人员邮件用SNS主题和已确认的邮件订阅；执行自定义动作则把相应Lambda函数设为目标。','通知与动作分工')],
 [deletion,eventexists],
 'DeleteKey不是不存在的事件：AWS确实记录它，但发生在等待期结束的实际销毁时。B/C等待该事件才取消已来不及，D只通知且无预防；A把Config规则当直接取消动作，未建立实际受支持整改。原题没有完整的等待期取消加SNS链。',
 {'1':'评估规则本身不是CancelKeyDeletion执行器。','2':'实际DeleteKey之后不可取消。','3':'同样触发太晚。','4':'只是通知且触发实际删除后。'},
 source={'status':'CONFIRMED_EVENT_LIFECYCLE_MISMATCH','reason':'官方明确DeleteKey产生在实际删除时，不能将其当用户计划删除请求。'},
 proposal={'target':'option C','text':'用CloudTrail支持的EventBridge事件模式匹配ScheduleKeyDeletion，在等待期内调用Systems Manager Automation runbook执行CancelKeyDeletion，并发送SNS邮件通知。','preserves':'防止误删且尝试删除时通知','notTested':True})
add(801,'UNKNOWN',[1,4],[
 ('CUR:CMP-M20','应用应先用可调用的客户密钥完成客户端加密，再交给存储。','本地客户端密文路径'),
 ('CUR:XA029','使用KMS external key store，由外部key manager保留并使用实际密钥。','KMS也可接外部保管key'),
 ('CUR:CMP-M11','真正建立TLS才保护连接。','传输连接加密独立于静态加密')],
 [xks],
 'D在公司侧加密并保留本地密钥是直接可行方向，但原文字面还要求传输加密。A没有指定key store，现行客户管理KMS key可用XKS让实际密钥留在AWS外；不能据customer managed字样断言一定在AWS内。A需额外明确XKS，D需明确本地保管与传输配置，现有选项不足以独立确认唯一完整实现。',
 {'1':'普通KMS与XKS是不同可能，原选项未限定。','2':'AWS managed不能提供这里的外部保管控制。','3':'默认SSE没有外部密钥管理。','4':'本地客户端加密方向正确，但不据地点自动断言所有连接配置已建立。'},
 source={'status':'UNKNOWN_UNSPECIFIED_KEY_STORE_AND_TRANSPORT','reason':'XKS官方正证使旧“所有KMS密钥都在AWS”排除法无效；未确认源题唯一性。'},
 conditions=['不把XKS补进A后当作原选项已完整写出；不为了省卡删除有效的外部密钥原目标。'])
add(810,'SOURCE_ISSUE',[3,4],[
 ('CUR:CMP-M04','供应商自建TCP服务，供应商先在服务前配置NLB并发布endpoint service，客户再建interface endpoint连接它。','C的发布/消费路径'),
 ('CUR:CMP-M04','若NLB后端IP会变，例如RDS故障切换，注册目标须同步更新；','RDS IP目标变化仍要处理')],
 [private,peer,peeraccounts],
 'C可提供受控PrivateLink数据库入口。原题未要求仅发布单服务、禁止VPC间路由或最少运维；D明确包括VPC peering，也能在跨账户私有IP间连数据库，无需题面列为缺失的IGW/DX/VPN。TGW再加peering可能冗余，但冗余不等于不满足原需求，不能据此唯一排除D。',
 {'1':'Hosted Connection Program与基本peering无关且给出额外未知资格。','2':'Client VPN不是原生VPC-to-VPC路由替代，未写客户端实现。','3':'NLB/PrivateLink是有效方案，须维护目标IP。','4':'含有效跨账户peering私网路径；原题未禁止冗余路由。'},
 source={'status':'CONFIRMED_MULTIPLE_PRIVATE_CONNECTIVITY_SOLUTIONS','reason':'PrivateLink与跨账户peering均有官方私有连接正证，原文无唯一化约束。'})
add(833,'SOURCE_ISSUE',[1,3],[
 ('CUR:CC17','事件模式筛选并路由事件；目标的input transformer裁剪或重排发送给函数的字段。','C的字段裁剪'),
 ('VC-001','配置SQS事件源映射：Lambda服务轮询队列并批量调用函数，整批成功后删除消息。','A的每步独立队列消费者')],
 [transform,sqsmapping],
 'C用规则及input transformer直接满足字段最小化和松耦合。A也明确有独立转换函数给每个独立队列投递该步骤所需格式，并由各步骤消费者读取；队列隔离处理，变化可修改转换路由。题目没有最少运维或禁止自定义转换代码，不能仅因A组件更多判不满足。',
 {'1':'代码转换加独立队列也能实现同样字段隔离与松耦合。','2':'消息过滤选择整条消息，不等于裁剪发送字段。','3':'托管转换直接满足。','4':'同步调用和线程编排更紧耦合。'},
 source={'status':'CONFIRMED_MULTIPLE_VIABLE_OPTIONS','reason':'A/C均提供实际字段转换与独立消费者；原文没有唯一化成本/维护条件。'},
 conditions=['未将“最少组件/最少运维”偷偷加入原题。'])
add(841,'UNKNOWN',[2,3],[
 ('GSC-018','不一定，要按归档后的完整快照大小及保留、恢复费用比较。','成本比较不能只看单价'),
 ('GSC-018','标准层快照利用增量块共享；归档时会转成包含该恢复点全部已写数据块的完整快照，计费数据量可能变大。','增量共享与归档完整量')],
 [archive,cost],
 'B是适用长期归档机制，C是适用标准增量保留机制。350TB与每日5%改变未说明是否持续改相同块、月间块重叠/未引用块大小及恢复频率，因此不能独立推出哪项总费用最低。连续改同5%块和每天改不同块都符合题面，却产生不同增量谱系共享，不能把5%×30机械当新增且不共享。',
 {'1':'不能直接把原生EBS快照当自有S3对象转Deep Archive。','2':'可行归档，但完整快照计费与未引用块节省待比较。','3':'可行增量长期留存，费用取决于实际块共享。','4':'读取快照块并写S3不是自动保留可直接恢复的原生快照策略。'},
 source={'status':'UNKNOWN_TOTAL_COST_ORDERING','reason':'官方要求比较完整量与标准层实际减少量，原题5%不决定月度未引用量。'},
 conditions=['不新编随机独立写入分布来证明B最便宜；也不把每GiB归档便宜当充分。'])
add(851,'UNKNOWN',[2,3],[
 ('CUR:XA020','把批准配置发布为Service Catalog产品，向开发者开放相应portfolio，并设置开通约束。','配置边界与自助'),
 ('CUR:XB027','启用自动暂停，把支持的最小容量设为0 ACU，并设定空闲等待时间。','版本和容量条件决定暂停'),
 ('CUR:XB027','只是选了Serverless名称，并不等于默认就会降到零或立刻响应。','默认名义不是零闲置保证')],
 [pause],
 'B明确限制开通规格。C有Serverless方向，但default capacity settings没指定版本、最小0ACU、自动暂停或每开发者数据库限制；不能用旧Serverless v1默认暂停来替代现行v2配置。题面没有工作时长、容量上限及产品具体限制，无法独立确认最经济且满足全部边界的唯一项。',
 {'1':'可按工作日启停但未给数据库规格限制和全球开发者计划。','2':'明确有限规格和自助，但未写闲置停算策略。','3':'需适用版本及明确暂停/容量边界，名称本身不够。','4':'终止会删除开发数据语义，不是保留数据库只停闲置计算。'},
 source={'status':'UNKNOWN_SERVERLESS_VERSION_AND_DEFAULTS','reason':'只证实自动暂停必须具备条件；没有以未找到某个默认值断言C不支持。'},
 gaps=['若需唯一比较，须明确原产品的版本、容量边界和闲置策略；不是直接新增卡的义务。'])
add(869,'SOURCE_ISSUE',[1],idem,[duplicate],
 'A提供可缓冲突增的FIFO/Lambda方向，但已知至少一次执行语义不保证业务exactly once。原要求的每订单恰好一次需要稳定业务ID和并发安全幂等副作用，选项未给出；其他选项也不提供这层保证。',
 {'1':'FIFO不等于Lambda业务恰好一次。','2':'SNS standard更没有业务幂等保证。','3':'AppFlow未给订单业务去重执行协议。','4':'X-Ray/CloudWatch不是订单持久工作队列。'},
 source={'status':'CONFIRMED_MISSING_BUSINESS_EXACTLY_ONCE_GUARANTEE','reason':'官方SQS函数至少一次执行及重复可能性与仅靠FIFO保证业务一次的推断冲突。'},
 proposal={'target':'option A','text':'SQS FIFO连接Lambda消费，并对稳定order ID实施持久、并发安全的幂等处理与结果复用。','preserves':'突增下每订单只产生一次业务效果','notTested':True})
add(900,'SOURCE_ISSUE',[1,2,3],[
 ('GSC-140','可评估ECS Anywhere把适用外部实例纳入管理，工作负载仍在本地主机执行。','A的本地external运行'),
 ('CUR:XB019','少维护宿主机可选Fargate；','A的云端Fargate'),
 ('CUR:XB041','NLB处理传输层连接和流量，ALB理解HTTP请求内容；协议层决定能做哪类分流。','HTTP载荷并不强制需要L7字段路由')],
 [nlb],
 'A符合本地external与云端Fargate。B的ALB当然能负载均衡HTTP；但C的NLB也可在TCP端口转发HTTP，官方ECS NLB配置直接以80/HTTP为例。原文没有路径/主机字段等L7路由要求，因此Choose two不能在A+B与A+C之间唯一化。',
 {'1':'本地/云端运行模式正确。','2':'可行HTTP入口。','3':'同样可以承载HTTP应用传输。','4':'Fargate不把任务留在本地外部主机执行。','5':'本地Anywhere不是Fargate launch type。'},
 source={'status':'CONFIRMED_MULTIPLE_VALID_COMBINATIONS','reason':'官方NLB的HTTP实际配置正证排除“HTTP只能ALB”的误推。'},
 conditions=['不擅自加入按HTTP路径路由来制造唯一答案；如用户另给原意才另存纠错练习。'])
add(902,'SUPPORTED',[3],[
 ('CUR:CB03','把实例分散到独立AZ，才避免同一故障域一起失效，Auto Scaling再补足损失。','跨AZ提高可用性'),
 ('CUR:CB10','在实际承载请求的受支持HTTP入口关联WAF web ACL，配置相应内容规则或IP set规则。','WAF在ALB入口'),
 ('CUR:CB04','ALB接收入口连接后再连接私有目标。','ALB到应用实例')],
 [target],
 'C字面提供跨两个AZ的实例、以实例作为ALB目标并关联WAF，满足提高可用性和使用WAF。原题未要求自动替换或负载动态伸缩，所以不能仅因C没ASG判缺。A/D把ASG对象写成ALB target，不是当前目标类型；可通过改成target group attachment修复，但本次不悄悄改原文。',
 {'1':'字面把ASG对象注册为目标不符合官方目标类型。','2':'WAF不关联placement group，cluster组也集中故障域。','3':'实例目标跨AZ加ALB web ACL完整匹配。','4':'WAF不关联ASG。'},
 source={'status':'VALID_LITERAL_OPTION_EXISTS','reason':'虽然A使用技术简写/错误目标对象，C仍能按原文独立满足，不因此自动把全题列源错。'},
 conditions=['若外部作者把A解释为ASG关联ALB目标组，则也能成立；此处选C不替A修词，也不假定原印刷答案。'])
save('batch02')

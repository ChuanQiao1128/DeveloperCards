import pathlib,json,hashlib,datetime
V=pathlib.Path(__file__).resolve().parents[2];R=V/'review/questions-c';MP=R/'input/cases01.v3.manifest.json';M=json.loads(MP.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def ca(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
assert all(sha(pathlib.Path(f).read_bytes())==h for f,h in M.items())
CP=R/'input/cases01.v3.json';cases=json.loads(CP.read_text());byq={c['qid']:c for c in cases}
B=json.loads((R/'input/extra-knowledge.v3.binding.json').read_text());GP=pathlib.Path(B['globalSnapshotPath']);assert sha(GP.read_bytes())==B['globalFileSha256'];cards={c['ruleId']:c for c in json.loads(GP.read_text())};assert len(cards)==355 and 'GCL-020' not in cards
STATUS={'SUPPORTED','CONDITIONAL','INSUFFICIENT_CARDS','SOURCE_ISSUE','UNKNOWN'}
def an(rid,quote,supports):
 c=cards[rid];assert sha(ca(c['visibleBody']))==c['bodySha256']
 fields=[(k,v.index(quote)) for k,v in c['visibleBody'].items() if quote in v];assert fields,(rid,quote)
 field,start=fields[0]
 return {'cardId':rid,'field':field,'quote':quote,'quoteStart':start,'quoteEnd':start+len(quote),'bodySha256':c['bodySha256'],'supports':supports}
def result(qid,status,selected,anchors,reason,nearest,missing=None,conditions=None,candidates=None):
 assert status in STATUS and qid in byq
 x=byq[qid];valid={o['ordinal'] for o in x['question']['options']};assert set(selected)<=valid
 used=list(dict.fromkeys(a['cardId'] for a in anchors));assert all(r in cards for r in used)
 extras=[r for r in used if r not in {c['ruleId'] for c in x['visibleCards']}]
 for v in x['visibleCards']:assert cards[v['ruleId']]['bodySha256']==v['bodySha256']
 return {'qid':qid,'status':status,'selectedOptionOrdinals':selected,'candidateOptionOrdinals':candidates or [],'usedRuleIds':used,'necessaryAnchors':anchors,'reasoning':reason,'nearestCompetitor':nearest,'missingJudgments':missing or [],'conditionsAndSourceIssues':conditions or [],'questionSha256':sha(ca(x['question'])),'providedVisibleCardBindings':{v['ruleId']:v['bodySha256'] for v in x['visibleCards']},'additionalVisibleCardBindings':{r:cards[r]['bodySha256'] for r in extras},'globalAdditionalSnapshotSha256':B['globalFileSha256'] if extras else None,'withheldRuleIds':x.get('withheldRuleIds',[]),'deletionCheck':{'mayOmitMappedRuleIdsForThisQuestion':[r for r in x['cardRuleIds'] if r not in used],'scope':'Only this question can omit these references; no global card deletion claim.'}}
def writepart(number,rows):
 start=(number-1)*22;expect=[x['qid'] for x in cases[start:start+22]];assert [x['qid'] for x in rows]==expect,([x['qid'] for x in rows],expect)
 p=R/f'results-part{number:02d}.json';assert not p.exists(),'preserve existing part; use explicit repair instead'
 counts={s:sum(r['status']==s for r in rows) for s in sorted(STATUS)}
 report={'schemaVersion':1,'reviewer':'actual_cards_review independent visible-card backtest','inputVersion':'cases01.v3','inputManifestPath':str(MP),'inputManifestSha256':sha(MP.read_bytes()),'inputFiles':M,'part':number,'questionCount':len(rows),'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Design-level sufficiency from actual visible Chinese bodies, not measured learner accuracy, not full-library closure or final N','statusCounts':counts,'results':rows}
 for row in rows:
  for a in row['necessaryAnchors']:
   body=cards[a['cardId']]['visibleBody'];assert body[a['field']][a['quoteStart']:a['quoteEnd']]==a['quote']
 p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 files=sorted(R.glob('results-part[0-9][0-9].json'));done=[q for f in files for q in json.loads(f.read_text())['results']];assert len({q['qid'] for q in done})==len(done)
 pending=[x['qid'] for x in cases if x['qid'] not in {q['qid'] for q in done}]
 state={'phase':'independent_question_backtest_in_progress','inputVersion':'cases01.v3','inputManifestSha256':sha(MP.read_bytes()),'current_artifacts':[str(f) for f in files],'completedQuestionCount':len(done),'pending_ids':pending,'findings':[{'qid':q['qid'],'status':q['status'],'missingJudgments':q['missingJudgments'],'conditionsAndSourceIssues':q['conditionsAndSourceIssues']} for q in done if q['status']!='SUPPORTED'],'attempts':{'initialReviewParts':len(files),'repairs':0,'historyPreserved':True},'next_action':'Review next 22 original full stems/options against current visible cards; do not author or infer global deletion/final N.'}
 (R/'state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'part':number,'counts':counts,'completed':len(done),'pending':len(pending)},ensure_ascii=False))

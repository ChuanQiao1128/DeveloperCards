# 220题可见卡面独立回测

完成220/220。SUPPORTED 144，CONDITIONAL 11，INSUFFICIENT_CARDS 60，SOURCE_ISSUE 5。

本报告是冻结中文可见卡组对原题选型的设计支撑；不代表学员已答对，不确认全库N，不把题源例外移出分母。输入cases01.v3；只用已冻结355卡池，GCL-020隔离未使用。

逐题完整锚点、卡句偏移/正文哈希、题干哈希、必要竞争条件与映射可省项均在results.json。单题未用某张映射卡，不证明该卡全局可删除。

源问题：Q717、Q740、Q767、Q900、Q902，均保留原题和官方原句证据；未获用户接受，不能算已闭合覆盖。

当前Skill前向检查见skill-forward-check.md。仅Q755由CONDITIONAL定向修正为SUPPORTED（选型知识），20%生产改善实测单列未测；旧结果见results-part04.json和repair-forward01.json。

| 题号 | 当前状态 | 所选序号 | 缺口/条件 |
|---|---|---|---|
| Q635 | INSUFFICIENT_CARDS | — | 新建DR时选择SnapMirror持续复制而非Backup恢复的适用条件、自动化与运维差异 |
| Q636 | INSUFFICIENT_CARDS | — | Lambda可通过SQS事件源映射消费队列并扩展处理的能力 |
| Q637 | SUPPORTED | 2,3 |  |
| Q639 | SUPPORTED | 1 |  |
| Q641 | SUPPORTED | 2 |  |
| Q642 | SUPPORTED | 1 |  |
| Q643 | SUPPORTED | 1 |  |
| Q646 | SUPPORTED | 3 |  |
| Q647 | INSUFFICIENT_CARDS | — | Global Accelerator的全球网络/就近健康端点与VoIP所需传输协议能力 |
| Q648 | SUPPORTED | 2 |  |
| Q649 | INSUFFICIENT_CARDS | — | RDS PostgreSQL gp3可满足15,000 IOPS的适用配置及相对io1的费用取舍 |
| Q650 | SUPPORTED | 1 |  |
| Q651 | INSUFFICIENT_CARDS | — | Glacier Instant Retrieval即时访问与Flexible的区别；Deep Archive满足12小时取回窗口的适用恢复模式 |
| Q652 | SUPPORTED | 2 |  |
| Q653 | SUPPORTED | 2 |  |
| Q654 | SUPPORTED | 4 |  |
| Q656 | CONDITIONAL | 4 | 需把年份→对象位置索引落实在既有网站，而非假设S3网站自身会按年检索 |
| Q658 | SUPPORTED | 1,5 |  |
| Q659 | INSUFFICIENT_CARDS | — | Snowball Edge具体离线运输能力与现行可用资格；50TB在既有剩余带宽/设备交付窗口下的可行比较 |
| Q660 | SUPPORTED | 4 |  |
| Q661 | SUPPORTED | 2 |  |
| Q662 | SUPPORTED | 4 |  |
| Q664 | INSUFFICIENT_CARDS | — | 未教会该低频突发形状下burstable与compute optimized的明确选择边界。 |
| Q666 | SUPPORTED | 2,5 |  |
| Q670 | INSUFFICIENT_CARDS | — | 4小时/周的闲置成本与可调预置容量如何比较；长期预留不适配的承诺利用逻辑。 |
| Q671 | SUPPORTED | 2 |  |
| Q672 | SUPPORTED | 2 |  |
| Q673 | INSUFFICIENT_CARDS | — | Deep Archive满足24小时取回所需的具体检索能力/模式。 |
| Q674 | SUPPORTED | 2,4 |  |
| Q677 | SUPPORTED | 1 |  |
| Q680 | INSUFFICIENT_CARDS | — | DataSync支持S3→S3及S3→EFS，以及只传变化文件/覆盖条件的具体任务模式。 |
| Q683 | SUPPORTED | 1,3 |  |
| Q684 | CONDITIONAL | 2 | 所选Local Zone的实际位置与其父Region依赖须符合法规；临近该Region本身不能证明。 |
| Q685 | SUPPORTED | 2 |  |
| Q686 | SUPPORTED | 3 |  |
| Q687 | CONDITIONAL | 4,5 | 必须已有Forecast使用资格，且数据和任务在Forecast支持范围内；原题没有提供资格。 |
| Q690 | SUPPORTED | 3,4 |  |
| Q691 | SUPPORTED | 2,5 |  |
| Q692 | SUPPORTED | 1 |  |
| Q693 | INSUFFICIENT_CARDS | — | DMS支持的源/目标及此未指明嵌入式NoSQL迁移适配；DynamoDB托管多AZ可用性没有在相关卡面明确教会。 |
| Q694 | INSUFFICIENT_CARDS | — | 购物车会话在Redis中的持久性、恢复和数据丢失边界；仅有副本不能证明任何时候都不丢。 |
| Q695 | SUPPORTED | 2 |  |
| Q698 | SUPPORTED | 2 |  |
| Q699 | SUPPORTED | 2 |  |
| Q700 | INSUFFICIENT_CARDS | — | GA支持公网客户端经内部NLB访问及低延迟跨RegionTCP/UDP路径。 |
| Q702 | INSUFFICIENT_CARDS | — | Snowball返回AWS后的导入目的地和是否能直接导入FSx。 |
| Q703 | SUPPORTED | 2 |  |
| Q704 | SUPPORTED | 3 |  |
| Q705 | SUPPORTED | 1,4 |  |
| Q706 | SUPPORTED | 2 |  |
| Q711 | SUPPORTED | 3 |  |
| Q713 | SUPPORTED | 2 |  |
| Q714 | INSUFFICIENT_CARDS | — | RequestCountPerTarget/ActiveConnectionCount与RequestCount/TargetResponseTime的含义及题中使用方式。 |
| Q715 | INSUFFICIENT_CARDS | — | AWS Budgets支持Savings Plans覆盖率预算与阈值通知。 |
| Q717 | SOURCE_ISSUE | — | 单选有至少A/D两种可行架构；若额外要求入口只走已有私网，D才唯一。 |
| Q718 | INSUFFICIENT_CARDS | — | EMR能否在Outposts实际运行及Hadoop/Spark适配。 |
| Q719 | SUPPORTED | 2 |  |
| Q720 | SUPPORTED | 3 |  |
| Q721 | SUPPORTED | 4 |  |
| Q722 | SUPPORTED | 1 |  |
| Q724 | SUPPORTED | 2 |  |
| Q725 | SUPPORTED | 2 |  |
| Q726 | SUPPORTED | 4 |  |
| Q727 | INSUFFICIENT_CARDS | — | DynamoDB表删除保护的实际能力与适用性。 |
| Q728 | INSUFFICIENT_CARDS | — | cached回源取回的延迟及费用是否满足无额外成本条件。 |
| Q729 | SUPPORTED | 2 |  |
| Q730 | SUPPORTED | 1 |  |
| Q731 | SUPPORTED | 3 |  |
| Q734 | INSUFFICIENT_CARDS | — | Direct Connect gateway跨Region关联和VPC/机房之间的实际转接范围。 |
| Q735 | CONDITIONAL | 1 | 如果“按接收顺序”指同一玩家/业务键，应使用稳定partition key并有序消费；若要求所有玩家全局顺序，还需单一顺序域且峰值在其容量内，原题未明确。 |
| Q736 | INSUFFICIENT_CARDS | — | S3 Same-Region Replication的同Region跨账户能力。 |
| Q737 | SUPPORTED | 3,5 |  |
| Q738 | INSUFFICIENT_CARDS | — | 就近Region上传与Transfer Acceleration的延迟边界；CloudFront分发对上传实际起的作用。 |
| Q739 | SUPPORTED | 2 |  |
| Q740 | SOURCE_ISSUE | — | 若原意只是customer-managed KMS key，仍须改写方案为对象清单驱动的SSE-KMS批量复制及默认SSE-KMS；现有选项不直接给出该完整组合。 |
| Q741 | SUPPORTED | 1 |  |
| Q744 | SUPPORTED | 1 |  |
| Q746 | SUPPORTED | 1,3 |  |
| Q747 | SUPPORTED | 3 |  |
| Q752 | INSUFFICIENT_CARDS | — | SQS FIFO具体去重窗口、投递/重试保证，以及其与业务幂等的边界。 |
| Q753 | SUPPORTED | 1 |  |
| Q754 | SUPPORTED | 2 |  |
| Q755 | SUPPORTED | 2 |  |
| Q757 | SUPPORTED | 3 |  |
| Q758 | SUPPORTED | 1 |  |
| Q759 | INSUFFICIENT_CARDS | — | Flexible Retrieval expedited/bulk与1–10GB对象的取回时间和成本边界。 |
| Q760 | SUPPORTED | 3 |  |
| Q762 | SUPPORTED | 3 |  |
| Q763 | INSUFFICIENT_CARDS | — | 具体离线设备资格、容量与运输导入期限。 |
| Q767 | SOURCE_ISSUE | — | 若原应用必须iSCSI块卷，则C；若需SMB/NFS文件接口则B。原题未给这个决定条件。 |
| Q768 | SUPPORTED | 1 |  |
| Q769 | SUPPORTED | 2 |  |
| Q770 | SUPPORTED | 3 |  |
| Q771 | SUPPORTED | 3 |  |
| Q772 | SUPPORTED | 1,2 |  |
| Q773 | SUPPORTED | 4 |  |
| Q776 | INSUFFICIENT_CARDS | — | Redis快照与亚毫秒响应适用性。 |
| Q778 | INSUFFICIENT_CARDS | — | Snowball当前使用资格、设备并行容量和4周交付；与Snowmobile适用规模的区分。 |
| Q781 | INSUFFICIENT_CARDS | — | cost budget与usage budget的计量和阈值区别；题面usage措辞是否误写。 |
| Q784 | SUPPORTED | 3 |  |
| Q785 | INSUFFICIENT_CARDS | — | FIFO去重窗口/重投语义；C须明确实际执行稳定业务ID的原子幂等，而非仅更换队列。 |
| Q786 | CONDITIONAL | 2 | 须已有Application Discovery Service使用资格；新客户要评估Transform路径，原题没有交代资格。 |
| Q788 | SUPPORTED | 3 |  |
| Q790 | SUPPORTED | 2,5 |  |
| Q792 | SUPPORTED | 1 |  |
| Q794 | SUPPORTED | 2 |  |
| Q795 | SUPPORTED | 2,4 |  |
| Q796 | SUPPORTED | 2 |  |
| Q798 | SUPPORTED | 2 |  |
| Q799 | SUPPORTED | 1 |  |
| Q800 | INSUFFICIENT_CARDS | — | 跨账户Lambda→EFS服务集成的实际支持路径及B/C成本适配。 |
| Q802 | SUPPORTED | 4 |  |
| Q804 | INSUFFICIENT_CARDS | — | Redshift Serverless的MPP仓库能力与服务托管范围。 |
| Q806 | SUPPORTED | 2 |  |
| Q807 | SUPPORTED | 2 |  |
| Q809 | SUPPORTED | 1 |  |
| Q812 | INSUFFICIENT_CARDS | — | DataBrew的数据谱系与数据剖析能力。 |
| Q813 | SUPPORTED | 1 |  |
| Q814 | SUPPORTED | 2 |  |
| Q815 | INSUFFICIENT_CARDS | — | Global Accelerator优化全球用户到现有多Region NLB路径的机制。 |
| Q816 | SUPPORTED | 2 |  |
| Q817 | SUPPORTED | 3 |  |
| Q818 | SUPPORTED | 1 |  |
| Q819 | SUPPORTED | 2 |  |
| Q820 | SUPPORTED | 3 |  |
| Q822 | SUPPORTED | 1 |  |
| Q823 | SUPPORTED | 3 |  |
| Q824 | SUPPORTED | 3 |  |
| Q827 | CONDITIONAL | 4 | 需实测或估算I/O费用占比及总账单，确认适用I/O-Optimized；不能仅凭流量大作无条件最低成本承诺。 |
| Q829 | SUPPORTED | 1 |  |
| Q830 | SUPPORTED | 2 |  |
| Q831 | SUPPORTED | 4 |  |
| Q834 | SUPPORTED | 3 |  |
| Q835 | SUPPORTED | 1 |  |
| Q836 | SUPPORTED | 2 |  |
| Q837 | SUPPORTED | 3 |  |
| Q840 | INSUFFICIENT_CARDS | — | GA对全球TCP上传/RTMP的加速机制。 |
| Q841 | INSUFFICIENT_CARDS | — | Archive/Standard完整与共享块实际计量及费用，含月度变更块重叠与恢复费用。 |
| Q842 | INSUFFICIENT_CARDS | — | AWS Backup对EFS的备份与跨Region复制支持。 |
| Q843 | SUPPORTED | 3 |  |
| Q844 | SUPPORTED | 4 |  |
| Q845 | SUPPORTED | 3 |  |
| Q846 | SUPPORTED | 2 |  |
| Q848 | INSUFFICIENT_CARDS | — | RDS Custom for Oracle实际引擎/许可与所需特权功能适配。 |
| Q849 | SUPPORTED | 2 |  |
| Q852 | SUPPORTED | 2 |  |
| Q857 | SUPPORTED | 1 |  |
| Q858 | SUPPORTED | 3 |  |
| Q859 | INSUFFICIENT_CARDS | — | Trusted Advisor的RDS Reserved Instance Optimization检查及成员/管理账户建议范围。 |
| Q861 | SUPPORTED | 1 |  |
| Q863 | INSUFFICIENT_CARDS | — | RDS自动备份保留窗口包括30天及自动每日备份能力。 |
| Q864 | SUPPORTED | 3 |  |
| Q865 | SUPPORTED | 1,5 |  |
| Q867 | INSUFFICIENT_CARDS | — | Compute Optimizer EBS建议包含预计月节省机会的能力。 |
| Q869 | INSUFFICIENT_CARDS | — | FIFO去重窗口/Lambda队列消费；必须实际实现已教业务ID原子幂等。 |
| Q871 | SUPPORTED | 1 |  |
| Q874 | SUPPORTED | 1 |  |
| Q876 | SUPPORTED | 2,4 |  |
| Q877 | SUPPORTED | 2 |  |
| Q879 | SUPPORTED | 1,3 |  |
| Q880 | SUPPORTED | 2 |  |
| Q881 | INSUFFICIENT_CARDS | — | CloudFront default TTL、max-age、invalidation及事件阶段的缓存效果。 |
| Q882 | SUPPORTED | 3 |  |
| Q885 | INSUFFICIENT_CARDS | — | Compute Savings Plans包括Fargate；SageMaker Savings Plans适用范围。 |
| Q886 | SUPPORTED | 2,3 |  |
| Q888 | SUPPORTED | 1 |  |
| Q889 | SUPPORTED | 2 |  |
| Q890 | INSUFFICIENT_CARDS | — | Glacier Instant Retrieval即时读取、耐久部署及5MB/长留存成本比较。 |
| Q891 | INSUFFICIENT_CARDS | — | MRAP的AWS网络加速路径与active-active失败路由能力。 |
| Q892 | SUPPORTED | 1 |  |
| Q894 | SUPPORTED | 1 |  |
| Q895 | SUPPORTED | 4 |  |
| Q896 | INSUFFICIENT_CARDS | — | Aurora global database复制与managed failover实际能力，及目标下的演练时长。 |
| Q897 | SUPPORTED | 1 |  |
| Q899 | SUPPORTED | 4 |  |
| Q900 | SOURCE_ISSUE | — | 若要求HTTP字段路由等L7功能，则A+B唯一；仅转发HTTP应用连接时A+C亦可。 |
| Q901 | SUPPORTED | 2 |  |
| Q902 | SOURCE_ISSUE | — | 若额外要求自动维护容量，则A优于C；当前单选条件不唯一。 |
| Q904 | INSUFFICIENT_CARDS | — | S3事件到SQS和Lambda SQS事件源映射/受管消费。 |
| Q905 | INSUFFICIENT_CARDS | — | GA全球优化网络到多Region负载均衡器的机制。 |
| Q906 | SUPPORTED | 3 |  |
| Q909 | SUPPORTED | 4 |  |
| Q910 | INSUFFICIENT_CARDS | — | EC2 detailed monitoring的1分钟粒度及与默认5分钟区别。 |
| Q911 | SUPPORTED | 3 |  |
| Q912 | SUPPORTED | 4 |  |
| Q914 | SUPPORTED | 2 |  |
| Q915 | INSUFFICIENT_CARDS | — | Redis持久化、恢复和重启数据保留边界。 |
| Q917 | SUPPORTED | 4 |  |
| Q918 | INSUFFICIENT_CARDS | — | Glacier Instant Retrieval能力与DataSync存储层支持，打包/转层总成本。 |
| Q919 | INSUFFICIENT_CARDS | — | io1具体IOPS上限/容量关系，以及实例EBS吞吐余量。 |
| Q920 | SUPPORTED | 4 |  |
| Q921 | SUPPORTED | 1 |  |
| Q923 | SUPPORTED | 2,5 |  |
| Q926 | INSUFFICIENT_CARDS | — | Compute Optimizer对ECS Fargate服务/任务rightsizing的支持。 |
| Q930 | CONDITIONAL | 1 | 提取程序须能在Lambda支持环境/资源/时长内以允许的封装方式运行且不改原业务代码；100% uptime是目标，不是架构已实测或服务保证。 |
| Q933 | SUPPORTED | 1 |  |
| Q934 | INSUFFICIENT_CARDS | — | FSx for ONTAP Multi-AZ部署的AZ级冗余能力。 |
| Q935 | SUPPORTED | 2,3 |  |
| Q937 | INSUFFICIENT_CARDS | — | Compute Optimizer对Auto Scaling groups的建议范围。 |
| Q938 | INSUFFICIENT_CARDS | — | EFS私网数据路径与题中所需接口/性能的决定条件。 |
| Q939 | CONDITIONAL | 2 | 缩小后须仍能重放写入并满足读延迟/未来增长，核对CPU之外内存、I/O与lag。 |
| Q940 | INSUFFICIENT_CARDS | — | EC2 Instance Savings Plans范围、1/3年及支付方式折扣条件。 |
| Q943 | CONDITIONAL | 3 | 若必须完整回报过去3个月，需有历史标签和可用回填条件；不能将新激活直接冒充旧期间完整明细。 |
| Q944 | SUPPORTED | 2 |  |
| Q946 | SUPPORTED | 1 |  |
| Q948 | SUPPORTED | 2 |  |
| Q953 | CONDITIONAL | 1 | 原始图片完成首次生成用途后归档，半年度训练允许提前恢复；若原图仍需即时重生成，则需另选即时层。 |
| Q954 | SUPPORTED | 4 |  |
| Q955 | SUPPORTED | 1 |  |
| Q956 | INSUFFICIENT_CARDS | — | GIR最低计费/读取与S3 Standard首30天比较；归档期总成本。 |
| Q957 | CONDITIONAL | 2,4 | 实际机房到所选AWS接入/Region路径必须达到单数字毫秒；该条件需网络测量，非卡片可保证固定SLA。 |
| Q958 | SUPPORTED | 1 |  |
| Q959 | INSUFFICIENT_CARDS | — | State Manager关联执行RDS启动/停止自动化的支持/维护范围与Lambda调度比较。 |
| Q960 | SUPPORTED | 1 |  |
| Q961 | SUPPORTED | 3 |  |
| Q962 | SUPPORTED | 2 |  |
| Q963 | SUPPORTED | 3 |  |
| Q964 | SUPPORTED | 4 |  |
| Q967 | INSUFFICIENT_CARDS | — | FIFO去重与消费重试语义，及业务幂等的实际结合。 |
| Q968 | SUPPORTED | 4 |  |

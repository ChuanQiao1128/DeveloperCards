from question_review_lib import *
import collections,copy
skill=pathlib.Path('/Users/qc/.codex/skills/aws-card-count-verify/SKILL.md');sb=skill.read_bytes();sh=sha(sb);assert sh=='ed4d17efa77d0a2908ec1ef5a7ce28ffdae033ec121209c3fe16bcbd2af4e724'
sp=R/'input/skill-forward-check.current.snapshot.md';assert not sp.exists();sp.write_bytes(sb)
parts=[R/f'results-part{i:02d}.json' for i in range(1,11)];raw=[q for f in parts for q in json.loads(f.read_text())['results']]
assert [q['qid'] for q in raw]==[x['qid'] for x in cases] and len(set(q['qid'] for q in raw))==220
old=next(q for q in raw if q['qid']==755);assert old['status']=='CONDITIONAL'
new=result(755,'SUPPORTED',[2],[an('CUR:CB18','减少连接风暴，也降低后端角色变化对客户端的影响','同一方案同时针对连接过多与切换客户端恢复')],'RDS Proxy是所有选项中同时保留当前Aurora关系模型、管理连接风暴并减少writer角色变化对客户端影响的方案，B的选型可由实际卡句唯一推得。20%是该部署的优化目标；本复核不把选型知识等同已实测达标，也不因缺生产测量要求再补卡。',{'optionOrdinal':1,'explanation':'更换数据库部署未提供连接池层；C改变数据模型，D分析仓库迁移不解决当前Aurora连接恢复。'},conditions=['生产20%实际改善需单独测量；此项不降低已充分的原题架构选型知识支撑。'])
new['selectionVsImplementation']={'selectionKnowledge':'SUPPORTED from the frozen visible body','productionMeasurement':'NOT_MEASURED: 20% failover improvement remains an implementation target, not a claimed measured result.'}
repair={'schemaVersion':1,'reviewer':'actual_cards_review','repairId':'questions-c-forward01','reason':'Current Skill explicitly distinguishes architecture-selection knowledge from measured production SLA. Only Q755 was reconsidered in this targeted hard-condition forward check.','questionId':755,'previousArtifact':str(R/'results-part04.json'),'previousArtifactSha256':sha((R/'results-part04.json').read_bytes()),'previousResult':old,'currentResult':new,'skillPath':str(skill),'skillSnapshotPath':str(sp),'skillSha256':sh,'caseManifestPath':str(MP),'caseManifestSha256':sha(MP.read_bytes()),'cardsRemainFrozen':True,'historyPreserved':True,'contentAuthoring':False}
rp=R/'repair-forward01.json';assert not rp.exists();rp.write_text(json.dumps(repair,ensure_ascii=False,indent=2)+'\n')
current=[new if q['qid']==755 else q for q in raw]
counts=dict(collections.Counter(q['status'] for q in current))
for q in current:
 c=byq[q['qid']];assert q['questionSha256']==sha(ca(c['question']))
 valid={o['ordinal'] for o in c['question']['options']};assert set(q['selectedOptionOrdinals'])<=valid and set(q['candidateOptionOrdinals'])<=valid
 if q['status']=='SUPPORTED':assert q['selectedOptionOrdinals']
 if 'choose two' in c['question']['stem'].lower() and q['status']=='SUPPORTED':assert len(q['selectedOptionOrdinals'])==2,q['qid']
 assert 'GCL-020' not in q['usedRuleIds']
 assert set(q['providedVisibleCardBindings'])=={v['ruleId'] for v in c['visibleCards']}
 for rid,h in {**q['providedVisibleCardBindings'],**q['additionalVisibleCardBindings']}.items():assert cards[rid]['bodySha256']==h
 for a in q['necessaryAnchors']:
  body=cards[a['cardId']];assert body['bodySha256']==a['bodySha256'];assert body['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']]==a['quote'];assert a['supports']
 assert set(q['usedRuleIds'])=={a['cardId'] for a in q['necessaryAnchors']}
 for e in q.get('officialSourceIssueEvidence',[]):
  p=pathlib.Path(e['path']);assert sha(p.read_bytes())==e['fileSha256'];d=json.loads(p.read_text());assert d['url']==e['url'];assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
 if q['status']=='SOURCE_ISSUE':assert q.get('officialSourceIssueEvidence'),q['qid']
report={'schemaVersion':1,'reviewer':'actual_cards_review independent current-visible-card backtest','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exactly 220 original questions in questions-c v3; design-level selection support from frozen visible Chinese bodies, not learner accuracy, not global coverage or final N.','inputVersion':'cases01.v3','inputManifestPath':str(MP),'inputManifestSha256':sha(MP.read_bytes()),'inputFiles':M,'globalAdditionalPoolBinding':B,'initialParts':[{'path':str(f),'sha256':sha(f.read_bytes())} for f in parts],'targetedRepairs':[{'path':str(rp),'sha256':sha(rp.read_bytes())}],'questionCount':220,'statusCounts':counts,'results':current,'historyPreserved':True,'cardBodiesChanged':False,'sourceIssuesAreUnacceptedExceptions':True,'globalCompletion':False,'finalN':None}
op=R/'results.json';assert not op.exists();op.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
check={'schemaVersion':1,'outcome':'PASS','completedQuestionCount':220,'uniqueQuestionCount':220,'pending_ids':[],'checks':{'inputManifestsUnchanged':True,'exactCaseOrderAndDenominator':True,'canonicalQuestionHashes':True,'allOptionsRead':True,'selectedOrdinalsValid':True,'supportedMultiSelectCardinality':True,'allVisibleBindingsMatch355Snapshot':True,'allLiteralCardQuotesAndOffsets':True,'allSourceIssueQuotesOffsetsAndFileHashes':True,'quarantinedGCL020Absent':True,'initialFailuresAndConditionalHistoryPreserved':True,'noCardEdits':True,'noProductionPointersOrBudgetsChanged':True},'resultsPath':str(op),'resultsSha256':sha(op.read_bytes()),'statusCounts':counts,'sourceIssueIds':[q['qid'] for q in current if q['status']=='SOURCE_ISSUE'],'skillForwardCheck':{'skillSnapshotPath':str(sp),'skillSha256':sh,'hardConditionQuestion':755,'ordinarySelectionQuestion':958,'targetedRepairPath':str(rp)},'scopeLimitation':'PASS confirms this shard artifact integrity; 220 review attempts do not establish full 1018-question coverage, learner accuracy, global deletion or final N.'}
(R/'final-readback.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n')
state={'phase':'independent_question_backtest_shard_complete','inputVersion':'cases01.v3','inputManifestSha256':sha(MP.read_bytes()),'current_artifacts':[str(op),str(R/'final-readback.json'),str(rp),str(R/'skill-forward-check.md')],'completedQuestionCount':220,'pending_ids':[],'statusCounts':counts,'findings':[{'qid':q['qid'],'status':q['status'],'missingJudgments':q['missingJudgments'],'conditionsAndSourceIssues':q['conditionsAndSourceIssues']} for q in current if q['status']!='SUPPORTED'],'attempts':{'initialReviewParts':10,'targetedReviewRepairs':1,'cardAuthoringCalls':0,'historyPreserved':True},'next_action':'Parent may aggregate this 220-question shard, resolve actual teaching gaps/conditions/source issues and recheck affected dependencies. Full-library proof and final N remain open.','globalCompletion':False}
(R/'state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
assert skill.read_bytes()==sb
print(json.dumps(check,ensure_ascii=False))

import pathlib,json,hashlib,datetime,collections,re
P=pathlib.Path(__file__).parent;V=P.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
read=lambda p:json.loads(p.read_text())
m=read(P/'input/manifest.json')
for f,h in m.items():assert sha(pathlib.Path(f))==h,f
A=read(P/'input/cases.json');C={x['ruleId']:x for x in read(P/'input/core-visible.frozen.json')};D={x['qid']:x for x in read(P/'decisions.json')}
assert len(A)==len(D)==10 and len(C)==362
ctxpath=V/'validation/immutable-contexts/6a53dad40c630921024eb5a971cb7581b309211fc2376f8e967475ae6a5d0a58.json';ctx=read(ctxpath);orig={int(x['qid']):x for x in ctx['results']}
for c in C.values():assert canon(c['visibleBody'])==c['bodySha256']
# Freeze read-only current FACT index as an explicit additional context, not a replacement of original input.
indexPath=V/'validation/current-card-review-index.json';idx=read(indexPath);I={x['ruleId']:x for x in idx['cards']};(P/'card-review-index.readonly-snapshot.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
E={}
for key,x in ctx['officialSources'].items():
 if any(key in d.get('evidenceIds',[]) for d in D.values()) or 'snowmobile' in str(x).lower():
  p=pathlib.Path(x['snapshotPath']);o=read(p);t=o['text'];assert sha(p)==x['snapshotSha256'];assert hashlib.sha256(t.encode()).hexdigest()==x['textSha256'];assert t[x['quoteStart']:x['quoteEnd']]==x['quote']
  E[key]={'url':x['url'],'path':str(p),'sha256':sha(p),'textSha256':x['textSha256'],'quote':x['quote'],'start':x['quoteStart'],'end':x['quoteEnd'],'origin':'reused immutable independent source record'}
def ev(k,name,quote):
 p=P/'evidence'/name;o=read(p);t=o['text'];assert quote in t,(k,quote);at=t.index(quote);assert hashlib.sha256(t.encode()).hexdigest()==o['textSha256']
 E[k]={'url':o['url'],'path':str(p),'sha256':sha(p),'textSha256':o['textSha256'],'quote':quote,'start':at,'end':at+len(quote),'origin':'targeted independent scope validation for Q687'}
ev('AUTOPILOT_TS_TRAIN_ENDPOINT','sagemaker-autopilot-timeseries.snapshot.json','automatically deploy your forecast model to an endpoint. To\n          enable automatic deployment for the best model candidate of an AutoML job, include a\nModelDeployConfig\nin the AutoML job request.')
ev('AUTOPILOT_TS_DEPLOY','sagemaker-timeseries-deploy.snapshot.json','After training your models using the AutoML API, you can deploy them for real-time or\n      batch-based forecasting.')
ev('AUTOPILOT_TS_INTERACTIVE_ENDPOINT','sagemaker-timeseries-deploy.snapshot.json','either set up an endpoint to\n      obtain forecasts interactively or use batch forecasting to make predictions on a batch of\n      observations.')
ev('AUTOMLV2_API_SCOPE','sagemaker-api-automlv2.snapshot.json','ModelDeployConfig\nSpecifies how to generate the endpoint name for an automatic one-click Autopilot model\n         deployment.')
apiText=read(P/'evidence/sagemaker-api-automlv2.snapshot.json')['text']
apiAt=apiText.index('DataSplitConfig\nThis structure')
apiEnd=apiText.index('ModelDeployConfig\nSpecifies',apiAt)
ev('AUTOMLV2_DATASPLIT_LIMIT','sagemaker-api-automlv2.snapshot.json',apiText[apiAt:apiEnd].rstrip())
(P/'source-evidence.json').write_text(json.dumps({'evidence':E,'scope':'original defects and same-task scope proof; no original-answer reuse'},ensure_ascii=False,indent=2)+'\n')
R=[];usedAll=set();receiptPaths={}
for item in A:
 qid=item['originalQid'];d=D[qid];oq=item['originalQuestion'];cq=item['correctedQuestion'];assert canon(oq)==item['originalQuestionCanonicalSha256'];assert canon(cq)==item['correctedQuestionCanonicalSha256'];assert orig[qid]['questionSha256']==canon(oq)
 assert orig[qid]['sourceIssue']['confirmed'] and orig[qid]['status']=='SOURCE_ISSUE'
 lines=cq['stem'].splitlines(keepends=True);adds=[s for s in lines if s.startswith('For this practice only:')];assert len(adds)==1
 stripped=''.join(s for s in lines if not s.startswith('For this practice only:'));assert stripped==oq['stem']
 assert cq['options']==oq['options'] and cq['qid']==oq['qid']
 sourceOriginal={'path':str(ctxpath),'sha256':sha(ctxpath),'recordQid':qid,'recordSha256':canon(orig[qid]),'originalQuestionCanonicalSha256':canon(oq),'originalSourceStatus':'SOURCE_ISSUE','confirmed':True,'missingDecisiveInput':orig[qid]['sourceIssue']['missingDecisiveInput'],'sourceEvidenceIds':[k for k in d['evidenceIds'] if k in ctx['officialSources']]}
 used=[]
 def visit(r):
  if r in used:return
  used.append(r)
  for x in C[r].get('prerequisiteRuleIds',[]):visit(x)
 for rid in d['ids']:visit(rid)
 anchors=[];bindings=[]
 for rid in used:
  c=C[rid];i=I[rid];assert i['status']=='PASS' and i['currentBodySha256']==c['bodySha256'],rid
  for pr in i['proofs']:
   if pr['path'] not in receiptPaths:receiptPaths[pr['path']]=sha(pathlib.Path(pr['path']))
   assert receiptPaths[pr['path']]==pr['sha256'],pr['path']
  bindings.append({'ruleId':rid,'bodySha256':c['bodySha256'],'prerequisiteRuleIds':c.get('prerequisiteRuleIds',[]),'currentIndependentFactStatus':'PASS','currentIndependentFactProofs':i['proofs']})
  for f,q in c['visibleBody'].items():
   if q:anchors.append({'ruleId':rid,'field':f,'quote':q,'bodySha256':c['bodySha256'],'start':0,'end':len(q),'offsetUnit':'unicode codepoints','role':'necessary card scope / conclusion / mechanism / declared prerequisite'})
 usedAll.update(used)
 status=d['status'];eligible=status=='SUPPORTED'
 rec={'variantId':item['variantId'],'originalQid':qid,'status':status,'minimality':{'status':'PASS','reason':d['minimalityReason'],'originalTextPreservedByRemovingOnePracticeLine':True,'originalOptionsIdentical':True,'businessAndOptimizationObjectivePreserved':True,'practiceOnlyMarkerPresent':True,'newFieldsAreExerciseInputsNotRecoveredOriginalFacts':True,'arbitraryToolPreferenceAdded':False,'insertedPracticeField':adds[0].rstrip('\n')},'originalQuestionCanonicalSha256':canon(oq),'correctedQuestionCanonicalSha256':canon(cq),'questionHashContract':'SHA256 UTF-8 canonical JSON of qid/stem/all ordinal-label-text options; ensure_ascii=false sort_keys=true compact','originalSourceDefect':sourceOriginal,'originalQualificationDefectClosedByExplicitInput':True,'closureEligible':eligible,'wholeQuestionCurrentCardGroupStatus':'SUPPORTED_UNIQUE_CHOICE' if eligible else 'FAIL_UNRESOLVED_MULTIPLE_VALID_MANAGED_PATHS','selectedOptionOrdinals':d['selected'],'selectedOrdinalsMeaning':'accepted corrected-practice choice only; no original promotion' if eligible else 'no accepted unique combination','candidateValidOptionCombinations':d.get('validCombinations',[]),'usedRuleIds':d['ids'],'recursiveUsedRuleIds':used,'recursivePrerequisiteRuleIds':[r for r in used if r not in d['ids']],'dependencyEdges':[{'from':r,'to':p} for r in used for p in C[r].get('prerequisiteRuleIds',[])],'necessaryAnchors':anchors,'cardBindings':bindings,'reason':d['reason'],'nearestCompetitionReasoning':d['competition'],'optionJudgments':[{'ordinal':o['ordinal'],'originalLabel':o['originalLabel'],'optionTextSha256':hashlib.sha256(o['text'].encode()).hexdigest(),'reason':reason} for o,reason in zip(cq['options'],d['optionReasons'])],'allOriginalAndCorrectedOptionsRead':True,'officialEvidenceIds':d['evidenceIds'],'failures':d.get('failures',[]),'followup':d.get('followup'),'normalImplementationAndProductionSLAValidationNotBlocking':True,'originalStatusUpgraded':False,'currentOrInventoryChanged':False,'newCardAuthored':False,'learnerMemoryOrAccuracyMeasured':False}
 if qid==687:
  rec['sameTaskSageMakerScopeCheck']={'status':'CONFIRMED_TIME_SERIES_ENDPOINT_NOT_GENERIC_STITCHING','trainingSource':'AUTOPILOT_TS_TRAIN_ENDPOINT','deploymentSource':'AUTOPILOT_TS_DEPLOY','interactiveEndpointSource':'AUTOPILOT_TS_INTERACTIVE_ENDPOINT','apiModelDeploySource':'AUTOMLV2_API_SCOPE','dataSplitNoteScope':'The TS do-not-set restriction belongs to DataSplitConfig, not ModelDeployConfig.','concreteCommonDataset':'36 monthly rows per resource_id, timestamp and target_value in S3 CSV; same supported monthly demand series, no manual algorithm design required.','alternativeAB':'Create AutoML V2 TimeSeriesForecastingJobConfig with monthly frequency, train/select model automatically, deploy that TS BestCandidate as a SageMaker endpoint and invoke forecasts.','alternativeDE':'Qualified Forecast customer trains supported predictor and Lambda function URL wraps supported forecast creation/query APIs.','genericTabularEndpointDocumentUsedAsDecisiveProof':False,'privateNewCapabilityPretendedAlreadyTaught':False,'cardFailureMeaning':'GSC109 may recommend dedicated Forecast over manual modeling, but does not prove SageMaker AutoML impossible. No current card-group unique-choice acceptance.'}
  rec['officialEvidenceIds']+=['AUTOPILOT_TS_INTERACTIVE_ENDPOINT','AUTOMLV2_DATASPLIT_LIMIT']
 if qid in [215,398,763,778]:
  params={215:(700e12,500e6,31),398:(600e12,100e6,14),763:(150e12,100e6,31),778:(1e15,2e9,28)}[qid];data,bps,days=params
  rec['deterministicFeasibility']={'byteConvention':'decimal TB/PB; binary units would only increase these transfer lower bounds','dataBytesPerSite':int(data),'optimisticContinuousBitsPerSecond':int(bps),'deadlineDaysOptimisticallyUsed':days,'onlineIdealLowerBoundDays':data*8/bps/86400,'maxOnlinePayloadTBWithinDeadline':bps*days*86400/8/1e12,'onlineCannotMeetDeadline':data*8/bps>days*86400,'nightOnlyLimitIgnoredConservatively':qid==763,'siteCount':80 if qid==778 else 1,'offlineUsableCapacityAndWholeWorkflowDeadlineAreExplicitPracticeGivens':True}
  if qid in [398,778]:rec['newDXProjectInputCheck']={'carrierEstimateWeeks':6,'carrierEstimateDays':42,'deadlineDays':days,'estimateExceedsDeadline':42>days,'notAnAWSUniversalLeadTimeClaim':True,'notJustAServicePreference':True,'notWrittenBackIntoOriginal':True}
 R.append(rec)
counts=dict(collections.Counter(r['status'] for r in R));out={'reviewId':'corrected-variants13','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'independent_native','scope':'10 minimal corrected practices, originals read unchanged; current362 after18','inputManifestSha256':sha(P/'input/manifest.json'),'inputHashes':m,'additionalReadOnlyFactIndexSnapshot':{'path':str(P/'card-review-index.readonly-snapshot.json'),'sha256':sha(P/'card-review-index.readonly-snapshot.json'),'readFromPath':str(indexPath)},'currentFrozenCoreCount':len(C),'coreCountIsFinalN':False,'counts':{'reviewed':len(R),'minimalityPASS':10,'closureEligible':sum(r['closureEligible'] for r in R),'status':counts},'sourceEvidencePath':str(P/'source-evidence.json'),'sourceEvidenceSha256':sha(P/'source-evidence.json'),'uniqueActuallyUsedRulesIncludingRecursive':len(usedAll),'independentFactReceiptFiles':len(receiptPaths),'results':R,'originalQuestionOrStatusChanged':False,'currentInventoryOrPointersChanged':False,'newCardsAuthored':0,'correctedVariantsAuthoredByReviewer':0,'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','subagentsSpawned':0,'priorClockBudgetCountersHistoryReset':False,'publishingOrOTA':False,'formalBilingualOrFinalNAccepted':False,'learnerOutcomeMeasured':False}
(P/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out['counts']);print('rules',len(usedAll),'FACT files',len(receiptPaths));print('results sha',sha(P/'results.json'))

13组10个最小修正版已独立验收：**9个可闭合，Q687-CV13因仍有其他有效托管预测路线而FAIL**。10项最小性均PASS；补资格没有自动变成整题通过。原文状态未升级。

| 练习 | 当前卡组选择 | closureEligible |
| --- | --- | --- |
| Q064-CV13 | D：FSx共享后端＋机房FSx File Gateway缓存 | true |
| Q215-CV13 | A：合格离线设备＋Deep Archive | true |
| Q295-CV13 | B：Object Lambda按应用在读取时脱敏 | true |
| Q398-CV13 | C：合格加密离线设备；新DX六周不及两周 | true |
| Q687-CV13 | D+E可行，A+B也可行，未接受唯一组合 | **false** |
| Q756-CV13 | ordinal 1：Object Lambda access point读取时脱敏 | true |
| Q763-CV13 | B：合格当前Snowball设备 | true |
| Q778-CV13 | B：80处分别的合格设备/容量；新DX不及四周 | true |
| Q786-CV13 | B：既有合格ADS/Migration Hub发现项目 | true |
| Q969-CV13 | A：受支持App2Container工件＋ECS/Fargate | true |

所有修订都只插入一行明确的“For this practice only”输入。删除该行后，原题干逐字恢复，所有原选项、原业务场景及优化目标保留。Q756原ordinal 3的重复B标签也未被修改，选择始终按ordinal记录。

398/778的新DX六周交付是练习项目的承运输入，分别超过14/28天期限；不是AWS统一交付承诺，也不是“偏好Snowball”字段。离线设备合计可用容量与复制/运输/导入全流程及时完成均由练习明确给定。保守在线下限为215约129.6天、398约555.6天、763即使全天亦138.9天、778每处以2Gbps全天亦46.3天；763夜间限制只会更紧。没有再要求用户做生产SLA才能通过。

Q687的失败已核同一任务范围。官方**时序专页**说明AutoML训练后可部署进行实时或批量预测，也明确可设endpoint交互取得forecast；并非把generic tabular AutoML自动部署能力套给时序模型。见[时序模型部署](https://docs.aws.amazon.com/sagemaker/latest/dg/timeseries-forecasting-deploy-models.html)及[时序训练/自动部署](https://docs.aws.amazon.com/sagemaker/latest/dg/autopilot-create-experiment-timeseries-forecasting.html)。API的“时序不能设置”限制属于DataSplitConfig，而非ModelDeployConfig，已用[CreateAutoMLJobV2](https://docs.aws.amazon.com/sagemaker/latest/APIReference/API_CreateAutoMLJobV2.html)字段正文核对。

同一S3 CSV可包含36个月、按resource_id/timestamp/target_value组织的制造需求时序。A+B可用Autopilot自动训练/选模型并部署该TS模型的endpoint；D+E则使用已合格Forecast和Lambda包装其适用生成/查询API。原题只要求没有ML经验且训练预测托管，没有唯一排除SageMaker AutoML的约束。当前GSC-109建议优先评估专用Forecast，不能把这个建议变成“SageMaker所有模式都要手工建模”。因此687资格缺陷已补，整题仍不闭合；建议保留失败，若改为选择全部路线，还须核卡组对相应SageMaker能力的实际教学支撑，不能仅加“必须Forecast”的工具偏好。

969已复用AWS现行支持矩阵明确的ASP.NET (Windows, Linux)正证，没有用假设创造不存在的平台组合。App2Container负责打包及部署工件，不被说成自动重写任意应用；ECS/Fargate运行容器并按CloudWatch指标扩任务。关闭新客户的服务均按既有合格客户继续服务处理，没有一概称为全面退役。

`results.json`含两份完整题hash、逐项最小性、原缺陷正证、必要句/当前hash、递归依赖和全部选项判断。19个实际使用卡（含递归先修）与13份当前独立FACT凭证绑定；`source-evidence.json`另绑定资格及同任务时序正证。`readback.json`仅核验本10项，不升级原题或最终N。

未改原文、当前卡、库存、生产指针和预算历史；无新卡或练习作者调用，CLI/API模型调用0，native用量unknown。通过仅指当前中文卡组对修正版的设计支撑，未量测学习者效果。

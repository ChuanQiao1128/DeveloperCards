import pathlib,json,hashlib,datetime,collections,re,math
P=pathlib.Path(__file__).parent;V=P.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
read=lambda p:json.loads(p.read_text())
checks=[]
def ck(name,ok):
 assert ok,name
 checks.append({'check':name,'status':'PASS'})
m=read(P/'input/manifest.json')
for f,h in m.items():ck('frozen input '+pathlib.Path(f).name,sha(pathlib.Path(f))==h)
R=read(P/'results.json');A={x['variantId']:x for x in read(P/'input/cases.json')};C={x['ruleId']:x for x in read(P/'input/core-visible.frozen.json')};I={x['ruleId']:x for x in read(P/'card-review-index.readonly-snapshot.json')['cards']}
ck('ten variants exactly',len(A)==len(R['results'])==len({x['variantId'] for x in R['results']})==10 and set(A)=={x['variantId'] for x in R['results']})
ck('362 frozen current core',len(C)==362)
ck('nine closures one explicit failure',sum(x['closureEligible'] for x in R['results'])==9 and R['counts']['closureEligible']==9 and R['counts']['status']=={'SUPPORTED':9,'FAIL_AMBIGUOUS':1})
ck('ten minimality pass',all(x['minimality']['status']=='PASS' for x in R['results']))
ck('FACT index additional snapshot',sha(P/'card-review-index.readonly-snapshot.json')==R['additionalReadOnlyFactIndexSnapshot']['sha256'])
used={};proofs={};anchorCount=0
for x in R['results']:
 name=x['variantId'];item=A[name];o=item['originalQuestion'];c=item['correctedQuestion']
 ck(name+' original complete hash',canon(o)==x['originalQuestionCanonicalSha256']==item['originalQuestionCanonicalSha256'])
 ck(name+' corrected complete hash',canon(c)==x['correctedQuestionCanonicalSha256']==item['correctedQuestionCanonicalSha256'])
 lines=c['stem'].splitlines(keepends=True);adds=[s for s in lines if s.startswith('For this practice only:')]
 ck(name+' only one inserted practice line',len(adds)==1 and ''.join(s for s in lines if not s.startswith('For this practice only:'))==o['stem'])
 ck(name+' all options retained exact',o['options']==c['options'] and len(c['options'])==len(x['optionJudgments']))
 ck(name+' original objective retained',o['stem'].splitlines()[-1]==c['stem'].splitlines()[-1] and x['minimality']['businessAndOptimizationObjectivePreserved'])
 for b in x['optionJudgments']:
  actual=next(a for a in c['options'] if a['ordinal']==b['ordinal']);ck(name+' original option '+str(b['ordinal']),b['originalLabel']==actual['originalLabel'] and hashlib.sha256(actual['text'].encode()).hexdigest()==b['optionTextSha256'] and bool(b['reason']))
 src=x['originalSourceDefect'];p=pathlib.Path(src['path']);ctx=read(p);old=next(z for z in ctx['results'] if int(z['qid'])==x['originalQid'])
 ck(name+' independently confirmed original defect',sha(p)==src['sha256'] and canon(old)==src['recordSha256'] and old['sourceIssue']['confirmed'] and old['questionSha256']==canon(o))
 closure=[]
 def visit(r):
  if r in closure:return
  closure.append(r)
  for d in C[r].get('prerequisiteRuleIds',[]):visit(d)
 for r in x['usedRuleIds']:visit(r)
 ck(name+' actual recursive dependency closure',closure==x['recursiveUsedRuleIds'] and [z for z in closure if z not in x['usedRuleIds']]==x['recursivePrerequisiteRuleIds'])
 for b in x['cardBindings']:
  card=C[b['ruleId']];idx=I[b['ruleId']];used[b['ruleId']]=b['bodySha256'];ck(name+'/'+b['ruleId']+' current body/FACT',canon(card['visibleBody'])==card['bodySha256']==b['bodySha256']==idx['currentBodySha256'] and idx['status']==b['currentIndependentFactStatus']=='PASS')
  ck(name+'/'+b['ruleId']+' exact dependencies/proofs',b['prerequisiteRuleIds']==card.get('prerequisiteRuleIds',[]) and b['currentIndependentFactProofs']==idx['proofs'])
  for pr in b['currentIndependentFactProofs']:proofs[pr['path']]=pr['sha256']
 for a in x['necessaryAnchors']:
  card=C[a['ruleId']];anchorCount+=1;ck(name+'/'+a['ruleId']+'/'+a['field']+' exact quote',a['bodySha256']==card['bodySha256'] and card['visibleBody'][a['field']][a['start']:a['end']]==a['quote'])
 if x['closureEligible']:
  ck(name+' appropriate choice count',x['status']=='SUPPORTED' and len(x['selectedOptionOrdinals'])==(2 if re.search(r'choose\s+two',c['stem'],re.I) else 1) and not x['failures'])
 else:ck(name+' failure not hidden by qualification',bool(x['failures']) and len(x['candidateValidOptionCombinations'])>=2 and not x['selectedOptionOrdinals'])
 if 'deterministicFeasibility' in x:
  d=x['deterministicFeasibility'];lb=d['dataBytesPerSite']*8/d['optimisticContinuousBitsPerSecond']/86400
  ck(name+' local network lower bound',math.isclose(lb,d['onlineIdealLowerBoundDays']) and lb>d['deadlineDaysOptimisticallyUsed'] and d['onlineCannotMeetDeadline'])
 if 'newDXProjectInputCheck' in x:
  d=x['newDXProjectInputCheck'];ck(name+' six-week project field not preference',d['carrierEstimateDays']==42 and d['carrierEstimateDays']>d['deadlineDays'] and d['notAnAWSUniversalLeadTimeClaim'] and d['notJustAServicePreference'])
 ck(name+' originals never promoted',not x['originalStatusUpgraded'] and not x['currentOrInventoryChanged'] and not x['newCardAuthored'])
for p,h in proofs.items():ck('current FACT receipt '+pathlib.Path(p).name,sha(pathlib.Path(p))==h)
E=read(P/'source-evidence.json')['evidence'];ck('source evidence full binding',sha(P/'source-evidence.json')==R['sourceEvidenceSha256'])
for k,e in E.items():
 o=read(pathlib.Path(e['path']));ck(k+' file/text/quote',sha(pathlib.Path(e['path']))==e['sha256'] and hashlib.sha256(o['text'].encode()).hexdigest()==e['textSha256'] and o['text'][e['start']:e['end']]==e['quote'])
 ck(k+' AWS URL',e['url'].startswith(('https://aws.amazon.com/','https://docs.aws.amazon.com/')))
for x in R['results']:
 for k in x['officialEvidenceIds']:ck(x['variantId']+' source registered '+k,k in E)
f=next(x for x in R['results'] if x['originalQid']==687)
ck('687 exact TS endpoint evidence, not generic tabular',f['sameTaskSageMakerScopeCheck']['genericTabularEndpointDocumentUsedAsDecisiveProof'] is False and 'timeseries-forecasting-deploy-models.html' in E['AUTOPILOT_TS_DEPLOY']['url'] and 'real-time' in E['AUTOPILOT_TS_DEPLOY']['quote'])
ck('687 DataSplit restriction scoped to right field','DataSplitConfig' in E['AUTOMLV2_DATASPLIT_LIMIT']['quote'] and 'This attribute must not be set for the time-series forecasting problem type' in E['AUTOMLV2_DATASPLIT_LIMIT']['quote'] and 'ModelDeployConfig' not in E['AUTOMLV2_DATASPLIT_LIMIT']['quote'])
corePath=V/'deliverables/core-visible-knowledge.provisional.json';current=read(corePath);M={x['ruleId']:x for x in current}
ck('actual current core unique with necessary cards',len(current)==len(M) and set(used)<=set(M))
for rid,h in used.items():ck('actual latest body '+rid,M[rid]['bodySha256']==h and M[rid].get('prerequisiteRuleIds',[])==C[rid].get('prerequisiteRuleIds',[]))
ck('no authoring mutations or reset',R['newCardsAuthored']==R['correctedVariantsAuthoredByReviewer']==R['newContentModelCallsCLIAPI']==R['subagentsSpawned']==0 and not R['originalQuestionOrStatusChanged'] and not R['currentInventoryOrPointersChanged'] and not R['priorClockBudgetCountersHistoryReset'])
out={'reviewId':'corrected-variants13','status':'PASS_readback_with_one_explicit_semantic_failure','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resultsSha256':sha(P/'results.json'),'reportSha256':sha(P/'results.md'),'inputManifestSha256':sha(P/'input/manifest.json'),'sourceEvidenceSha256':sha(P/'source-evidence.json'),'reviewedVariants':10,'minimalityPassCount':10,'closureEligibleCount':9,'failedVariantIds':[f['variantId']],'failedVariantsNotAccepted':True,'allNecessaryUsedCurrentBodiesMatch':True,'actuallyUsedCardCountIncludingRecursive':len(used),'currentFactReceiptFileCount':len(proofs),'necessaryAnchorCount':anchorCount,'officialEvidenceRecordCount':len(E),'checkCount':len(checks),'checks':checks,'currentCorePath':str(corePath),'currentCoreSha256':sha(corePath),'frozenAssignedCoreCount':362,'currentCoreCount':len(current),'globalCountDifferenceNotInventoriedByReviewer':len(current)!=362,'coreCountIsFinalN':False,'priorMechanicalReadbackFailurePath':str(P/'readback-attempt01.failure.json'),'priorMechanicalReadbackFailureSha256':sha(P/'readback-attempt01.failure.json'),'originalQuestionOrStatusChanged':False,'currentInventoryOrPointersChanged':False,'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','priorClockBudgetHistoryCountersReset':False,'publicationPerformed':False,'learnerOutcomeMeasured':False}
(P/'readback.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('PASS',len(checks),'checks',anchorCount,'anchors',len(used),'cards');print('results',out['resultsSha256']);print('readback',sha(P/'readback.json'))

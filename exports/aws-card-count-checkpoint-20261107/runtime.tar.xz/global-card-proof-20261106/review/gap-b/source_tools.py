import pathlib, json, hashlib, subprocess, datetime, re, shutil
from html.parser import HTMLParser
V=pathlib.Path(__file__).resolve().parents[2];D=V/'review/gap-b';E=D/'evidence';E.mkdir(exist_ok=True)
def sha(x):return hashlib.sha256(x).hexdigest()
class Text(HTMLParser):
 def __init__(self):super().__init__();self.a=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ('script','style'):self.skip+=1
  elif t in ('p','div','li','tr','br','h1','h2','h3','h4'):self.a.append('\n')
 def handle_endtag(self,t):
  if t in ('script','style'):self.skip=max(0,self.skip-1)
  elif t in ('p','li','tr','h1','h2','h3','h4'):self.a.append('\n')
 def handle_data(self,d):
  if not self.skip:self.a.append(d)
def fetch(key,url):
 p=E/(key+'.json')
 if p.exists():return p
 r=subprocess.run(['curl','-fLsS','--max-time','30','--write-out','\n%{url_effective}\n%{http_code}',url],capture_output=True,check=True);b,u,status=r.stdout.rsplit(b'\n',2);h=Text();h.feed(b.decode());t='\n'.join(' '.join(s.split()) for s in ''.join(h.a).splitlines() if s.strip());p.write_text(json.dumps(dict(url=u.decode(),requestedUrl=url,httpStatus=int(status),htmlSha256=sha(b),textSha256=sha(t.encode()),text=t,retrievedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()),ensure_ascii=False,indent=2)+'\n');return p
def pool():
 cat=json.loads((V.parent/'domain1-final-card-catalog-20261105/official-sources.catalog.json').read_text());paths=[pathlib.Path(x['sourcePath']) for x in cat if x.get('sourcePath')]
 paths+=list((V/'evidence/cards-c').glob('*.json'))+list((V/'evidence/gap-a').glob('*.json'))+list(E.glob('*.json'));out=[]
 for p in paths:
  try:d=json.loads(p.read_text());t=d.get('text');u=d.get('finalUrl') or d.get('url')
  except:continue
  if t and u and re.match(r'https://(?:docs\.)?aws\.amazon\.com/',u):out.append(dict(path=p,text=t,url=u))
 return out
def excerpt(path,starttext,endtext=None,length=700):
 p=pathlib.Path(path);s=json.loads(p.read_text());t=s['text'];st=t.index(starttext);en=t.index(endtext,st)+len(endtext) if endtext else min(len(t),st+length);q=t[st:en];dst=E/('cache-'+sha(p.read_bytes())[:20]+'.json')
 if p!=dst and not dst.exists():shutil.copyfile(p,dst)
 return dict(url=s.get('finalUrl') or s['url'],quote=q,quoteStart=st,quoteEnd=en,textSha256=sha(t.encode()),snapshotPath=str(dst),snapshotSha256=sha(dst.read_bytes()))

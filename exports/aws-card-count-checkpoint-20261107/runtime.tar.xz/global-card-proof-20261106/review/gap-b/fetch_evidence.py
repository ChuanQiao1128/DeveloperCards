from source_tools import fetch
import concurrent.futures
urls={
'api-kinesis':'https://docs.aws.amazon.com/apigateway/latest/developerguide/integrating-api-with-aws-services-kinesis.html',
'api-firehose':'https://docs.aws.amazon.com/solutions/latest/constructs/aws_apigateway_kinesisfirehose.html',
'firehose-redshift':'https://docs.aws.amazon.com/firehose/latest/dev/basic-deliver.html',
'dx-pricing':'https://aws.amazon.com/directconnect/pricing/',
'glue-streaming':'https://docs.aws.amazon.com/glue/latest/dg/add-job-streaming.html',
'cloudfront-invalidate':'https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/Invalidation.html',
'pinpoint-end':'https://docs.aws.amazon.com/pinpoint/latest/userguide/migrate.html',
'elastic-transcoder':'https://docs.aws.amazon.com/pt_br/elastictranscoder/latest/developerguide/introduction.html',
'snow-device-updates':'https://aws.amazon.com/blogs/storage/aws-snow-device-updates/',
'workload-discovery':'https://docs.aws.amazon.com/solutions/latest/workload-discovery-on-aws/solution-overview.html',
'batch-windows':'https://docs.aws.amazon.com/batch/latest/APIReference/API_RuntimePlatform.html',
'batch-compute-windows':'https://docs.aws.amazon.com/batch/latest/userguide/create-compute-environment-fargate.html',
'batch-pricing':'https://aws.amazon.com/batch/pricing/',
'ecs-pricing':'https://aws.amazon.com/ecs/pricing/',
'fargate-cpu':'https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task-cpu-memory-error.html',
'kinesis-retention':'https://docs.aws.amazon.com/streams/latest/dev/kinesis-extended-retention.html',
'lambda-storage':'https://docs.aws.amazon.com/lambda/latest/dg/configuration-ephemeral-storage.html',
'cost-tags':'https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/activating-tags.html',
'dlm-ami':'https://docs.aws.amazon.com/ebs/latest/userguide/ami-policy.html',
'cost-forecast':'https://docs.aws.amazon.com/cost-management/latest/userguide/ce-api-best-practices.html',
'transfer-ftp':'https://docs.aws.amazon.com/transfer/latest/userguide/create-server-ftp.html',
'lambda-url-auth':'https://docs.aws.amazon.com/lambda/latest/dg/urls-auth.html',
'rds-engine-features':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Concepts.RDSFeaturesRegionsDBEngines.grids.html',
'sp-sharing':'https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/con-bill-blended-rates.html',
'elasticache-serverless':'https://docs.aws.amazon.com/AmazonElastiCache/latest/dg/WhatIs.html',
'snow-tape':'https://docs.aws.amazon.com/snowball/latest/api-reference/API_TGWOnDeviceServiceConfiguration.html',
'hibernate':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/Hibernate.html',
'nlb':'https://docs.aws.amazon.com/elasticloadbalancing/latest/network/introduction.html',
'aurora-migrate':'https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/AuroraPostgreSQL.Migrating.RDSPostgreSQL.Replica.html',
'ddb-schema':'https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/HowItWorks.CoreComponents.html',
'neptune-streams':'https://docs.aws.amazon.com/neptune/latest/userguide/streams.html',
'redshift-copy':'https://docs.aws.amazon.com/redshift/latest/dg/r_COPY.html',
'peering-pricing':'https://docs.aws.amazon.com/vpc/latest/peering/what-is-vpc-peering.html',
'eks-connector':'https://docs.aws.amazon.com/eks/latest/userguide/eks-connector.html',
}
def safe(k):
 try:return k,str(fetch(k,urls[k]))
 except Exception as e:return k,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
 for result in ex.map(safe,urls): print(result)

import pathlib,json,hashlib,datetime
V=pathlib.Path(__file__).resolve().parents[2];D=V/'review/gap-b';I=D/'input'
def sha(b):return hashlib.sha256(b).hexdigest()
C={x['ruleId']:x for x in json.loads((I/'visible-cards355.json').read_text())};Q={x['qid']:x for x in json.loads((I/'cases76.json').read_text())};OLD={x['qid']:x for x in json.loads((I/'prior-nonpass76.json').read_text())}
def write(part,specs):
 out=[]
 for q,status,opts,ids,reason,req,impl in specs:
  anchors=[dict(ruleId=k,bodySha256=C[k]['bodySha256'],field=f,quote=C[k]['visibleBody'][f],additionalToInitialGroup=k not in Q[q]['cardRuleIds']) for k in ids for f in ('answerZH','keyPointZH','watchOutZH') if C[k]['visibleBody'].get(f)]
  out.append(dict(qid=q,status=status,previousStatus=OLD[q]['status'],selectedOptionOrdinals=opts if status=='SUPPORTED' else [],candidateOptionOrdinals=opts if status!='SUPPORTED' else [],usedRuleIds=ids,necessaryAnchors=anchors,reasoningAndClosestCompetitor=reason,minimumClarificationRequestIds=req,implementationChecks=impl,questionSha256=sha(json.dumps(Q[q]['question'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),initialCardGroupRuleIds=Q[q]['cardRuleIds'],previousReportedMissingJudgments=OLD[q].get('missingJudgments',[]),previousConditions=OLD[q].get('conditions',[]),previousSourceIssues=OLD[q].get('sourceIssues',[])))
 data=dict(schemaVersion=1,reviewer='actual_gap_review',inputManifestPath=str(I/'manifest.json'),inputManifestSha256=sha((I/'manifest.json').read_bytes()),visibleCardCount=355,reviewedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=out)
 p=D/f'results-part{part:02}.json';p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(p,len(out))

import json,pathlib,sys,hashlib,datetime,collections,shutil
from write_review import Q,C,OLD,D,I,V,sha
from source_tools import pool,excerpt,fetch
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def own(k):return D/'evidence'/f'{k}.json'
def urlpath(suffix):
 hits=[s for s in pool() if s['url'].endswith(suffix) and len(s['text'])>300]
 if not hits:raise ValueError(suffix)
 return hits[0]['path']
def ex(k,start,end=None,length=600):
 p=own(k) if own(k).exists() else urlpath(k)
 return excerpt(p,start,end,length)
E={};FAIL=[]
def ev(k,*args,**kwargs):
 try:E[k]=ex(*args,**kwargs)
 except Exception as er:FAIL.append((k,str(er),args));print("FAIL",k,str(er),args)
 return k
# Exact paragraphs chosen for their semantic scope. A title/URL/hash is not the technical assertion.
ev('api-kinesis','api-kinesis','Expose an HTTP PUT method', 'record to the named stream.')
ev('api-firehose','api-firehose-direct','As no additional logic is necessary for this example,','proxy to directly integrate with Firehose.')
ev('firehose-redshift','firehose-redshift','For data delivery to Amazon Redshift, Firehose first delivers incoming data','to your Amazon Redshift provisioned cluster or Amazon Redshift Serverless workgroup.')
ev('dx-rate','dx-pricing','Data transfer out (DTO) over AWS Direct Connect refers','you are using (see tables below).')
ev('aurora-failover','Concepts.AuroraHighAvailability.html','If the primary instance fails,','to the new primary instance.')
ev('cf-invalidation','cloudfront-invalidate','Invalidate the file from edge caches.','latest version of the file.')
ev('glue-streaming','glue-streaming','You can create streaming extract, transform, and load (ETL) jobs','lakes or JDBC data stores.')
ev('fargate-resource','fargate-cpu','32 vCPU',length=500)
ev('batch-purpose','what-is-batch.html','AWS Batch helps you to run batch computing workloads','reduce compute costs, and deliver results quickly.')
ev('retention','kinesis-retention','A Kinesis data stream stores records from','default, up to 8760 hours (365 days).')
ev('aurora-mysql-snapshot','aurora-snapshot-mysql','You can migrate a DB snapshot of an RDS for MySQL DB instance','compatible with Aurora MySQL.')
ev('lambda-storage','lambda-storage','You can configure ephemeral storage between','in 1-MB increments.')
ev('tag-control','cost-tag-manager','Only a management account in an organization','the Billing and Cost Management console.')
ev('aurora-global-lag','aurora-global-database.html','After any write operation, Aurora replicates data','typically under a second.')
ev('dlm-copy','dlm-ami','This example creates an AMI lifecycle policy that creates AMIs','2 AMI copies, and automatically deprecates the oldest AMI.')
ev('backup-copy','cross-region-backup.html','Using AWS Backup, you can copy backups','as part of a scheduled backup plan.')
ev('forecast','cost-forecast','It can also provide 3 months of cost forecast data','granularity.')
ev('ftp','transfer-ftp','Publicly accessible endpoints are not supported.',length=730)
ev('function-none','lambda-url-auth','When your function URL auth type is NONE','URL, choose the NONE auth type.')
ev('rds-engine-grid','rds-engine-features','Feature quick reference\nThe following quick reference table','Not available\nPerformance Insights')
ev('peering-price','peering-pricing','There is no charge to create a VPC peering connection.','cross Availability Zones and Regions.')
ev('tgw-price','tgw-price','The VPC account owner is billed hourly','attached to an AWS Transit Gateway.')
ev('acu','aurora-acu',"That's because each ACU corresponds to approximately 2 GiB of memory.",length=64)
ev('mysql-autopause','aurora-serverless-v2-auto-pause.html',"If you're using Aurora MySQL,",'version 3.08.0 or higher.')
ev('gp3-price','ebs-gp3','prices that are up to 20 percent lower than gp2 volumes.',length=56)
ev('hibernate','hibernate','Hibernation saves the contents from the instance memory (RAM)','The processes that were previously running on the instance are resumed')
ev('nlb','nlb','A Network Load Balancer functions at the fourth layer','It can handle millions of requests per second.')
ev('aurora-pg-migrate','aurora-migrate','Migrating from an RDS for PostgreSQL DB instance to an Aurora PostgreSQL DB cluster is a','writer instance for the cluster.')
ev('ddb-schema','ddb-schema','Other than the primary key, the People table is','attributes.')
ev('neptune','neptune-streams','Neptune Streams logs every change','backup, security and expiry.')
ev('eks-connector','eks-connector','You can use Amazon EKS Connector','but you can’t manage them.')
ev('s3-small','s3-transition-current','Objects smaller than 128 KB will not transition by default','(ObjectSizeLessThan).')
ev('s3-flexible-time','glacier-storage-classes.html','Standard retrieval – Typically restores the object in 3–5 hours',length=220)
ev('s3-deep-time','glacier-storage-classes.html','Standard retrieval – Typically restores the object within 12 hours',length=220)
ev('rds-event-kind','rds-events','You can subscribe to an event category','when the event notification subscription changes.' if False else 'when an event notification subscription changes.')
ev('fleet-template','Fleets.html','Each instance in a fleet is either','manually at launch.')
ev('asg-mixed','ec2-auto-scaling-mixed-instances-groups.html','On-Demand',length=550)
ev('random-dns','routing-policy-multivalue.html','To route traffic roughly at random','to different DNS resolvers.')
ev('cache-multiAZ','elasticache-deployment','ElastiCache Serverless automatically stores data','provides a 99.99% availability Service Level Agreement (SLA).')
ev('cache-engines','elasticache-serverless','Amazon ElastiCache works with the Valkey, Memcached, and Redis OSS engines.',length=76)
ev('web-session','web-session-store','By moving the session state to a central location,','and I will focus on Redis here.')
ev('cache-ha','cache-replication',"However, if you're running a Valkey or Redis OSS engine,",'some data may be lost if it is the primary read/write node that fails.')
ev('external-state','external-state','Offload session data to a database, cache, or external','that you can use to offload session data.')
ev('sharing','sp-sharing','The Savings Plans are applied to the account that owns the Savings Plans.','other accounts in the AWS organization.')
ev('batch-windows','batch-windows','The operating system for the compute environment. Valid values are:','WINDOWS_SERVER_2022_FULL.')
ev('batch-no-fee','batch-pricing','There is no additional charge for AWS Batch.','to store and run your application.')
ev('ecs-no-fee','ecs-pricing','There is no additional charge for Amazon ECS orchestration.','used to run your containerized applications.')
ev('snowcone-end','snow-device-updates','After careful consideration, we have discontinued the AWS Snowcone service,','complete their jobs and return the devices.')
ev('tape-end','snow-tape','The Tape Gateway service is no longer available on Snow Family devices.',length=70)
ev('transcoder-end','elastic-transcoder','Aviso de fim do suporte:', 'recursos do Elastic Transcoder.')
ev('discovery-end','workload-discovery','This AWS Solution is no longer available.','discover, visualize, and explain workloads on AWS.')
ev('pinpoint-end','pinpoint-end','Support for Amazon Pinpoint ended','are no longer available.')
ev('redshift-cse','redshift-copy',"After April 30, 2026, you won't be able to",'use client-side encryption for COPY and UNLOAD.')
if FAIL:raise RuntimeError("Fix missing exact excerpts before writing final outputs")
# Preserve the four first-pass reviews; append explicit changes caused by full-pool recheck.
results=[]
for p in sorted(D.glob('results-part*.json')):results+=json.loads(p.read_text())['results']
R={x['qid']:x for x in results};overrides=[]
def override(q,status,opts,ids,reason,req=None):
 old=dict(R[q]);x=R[q];x['status']=status;x['selectedOptionOrdinals']=opts if status=='SUPPORTED' else [];x['candidateOptionOrdinals']=opts if status!='SUPPORTED' else [];x['usedRuleIds']=ids;x['reasoningAndClosestCompetitor']=reason
 if req is not None:x['minimumClarificationRequestIds']=req
 x['necessaryAnchors']=[dict(ruleId=k,bodySha256=C[k]['bodySha256'],field=f,quote=C[k]['visibleBody'][f],additionalToInitialGroup=k not in Q[q]['cardRuleIds']) for k in ids for f in ('answerZH','keyPointZH','watchOutZH') if C[k]['visibleBody'].get(f)]
 overrides.append(dict(qid=q,firstPassStatus=old['status'],finalStatus=status,reason=reason,withdrawnRequestIds=[a for a in old['minimumClarificationRequestIds'] if a not in x['minimumClarificationRequestIds']]))
override(84,'SUPPORTED',[2],['GSC-146','GSC-150','GSC-147','GSC-155'],'全池GSC147已明确Regional RI为价格折扣、以承诺管理价格，GSC155要求未来稳定用量匹配。24h稳定不可中断生产适用RI，Spot回收不符；开发测试停止即可避免空闲计算并按需使用，B。无需再记每种购买方式清单。',[])
override(146,'SUPPORTED',[2],['GSC-146','GSC-147','GSC-155'],'稳定基线用已教价格承诺匹配长期用量，可恢复无状态突增用Spot，B；C全部按需没有基线承诺折扣，A全Spot不保稳定基线，D专属不提供此处成本优势。GSC147/155补齐初始卡组漏取的经济规则，撤回GB-R02。',[])
override(167,'SUPPORTED',[3],['GSC-079','GSC-146','GSC-147','GSC-155'],'SQS使Spot被回收的任务可恢复；稳定RI基线+Spot突增同时避免按峰值全承诺的闲置与全Spot的不确定性，C。长期价格承诺已由GSC147/155教会，不需加卡，部署基线数量另核。',[])
override(290,'SUPPORTED',[3],['GSC-146','GSC-147','GSC-155'],'C的On-Demand基线配合可恢复Spot额外容量，避免RI折扣对应的长期承诺；D不符不作长期承诺目标，专属容量也不因专属而低价。GSC147已教RI折扣承诺、GSC146已教Spot经济与回收风险，可直接迁移。',[])
override(383,'SUPPORTED',[1],['GSC-149','GSC-147','GSC-155'],'按socket/core并控制物理主机，GSC149排除Dedicated Instance；三年稳定使用再迁移GSC147/155的价格承诺匹配稳定用量判断，A reserved Host优于B按需Host。此处不要求新记Host购买菜单；许可证实际迁移资格留实施核对。',[])
override(300,'CONDITIONAL',[3],['CUR:CC22','GSC-054','GSC-050','GSC-147','GSC-155'],'长期稳定计算/数据库的预留折扣可由GSC147/155及GSC054迁移，C经济缺口撤回。仍须原legacy关系库属于Aurora支持的兼容引擎；原题未给，不能用一般“关系数据库”代替MySQL/PostgreSQL兼容前提。',[])
override(424,'CONDITIONAL',[2],['GSC-146','GSC-147','GSC-155'],'RI稳定前端的承诺经济规则已由GSC147/155教会。B后端Spot仍要求可中断恢复；原题只给短时/数量变动，不能必然推出可重做。保留该源条件，不能靠添卡制造中断容忍前提；若不允许中断，需比较按需Fargate。',[])
override(551,'INSUFFICIENT_CARDS',[1],['CUR:CMP-M01','GSC-024','GSC-025'],'A是多年冷存/允许6小时等待的候选；C错误地把Intelligent-Tiering内部层写成外部存储类。当前卡虽提到6小时/12小时会改变方案，却未教Flexible标准取回通常3–5小时、Deep Archive通常12小时的对应，仍有具体取回知识缺口。撤回首稿未获现行官方支持的“7天不能转IA”断言：30天最低存储计费不等于创建年龄门槛，7天IA合法性尚待核清。A/B总费用还要按50KB对象的最小计费、40KB元数据、转换请求与多年保留比较；不把A写成无条件已闭合。',['GB-R23'])
override(631,'INSUFFICIENT_CARDS',[2],['CUR:NC11','GSC-042'],'沿人/关系多跳分析选Neptune，账本不是关系遍历模型；B原生变化流比另接通用Kinesis少开发。现卡仅明确DynamoDB变化流，未教Neptune Streams记录图更改并供应用消费，不能由相似名称补能力。补实际数据源范围，不扩整套图库特性表。',['GB-R34'])
# Requests are evidence-backed minimal clarifications, not approved edits or new cards.
def req(k,summary,ids,evidence,kind='clarify_existing',limits=None):
 qs=sorted(q for q,x in R.items() if k in x['minimumClarificationRequestIds'])
 return dict(requestId=k,status='PROPOSED_NOT_AUTHORED',kind=kind,qids=qs,targetExistingRuleIds=ids,minimumClarification=summary,officialEvidenceKeys=evidence,scopeLimit=limits or '只补本判断所需能力/条件；不得自动扩卡或把私有说明当已教会。')
requests=[
req('GB-R01','API Gateway可用AWS服务代理直接接Kinesis PutRecord或Firehose；无需为纯转发另放Lambda。',['CUR:CA17'],['api-kinesis','api-firehose']),
req('GB-R04','Firehose支持交付Redshift，先暂存S3再COPY导入。',['CUR:NS01'],['firehose-redshift']),
req('GB-R05','既有DX与Internet是不同DTO计费路径；比较同Region/地点适用出站单价，不能从专线隔离性推出永远最低价。',['GSC-078','CUR:NB01'],['dx-rate']),
req('GB-R06','同Region Aurora reader可在writer失败时提升为primary；读扩展与HA职责可在同一判断解释。',['GSC-055'],['aurora-failover']),
req('GB-R07','CloudFront invalidation主动让已缓存对象失效，下一次请求回源取新版本。',['GSC-131'],['cf-invalidation']),
req('GB-R08','Glue有持续流式ETL，可消费MSK/Kafka/Kinesis并把转换结果写S3。',['GSC-095'],['glue-streaming']),
req('GB-R10','Fargate单任务CPU/内存有实际资源边界，64vCPU/512GiB不在所核当前表内；不得写旧16vCPU上限。',['CUR:XB019'],['fargate-resource']),
req('GB-X01','Batch批作业的排队、资源调度与执行职责，不能只从服务名推出。',[],['batch-purpose'],'deferred_independent_task','独立学习任务；先检验是否可由其他卡替换/迁移。本复核不新增卡、不授权扩量。'),
req('GB-R12','Kinesis默认保留24小时，可延长；retention与shard数量解决不同问题。',['GSC-091'],['retention']),
req('GB-R13','受兼容版本约束的RDS MySQL原生快照可迁为Aurora MySQL，不能泛化任意S3 dump。',['GCL-019'],['aurora-mysql-snapshot']),
req('GB-R14','Lambda /tmp临时存储可配置512–10240MB，足容2GiB任务临时盘，不是持久数据库。',['GSC-133'],['lambda-storage']),
req('GB-R15','组织用户成本分配标签由管理账户在Billing激活，资源打标签不自动完成该步骤。',['GSC-154'],['tag-control']),
req('GB-R16','Aurora Global复制通常亚秒，仍是异步；跨区域reader不是立即全局强一致。',['GSC-056'],['aurora-global-lag']),
req('GB-R17','DLM可管EBS-backed AMI并跨Region复制，AWS Backup对受支持EC2备份可配置copy；定时创建不等于副本已可恢复。',['CUR:NS03','GCL-014'],['dlm-copy','backup-copy']),
req('GB-R18','Cost Explorer月粒度预测可达12个月，日粒度预测3个月；不能从泛称预测推出任意范围。',['GSC-153'],['forecast']),
req('GB-R20','Transfer Family确有FTP入口，受VPC私有入口限制，后端S3/EFS而非EBS；SFTP加密性质不自动套FTP。',['CUR:CMP-M19'],['ftp']),
req('GB-R21','function URL可用NONE，Lambda不做IAM认证；普通webhook另在函数验证第三方签名等。',['CUR:XB012'],['function-none']),
req('GB-R22','RDS Multi-AZ DB cluster与经典Multi-AZ实例区别须保留引擎支持；Oracle不在此cluster支持范围。',['GSC-046'],['rds-engine-grid']),
req('GB-R23','明确Flexible与Deep Archive实际取回窗口，用于6小时等待判断；50KB总费用按已教费用项比较。',['CUR:CMP-M01'],['s3-flexible-time','s3-deep-time','s3-small'],limits='不补未证实的创建30天年龄门槛；7天IA合法性仍UNKNOWN，最低存储计费与最早转换年龄分开。不得把本澄清完成视作原题自动PASS。'),
req('GB-R25','Peering无建立连接费，跨AZ流量另计；TGW有attachment小时费与处理费，两个VPC按适用路径比较。',['CUR:CB16','GSC-075'],['peering-price','tgw-price']),
req('GB-R26','1ACU约2GiB内存，可据硬内存需求设置最小容量。',['GSC-057'],['acu']),
req('GB-R27','Aurora MySQL受支持版本也可自动暂停到0ACU，暂停卡不局限PostgreSQL。',['CUR:XB027'],['mysql-autopause']),
req('GB-R28','gp3价格与性能配置相对gp2的实际经济差异，不能从独立调IOPS推出绝对最低价。',['GSC-015'],['gp3-price']),
req('GB-R30','Hibernation将RAM存到EBS并恢复RAM/进程，区别于普通Stopped warm pool。',['GSC-117','GSC-118'],['hibernate']),
req('GB-R31','NLB面向百万级请求/秒的低延迟L4负载；这不是任意配置3M/s的保证。',['CUR:XB041'],['nlb']),
req('GB-R32','RDS PostgreSQL可建Aurora PostgreSQL迁移读副本并提升，是真实原生持续迁移路径。',['GSC-060'],['aurora-pg-migrate']),
req('GB-R33','DynamoDB除主键外每项属性可不同，无需预定义统一列；仍须设计主键/访问路径。',['GSC-038'],['ddb-schema']),
req('GB-R34','Neptune Streams原生记录图更改供应用读取，区别资源状态通知或另建通用流。',['GSC-042','CUR:NC11'],['neptune']),
req('GB-X02','EKS Connector注册外部Kubernetes供EKS控制台查看，不是部署EKS Anywhere或仅看CPU指标。',[],['eks-connector'],'deferred_independent_task','独立注册/查看任务；本次仅保留缺口，未自动新增卡。')]
# Source findings retain full original anchors, positive proof and unresolved boundaries.
SF=[]
def finding(q,kind,proof,conclusion,competing=None,obsolete=False,destination=None,correction=None):
 x=dict(qid=q,kind=kind,status=R[q]['status'],questionSha256=R[q]['questionSha256'],originalQuestion=Q[q]['question'],officialEvidenceKeys=proof,conclusion=conclusion,competingOptionOrdinals=competing or [],officiallyConfirmedObsolete=obsolete,scopePolicyPath=str(V/'inputs/user-knowledge-scope-accepted.json'))
 if obsolete:x.update(proposedCorrection=correction,knowledgeDestination=destination,correctionDisposition='PROPOSED_CURRENT_AWS_NOT_AUTOMATIC_SUPPORTED',originalDenominatorPreserved=True)
 SF.append(x)
finding(108,'wrong_event_source',['rds-event-kind'],'RDS事件是数据库资源/备份/配置等事件；D下游SNS扇出正确不弥补每次业务sold变更的上游。其他项也未提供每目标独立副本路径。')
finding(145,'resource_relationship',['fleet-template','asg-mixed'],'Fleet使用launch template；ASG的混合购买策略配置在ASG，不能将模板配置为使用Spot Fleet。D需改该关系后才是现代架构，不能直接修原文再判PASS。')
finding(224,'multiple_valid_combinations',['random-dns'],'C随机健康DNS可配D的2+1或E的2+2跨AZ，均有另AZ资源；没有单机容量/成本约束唯一排除D。',[3,4,5])
finding(302,'confirmed_obsolete_service',['transcoder-end'],'Elastic Transcoder已过停止日；原转码与分发核心仍有效。',[1,5],True,['GSC-110','CUR:CA13'],'保留原选项并标历史C；当前用受支持转码服务MediaConvert，边缘分发CloudFront。原题A+E是当前可运行替代，但不按原历史预期直接PASS。')
finding(454,'confirmed_obsolete_service',['discovery-end'],'官方Solution不再可用；不是“新客限制”推断。',[],True,[],'保留自动跨账户架构关系发现义务；按官方建议确认当前Application Map/DevOps Agent实际覆盖再定教学，未新增卡。')
finding(483,'current_multiple_valid_options',['batch-windows','batch-no-fee','ecs-no-fee'],'Batch支持Windows Fargate；B/C相同Fargate任务均可按调度运行，编排无额外费，原题缺唯一成本差异。',[2,3])
finding(500,'confirmed_obsolete_ordering',['snowcone-end'],'原D需订购Snowcone，官方对新旧客户都停止订购且支持期结束；不混同Snowball仅限现有客户。',[1],True,['CUR:XB023'],'保留Windows ACL迁移核心；当前A DataSync SMB可选，原choose two不存在现行第二项，删除/替换旧Snowcone选项另记。')
finding(537,'current_multiple_valid_options',['cache-engines','cache-multiAZ','web-session'],'Memcached Serverless也三AZ冗余且可共享Web会话；A/B同等RDS/ASG，原题未限定node-based。',[1,2])
finding(543,'multiple_valid_combinations',['sharing'],'同组织合格用量可共享已有SP；购买账户加入新payer组织或自己建组织都成立，A+D与A+E均有效。',[1,4,5])
finding(583,'confirmed_obsolete_service_combination',['tape-end'],'5PB/1Gbps约463天超6个月；C的Snow设备Tape Gateway官方不再支持，其他在线项不满足带宽硬约束。',[],True,['GSC-077','GSC-013'],'保留离线大规模磁带迁移义务；当前可用磁带到对象的离线流程待确认，不教已失效Snowball组合。')
finding(589,'multiple_supported_state_stores',['web-session','external-state'],'官方Web会话模式支持外置Memcached或Redis；题干只指定Web主机故障。RDS也是可持久化外部状态存储，未给延迟/成本约束唯一选Redis；当前不声称单节点cache自身容错。',[1,2,4])
finding(593,'overlapping_ha_options',['cache-ha'],'A/C可描述同样跨AZ主从HA；异步Redis不保证零数据丢失，更多节点也不等于不降速。Region全毁与Region内AZ故障语义亦不同，原文未区分。',[1,3])
finding(201,'partially_obsolete_unresolved_current_option',['pinpoint-end'],'Pinpoint journeys官方已停，但Connect当前双向SMS及1年归档路径仍未完整证明；不能把整题因B过时自动豁免。',[1,2],True,[],'标记原B journey过时并保留A的真实SMS/长期归档待核；当前选择仍UNKNOWN，不宣称纠错义务已完成。')
finding(515,'narrow_retirement_not_global_impossibility',['redshift-cse'],'COPY/UNLOAD旧客户端加密的停止不证明所有应用侧加密值都不可能；原B范围仍未核清，不能自动豁免整题。',[1,2,3])
finding(540,'invalid_cluster_engine_with_other_option_unresolved',['rds-engine-grid'],'Oracle不支持所称RDS Multi-AZ DB cluster；同AZOracle读副本是否满足原文相对单机更高可用仍未排尽，因此保留UNKNOWN而非无解。',[2])
finding(551,'unproven_transition_age',['s3-flexible-time','s3-deep-time','s3-small'],'撤回7天IA已证无效的首稿断言；当前页面没有句子不证明限制取消。现行年龄条件仍UNKNOWN，最低存储计费不能代替。数年50KB总费用与具体取回知识另按卡片缺口处理。',[1,2])
# Add evidence references to every result, including explicit empty set for judgments relying only on visible rules.
reqmap={x['requestId']:x for x in requests};sfmap={x['qid']:x for x in SF}
for q,x in R.items():
 keys=[]
 for k in x['minimumClarificationRequestIds']:keys+=reqmap[k]['officialEvidenceKeys']
 if q in sfmap:keys+=sfmap[q]['officialEvidenceKeys']
 x['officialEvidenceKeys']=list(dict.fromkeys(keys));x['sourceFindingId']=f'Q{q}' if q in sfmap else None
 x['sourceOriginalPreserved']=True;x['currentAwsCorrectionOnlyForConfirmedObsolete']=bool(q in sfmap and sfmap[q]['officiallyConfirmedObsolete'])
# Freeze final skill/policy; old manifest remains an honest historical fingerprint.
for src,name in [(pathlib.Path('/Users/qc/.codex/skills/aws-card-count-verify/SKILL.md'),'skill-final.md'),(V/'inputs/user-knowledge-scope-accepted.json','user-knowledge-scope-accepted.json')]:shutil.copyfile(src,I/name)
manifest=dict(schemaVersion=2,finalizedAtUtc=NOW,initialManifestPath=str(I/'manifest.json'),initialManifestSha256=sha((I/'manifest.json').read_bytes()),initialGlobalSkillChanged=True,initialSkillHash='ed4d17efa77d0a2908ec1ef5a7ce28ffdae033ec121209c3fe16bcbd2af4e724',finalSkillHash=sha((I/'skill-final.md').read_bytes()),skillDriftDisposition='已实际回读最新版；新增批量删除/主归规则与本次逐题复核无冲突，初稿与旧hash保留；不声称原全局路径未变。',frozenInputs={str(p):sha(p.read_bytes()) for p in [I/'cases76.json',I/'prior-nonpass76.json',I/'visible-cards355.json',I/'skill-final.md',I/'user-knowledge-scope-accepted.json',V/'rules.md',V/'inputs/teaching-standard.md']},currentPool='冻结355旧正文；本次不混入后来修订卡',reviewOnly=True,cliApiCalls=0,nativeUsage='unknown',sourceQuestionDenominator=1018,reviewQuestionCount=76)
dump(I/'manifest-final.json',manifest)
dump(D/'official-evidence.json',dict(schemaVersion=1,evidence=E,semanticSelection='逐项读取并选取对应机制段落；哈希验证只证明摘录绑定，不替代语义审查。'))
dump(D/'revision-requests.json',dict(schemaVersion=1,requests=requests,withdrawnRequests=[dict(requestId='GB-R02',reason='全355池GSC147/GSC155已教价格承诺；不新增RI同义教学。')],noNewCardAuthorization=True))
dump(D/'source-findings.json',dict(schemaVersion=1,scopePolicy='current_AWS',findings=SF,denominatorPreserved=1018,notAllSourceIssuesExempt=True))
dump(D/'final-overrides.json',dict(schemaVersion=1,overrides=overrides,firstPassFilesPreserved=True))
counts=dict(collections.Counter(x['status'] for x in results))
dump(D/'results.json',dict(schemaVersion=2,reviewer='actual_gap_review',finalInputManifestPath=str(I/'manifest-final.json'),finalInputManifestSha256=sha((I/'manifest-final.json').read_bytes()),reviewedAtUtc=NOW,counts=counts,visibleCardCount=355,questionCount=76,minimumClarificationCount=len(requests),deferredIndependentTaskCount=sum(x['kind']=='deferred_independent_task' for x in requests),notNewCardCount=True,results=results,citationCorrectionsPath=str(D/'citation-corrections.json'),scopePolicy='current_AWS',sourceDenominatorPreserved=1018,cliApiCalls=0,nativeUsage='unknown',conclusion='只完成指定76题缺口反向复核；不表示355卡已覆盖全库或最终N已知。'))
checks={}
checks['76_unique_exact_questions']=len(R)==76 and set(R)==set(Q)
checks['all_question_hashes_match']=all(x['questionSha256']==sha(json.dumps(Q[x['qid']]['question'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()) for x in results)
checks['all_card_anchors_exact']=all(a['bodySha256']==C[a['ruleId']]['bodySha256'] and a['quote']==C[a['ruleId']]['visibleBody'][a['field']] for x in results for a in x['necessaryAnchors'])
checks['all_request_ids_defined']=all(k in reqmap for x in results for k in x['minimumClarificationRequestIds'])
checks['all_evidence_keys_defined']=all(k in E for x in requests+SF for k in x['officialEvidenceKeys'])
checks['all_source_quotes_offsets_and_hashes_match']=all((lambda p,d,e:sha(p.read_bytes())==e['snapshotSha256'] and sha(d['text'].encode())==e['textSha256'] and d['text'][e['quoteStart']:e['quoteEnd']]==e['quote'])(pathlib.Path(e['snapshotPath']),json.loads(pathlib.Path(e['snapshotPath']).read_text()),e) for e in E.values())
checks['frozen_final_inputs_match']=all(sha(pathlib.Path(p).read_bytes())==h for p,h in manifest['frozenInputs'].items())
checks['original_three_data_inputs_unchanged']=all(sha(pathlib.Path(p).read_bytes())==h for p,h in json.loads((I/'manifest.json').read_text()).items() if p.endswith(('cases76.json','prior-nonpass76.json','visible-cards355.json')))
checks['quarantined_GCL020_not_used']=all('GCL-020' not in x['usedRuleIds'] for x in results)
checks['no_unresolved_upgraded_by_policy']=all(x['status']!='SUPPORTED' for x in SF if x['officiallyConfirmedObsolete'])
checks['parts_preserved']=len(list(D.glob('results-part*.json')))==4
assert all(checks.values()),checks
dump(D/'final-readback.json',dict(schemaVersion=1,readbackAtUtc=NOW,status='PASS_MECHANICAL_ONLY',checks=checks,counts=counts,requestCount=len(requests),noCardEdits=True,cliApiCalls=0,semanticCaveat='机械回读不将UNKNOWN/CONDITIONAL/题源问题升级为语义PASS；S3年龄门槛仍未确认。',outputSha256={str(p):sha(p.read_bytes()) for p in [D/'results.json',D/'revision-requests.json',D/'source-findings.json',D/'official-evidence.json',D/'final-overrides.json',D/'citation-corrections.json']}))
print(counts,'requests',len(requests),'evidence',len(E))

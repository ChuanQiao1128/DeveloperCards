7题已收束：**2题卡组充分、3题确认题面欠定、2题只缺精确必要句**。完整原题、四选项与原冻结362卡保留；本报告不验收最终N、双语正式包或学习者记忆/正确率。

| 原题 | 结论 | 关键理由 |
| --- | --- | --- |
| Q49 | SOURCE_ISSUE | S3中已建的客户/日期位置索引可查，不应把C等同“任意标签搜索”。RDS固定成本与Deep Archive多年节省，随正常冷库规模反转C/D次序。 |
| Q257 | INSUFFICIENT_CARDS；技术候选C | 原文要报告扩缩容events。Metric Streams导出数值指标，不能自动输出逐活动成功/失败记录；定时Lambda可取控制面活动记录，但当前卡没教此数据来源。 |
| Q463 | SUPPORTED C | 原题每床2MB、1GB、30秒，是当前卡已教的S3事件触发Python Lambda短任务；不为无跨节点需求引入Spark ETL/EMR。Glue也是serverless，未用错误理由排除。 |
| Q534 | SOURCE_ISSUE | 后60天无读取时，对象大小改变C/D最低总费。第90天expiration优先，B/D不会先进入Flexible再付最低归档费。 |
| Q551 | SOURCE_ISSUE | 现行B的7天转Standard-IA合法。固定50KB/5年，仅改变冷读0次与每年1次，A/B费用次序即反转。 |
| Q649 | SUPPORTED C | 现有卡明确RDS gp3从400GiB起含12000基线，可到64000IOPS，够用时先提高gp3。15000在范围内，缺容量没有产生另一答案。 |
| Q989 | INSUFFICIENT_CARDS；技术候选C | 原生集群保留1–35天可设30天，手工快照另删。AWS Backup不支持该Multi-AZ DB cluster的连续备份/PITR；当前卡没教足以排除A的这个资源边界。 |

全部费用均为当前AWS us-east-1公开按需美元价格。单价的SKU、完整属性、发布版本、源文件SHA与计算组件保存在`cost-calculations.json`，本地脚本`calculate_costs.py`可复算。下表只列差异部分，共同的上传、前段Standard访问和同量数据出站费用抵消。

| 题目/具体情境 | 较便宜方案 | 比较费用USD |
| --- | --- | --- |
| Q49：10万冷文件，每个1MiB，12月热存+60月冷存，按客户/日期查位置，每年冷取回0.1% | C | 60个月C 30.75；D 850.85 |
| Q49：相同访问/保留规则，2000万冷文件 | D | 60个月C 6135.40；D 4501.44 |
| Q534：100万份50KiB日志，前30天频繁分析，后60天无读取 | D | C 31.20；B 13.05；D 12.44 |
| Q534：相同规则，每份10MiB | C | C 136.15；B 254.14；D 205.31 |
| Q551：100万份，每份50,000字节，首周后保留5年，无冷读取 | A | A 57.18；B 101.55 |
| Q551：相同文件/保留规则，每年只冷读一次 | B | A 311.69；B 108.88 |

Q49两例均采用新客户、无S3/Glacier Select既有使用资格；B在该明确情境不能使用。官方仍服务合格既有客户，未把它称为全面退役。C的索引按客户/日期编排S3对象键，保存文件位置，不要求S3原生执行任意标签谓词。两例含标签、索引存储/请求、归档元数据、转换、低频恢复与RDS：小例db.t4g.micro/20GiB，大例db.t4g.small/100GiB，低吞吐索引查询。两例热数据均在Standard，原题允许旧文件等待；没有删掉原题条件。

Q534的HA要求按原文只施于前30天。没有把它私下延长到全部90天。Flexible虽只实际保留60天，仍支付90天最低存储费；这不禁止提前删除。50KiB例用文档允许的显式尺寸filter转层，属于正常配置。A字面“Lifecycle转到STANDARD”不在当前支持枚举；如果宽松解释为继续存Standard，小对象费用可能更低，只会进一步推翻“C必然唯一最便宜”。

Q551用了一个关键现行变更：[AWS于2026-07-16移除Standard到Standard-IA/OneZone-IA的30天年龄限制](https://aws.amazon.com/about-aws/whats-new/2026/07/s3-removes-30-day-transitions-standard-ia-one-zone-ia/)。30天最低计费期仍存在，不能混为同一规则。实算包含IA的128KiB最低对象、Flexible的32KiB归档/8KiB Standard元数据、转层请求、Standard恢复请求、取回字节及一天临时副本。A按通常3–5小时Standard恢复，不用常常超过6小时的Bulk。C所写自动分层对全50KB对象不成立，不能私改为另一条Lifecycle动作；D取回超通常6小时预算。

Q649的价表只复核当前已有“够用先用gp3”的可见判断规则：同容量S时，gp3为0.115S+60美元/月，io1为0.125S+1500；后者多0.01S+1440。即使小库要把gp3分到400GiB，也为106美元/月；io1为15000IOPS至少需300GiB，为1537.50。没有要求学习者背这组动态价率，也没有把本次私有查价当作已教前提。

Q463也没有用私有价格替代教学：GSC-133明确Python/1GB与900秒范围；GSC-029给S3创建事件；CUR:CA17和GSC-136给按请求托管执行及资源/时长的因果；GSC-097及**supplemental15已接受的GSC-095新正文**解释Spark多worker处理的用途。每床独立小任务不需要该分布式规模。公开Lambda费用约0.000500201美元/文件只是合理性复核；未要求背Glue DPU下限，未虚构大规模聚合或Spot例外。

仅需定向补足的可见知识有两句，不要求新增卡或重审其他内容：

1. **Q257**：扩缩容成功/失败等逐次活动状态可由DescribeScalingActivities取得并定时落S3；Metric Streams只导出数值指标，不承载活动事件明细。[活动API](https://docs.aws.amazon.com/autoscaling/ec2/APIReference/API_DescribeScalingActivities.html)与现存指标快照分别在证据注册表`ASG_ACTIVITY_API`、`ASG_METRIC_SCHEMA`。本题未被标成“events也许是metrics”的泛化源疑点。
2. **Q989**：RDS Multi-AZ DB cluster的自动备份窗口可原生设1–35天；AWS Backup不支持该集群连续备份/PITR，周期快照计划不等于接管原生自动备份。[AWS Backup当前支持说明](https://docs.aws.amazon.com/aws-backup/latest/devguide/point-in-time-recovery.html)及[ModifyDBCluster](https://docs.aws.amazon.com/AmazonRDS/latest/APIReference/API_ModifyDBCluster.html)已有精确快照。没有声称AWS Backup必有固定附加费或必造新全量副本；DB实例快照的增量链说明保留其instance范围。RDS免费备份额度涵盖DB/cluster snapshots，删除旧快照的节省还取决于共享计费块。

原冻结362核心卡不改；只对实际用到的GSC-095引用supplemental15独立PASS与当前正文`d5a8e6ba11647c3c75b75b23f6403c3054316362efcaa22e80aedd3284150ac3`。VC-006复用supplemental13同正文FACT证据。当前`cards.current.json`为370候选，`core-visible-knowledge.provisional.json`为362拟保留卡；8项历史候选不被本报告当作新增或最终N。

25份官方证据快照、原题/可见卡精确句段、全部选项去向与7题结构化结论在`evidence-registry.json`、`results.json`。`readback.json`核验输入未变、当前必要正文、证据字句/SHA、官方价率SKU、双情境计算和状态计数。本轮CLI/API模型调用0，native用量unknown；无新卡/练习作者、无发布或生产库存修改，原时钟、预算、历史用量不重置。

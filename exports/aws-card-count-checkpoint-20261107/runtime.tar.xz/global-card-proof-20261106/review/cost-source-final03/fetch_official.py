import json,pathlib,requests,hashlib,concurrent.futures,datetime
from html.parser import HTMLParser
class Parser(HTMLParser):
 def __init__(self): super().__init__();self.out=[];self.skip=0
 def handle_starttag(self,tag,attrs):
  if tag in ("script","style","nav"): self.skip+=1
 def handle_endtag(self,tag):
  if tag in ("script","style","nav") and self.skip: self.skip-=1
 def handle_data(self,data):
  if not self.skip and data.strip():self.out.append(data.strip())
base=pathlib.Path(__file__).parent/'evidence'
urls={'backup-pitr': 'https://docs.aws.amazon.com/aws-backup/latest/devguide/point-in-time-recovery.html', 'backup-rds': 'https://docs.aws.amazon.com/aws-backup/latest/devguide/rds-backup.html', 'rds-retention': 'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_WorkingWithAutomatedBackups.BackupRetention.html', 'rds-modifycluster': 'https://docs.aws.amazon.com/AmazonRDS/latest/APIReference/API_ModifyDBCluster.html', 'rds-storage': 'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_Storage.html', 's3-transition-api': 'https://docs.aws.amazon.com/AmazonS3/latest/API/API_Transition.html', 's3-lifecycle-constraints': 'https://docs.aws.amazon.com/AmazonS3/latest/userguide/lifecycle-transition-general-considerations.html', 's3-lifecycle-overlap': 'https://docs.aws.amazon.com/AmazonS3/latest/userguide/lifecycle-configuration-examples.html', 'asg-activities': 'https://docs.aws.amazon.com/autoscaling/ec2/APIReference/API_DescribeScalingActivities.html', 's3-listobjects': 'https://docs.aws.amazon.com/AmazonS3/latest/API/API_ListObjectsV2.html', 's3-query-metadata': 'https://docs.aws.amazon.com/AmazonS3/latest/userguide/metadata-tables-overview.html', 'lambda-pricing': 'https://aws.amazon.com/lambda/pricing/', 'glue-pricing': 'https://aws.amazon.com/glue/pricing/', 's3-glacier-select': 'https://docs.aws.amazon.com/amazonglacier/latest/dev/querying-archives.html'}

def fetch(kv):
 k,u=kv;r=requests.get(u,timeout=45);r.raise_for_status();s=Parser();s.feed(r.content.decode("utf-8"));t='\n'.join(s.out);d={'url':u,'finalUrl':r.url,'httpStatus':r.status_code,'retrievedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':t,'textSha256':hashlib.sha256(t.encode()).hexdigest(),'htmlSha256':hashlib.sha256(r.content).hexdigest()};f=base/(k+'.snapshot.json');f.write_text(json.dumps(d,ensure_ascii=False,indent=2));return(k,len(t),r.url)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
 for item in urls.items():
  try:print(fetch(item))
  except Exception as e:print(item[0],str(e))

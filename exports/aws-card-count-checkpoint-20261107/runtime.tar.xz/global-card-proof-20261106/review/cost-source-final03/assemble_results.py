import pathlib,json,hashlib,datetime,collections
P=pathlib.Path(__file__).parent;V=P.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
manifest=json.loads((P/'input/manifest.json').read_text())
for fn,h in manifest.items():assert sha(pathlib.Path(fn))==h,(fn,'input changed')
qs={q['qid']:q['question'] for q in json.loads((P/'input/questions.json').read_text())}
cs={c['ruleId']:c for c in json.loads((P/'input/visible-pool.frozen.json').read_text())}
assert len(cs)==362
# Preserve frozen source; overlay only the explicit current accepted dependency actually used.
supp15Path=V/'review/reuse-a/supplemental15.review.json'
supp15=json.loads(supp15Path.read_text())
new095=next(x for x in supp15['results'] if x['ruleId']=='GSC-095')
assert new095['status']=='PASS'
old095=cs['GSC-095']['bodySha256']
cs['GSC-095']=dict(cs['GSC-095'],visibleBody=new095['visibleBody'],bodySha256=new095['bodySha256'],prerequisiteRuleIds=new095['prerequisiteRuleIds'])
currentIncrement=[{'ruleId':'GSC-095','frozenBodySha256':old095,'currentBodySha256':new095['bodySha256'],'currentVisibleBody':new095['visibleBody'],'independentProofPath':str(supp15Path),'independentProofSha256':sha(supp15Path),'independentStatus':'PASS','scope':'onlyQ463necessityandcurrentbodychecked;unrelatedproofsnotrerun','frozenInputMutated':False}]
for c in cs.values():assert canon(c['visibleBody'])==c['bodySha256'],c['ruleId']
cost=json.loads((P/'cost-calculations.json').read_text())
evidence={}
def ev(k,rel,quotes):
 f=V/rel;o=json.loads(f.read_text());t=o['text'];assert hashlib.sha256(t.encode()).hexdigest()==o['textSha256']
 refs=[]
 for q in quotes:
  assert q in t,(k,repr(q));s=t.index(q);refs.append({'quote':q,'start':s,'end':s+len(q)})
 evidence[k]={'sourceFile':str(f),'sourceFileSha256':sha(f),'textSha256':o['textSha256'],'url':o['url'],'finalUrl':o.get('finalUrl',o['url']),'httpStatus':o.get('httpStatus',200),'quotes':refs,'reusedSnapshot':not str(f).startswith(str(P))}
 return k
E='review/cost-source-final03/evidence/'
O='review/remaining-source10/evidence/'
ev('S3_PRICING_NOTES',O+'s3-pricing.json',[
'8 KB charged at S3 Standard rates and 32 KB charged at S3 Glacier Flexible Retrieval or S3 Deep Archive rates',
'S3 Standard-IA and S3 One Zone-IA storage have a minimum billable object size of 128 KB.',
'S3 Glacier Instant Retrieval and S3 Glacier Flexible Retrieval are charged for a minimum storage duration of 90 days',
'charged at the S3 Standard storage rate for a duration of time you choose'])
ev('S3_RETRIEVAL_TIMES','review/reuse-a/sources/da2fee77e2fad08a2b8c.json',['Standard retrievals typically finish within 3–5 hours for the S3 Glacier Flexible Retrieval storage class','Standard retrievals typically finish within 12 hours for the S3 Glacier Deep Archive storage class','these retrievals typically finish within 48 hours.'])
ev('S3_EARLY_IA_20260716',E+'s3-early-ia-announcement.snapshot.json',[
'Jul 16, 2026','You can now transition objects to S3 Standard-Infrequent Access (S3 Standard-IA) and S3 One Zone-Infrequent Access (S3 One Zone-IA) as soon as the day they are created, without the previous 30-day minimum retention in S3 Standard.'])
ev('S3_TRANSITION_API',E+'s3-transition-api.snapshot.json',['The value can be\n0\nor any positive integer.','GLACIER | STANDARD_IA | ONEZONE_IA | INTELLIGENT_TIERING | DEEP_ARCHIVE | GLACIER_IR'])
ev('S3_SMALL_OBJECT_OVERRIDE',E+'s3-lifecycle-constraints.snapshot.json',['Objects smaller than 128 KB will not transition by default to any storage class','To allow smaller objects to transition, you can add an\nobject size filter'])
ev('S3_EXPIRATION_PRIORITY',E+'s3-lifecycle-overlap.snapshot.json',['Permanent deletion takes precedence over transition.'])
ev('S3_METADATA_KEYS',E+'s3-listobjects.snapshot.json',['Returns some or all (up to 1,000) of the objects in a bucket with each request.','Limits the response to keys that begin with the specified prefix.'])
ev('S3_SELECT_ELIGIBILITY',E+'s3-restore-api.snapshot.json',['Amazon S3 Select is no longer available to new customers. Existing customers of Amazon S3 Select can\n        continue to use the feature as usual.','Describes the parameters for Select job types.'])
ev('AWS_MAINTENANCE',E+'aws-maintenance.snapshot.json',['Customers can\'t on-board to services\n   and features in the maintenance stage.','Customers already using these services and features can continue to do so.','Amazon S3 Glacier Select\nJuly 25, 2024'])
ev('S3_INTELLIGENT_SMALL',E+'s3-classes.snapshot.json',['If the size of an object is less than 128 KB, it is not monitored and not eligible for\n        auto-tiering. Smaller objects are always stored in the Frequent Access tier.'])
ev('ASG_ACTIVITY_API',E+'asg-activities.snapshot.json',['Gets information about the scaling activities in the account and Region.','When scaling events occur, you see a record of the scaling activity in the scaling\n            activities.','StatusCode','StatusMessage'])
ev('ASG_METRIC_SCHEMA',O+'asg-metrics.json',['Group metrics are available at one-minute granularity at no additional charge, but you must enable them.','GroupInServiceInstances The number of instances that are running as part of the Auto Scaling group.','GroupPendingInstances'])
ev('CW_METRIC_STREAMS',O+'cw-streams.json',['continually stream CloudWatch metrics to a destination of your choice, with near-real-time delivery and low latency.','Custom setup with Firehose'])
ev('ASG_EVENTBRIDGE',O+'asg-events.json',['Events from Amazon EC2 Auto Scaling are delivered to EventBridge in near real time.'])
ev('LAMBDA_PRICING',E+'lambda-pricing.snapshot.json',['The monthly compute price is $0.0000166667 per GB-s','The monthly request price is $0.20 per one million requests'])
ev('LAMBDA_LIMITS',O+'lambda-limits.json',['900 seconds'])
ev('S3_EVENT_NOTIFICATION',O+'s3-notifications.json',['AWS Lambda'])
ev('GLUE_PRICING',E+'glue-pricing.snapshot.json',['The price of 1 DPU-hour is $0.44.'])
ev('GLUE_SPARK_RESOURCES',E+'glue-job-api.snapshot.json',['you can allocate from 2 to 100 DPUs. The default is 10 DPUs. This job type cannot\n              have a fractional DPU allocation.'])
ev('RDS_GP3_STORAGE',E+'rds-storage.snapshot.json',['By using General Purpose gp3 storage volumes, you can customize storage\n                performance independently of storage capacity.','400–65,536 GiB\n12,000 IOPS/500 MiB/s\n12,000–64,000 IOPS','The ratio of IOPS to allocated storage (in GiB) must be from 1–50\n                        on RDS for SQL Server, and 0.5–50 on other RDS DB engines.'])
ev('BACKUP_MULTIAZ_PITR',E+'backup-pitr.snapshot.json',['AWS Backup does not support\n          continuous backups or point-in-time recovery for Amazon RDS Multi-AZ clusters.'])
ev('RDS_CLUSTER_RETENTION',E+'rds-retention.snapshot.json',['For a Multi-AZ DB cluster, you can set the backup retention period\n            to between 1 and 35 days.'])
ev('RDS_MODIFY_CLUSTER_RETENTION',E+'rds-modifycluster.snapshot.json',['BackupRetentionPeriod\nThe number of days for which automated backups are retained. Specify a minimum value of\n1\n.\nValid for Cluster Type: Aurora DB clusters and Multi-AZ DB clusters','Must be a value from 1 to 35.'])
ev('RDS_BACKUP_ACCOUNTING',E+'rds-backup-guide.snapshot.json',['Amazon RDS provides a free amount of backup storage equal to 100 percent of the total\n                provisioned database storage in your AWS account for each Region.','You receive this free allowance for DB snapshots and DB cluster snapshots.'])
ev('BACKUP_RDS_SNAPSHOT_TYPES',E+'backup-rds.snapshot.json',['Periodic snapshots\ncreated by AWS Backup are considered manual backups in Amazon RDS.','Continuous backups\ncreated by AWS Backup are considered automated backups in Amazon RDS.','All snapshots of a DB instance, whether they come from Amazon RDS automated backups, manual snapshots, or AWS Backup, belong to the same incremental snapshot chain for that instance.','AWS Backup backs up and supports Amazon RDS for MySQL and for PostgreSQL Multi-AZ'])
(P/'evidence-registry.json').write_text(json.dumps({'evidence':evidence,'priceBindingsFile':str(P/'cost-calculations.json'),'priceBindingsFileSha256':sha(P/'cost-calculations.json'),'priceRegistryLocation':'priceBindings','pricesAreOfficialCorroborationNotInvisibleLearnerTeaching':True},ensure_ascii=False,indent=2)+'\n')

def anchors(rule,fields=None):
 c=cs[rule];a=[]
 for f in fields or ['frontZH','answerZH','keyPointZH','watchOutZH']:
  q=c['visibleBody'].get(f,'')
  if q:a.append({'ruleId':rule,'bodySha256':c['bodySha256'],'field':f,'quote':q,'start':0,'end':len(q),'role':'necessary_visible_premise'})
 return a

def result(qid,status,selected,ids,reason,competition,eids,opts,**kw):
 rec=[]
 def walk(r):
  if r in rec:return
  rec.append(r)
  for a in cs[r].get('prerequisiteRuleIds',[]):walk(a)
 for r in ids:walk(r)
 o={'qid':qid,'status':status,'questionCanonicalSha256':canon(qs[qid]),'questionInputObjectSha256':canon(qs[qid]),'originalQuestionPreserved':True,'fullStemAndAllOptionsReviewed':True,'selectedOptionOrdinals':selected,'selectedOrdinalsMeaning':'technical candidate or scenario alternatives; original SUPPORTED only if status says SUPPORTED','choiceReasoning':reason,'keyCompetitionReasoning':competition,'optionDispositions':[{'ordinal':i+1,'originalLabel':chr(65+i),'textSha256':hashlib.sha256(qs[qid]['options'][i]['text'].encode()).hexdigest(),'reason':r} for i,r in enumerate(opts)],'directlyUsedRuleIds':ids,'actualUsedRuleIdsIncludingRecursivePrerequisites':rec,'cardBindings':[{'ruleId':r,'bodySha256':cs[r]['bodySha256'],'prerequisiteRuleIds':cs[r].get('prerequisiteRuleIds',[])} for r in rec],'necessaryPremiseAnchors':[a for r in rec for a in anchors(r)],'officialEvidenceIds':eids,'priceEvidenceFile':str(P/'cost-calculations.json') if qid in [49,463,534,551,649] else None,'priceEvidenceFileSha256':sha(P/'cost-calculations.json') if qid in [49,463,534,551,649] else None,'factReviewSeparatedFromVisibleCardSupport':True,'learnerPerformanceMeasured':False}
 o.update(kw);return o
R=[]
R.append(result(49,'SOURCE_ISSUE',[3,4],['GSC-031','CUR:CMP-M01','GSC-024'],
'原题未给检索方式、冷数据规模/保留时长、取回量及元数据数据库的成本背景。C不是天然无查询能力：按客户/日期编码的S3 Standard位置索引可用prefix/GET查找；它不等于对任意标签执行数据库查询。D的RDS索引与Deep Archive也可满足。冻结两个常规成本情境，C/D的最低总费用次序反转，因此不能据Deep Archive单价自动选D。',
'A只加标签便声称可查询，没有提供所需的可查询索引。B使用的Glacier Select仍服务合格既有客户，不能一概称退役；但当前新客户不能使用。两个反例都取未获Select既有资格的普通客户，排除B且不改变C/D比较。',
['S3_METADATA_KEYS','S3_PRICING_NOTES','AWS_MAINTENANCE','S3_SELECT_ELIGIBILITY','RDS_BACKUP_ACCOUNTING'],[
'A未建立业务可查询索引；标签本身不满足。','B有当前既有客户资格及输入查询格式边界；两个明确反例均无该既有资格，故不靠它取得唯一答案。','C在已建客户/日期S3位置索引的情境可行，低规模时比新增RDS更便宜。','D在相同立即热读要求下可行，较大多年冷库时Deep Archive节省足以超过RDS成本。'],
remainingConditions=[{'kind':'decisive_input_missing','description':'两种已证明可行架构的费用次序随正常数据量和索引成本改变。未知的是原公司的实际数值，不是AWS能力。','blocksOriginalSupport':True}],
sourceConfirmation={'subtype':'decisive_input_missing','construct1':cost['Q49'][0],'construct2':cost['Q49'][1],'priceComparisonSummaryUSD':{'smallC':30.749630554199218,'smallD':850.8492071614583,'largeC':6135.399110839844,'largeD':4501.441432291667},'whyNotContrived':'100GiB至约20TiB冷库、每年取回0.1%、客户/日期查找和普通小型RDS，均为常规档案情境。两例热数据都在Standard；不更改原文允许旧文件等待的条件。','minimalClarificationRecommendation':'原题保留；练习版可提供一个冻结的实际计费情境，或改为选择满足访问条件的可行方案并明确Select既有资格。不要只补“Deep Archive最低单价”来假定最低总费。','originalRemainsUnchanged':True,'correctedVariantAuthored':False},
cardSufficiency='当前卡已教索引与总费用比较原则，但原题无法给出唯一费用结论；不为源欠定伪造新的价格记忆卡。'))
R.append(result(257,'INSUFFICIENT_CARDS',[3],['GCL-004','GSC-089','CUR:NS01'],
'按原文report Auto Scaling events保留逐次扩缩容活动语义。C可定时由Lambda调用DescribeScalingActivities收集活动ID、成功/失败和StatusMessage，再写S3；每分钟控制面轮询无需在实例启动路径安装agent，也不阻塞启动。原题没有给出严于该正常近实时方案的秒级上限。',
'A导出的CloudWatch group metrics是实例数/容量等数值；其一分钟粒度不能把指标自动变成逐次活动事件明细。不能仅因A更托管就将原题events降为数值容量面板。B的EMR集群与serverless目标不合；D在启动bootstrap安装agent且并未提供控制面活动记录。',
['ASG_ACTIVITY_API','ASG_METRIC_SCHEMA','CW_METRIC_STREAMS','ASG_EVENTBRIDGE'],[
'A适合已有数值指标，但不是原题字面要求的逐活动成功/失败事件明细路径。','B明确启动EMR集群，不是所需的serverless收集方案。','C技术上可行；关键控制面活动状态接口未在当前卡中教出。','D把安装采集器放入实例启动流程，且活动控制面数据并非默认实例文件。'],
remainingConditions=[{'kind':'visible_card_gap','description':'缺少活动状态从何处取得，以及数值metric与活动事件记录的区别。不是缺IAM细节或要求生产压测。','blocksOriginalSupport':True}],
minimalMissingVisiblePremises=[{'statement':'扩缩容成功/失败等逐次活动状态可由DescribeScalingActivities取得并定时落S3；Metric Streams只导出数值指标，不承载活动事件明细。','whyNecessary':'当前GCL-004只教已有指标导出；GSC-089只教时间/事件触发。学习者不能由它们自行发明C的数据来源，也不能排除A。','officialEvidenceIds':['ASG_ACTIVITY_API','ASG_METRIC_SCHEMA'],'newCardRequired':False,'suggestedScope':'可定向修订既有状态/Metric Streams卡；不要求背API全部参数或另教部署清单。'}],
sourceIssueConfirmed=False,ordinaryImplementationDetailsNotNewGaps=['循环处理Region/分页','IAM权限','记录水位与去重','一分钟schedule配置'],
privateOfficialResearchDoesNotUpgradeCurrentCardSupport=True))
R.append(result(463,'SUPPORTED',[3],['GSC-133','GSC-029','GSC-136','CUR:CA17','GSC-095','GSC-097'],
'每床2MB文件独立处理，题面给定1GB内存且30秒结束。GSC-133直接教Python/1GB可用标准Lambda且900秒上限；GSC-029教S3对象创建触发计算，CUR:CA17教按请求托管执行而不维持服务器，GSC-136教资源与实际持续时间共同影响费用。采用按对象触发的Python Lambda即可。',
'GSC-097把Spark/EMR的用途讲成把可拆计算分给多节点；这里没有跨节点规模要求。GSC-095已明确Glue也无服务器，不能用“Glue非serverless”排除A/D；成本与适配判断在于短小独立函数无需引入分布式Spark ETL资源。原题给的负载落在现有Lambda卡明确范围，不因未给总床数或未做Spot/常驻集群特殊摊销而欠定。',
['LAMBDA_PRICING','LAMBDA_LIMITS','S3_EVENT_NOTIFICATION','GLUE_PRICING','GLUE_SPARK_RESOURCES'],[
'A为该1GB/30秒独立文件任务引入Scala/Spark ETL，无须该分布式处理框架。','B的EMR Spark分布式处理资源用于规模拆分，题面无该需求；维护集群不适合此按对象短任务。','C当前可见卡足以推出内存/时间适配、S3事件及时启动和按请求执行。','D与A同样引入Spark ETL；不误称Glue不是serverless。'],
remainingConditions=[],learnerDerivation={'givens':['每床约2MB','每床独立汇总','1GB内存','30秒结束','尽早可用'],'visibleCausalChain':['GSC-133: Python/1GB符合Lambda执行范围，30秒远低于900秒','GSC-029: 文件到达触发计算，无须等待定时扫描','CUR:CA17 + GSC-136: 托管按请求执行、资源与时长决定费用','GSC-097 + GSC-095: Spark/ETL解决分布式数据处理；这里无该额外处理规模要求'],'newPrivatePriceFactRequiredForChoice':False,'priceRole':'按公开价单次Lambda约0.000500201美元仅作技术合理性复核；学习者无需背DPU下限或美元常数。'},sourceIssueConfirmed=False))
R.append(result(534,'SOURCE_ISSUE',[3,4],['CUR:CMP-M01','GSC-024','VC-012'],
'原题只在前30天要求highly available/frequent analysis，之后60天是备份保留，未补写后期多AZ要求。C可在第30天进入Flexible并第90天删除，但会支付90天归档最低计费；这不等于不可提前删除。D在后60天One Zone-IA也符合题面这段的明确要求。对象大小未给，转换请求/128KiB最低对象/40KiB元数据使C与D费用反转。',
'B/D第90天同时转换Flexible和expiration时，永久删除优先；不实际转入归档，不应额外算一笔90天归档费。A字面以Lifecycle转换至STANDARD不在Transition枚举；若宽松理解为继续留Standard，小文件情境中它只会进一步削弱C唯一最便宜，而不会恢复唯一答案。',
['S3_PRICING_NOTES','S3_TRANSITION_API','S3_SMALL_OBJECT_OVERRIDE','S3_EXPIRATION_PRIORITY'],[
'A字面Transition至STANDARD不是支持的Lifecycle转层值；不能把它私改成另一方案作唯一答案。','B可在30天进Standard-IA，90天expiration优先，无90天额外归档费。','C可行并需付90天最少归档费；10MiB日志例为最便宜。','D前30天Standard、后60天OneZone-IA可行；50KiB日志例更便宜，不能擅自把前段HA延伸到全部90天。'],
remainingConditions=[{'kind':'decisive_input_missing','description':'未提供日志对象大小/聚合程度，实算可改变最便宜的合法选项。','blocksOriginalSupport':True}],
sourceConfirmation={'subtype':'decisive_input_missing','construct1':cost['Q534'][0],'construct2':cost['Q534'][1],'smallObjectsNotASeparateSourceDefect':'按现行文档用显式对象大小filter允许50KiB转层，属于正常规则配置，不将默认128KiB门槛单独判题目不可执行。','minimalClarificationRecommendation':'若需C唯一成本答案，练习版至少明确足够大的对象（如冻结10MiB例）及后60天无读取；原题本身保留欠定。若要求全90天多AZ，要明确另加练习条件而非倒写原文。','originalRemainsUnchanged':True,'correctedVariantAuthored':False}))
R.append(result(551,'SOURCE_ISSUE',[1,2],['GSC-024','CUR:CMP-M01','VC-006','VC-012'],
'先明确现行变更：自2026-07-16起Standard-IA允许0天转层，因此B的7天已非技术错误。50KB文件可用明确尺寸filter转层。A的Flexible Standard通常3–5小时、B即时读取均满足题面通常6小时取回要求。五年保留、无冷取回时A比B便宜；同样五年、每年仅一次冷取回时，A每对象恢复请求费反使B更便宜。题面没有给后续访问量，不能唯一选A。',
'D的Deep Archive取回不符合6小时通常预算。C字面说由Intelligent-Tiering转到独立STANDARD_IA/GLACIER类别，且50KB对象不参与自动分层；不能将C偷偷改成自定义Lifecycle或忽略其要求的动作。不是把“所有小文件永远应Standard”当答案，而是对A/B两个合法选项算完整费用。',
['S3_RETRIEVAL_TIMES','S3_EARLY_IA_20260716','S3_TRANSITION_API','S3_SMALL_OBJECT_OVERRIDE','S3_PRICING_NOTES','S3_INTELLIGENT_SMALL'],[
'A可行；在五年无冷读例较便宜，需计32+8KiB及转换/恢复请求，不能只看GiB单价。','B现行7天转层可行，按128KiB最低大小收费；年取回一次例更便宜。','C所写自动分层行为对全50KB对象不成立，内部访问tiers也不等于独立S3存储类别。','D通常Deep Archive取回超6小时；不因单价最低而可选。'],
remainingConditions=[{'kind':'decisive_input_missing','description':' several years的实际年数与第1周后的取回次数未给；固定同样5年，仅年取回0/1次即可反转A/B。','blocksOriginalSupport':True}],
sourceConfirmation={'subtype':'decisive_input_missing','construct1':cost['Q551'][0],'construct2':cost['Q551'][1],'whyNotContrived':'每年一次读取是金融历史报告的普通低频需求，非高频极端场景；平均50KB按每个50,000字节实现。两例保留期和首周频繁访问完全相同。','technicalChangeDate':'2026-07-16','oldBefore30DaysProhibitionUsed':False,'minimumBillingConfusedWithTransitionEligibility':False,'minimalClarificationRecommendation':'练习版可明确实际保留5年且首周后不再读取，再比较完整总费；不要沿用已移除的30天年龄门槛来排除B。','originalRemainsUnchanged':True,'correctedVariantAuthored':False}))
R.append(result(649,'SUPPORTED',[3],['GSC-015','GSC-051'],
'GSC-015已教gp2的基线与容量相连，gp3可独立配性能且RDS不能照搬EC2规则。GSC-051进一步明确PostgreSQL从400GiB起gp3有12000基线，可配到64000，并直接教在满足范围内先提高gp3、再比更高档存储。15000在该范围内，故C符合独立IOPS和正常成本选型。未给容量不产生另一答案：小库可正常分配400GiB；其费用仍远低于io1为15000IOPS所需费用。',
'A的gp2不能独立指定所需IOPS；B的io1能独立配置但没有题面要求gp3之外的持续性能/延迟边界；D磁盘不是此高IOPS独立配置选择。原文on-premises同时提EBS虽不寻常，并非改变目标RDS卷型的必要矛盾（如Outposts背景亦可），不据此豁免原题。',
['RDS_GP3_STORAGE'],[
'A与独立于容量配置IOPS不符。','B可行但按当前已有“够用先用gp3”的规则无额外高档需求；官方价表复核其IOPS费更高。','C在RDS实际400GiB门槛与64000IOPS范围内可配15000；按现有卡的选择规则优先。','D不提供所需高性能独立IOPS配置。'],
remainingConditions=[],learnerDerivation={'givens':['RDS PostgreSQL','峰值不超过15000IOPS','独立于存储容量配置IOPS','最合算'],'visibleCausalChain':['GSC-015排除gp2容量关联型并提醒产品边界','GSC-051明确RDS400GiB/12000基线/64000上限，15000属于支持范围','GSC-051答案明确先提高gp3、满足不了所需持续性能等再比更高档，无需自行猜价格'],'newPrivatePriceFactRequiredForChoice':False,'priceRole':'公开价率用于独立核查既有选择规则在本题确实成立；不要求把0.02/0.10美元或额外3000IOPS计费常数当已教的学生必答。'},technicalCostCrosscheck=cost['Q649'],sourceIssueConfirmed=False))
R.append(result(989,'INSUFFICIENT_CARDS',[3],['VC-010','GSC-047','CUR:NS03'],
'技术上C正确：原生RDS Multi-AZ DB cluster的自动备份保留期可设1–35天，设30天，并另删超30天手工快照，保持年轻恢复点。AWS Backup可做该集群周期快照，但当前不支持其连续备份/PITR，不能用A所述路径接管原生自动备份保留窗口。B/D的先禁用对该集群也非有效配置，且与保留现有自动恢复点的意图不符。',
'不能声称AWS Backup一定额外创建完整一份/必有固定附加费来排除A。官方说明DB实例的自动/手工/Backup快照共享增量链；此事实范围是instance，不能任意扩大到全部集群。RDS备份免费额度同时涵盖DB/cluster snapshots，删除旧快照的实际节省取决于计费块与共享引用，不等于每张全量字节立即消失。当前卡已足够教C的动作，但CUR:NS03的“受支持资源”没有告诉学习者A为什么对这个明确的Multi-AZ DB cluster不能管理连续备份，仍缺精确一条边界。',
['BACKUP_MULTIAZ_PITR','RDS_CLUSTER_RETENTION','RDS_MODIFY_CLUSTER_RETENTION','RDS_BACKUP_ACCOUNTING','BACKUP_RDS_SNAPSHOT_TYPES'],[
'A错在该Multi-AZ DB cluster无AWS Backup连续备份/PITR支持，周期快照计划不等于原生自动备份保留策略。','B的禁用自动备份不是Multi-AZ DB cluster支持的保留0配置，也不能用于保留现有年轻自动恢复点。','C原生保留30天加手工删除旧手工快照，技术正确；当前卡欠A所需资源边界。','D同B的禁用问题；CloudFormation不自动赋予手工快照按龄清理含义。'],
remainingConditions=[{'kind':'visible_card_gap','description':'缺当前Multi-AZ DB cluster与AWS Backup连续备份/PITR的支持边界；不是成本未知、不是A/C同效同价的源问题。','blocksOriginalSupport':True}],
minimalMissingVisiblePremises=[{'statement':'RDS Multi-AZ DB cluster的自动备份窗口可原生设1–35天；AWS Backup不支持该集群的连续备份/PITR，周期快照计划不等于接管原生自动备份。','whyNecessary':'当前VC-010已教手工快照另删，GSC-047已教PITR最多35天；还缺排除几乎同动作的A所需的资源特有支持边界。','officialEvidenceIds':['BACKUP_MULTIAZ_PITR','RDS_MODIFY_CLUSTER_RETENTION','BACKUP_RDS_SNAPSHOT_TYPES'],'newCardRequired':False,'suggestedScope':'只在现有保留策略/Backup边界卡定向补一句；不重审其他备份知识。'}],
sourceIssueConfirmed=False,privateOfficialResearchDoesNotUpgradeCurrentCardSupport=True))
assert set(qs)=={r['qid'] for r in R}
output={'reviewId':'cost-source-final03','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'independent_native','scope':'7 full original questions, all options, actual frozen362 visible cards; ordinary architecture choices and concrete cost/source cases only','inputManifestSha256':sha(P/'input/manifest.json'),'candidatePoolCount':362,'candidatePoolIsFinalN':False,'explicitCurrentIncrementalDependencies':currentIncrement,'reusedUnchangedProofs':[{'ruleId':'VC-006','bodySha256':cs['VC-006']['bodySha256'],'proofPath':str(V/'review/reuse-a/supplemental13.review.json'),'proofSha256':sha(V/'review/reuse-a/supplemental13.review.json'),'status':'PASS','scope':'same visible body and CUR:CMP-M01 dependency; no unrelated re-review'}],'originalQuestionCount':7,'statusCounts':dict(collections.Counter(r['status'] for r in R)),'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','priorClockBudgetCountersReset':False,'originalQuestionEdits':0,'currentProductionInventoryEdits':0,'correctedVariantsAuthored':0,'newCardsAuthored':0,'subagentsSpawned':0,'evidenceRegistryFile':str(P/'evidence-registry.json'),'evidenceRegistrySha256':sha(P/'evidence-registry.json'),'deterministicCalculationsFile':str(P/'cost-calculations.json'),'deterministicCalculationsSha256':sha(P/'cost-calculations.json'),'results':R,'resolvedEarlierPitfalls':['Q463 is ordinary short-function choice; no imagined bulk/Spot counterexample','Q649 missing storage size alone does not defeat gp3','Q551 current July2026 age rule removal, not obsolete30day exclusion','Q534 day90 expiration priority applied before charging transitions','Q989 AWS Backup current cluster support checked before billing','Q257 events not silently renamed metrics','Q49 S3 prefix index feasible; Select not called globally retired']}
(P/'results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(output['statusCounts']);print('evidence',len(evidence));print('results sha',sha(P/'results.json'))

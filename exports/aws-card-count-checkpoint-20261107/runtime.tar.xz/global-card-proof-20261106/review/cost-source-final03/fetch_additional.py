import json,pathlib,requests,hashlib,concurrent.futures,datetime
from html.parser import HTMLParser
class Parser(HTMLParser):
 def __init__(self): super().__init__();self.out=[];self.skip=0
 def handle_starttag(self,tag,attrs):
  if tag in ("script","style","nav"): self.skip+=1
 def handle_endtag(self,tag):
  if tag in ("script","style","nav") and self.skip: self.skip-=1
 def handle_data(self,data):
  if not self.skip and data.strip():self.out.append(data.strip())
base=pathlib.Path(__file__).parent/'evidence'
urls={'s3-early-ia-announcement': 'https://aws.amazon.com/about-aws/whats-new/2026/07/s3-removes-30-day-transitions-standard-ia-one-zone-ia/', 's3-restore-api': 'https://docs.aws.amazon.com/AmazonS3/latest/API/API_RestoreObject.html', 'aws-maintenance': 'https://docs.aws.amazon.com/general/latest/gr/maintenance_services.html', 's3-classes': 'https://docs.aws.amazon.com/AmazonS3/latest/userguide/storage-class-intro.html', 'rds-pg-pricing': 'https://aws.amazon.com/rds/postgresql/pricing/'}

def fetch(kv):
 k,u=kv;r=requests.get(u,timeout=45);r.raise_for_status();s=Parser();s.feed(r.content.decode("utf-8"));t='\n'.join(s.out);d={'url':u,'finalUrl':r.url,'httpStatus':r.status_code,'retrievedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':t,'textSha256':hashlib.sha256(t.encode()).hexdigest(),'htmlSha256':hashlib.sha256(r.content).hexdigest()};f=base/(k+'.snapshot.json');f.write_text(json.dumps(d,ensure_ascii=False,indent=2));return(k,len(t),r.url)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
 for item in urls.items():
  try:print(fetch(item))
  except Exception as e:print(item[0],str(e))

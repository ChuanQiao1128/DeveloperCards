import json,pathlib,hashlib,datetime
P=pathlib.Path(__file__).parent
V=P.parent.parent
B=V/'review/remaining-source10/evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plans={
's3-price-list-us-east-1.raw.json':{
 'standard':'WP9ANXZGBYYSGJEA','sia':'379GYJUQ5WFBUYGM','onezone':'KRY2B57FKTA8GJW7','gir':'NMJQ7TNW84EMBGZM','flex':'ZGASJWMFVH7NM8RK',
 'to_flex':'M2EZ4Q623R8XZ29A','to_sia':'JS3WNUP3WAZ96Q9X','to_onezone':'7Q8ZATUMRNWEPNWW','to_gir':'GMZJHKZDB9NQ9KKY','to_deep':'GQYN2VTWYJQVTWHQ',
 'flex_standard_restore_request':'XMSYDEX5BP3Q5UJE','flex_standard_retrieval_gb':'RWFBVGMQR3SY34J8','sia_retrieval_gb':'7594RTQEE8ND34GA','gir_retrieval_gb':'CN3DWKRWAMMHWCA3',
 'standard_get':'ZWQ6Q48CRJXX4FXE','sia_get':'GWU4HUHFNSRYMYNK','gir_get':'6WKRC2AMC45PNCVZ','deep_get':'WDAC2WRXVNRSNQS6','tag_month':'G76SDFUV63NSS6N2'},
's3gda-price-list-us-east-1.raw.json':{'deep':'SKAKWE8C8SPXCVHA','deep_bulk_restore_request':'JKJJ28K7NEVPDS24','deep_bulk_retrieval_gb':'2B8ZACNN7SPBKWVF'},
'amazonrds-price-list-us-east-1.raw.json':{'pg_gp3_storage':'KYVYY29G957PKY3B','pg_gp3_extra_iops':'B8T8RGQTMJBCQQY7','pg_io1_storage':'BM352JYZ8GWRJANX','pg_io1_iops':'87AUQYHJFZTNDMAT','pg_micro_hour':'9HPEGXQTDDGH53C9','pg_small_hour':'S9H3AXMBHSKRFJTA'}}
prices={};rates={}
for fn,entries in plans.items():
 f=B/fn;o=json.loads(f.read_text())
 for name,sku in entries.items():
  pd=[d for t in o['terms']['OnDemand'][sku].values() for d in t['priceDimensions'].values() if d.get('beginRange')=='0'][0]
  rates[name]=float(pd['pricePerUnit']['USD'])
  prices[name]={'sku':sku,'rateCode':pd['rateCode'],'rate':rates[name],'unit':pd['unit'],'description':pd['description'],'attributes':o['products'][sku]['attributes'],'sourceFile':str(f),'sourceSha256':sha(f),'offerCode':o['offerCode'],'version':o['version'],'publicationDate':o['publicationDate'],'officialPriceListUrl':f"https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/{o['offerCode']}/current/us-east-1/index.json"}
# Standard PUT/COPY/POST/LIST rate, select normal S3 standard API group.
o=json.loads((B/'s3-price-list-us-east-1.raw.json').read_text())
for sku,p in o['products'].items():
 a=p.get('attributes',{})
 if a.get('usagetype')=='Requests-Tier1' and a.get('groupDescription')=='PUT/COPY/POST or LIST requests':
  pd=next(iter(next(iter(o['terms']['OnDemand'][sku].values()))['priceDimensions'].values()))
  rates['standard_put']=float(pd['pricePerUnit']['USD']);prices['standard_put']={'sku':sku,'rateCode':pd['rateCode'],'rate':rates['standard_put'],'unit':pd['unit'],'description':pd['description'],'attributes':a,'sourceFile':str(B/'s3-price-list-us-east-1.raw.json'),'sourceSha256':sha(B/'s3-price-list-us-east-1.raw.json'),'offerCode':o['offerCode'],'version':o['version'],'publicationDate':o['publicationDate'],'officialPriceListUrl':'https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonS3/current/us-east-1/index.json'}
assert rates['standard_put']==.000005
G=2**30;K=1024;N=1_000_000
# Q534: the first 30 days and initial uploads are identical; compare days30-90 only.
q534=[]
for label,size in [('50KiB logs',50*K),('10MiB logs',10*2**20)]:
 flex={'transition':N*rates['to_flex'],'data_plus_32KiB_at_90day_minimum':N*(size+32*K)/G*rates['flex']*3,'8KiB_metadata_at_standard_for_actual_60days':N*8*K/G*rates['standard']*2}
 ia={'transition':N*rates['to_sia'],'storage_60days':N*max(size,128*K)/G*rates['sia']*2}
 one={'transition':N*rates['to_onezone'],'storage_60days':N*max(size,128*K)/G*rates['onezone']*2}
 amounts={'C_flexible':sum(flex.values()),'B_standard_ia':sum(ia.values()),'D_onezone_ia':sum(one.values())}
 q534.append({'label':label,'objectCount':N,'objectBytes':size,'first30dayHighlyAvailableFrequentAnalysis':'Standard in all compared designs; common charges cancel','coldAccesses':0,'actualColdDays':60,'flexBillableColdDays':90,'day90Action':'expiration takes precedence; B/D do not enter Flexible on day90','costComponentsUSD':{'C':flex,'B':ia,'D':one},'comparableColdCostUSD':amounts,'leastCostLiteralValidOption':min(amounts,key=amounts.get)[0]})
assert q534[0]['leastCostLiteralValidOption']=='D' and q534[1]['leastCostLiteralValidOption']=='C'
# Q551: five years after hot week, every object exactly50,000 bytes (therefore average50KB).
q551=[];size=50_000;months=60;years=5
for reads in [0,1]:
 count=N*years*reads
 flex={'transition':N*rates['to_flex'],'data_plus_32KiB_storage':N*(size+32*K)/G*rates['flex']*months,'8KiB_standard_metadata_storage':N*8*K/G*rates['standard']*months,'standard_restore_requests':count*rates['flex_standard_restore_request'],'retrieved_bytes':count*size/G*rates['flex_standard_retrieval_gb'],'restored_copy_get_requests':count*rates['standard_get'],'temporary_copy_storage_one_day_each':count*size/G*rates['standard']/30}
 ia={'transition':N*rates['to_sia'],'128KiB_minimum_storage':N*128*K/G*rates['sia']*months,'get_requests':count*rates['sia_get'],'retrieved_bytes':count*size/G*rates['sia_retrieval_gb']}
 q551.append({'coldReadsPerObjectPerYear':reads,'objectCount':N,'averageAndIndividualBytes':size,'monthsAfterDay7':months,'hotWeek':'same Standard storage/frequent access in A/B; common charges cancel','transitionValidSince':'2026-07-16; explicit size filter permits50KB transitions','retrievalTierA':'Flexible Standard, normally3-5hours; Bulk not assumed to meet6hours','costComponentsUSD':{'A':flex,'B':ia},'comparableColdCostUSD':{'A':sum(flex.values()),'B':sum(ia.values())},'leastCostLiteralValidOption':'A' if sum(flex.values())<sum(ia.values()) else 'B'})
assert q551[0]['leastCostLiteralValidOption']=='A' and q551[1]['leastCostLiteralValidOption']=='B'
# Q49: steady-state72-month retained corpus,12 hot+60 cold months, flat monthly arrivals.
# Sixty-month cost window: N cold objects held constantly, N transitions/deletions; .2N hot common objects.
q49=[]
for label,n,dbhour,dbstorage in [('small',100_000,'pg_micro_hour',20),('large',20_000_000,'pg_small_hour',100)]:
 size=2**20;months=60;records=n*1.2;reads=n*.001*5;index_queries=100*365*5
 c={'gir_cold_storage':n*size/G*rates['gir']*months,'gir_transition_requests':n*rates['to_gir'],'one_tag_per_hot_and_cold_file':records*rates['tag_month']*months,'256byte_s3_index_record_storage_hot_and_cold':records*256/G*rates['standard']*months,'new_s3_index_record_put_requests':n*rates['standard_put'],'index_get_requests':index_queries*rates['standard_get'],'cold_gir_get_requests':reads*rates['gir_get'],'cold_retrieved_bytes':reads*size/G*rates['gir_retrieval_gb']}
 d={'deep_cold_data_plus32KiB_storage':n*(size+32*K)/G*rates['deep']*months,'8KiB_standard_metadata_storage':n*8*K/G*rates['standard']*months,'deep_transition_requests':n*rates['to_deep'],'rds_instance_730hours_per_month':rates[dbhour]*730*months,'rds_gp3_storage':dbstorage*rates['pg_gp3_storage']*months,'cold_bulk_restore_requests':reads*rates['deep_bulk_restore_request'],'cold_retrieved_bytes':reads*size/G*rates['deep_bulk_retrieval_gb'],'cold_restored_get_requests':reads*rates['deep_get'],'temporary_restored_copies_one_day_each':reads*size/G*rates['standard']/30}
 q49.append({'label':label,'coldObjectCount':n,'hotObjectCount':int(.2*n),'objectBytes':size,'coldRetentionMonths':60,'commonFirstYearStorage':'S3 Standard, immediate object access; common upload/hot read/egress charges cancel','queryShape':'Known customer and call month/date; S3 Standard index key customer/date/call-id stores256byte location records. Prefix listing/direct index GET works; no arbitrary tag predicate search claimed. RDS has same logical index.','indexQueriesPerDay':100,'coldRetrievalsPerYearAsFraction':.001,'allObjectRetentionMonths':72,'rdsInstance':'db.t4g.micro' if label=='small' else 'db.t4g.small','rdsProvisionedGiB':dbstorage,'ordinaryDatabaseConfiguration':'Low indexed query throughput; no CPU-credit overage; allocated storage covers metadata and B-tree indices, backup physical blocks within free allowance; no pre-existing shared DB or promotional credits','selectEligibilityBothConstructs':'New usage without grandfathered S3/Glacier Select; B not available as written. This is not a claim of global retirement.','costComponentsUSD':{'C':c,'D':d},'comparable60MonthCostUSD':{'C':sum(c.values()),'D':sum(d.values())},'leastCostLiteralValidOption':'C' if sum(c.values())<sum(d.values()) else 'D'})
assert q49[0]['leastCostLiteralValidOption']=='C' and q49[1]['leastCostLiteralValidOption']=='D'
q649={'region':'us-east-1','deployment':'PostgreSQL Single-AZ, same suitable DB compute; DB compute/common transfer cancel','iops':15000,'gp3BaselineAtOrAbove400GiB':12000,'gp3ExtraIopsBilled':3000,'sameCapacityFormula':{'gp3':'0.115*S + (15000-12000)*0.02 =0.115*S+60','io1':'0.125*S+15000*0.10 =0.125*S+1500','io1MinusGp3':'0.01*S+1440 >0, for same storage where both15000IOPS configurations are supported'},'smallDatasetFeasibleMinimums':{'gp3':{'allocatedGiB':400,'USDPerMonth':400*rates['pg_gp3_storage']+3000*rates['pg_gp3_extra_iops']},'io1':{'allocatedGiB':300,'USDPerMonth':300*rates['pg_io1_storage']+15000*rates['pg_io1_iops']},'basis':'io1 max50IOPS/GiB; additional gp3IOPS requires>=400GiB for PostgreSQL'},'capacityIsMissingDecisiveInput':False,'priceTableIsNewLearnerPremise':False}
q463={'region':'us-east-1','onDemandLambdaX86ExampleUSDPerFile':30*.0000166667+.20/1_000_000,'givenDurationSeconds':30,'givenMemoryGiB':1,'architectureReason':'Current visible function-fit, event-driven processing and resource-duration cost rules apply to an independent per-object short job; distributed Spark scale-out has no requirement here. Not a forecast that every conceivable amortized market configuration loses.','dpuMinimumNotUsedAsHiddenLearnerPremise':True}
result={'generatedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Deterministic counterexamples and ordinary-platform cost corroboration; no real services or paid API invoked','currency':'USD','region':'us-east-1','pricingMode':'current public on-demand, no tax/credits/reserved-market enumeration','GBDivisor':G,'rates':rates,'priceBindings':prices,'Q49':q49,'Q534':q534,'Q551':q551,'Q649':q649,'Q463':q463}
(P/'cost-calculations.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for q in ['Q49','Q534','Q551']:
 print(q,[(x.get('label',x.get('coldReadsPerObjectPerYear')),x.get('comparable60MonthCostUSD',x.get('comparableColdCostUSD')),x['leastCostLiteralValidOption']) for x in result[q]])
print('Q649',q649['smallDatasetFeasibleMinimums'])

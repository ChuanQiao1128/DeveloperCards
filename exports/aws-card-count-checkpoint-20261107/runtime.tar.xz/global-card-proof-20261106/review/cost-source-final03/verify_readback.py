import json,pathlib,hashlib,collections,datetime,math
P=pathlib.Path(__file__).parent;V=P.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
read=lambda p:json.loads(p.read_text())
manifest=read(P/'input/manifest.json');checks=[]
def check(label,condition):
 assert condition,label
 checks.append({'check':label,'status':'PASS'})
for f,h in manifest.items():check('frozen input '+str(pathlib.Path(f).name),sha(pathlib.Path(f))==h)
r=read(P/'results.json');c=read(P/'cost-calculations.json');er=read(P/'evidence-registry.json');frozen={x['ruleId']:x for x in read(P/'input/visible-pool.frozen.json')};q={x['qid']:x['question'] for x in read(P/'input/questions.json')}
check('7 exact originals, no extra question',len(r['results'])==7 and {x['qid'] for x in r['results']}==set(q))
check('status counts',r['statusCounts']=={'SOURCE_ISSUE':3,'INSUFFICIENT_CARDS':2,'SUPPORTED':2} and r['statusCounts']==dict(collections.Counter(x['status'] for x in r['results'])))
check('result binds evidence registry',sha(P/'evidence-registry.json')==r['evidenceRegistrySha256'])
check('result binds cost file',sha(P/'cost-calculations.json')==r['deterministicCalculationsSha256'])
effective=dict(frozen)
for dep in r['explicitCurrentIncrementalDependencies']:
 p=pathlib.Path(dep['independentProofPath']);o=read(p);check('current increment proof hash '+dep['ruleId'],sha(p)==dep['independentProofSha256'])
 item=next(x for x in o['results'] if x['ruleId']==dep['ruleId'])
 check('current increment independent PASS '+dep['ruleId'],item['status']=='PASS' and item['bodySha256']==dep['currentBodySha256'] and canon(item['visibleBody'])==dep['currentBodySha256'])
 effective[dep['ruleId']]=dict(frozen[dep['ruleId']],visibleBody=item['visibleBody'],bodySha256=item['bodySha256'],prerequisiteRuleIds=item['prerequisiteRuleIds'])
for proof in r['reusedUnchangedProofs']:
 p=pathlib.Path(proof['proofPath']);o=read(p);item=next(x for x in o['results'] if x['ruleId']==proof['ruleId'])
 check('unchanged prior FACT '+proof['ruleId'],sha(p)==proof['proofSha256'] and item['status']=='PASS' and item['bodySha256']==effective[proof['ruleId']]['bodySha256'] and item['prerequisiteRuleIds']==effective[proof['ruleId']]['prerequisiteRuleIds'])
for o in r['results']:
 check('full original canonical Q'+str(o['qid']),canon(q[o['qid']])==o['questionCanonicalSha256'] and len(o['optionDispositions'])==len(q[o['qid']]['options']))
 for d in o['optionDispositions']:
  check('original option Q'+str(o['qid'])+d['originalLabel'],hashlib.sha256(q[o['qid']]['options'][d['ordinal']-1]['text'].encode()).hexdigest()==d['textSha256'])
 for b in o['cardBindings']:
  e=effective[b['ruleId']];check('body/dependency Q'+str(o['qid'])+'/'+b['ruleId'],b['bodySha256']==e['bodySha256']==canon(e['visibleBody']) and b['prerequisiteRuleIds']==e['prerequisiteRuleIds'])
 for a in o['necessaryPremiseAnchors']:
  e=effective[a['ruleId']];check('visible quote Q'+str(o['qid'])+'/'+a['ruleId']+'/'+a['field'],e['bodySha256']==a['bodySha256'] and e['visibleBody'][a['field']][a['start']:a['end']]==a['quote'])
 for eid in o['officialEvidenceIds']:check('registered evidence Q'+str(o['qid'])+'/'+eid,eid in er['evidence'])
for eid,e in er['evidence'].items():
 p=pathlib.Path(e['sourceFile']);o=read(p);check('evidence file/text SHA '+eid,sha(p)==e['sourceFileSha256'] and hashlib.sha256(o['text'].encode()).hexdigest()==e['textSha256'])
 check('official URL '+eid,e['url'].startswith(('https://docs.aws.amazon.com/','https://aws.amazon.com/')))
 for anchor in e['quotes']:check('official quote '+eid+':'+str(anchor['start']),o['text'][anchor['start']:anchor['end']]==anchor['quote'])
for n,entry in c['priceBindings'].items():
 p=pathlib.Path(entry['sourceFile']);o=read(p);check('raw price source SHA '+n,sha(p)==entry['sourceSha256'])
 dims=[d for t in o['terms']['OnDemand'][entry['sku']].values() for d in t['priceDimensions'].values() if d['rateCode']==entry['rateCode']]
 check('SKU/rate/unit/attribute '+n,len(dims)==1 and float(dims[0]['pricePerUnit']['USD'])==entry['rate']==c['rates'][n] and dims[0]['unit']==entry['unit'] and o['products'][entry['sku']]['attributes']==entry['attributes'])
 check('official regional price URL '+n,entry['officialPriceListUrl'].startswith('https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/'))
for qn,expected in [('Q49',['C','D']),('Q534',['D','C']),('Q551',['A','B'])]:
 check(qn+' concrete pair reverses least cost',[x['leastCostLiteralValidOption'] for x in c[qn]]==expected)
 for case in c[qn]:
  totals=case.get('comparable60MonthCostUSD',case.get('comparableColdCostUSD'))
  if qn=='Q534':totals={k[0]:v for k,v in totals.items()}
  check(qn+' every total equals full component sum '+str(case.get('label',case.get('coldReadsPerObjectPerYear'))),all(math.isclose(totals[k],sum(v.values()),rel_tol=1e-12) for k,v in case['costComponentsUSD'].items()))
# Independent numerical spot checks exercise decisive boundaries rather than implementation mirroring.
check('Q551 50KB StandardIA128KiB minimum',math.isclose(c['Q551'][0]['costComponentsUSD']['B']['128KiB_minimum_storage'],1_000_000*131072/(2**30)*.0125*60))
check('Q534 expiration priority excludes day90 archive fee',all('expiration takes precedence' in x['day90Action'] and len(x['costComponentsUSD']['D'])==2 for x in c['Q534']))
check('Q649 small DB still favors gp3',c['Q649']['smallDatasetFeasibleMinimums']['gp3']['USDPerMonth']==106 and c['Q649']['smallDatasetFeasibleMinimums']['io1']['USDPerMonth']==1537.5)
check('Q551 current early IA announcement used','S3_EARLY_IA_20260716' in next(x for x in r['results'] if x['qid']==551)['officialEvidenceIds'])
corePath=V/'deliverables/core-visible-knowledge.provisional.json';candidatePath=V/'deliverables/cards.current.json'
core=read(corePath);candidate=read(candidatePath);coremap={x['ruleId']:x for x in core};candmap={x['ruleId']:x for x in candidate}
used={b['ruleId']:b['bodySha256'] for x in r['results'] for b in x['cardBindings']}
for rid,h in used.items():check('actual current core/candidate necessary body '+rid,coremap[rid]['bodySha256']==candmap[rid]['bodySha256']==h)
check('362 core preserved,370 candidates observation',len(coremap)==len(core)==362 and len(candmap)==len(candidate)==370)
check('no authorship or promotion by reviewer',r['newContentModelCallsCLIAPI']==0 and r['newCardsAuthored']==r['correctedVariantsAuthored']==r['originalQuestionEdits']==r['currentProductionInventoryEdits']==r['subagentsSpawned']==0 and not r['priorClockBudgetCountersReset'])
out={'reviewId':'cost-source-final03','status':'PASS','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checkCount':len(checks),'checks':checks,'inputManifestSha256':sha(P/'input/manifest.json'),'resultSha256':sha(P/'results.json'),'reportSha256':sha(P/'results.md'),'evidenceRegistrySha256':sha(P/'evidence-registry.json'),'costCalculationsSha256':sha(P/'cost-calculations.json'),'currentNecessaryCardBindingCount':len(used),'frozenCoreCount':362,'currentCoreObservation':{'path':str(corePath),'sha256':sha(corePath),'count':len(core),'countIsFinalN':False},'currentCandidateObservation':{'path':str(candidatePath),'sha256':sha(candidatePath),'count':len(candidate),'countIsFinalN':False,'explanation':'370候选与362拟保留核心是不同集合；8历史/隔离候选不当作本次新增。'},'explicitCurrentIncrementalDependencies':r['explicitCurrentIncrementalDependencies'],'reusedUnchangedProofs':r['reusedUnchangedProofs'],'unusableFetchedSourceExcluded':{'path':str(P/'evidence/s3-glacier-select.snapshot.json'),'reason':'URL returned14-char guide-root redirect; not technical evidence, no verdict relies on it.'},'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','productionInventoryMutation':False,'originalQuestionMutation':False,'priorClocksBudgetsHistoryReset':False,'supportsOnlyPartialCloseout':'2SUPPORTED/3confirmedSOURCE_ISSUE/2precisevisiblegaps; not1018coverage or finalN or measuredlearning'}
(P/'readback.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(checks),'checks',len(used),'necessarycurrentcards');print('results',out['resultSha256']);print('readback',sha(P/'readback.json'))

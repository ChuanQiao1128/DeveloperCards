import collections, datetime, hashlib, json, pathlib, runpy, shutil

V=pathlib.Path(__file__).resolve().parents[3]
O=pathlib.Path(__file__).resolve().parent
P=O/'input'
E=O/'evidence';E.mkdir(exist_ok=True)
F=['frontZH','answerZH','keyPointZH','watchOutZH']
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s):return hashlib.sha256(s.encode()).hexdigest()
def ch(x):return th(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def body(c):return {f:c.get(f,'') for f in F}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

manifest=rd(P/'manifest.json');assert all(sha(p)==h for p,h in manifest.items())
cases=rd(P/'cases.json');assert len(cases)==114
pool={c['ruleId']:c for c in rd(P/'visible-pool.frozen.json')};assert len(pool)==362
assert all(ch(c['visibleBody'])==c['bodySha256'] for c in pool.values())
ixdoc=rd(P/'card-review-index.frozen.json');ix={x['ruleId']:x for x in ixdoc['cards']}
legacy_path=V/'inputs/existing176.json';legacy={c['ruleId']:c for c in rd(legacy_path)}
canonical_path=V.parent/'domain1-final-card-catalog-20261105/questions.all.json'
canonical=rd(canonical_path)
rows=runpy.run_path(str(O/'decisions.py'))['ROWS'];decisions={r[0]:r for r in rows}
assert len(rows)==len(decisions)==114 and set(decisions)=={q['qid'] for q in cases}
proof_cache={}
def bind(rid):
    if rid in proof_cache:return proof_cache[rid]
    c=pool[rid];idx=ix[rid]
    assert idx['status']=='PASS' and idx['currentBodySha256']==c['bodySha256']
    out=[]
    for p in idx['proofs']:
        assert sha(p['path'])==p['sha256']
        d=rd(p['path']);rs=d.get('results',d.get('cards',[]))
        if isinstance(rs,dict):rs=list(rs.values())
        matches=[r for r in rs if r.get('ruleId')==rid];assert matches,(rid,p['path'])
        r=matches[-1];rh=r['bodySha256'];contract='canonical four current visible fields including empty values'
        if rh!=c['bodySha256']:
            lb=body(legacy[rid]['body'])
            assert lb==c['visibleBody'] and ch({k:v for k,v in lb.items() if v})==rh,rid
            contract='legacy omitted-empty hash; exact four fields reconstructed from existing176 and matched to current body'
        if r.get('visibleBody'):assert r['visibleBody']==c['visibleBody']
        z=dict(ruleId=rid,path=p['path'],sha256=p['sha256'],receiptBodySha256=rh,currentBodySha256=c['bodySha256'],bodyBindingContract=contract)
        if r.get('proofs'):
            for pp in r['proofs']:assert sha(pp['path'])==pp['sha256']
            z['parentGateReceipts']=r['proofs']
        out.append(z)
    proof_cache[rid]=out;return out
def anchors(rid):
    c=pool[rid]
    return [dict(ruleId=rid,bodySha256=c['bodySha256'],field=f,quote=c['visibleBody'][f],startChar=0,endChar=len(c['visibleBody'][f]),offsetUnit='Unicode code points; zero-based half-open') for f in F if c['visibleBody'].get(f)]

# Source-only research is kept separate from learning-card anchors.
registry={}
def textcite(source,needle,end,claim):
    source=pathlib.Path(source)
    if not source.is_absolute():source=V/source
    frozen=E/(sha(source)+'.json')
    if not frozen.exists():shutil.copyfile(source,frozen)
    assert sha(frozen)==sha(source)
    d=rd(frozen);s=d['text'];lo=s.index(needle);hi=s.index(end,lo)+len(end);q=s[lo:hi]
    z=dict(claim=claim,url=d['url'],sourcePath=str(frozen),sourceFileSha256=sha(frozen),sourceTextSha256=th(s),quote=q,startChar=lo,endChar=hi,quoteSha256=th(q),role='source_defect_confirmation_only_not_hidden_teaching')
    k=ch(z);registry[k]=z;return k
snow=textcite('review/remaining-source10/evidence/snow-availability.json','With this change, AWS will no longer offer any AWS Snow Family devices for new customers to order.','data migration needs.','New ordering customers and customers already using Snowball have different current eligibility; no blanket shutdown claim.')
mpfit=textcite('evidence/gap-a/cache-050e9132ae81937e1f37.json','Mountpoint for Amazon S3 is ideal for read-heavy data lake workloads','image rendering.','Mountpoint is explicitly an image-rendering file client option under its supported read/write semantics.')
mpprem=textcite('evidence/gap-a/cache-050e9132ae81937e1f37.json','AWS PrivateLink for S3 provides private connectivity between Amazon S3 and on-premises.','AWS Direct Connect or AWS VPN.','Official Mountpoint FAQ describes on-premises application connectivity to S3.')
mpcost=textcite('evidence/gap-a/cache-050e9132ae81937e1f37.json','There is no additional charge for using Mountpoint for Amazon S3.','directory-listing operations.','Mountpoint itself has no additional service charge; actual requests/caching and filesystem fit matter to cost comparison.')
mpcache=textcite('review/current-impact02/b/evidence/mountpoint-usage.json','To accelerate repeated read','you should opt in to a local cache.','Current Mountpoint supports caching; do not exclude it categorically as uncached. The documented EC2/local-storage example is not converted into an unqualified on-premises SLA.')

rawprice=V/'review/remaining-source10/evidence/s3-price-list-us-east-1.raw.json'
price=rd(rawprice);frozenprice=E/(sha(rawprice)+'.raw.json')
if not frozenprice.exists():shutil.copyfile(rawprice,frozenprice)
assert sha(frozenprice)==sha(rawprice)
price_records={}
required={'TimedStorage-SIA-ByteHrs','Retrieval-SIA','Requests-SIA-Tier2','TimedStorage-GIR-ByteHrs','Retrieval-GIR','Requests-GIR-Tier2'}
for sku,p in price['products'].items():
    ut=p['attributes'].get('usagetype')
    if ut not in required:continue
    terms=price['terms']['OnDemand'][sku];assert len(terms)==1
    t=next(iter(terms.values()));dims=list(t['priceDimensions'].values());assert len(dims)==1
    price_records[ut]=dict(sku=sku,product=p,offerTerm=t,rateUSD=float(dims[0]['pricePerUnit']['USD']),productJsonPointer='/products/'+sku,termJsonPointer='/terms/OnDemand/'+sku)
assert set(price_records)==required
def cost(n,kind):
    gb=5_000_000/(1024**3);months=47
    u='GIR' if kind=='A_Glacier_Instant' else 'SIA'
    storage=price_records['TimedStorage-'+u+'-ByteHrs']['rateUSD']*gb*months
    retrieval=price_records['Retrieval-'+u]['rateUSD']*gb*n
    gets=price_records['Requests-'+u+'-Tier2']['rateUSD']*n
    # Capture lifecycle transition rates directly from the same official offer.
    op='S3-GIRTransition' if u=='GIR' else 'S3-SIATransition'
    pp=[(k,p) for k,p in price['products'].items() if p['attributes'].get('operation')==op]
    assert len(pp)==1,(op,len(pp));sku,p=pp[0];t=next(iter(price['terms']['OnDemand'][sku].values()));dims=list(t['priceDimensions'].values());assert len(dims)==1
    transition=float(dims[0]['pricePerUnit']['USD'])
    price_records[op]=dict(sku=sku,product=p,offerTerm=t,rateUSD=transition,productJsonPointer='/products/'+sku,termJsonPointer='/terms/OnDemand/'+sku)
    return dict(storage=storage,retrieval=retrieval,getRequests=gets,oneLifecycleTransition=transition,total=storage+retrieval+gets+transition)
counterexamples=[]
for n,label in [(4,'about one full-object read per year after first month'),(24,'about six full-object reads per year after first month')]:
    a=cost(n,'A_Glacier_Instant');c=cost(n,'C_Standard_IA')
    counterexamples.append(dict(scenario=label,lateFullObjectReads=n,A=a,C=c,cheaperOptionOrdinal=1 if a['total']<c['total'] else 3))
assert [x['cheaperOptionOrdinal'] for x in counterexamples]==[1,3]
cost_proof=dict(url='https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonS3/current/us-east-1/index.json',sourcePath=str(frozenprice),sourceFileSha256=sha(frozenprice),offerCode=price.get('offerCode'),version=price['version'],publicationDate=price['publicationDate'],records=price_records,assumptions=dict(region='us-east-1, an allowed original-question instance',objectBytes=5_000_000,lateRetentionMonths=47,first30DaysFrequentReads='same S3 Standard policy, common cost omitted',lateReads='whole object per GET; both examples low-frequency compared with initial frequent access',minimumDurationsSatisfied=True,objectMinimumBillableSizeNotBinding=True,commonTransferChargesCancel=True),counterexamples=counterexamples,role='source_decisive_input_missing_confirmation_only')
cp=E/'q890-cost-counterexamples.json';cp.write_text(json.dumps(cost_proof,ensure_ascii=False,indent=2)+'\n')

source_findings={
604:dict(confirmed=True,subtype='decisive_input_missing',missingInput='current Snowball ordering eligibility',officialEvidenceIds=[snow],scenarios=[dict(input='company already using/qualified for current Snowball Edge service',consequence='D remains the offline device direction; not a blanket shutdown'),dict(input='ordinary new Snowball customer planning first order',consequence='D cannot be ordered, and A/B/C cannot meet the link-bound six-week volume')],bandwidthCalculation=dict(totalUplinkMbps=500,availableFraction=0.8,availableMbps=400,dataBytes=10_000_000_000_000_000,idealOnlineSeconds=200_000_000,sixWeekSeconds=42*24*3600,maxBytesInSixWeeks=400_000_000*42*24*3600/8),logisticsSlaNotAddedAsNewGate=True),
890:dict(confirmed=True,subtype='decisive_input_missing',missingInput='post-day30 full-object retrieval rate/volume',candidateOptionOrdinals=[1,3],costProofPath=str(cp),costProofSha256=sha(cp),positiveCostReversal=[1,3],noStorageUnitPriceEqualsTotalCostAssumption=True),
1003:dict(confirmed=True,subtype='decisive_interface_and_cache_fit_missing',missingInput='required filesystem protocol/operations and usable caching/access-cost model',candidateOptionOrdinals=[1,2],officialEvidenceIds=[mpfit,mpprem,mpcost,mpcache],scenarios=[dict(input='compatible read-heavy Linux image rendering using supported Mountpoint file semantics and caching',consequence='A cannot be excluded merely as uncached; compare its request/cache deployment cost'),dict(input='application requires an SMB/NFS network file gateway with on-premises cached interface',consequence='B matches the explicit File Gateway interface; native Mountpoint client is a different access model')],knownVisibleCardGap='Current cards explain File Gateway but do not teach Mountpoint fit/caching; official source confirmation is not counted as learned card support',noOnPremisesLatencyGuaranteeInvented=True)
}

results=[]
for item in cases:
    qid=item['qid'];q=item['question'];assert q==canonical[str(qid)]
    row=decisions[qid];_,status,opts,ids,reason,*extra=row
    assert len(ids)==len(set(ids)) and all(r in pool for r in ids)
    aa=sum([anchors(r) for r in ids],[]);deps=[];seen=set();todo=list(ids)
    while todo:
        rid=todo.pop()
        if rid in seen:continue
        seen.add(rid);bind(rid)
        for dep in pool[rid].get('prerequisiteRuleIds',[]):
            assert dep in pool
            deps.append(dict(fromRuleId=rid,ruleId=dep,bodySha256=pool[dep]['bodySha256'],visibleBody=pool[dep]['visibleBody'],currentProofs=bind(dep)))
            todo.append(dep)
    candidates=opts if status=='SUPPORTED' else ({544:[1],604:[4],890:[1,3],1003:[1,2]}.get(qid,opts))
    r=dict(qid=qid,status=status,selectedOptionOrdinals=opts if status=='SUPPORTED' else [],candidateOptionOrdinals=candidates,
           questionSha256=ch(q),questionHashContract='SHA-256 canonical UTF-8 full original JSON including qid, exact stem, every ordinal/label/option; sorted keys compact separators ensure_ascii=false',
           stemUtf8Sha256=th(q['stem']),optionsCanonicalSha256=ch(q['options']),completeStemAndEveryOptionRead=True,
           usedRuleIds=ids,necessaryAnchors=aa,recursivePrerequisiteBindings=deps,
           currentProofRuleIds=sorted(seen),reasoningAndClosestCompetitor=reason,
           minimumRemainingJudgments=extra if status!='SUPPORTED' else [],sourceFinding=source_findings.get(qid),
           noPrivateTargetsOrPrintedAnswersUsed=True,noOfficialSourceSubstitutedForMissingVisibleCard=True,
           retrievalHintsTreatedAsProof=False,originalModified=False,cardGroupSupportAccepted=(status=='SUPPORTED'))
    results.append(r)

counts=dict(questionCount=114,statuses=dict(collections.Counter(r['status'] for r in results)),supportedQuestionCount=sum(r['status']=='SUPPORTED' for r in results),otherGroupAReviewed=False)
assert counts['statuses']=={'SUPPORTED':110,'INSUFFICIENT_CARDS':1,'SOURCE_ISSUE':3}
def retrieval(queries):
    return {term:[dict(ruleId=rid,bodySha256=c['bodySha256'],matchedFields=[f for f in F if term.lower() in c['visibleBody'].get(f,'').lower()]) for rid,c in pool.items() if any(term.lower() in c['visibleBody'].get(f,'').lower() for f in F)] for term in queries}
canary_queries=['canary','金丝雀','API Gateway','灰度','百分比']
mountpoint_queries=['mountpoint','挂载S3','对象文件客户端']
report=dict(schemaVersion=1,batch='current-impact02/b',reviewer='independent current dependency readback B',reviewedAtUtc=now(),status='COMPLETE_114_current_question_dispositions_not_all_supported',inputManifestPath=str(P/'manifest.json'),inputManifestSha256=sha(P/'manifest.json'),inputHashes=manifest,
            scope=dict(fullOriginalQuestionCount=114,currentVisiblePoolCount=362,onlyAssignedBGroup=True,otherGroupAQuestionCount=110,otherGroupAReviewed=False,noFull1018Rerun=True),
            canonicalOriginalSourcePath=str(canonical_path),canonicalOriginalSourceSha256=sha(canonical_path),legacyBodyBindingSourcePath=str(legacy_path),legacyBodyBindingSourceSha256=sha(legacy_path),
            counts=counts,results=results,usedCurrentCardProofBindings=proof_cache,sourceOnlyOfficialEvidenceRegistry=registry,
            sourceOnlyPricingProof=dict(path=str(cp),sha256=sha(cp)),
            targetedFullPoolRetrievalChecks=[dict(qid=544,scannedBodyCount=362,queries=canary_queries,actualRetrievalHits=retrieval(canary_queries),relatedCurrentRules=['GCL-011','GSC-127'],serviceCapabilityAbsent='API Gateway native canary stage capability not present; GCL011 generic parallel validation and GSC127 DNS routing retained separately'),dict(qid=1003,scannedBodyCount=362,queries=mountpoint_queries,actualRetrievalHits=retrieval(mountpoint_queries),serviceCapabilityAbsent='no visible Mountpoint comparison; not filled with official source research')],
            findings=[dict(qid=544,status='INSUFFICIENT_CARDS',minimumRepair='Provide a correctly scoped visible API Gateway canary capability/judgment or otherwise close the actual capability gap without a separate deployment checklist.'),dict(qid=604,status='SOURCE_ISSUE',subtype='decisive_input_missing'),dict(qid=890,status='SOURCE_ISSUE',subtype='decisive_input_missing'),dict(qid=1003,status='SOURCE_ISSUE',subtype='decisive_interface_and_cache_fit_missing')],
            sourceQualificationHandling='Planning new order is distinguished from already using eligible service. New-customer limits are not described as complete retirement.',
            implementationScope='Routine role, route, mount, source/target, retention rule, launch template and cache policy setup were not independently promoted to card/SLA gates. True service capabilities and original decisive conditions remain required.',
            formalCardAcceptanceChanged=False,learnerMemoryOrAccuracyMeasured=False,finalCardCountVerified=False,currentPointersChangedByReviewer=False,authoringPerformed=False,productionOrOriginalsChanged=False,
            externalOfficialReadOnlyFetches=dict(successful=1,pythonTlsFailure=1,verifiedSystemCurlFallback=True),directCliApiCalls=0,nativeUsage='unknown')
rp=O/'results.json';rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
z=rd(rp)
for r in z['results']:
    q=next(x['question'] for x in cases if x['qid']==r['qid'])
    assert ch(q)==r['questionSha256'] and th(q['stem'])==r['stemUtf8Sha256'] and ch(q['options'])==r['optionsCanonicalSha256']
    for a in r['necessaryAnchors']:
        assert pool[a['ruleId']]['bodySha256']==a['bodySha256'] and pool[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
    for dep in r['recursivePrerequisiteBindings']:
        assert pool[dep['ruleId']]['bodySha256']==dep['bodySha256'] and pool[dep['ruleId']]['visibleBody']==dep['visibleBody']
for k,e in z['sourceOnlyOfficialEvidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256'] and s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256'] and ch(e)==k
assert all(sha(p)==h for p,h in manifest.items())
rb=dict(status='PASS_114_result_readback_with_explicit_non_supported_dispositions',resultsPath=str(rp),resultsSha256=sha(rp),inputManifestSha256=sha(P/'manifest.json'),readBackAtUtc=now(),counts=counts,
        checks=dict(exact114UniqueAssignedQids=True,allOriginalStemsAndEveryOptionBound=True,allCurrentVisibleBodiesAndNecessaryAnchorsHashOffsetMatched=True,allRecursivePrerequisitesAndCurrentProofReceiptsBound=True,hintsNotUsedAsProof=True,sourceOnlyEvidenceSeparatedFromTeaching=True,currentSnowballEligibilityTwoScenariosExplicit=True,s3PriceCounterexampleReversalVerified=True,mountpointPositiveCapabilityNotSilentlyExcluded=True,allFrozenInputsStillUnchanged=True,noOriginalCurrentProductionOrInventoryMutation=True,noGroupADuplication=True),
        directCliApiCalls=0,nativeUsage='unknown',learnerEffectMeasured=False,finalNVerified=False)
(O/'readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(results=str(rp),sha256=sha(rp),counts=counts),ensure_ascii=False))

import pathlib,json,hashlib,datetime,collections,re
P=pathlib.Path(__file__).parent;V=P.parent.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
read=lambda p:json.loads(p.read_text())
manifest=read(P/'input/manifest.json')
for fn,h in manifest.items():assert sha(pathlib.Path(fn))==h,fn
cases=read(P/'input/cases.json');C={x['ruleId']:x for x in read(P/'input/visible-pool.frozen.json')};Q={x['qid']:x for x in cases};I={x['ruleId']:x for x in read(P/'input/card-review-index.frozen.json')['cards']}
D=[r for f in sorted(P.glob('decisions*.json')) for r in read(f)]
assert len(D)==len(Q)==110 and len({x['qid'] for x in D})==110 and set(Q)=={x['qid'] for x in D}
for c in C.values():assert canon(c['visibleBody'])==c['bodySha256']
proofCache={}
def checkProof(path,h):
 if path not in proofCache:proofCache[path]=sha(pathlib.Path(path))
 assert proofCache[path]==h,('proof changed',path)
# Source issues have explicit original-compatible cases and literal official sources, not old answers.
E={}
def ev(key,p,quotes):
 o=read(p);t=o['text'];th=hashlib.sha256(t.encode()).hexdigest();assert th==o['textSha256']
 aa=[]
 for q in quotes:
  assert q in t,(key,q);at=t.index(q);aa.append({'quote':q,'start':at,'end':at+len(q)})
 E[key]={'path':str(p),'sha256':sha(p),'textSha256':th,'url':o['url'],'quotes':aa}
S=V/'review/reuse-a/sources'
ev('SNOW_CURRENT_ELIGIBILITY',V/'review/reuse-a/supplemental12-work/sources/snow-faq.json',['Effective November 7, 2025, AWS Snowball Edge devices will only be available to existing customers.'])
ev('PRIVATELINK_PROVIDER_CONSUMER',S/'d4628bc773b7ceac74f8.json',['As the service provider, you create a Network Load Balancer in your VPC as the service front end.','As a service consumer, the customer creates an interface VPC endpoint'])
ev('COMPREHEND_MEDICAL_ENGLISH',P/'evidence/comprehend-medical-languages.snapshot.json',['Amazon Comprehend Medical only detects medical entities in English language (US-EN) texts.'])
ev('ONTAP_CURRENT_SSD_PERFORMANCE',P/'evidence/ontap-performance.snapshot.json',['Amazon FSx for NetApp ONTAP provides sub-millisecond file operation latencies with solid state\n        drive (SSD) storage','Second-generation Single-AZ file systems are powered by up to 12 HA pairs.','Single-AZ\n6,144\n1\n1,024'])
ev('ONTAP_NONE_STAYS_SSD',P/'evidence/ontap-tiers.snapshot.json',['None\n– This policy keeps all of your volume’s data on the primary storage tier, \n                                    and prevents it from being moved to capacity pool storage.'])
# Reuse the current independent FACT receipt for the Firehose Redshift pipeline.
f=V/'review/reuse-a/supplemental03.review.json';o=read(f)
entry=next(x for x in o['evidenceRegistry'].values() if 'Firehose supports Redshift delivery' in x.get('claim',''))
p=pathlib.Path(entry['sourcePath']);o=read(p)
ev('FIREHOSE_REDSHIFT_DELIVERY',p,['For data delivery to Amazon Redshift, Firehose first delivers incoming data to your\nS3 bucket','COPY command to load the data from your S3 bucket'])
(P/'source-evidence.json').write_text(json.dumps({'evidence':E,'reviewScope':'source exceptions only; ordinary card FACT gates reuse frozen current index'},ensure_ascii=False,indent=2)+'\n')
sourceRefs={6:['SNOW_CURRENT_ELIGIBILITY'],113:['SNOW_CURRENT_ELIGIBILITY'],331:['SNOW_CURRENT_ELIGIBILITY'],135:['PRIVATELINK_PROVIDER_CONSUMER'],192:['COMPREHEND_MEDICAL_ENGLISH'],299:['ONTAP_CURRENT_SSD_PERFORMANCE','ONTAP_NONE_STAYS_SSD'],320:['FIREHOSE_REDSHIFT_DELIVERY']}
# Full conditions are quoted where they govern an answer; these are citations, not new grading demands.
frontNeeded={'GSC-002','GSC-005','GSC-010','GSC-012','GSC-014','GSC-032','GSC-051','GSC-077','GSC-119','GSC-133','GSC-135','VC-003','VC-004','VC-007','CUR:CB01','CUR:CB16','CUR:CMP-M01','CUR:CMP-M04','CUR:CMP-M10','CUR:CMP-M16','CUR:XB006','CUR:XB018','CUR:XB019','GCL-012','GCL-014'}
watchNeeded={'GSC-010','GSC-012','GSC-014','GSC-025','GSC-032','GSC-051','GSC-057','GSC-077','GSC-133','CUR:CB16','CUR:CMP-M01','CUR:CMP-M06','CUR:CMP-M16','CUR:XA005','CUR:NEW02','CUR:XB014','VC-004','VC-007','GCL-014'}
R=[]
for d in D:
 qid=d['qid'];q=Q[qid]['question'];direct=list(dict.fromkeys(d['ids']));used=[];stack=[]
 def visit(r):
  assert r in C,r
  assert r not in stack,('cycle',stack,r)
  if r in used:return
  stack.append(r);used.append(r)
  for x in C[r].get('prerequisiteRuleIds',[]):visit(x)
  stack.pop()
 for r in direct:visit(r)
 anchors=[];bindings=[]
 for rid in used:
  c=C[rid];i=I[rid];assert i['status']=='PASS' and i['currentBodySha256']==c['bodySha256'],(qid,rid)
  for pr in i['proofs']:checkProof(pr['path'],pr['sha256'])
  bindings.append({'ruleId':rid,'bodySha256':c['bodySha256'],'prerequisiteRuleIds':c.get('prerequisiteRuleIds',[]),'currentIndependentFactStatus':'PASS','currentIndependentFactProofs':i['proofs']})
  fields=['answerZH','keyPointZH']
  if rid in frontNeeded:fields.insert(0,'frontZH')
  if rid in watchNeeded:fields.append('watchOutZH')
  for field in fields:
   text=c['visibleBody'].get(field,'')
   if text:anchors.append({'ruleId':rid,'field':field,'quote':text,'bodySha256':c['bodySha256'],'start':0,'end':len(text),'offsetUnit':'unicode codepoints','role':'decisive premises / necessary scope / declared prerequisite context'})
 rec={'qid':qid,'status':d['status'],'selectedOptionOrdinals':d['selected'],'selectedOrdinalsMeaning':'accepted unique selection if SUPPORTED; scenario candidates or flawed wording otherwise','usedRuleIds':direct,'recursiveUsedRuleIds':used,'recursivePrerequisiteRuleIds':[x for x in used if x not in direct],'dependencyEdges':[{'from':rid,'to':pr} for rid in used for pr in C[rid].get('prerequisiteRuleIds',[])],'necessaryAnchors':anchors,'cardBindings':bindings,'questionCanonicalSha256':canon(q),'questionHashContract':'SHA256 UTF-8 canonical JSON of qid/stem/all original ordinal-label-text options; ensure_ascii=false sort_keys=true compact','questionStemSha256':hashlib.sha256(q['stem'].encode()).hexdigest(),'allOptionsReviewed':True,'optionTextBindings':[{'ordinal':x['ordinal'],'originalLabel':x['originalLabel'],'textSha256':hashlib.sha256(x['text'].encode()).hexdigest()} for x in q['options']],'reason':d['reason'],'nearestCompetitionReasoning':d['competition'],'retrievalHintsWereNotProof':True,'cc08ActuallyRequired':'CUR:CC08' in used,'originalQuestionChanged':False,'newCardAuthored':False,'factReReviewPerformed':False,'learnerPerformanceMeasured':False,'remainingBlockingConditions':[]}
 if 'source' in d:
  rec['sourceConfirmation']=d['source'];rec['officialSourceEvidenceIds']=sourceRefs[qid];rec['sourceConfirmed']=True
 R.append(rec)
assert not any(x['cc08ActuallyRequired'] for x in R)
counts=dict(collections.Counter(x['status'] for x in R));used={x for r in R for x in r['recursiveUsedRuleIds']}
output={'reviewId':'current-impact02/a','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'independent_native_current_question_reviewer','scope':'110 frozen full original questions whose former sufficient proofs lost current body bindings; no other-library replay','inputManifestSha256':sha(P/'input/manifest.json'),'inputHashes':manifest,'currentFrozenCoreCount':len(C),'coreCountIsFinalN':False,'originalQuestionCount':len(R),'statusCounts':counts,'uniqueActuallyUsedRuleCount':len(used),'actuallyUsedCC08':False,'cc08DependentQuestionIds':[],'reusedFactReceiptFileCount':len(proofCache),'sourceEvidencePath':str(P/'source-evidence.json'),'sourceEvidenceSha256':sha(P/'source-evidence.json'),'results':R,'oldAnswerOrOldQuestionVerdictConsulted':False,'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','subagentsSpawned':0,'newCardsAuthored':0,'correctedVariantsAuthored':0,'originalQuestionEdits':0,'currentInventoryEdits':0,'productionPointersEdited':False,'priorClockBudgetHistoryCountersReset':False,'full1018Replay':False,'finalNVerified':False,'formalBilingualAcceptance':False,'measuredLearnerOutcome':False}
(P/'results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n');print(counts,'unique used',len(used),'fact receipt files',len(proofCache));print('results sha',sha(P/'results.json'))

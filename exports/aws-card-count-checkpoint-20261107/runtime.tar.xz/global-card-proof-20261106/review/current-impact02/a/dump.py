import pathlib,json,sys
P=pathlib.Path(__file__).parent
A=json.loads((P/'input/cases.json').read_text());C={c['ruleId']:c for c in json.loads((P/'input/visible-pool.frozen.json').read_text())}
a=int(sys.argv[1]);b=int(sys.argv[2]);ids=[]
for item in A[a:b]:
 q=item['question'];print('\nQ'+str(q['qid'])+' '+q['stem'].replace('\n',' '))
 for o in q['options']:print(o['ordinal'],o['text'].replace('\n',' '))
 print('HINTS',','.join(item['retrievalHintRuleIds']))
 for r in item['retrievalHintRuleIds']:
  if r not in ids:ids.append(r)
if len(sys.argv)>3 and sys.argv[3]=='cards':
 seen={r for x in A[:a] for r in x.get('retrievalHintRuleIds',[])}
 for r in ids:
  if r not in seen:print(r,json.dumps(C[r]['visibleBody'],ensure_ascii=False),C[r].get('prerequisiteRuleIds',[]))

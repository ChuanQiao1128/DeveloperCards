import pathlib,json,hashlib,datetime,collections,re
P=pathlib.Path(__file__).parent;V=P.parent.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
read=lambda p:json.loads(p.read_text())
checks=[]
def ck(n,b):
 assert b,n
 checks.append({'check':n,'status':'PASS'})
m=read(P/'input/manifest.json')
for f,h in m.items():ck('frozen file '+pathlib.Path(f).name,sha(pathlib.Path(f))==h)
R=read(P/'results.json');Q={x['qid']:x['question'] for x in read(P/'input/cases.json')};C={x['ruleId']:x for x in read(P/'input/visible-pool.frozen.json')};I={x['ruleId']:x for x in read(P/'input/card-review-index.frozen.json')['cards']}
ck('110 unique complete originals',len(R['results'])==len(Q)==len({x['qid'] for x in R['results']})==110 and {x['qid'] for x in R['results']}==set(Q))
ck('362 frozen cards',len(C)==362)
ck('status counts',R['statusCounts']=={'SUPPORTED':103,'SOURCE_ISSUE':7} and R['statusCounts']==dict(collections.Counter(x['status'] for x in R['results'])))
used={};proofs={};anchorCount=0;edges=set()
for x in R['results']:
 q=Q[x['qid']];prefix='Q'+str(x['qid'])
 ck(prefix+' full question canonical',x['questionCanonicalSha256']==canon(q))
 ck(prefix+' all options',len(x['optionTextBindings'])==len(q['options']))
 ck(prefix+' valid selected ordinal',len(x['selectedOptionOrdinals'])==len(set(x['selectedOptionOrdinals'])) and set(x['selectedOptionOrdinals'])<=set(o['ordinal'] for o in q['options']))
 if x['status']=='SUPPORTED':ck(prefix+' requested choice count',len(x['selectedOptionOrdinals'])==(2 if re.search(r'choose\s+two',q['stem'],re.I) else 1))
 for b in x['optionTextBindings']:
  o=next(o for o in q['options'] if o['ordinal']==b['ordinal']);ck(prefix+' original option '+str(b['ordinal']),o['originalLabel']==b['originalLabel'] and hashlib.sha256(o['text'].encode()).hexdigest()==b['textSha256'])
 closure=[]
 def visit(r):
  if r in closure:return
  closure.append(r)
  for d in C[r].get('prerequisiteRuleIds',[]):visit(d)
 for r in x['usedRuleIds']:visit(r)
 ck(prefix+' recursive closure',closure==x['recursiveUsedRuleIds'] and [r for r in closure if r not in x['usedRuleIds']]==x['recursivePrerequisiteRuleIds'])
 ck(prefix+' CC08 absent','CUR:CC08' not in closure and x['cc08ActuallyRequired'] is False)
 for b in x['cardBindings']:
  rid=b['ruleId'];c=C[rid];i=I[rid];used[rid]=b['bodySha256']
  ck(prefix+'/'+rid+' exact current FACT/body',b['bodySha256']==c['bodySha256']==canon(c['visibleBody'])==i['currentBodySha256'] and i['status']==b['currentIndependentFactStatus']=='PASS')
  ck(prefix+'/'+rid+' dependency binding',b['prerequisiteRuleIds']==c.get('prerequisiteRuleIds',[]) and b['currentIndependentFactProofs']==i['proofs'])
  for pr in b['currentIndependentFactProofs']:proofs[pr['path']]=pr['sha256']
 for a in x['necessaryAnchors']:
  c=C[a['ruleId']];anchorCount+=1;ck(prefix+'/'+a['ruleId']+'/'+a['field']+' exact anchor',a['bodySha256']==c['bodySha256'] and c['visibleBody'][a['field']][a['start']:a['end']]==a['quote'])
 for e in x['dependencyEdges']:edges.add((e['from'],e['to']))
 if x['status']=='SOURCE_ISSUE':ck(prefix+' source cases explicit',bool(x.get('sourceConfirmation',{}).get('construct1')) and bool(x['sourceConfirmation'].get('construct2')) and x.get('sourceConfirmed') and not x['sourceConfirmation']['subtype'].endswith('pending_official_confirmation'))
 ck(prefix+' full fresh reason and nearest competition',bool(x['reason']) and bool(x['nearestCompetitionReasoning']) and x['retrievalHintsWereNotProof'])
for f,h in proofs.items():ck('current independent receipt '+pathlib.Path(f).name,sha(pathlib.Path(f))==h)
E=read(P/'source-evidence.json')['evidence'];ck('source evidence binding',sha(P/'source-evidence.json')==R['sourceEvidenceSha256'])
for k,e in E.items():
 o=read(pathlib.Path(e['path']));ck(k+' evidence file/text',sha(pathlib.Path(e['path']))==e['sha256'] and hashlib.sha256(o['text'].encode()).hexdigest()==e['textSha256'])
 ck(k+' official URL',e['url'].startswith(('https://aws.amazon.com/','https://docs.aws.amazon.com/')))
 for a in e['quotes']:ck(k+' quote '+str(a['start']),o['text'][a['start']:a['end']]==a['quote'])
for x in R['results']:
 for k in x.get('officialSourceEvidenceIds',[]):ck('Q'+str(x['qid'])+' source evidence registered '+k,k in E)
corePath=V/'deliverables/core-visible-knowledge.provisional.json';current=read(corePath);M={x['ruleId']:x for x in current}
ck('current362 core',len(M)==len(current)==362)
for rid,h in used.items():ck('actual latest necessary core body '+rid,M[rid]['bodySha256']==h and M[rid].get('prerequisiteRuleIds',[])==C[rid].get('prerequisiteRuleIds',[]))
ck('no CC08 was used','CUR:CC08' not in used and not R['actuallyUsedCC08'] and not R['cc08DependentQuestionIds'])
ck('no original/current mutation or reset',R['originalQuestionEdits']==R['currentInventoryEdits']==R['newCardsAuthored']==R['correctedVariantsAuthored']==R['subagentsSpawned']==R['newContentModelCallsCLIAPI']==0 and not R['productionPointersEdited'] and not R['priorClockBudgetHistoryCountersReset'])
ck('only assigned110 scope',not R['full1018Replay'] and not R['finalNVerified'] and not R['measuredLearnerOutcome'])
o={'reviewId':'current-impact02/a','status':'PASS','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestSha256':sha(P/'input/manifest.json'),'resultsSha256':sha(P/'results.json'),'reportSha256':sha(P/'results.md'),'sourceEvidenceSha256':sha(P/'source-evidence.json'),'questionCount':110,'statusCounts':R['statusCounts'],'necessaryAnchorCount':anchorCount,'uniqueActuallyUsedRulesIncludingRecursive':len(used),'uniqueDependencyEdges':len(edges),'currentIndependentReceiptFileCount':len(proofs),'checkCount':len(checks),'checks':checks,'currentCorePath':str(corePath),'currentCoreSha256':sha(corePath),'currentCoreCount':len(current),'actualNecessaryBodiesMatchCurrent':True,'unusedCurrentDriftObserved':[{'ruleId':rid,'frozenBodySha256':c['bodySha256'],'currentBodySha256':M[rid]['bodySha256']} for rid,c in C.items() if rid not in used and rid in M and c['bodySha256']!=M[rid]['bodySha256']],'actuallyUsedCC08':False,'cc08DependentQuestionIds':[],'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','priorClocksBudgetsHistoryReset':False,'originalInventoryPointersMutation':False,'wholeLibraryOrFinalNOrLearnerOutcomeAccepted':False}
(P/'readback.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(checks),'checks;',anchorCount,'necessary anchors;',len(used),'used rules;',len(proofs),'FACT receipt files');print('results',o['resultsSha256']);print('readback',sha(P/'readback.json'))

A组当前依赖回读已完成：110道完整原题中，**103 SUPPORTED、7 SOURCE_ISSUE**。实际使用112个唯一知识卡（含递归先修），复用35个现行独立事实凭证文件；无实际CC08依赖，无新增卡片缺口，无CONDITIONAL或UNKNOWN。

7项保留原文的问题：

| 题号 | 问题及证据 |
| --- | --- |
| 6、113、331 | 原题未给Snowball Edge现行订购资格。已有合格客户可订适用设备；新客户不能订同设备，原容量/带宽条件可完全相同。331的10.5Mbps可用带宽30天至多传约3.402TB，无法在线迁20TB。复用supplemental12已核官方资格快照，不将仍服务既有客户的设备一概称退役。 |
| 135 | A可通过目标路由与有状态SG限制服务及发起方；D按通常PrivateLink发布语义亦可行，但原文资源术语没有区分提供方endpoint service与消费方interface endpoint。若严格按API资源名，D错误而A仍可行，不能用旧预期字母放行D唯一。建议明确两侧角色后改选全部可行方案，不凭空加入工具偏好。 |
| 192 | 医疗文本语言未给。英文扫描件可Textract→Comprehend Medical；西文扫描件也符合原文，但后者仅检测US-EN，须另用自定义/翻译路径，原E不能直接处理。 |
| 299 | 现行SSD ONTAP也提供亚毫秒、第二代每HA读取6144MBps且最多12HA；NONE保数据在SSD。足规格Lustre B与足HA/IOPS/SSD ONTAP D均可达原8TB/6GBps/百Linux节点要求。未用旧4GBps上限或把所有Lustre介质视为相同。 |
| 320 | KDS→托管Flink流式查询与Firehose→Redshift近实时摄取/查询都能避开原EC2易失缓冲。原文没给必须入库前分析、硬延迟或仓库排除条件，不能仅因A路径更直接便证明B不满足。 |

每题完整题干/全部选项hash、实际必要可见句（字段、精确quote、正文hash、字符偏移）、递归先修及最近竞争解释均在`results.json`。检索提示没有直接当证明：例如381补用实际Multi-AZ/reader辨析卡CB01，278补用DynamoDB导出卡GSC-043，374补用真实DX路径卡GSC-073；多项不必要提示被省去。

普通源连接器、schema、双向路由、跨区备份副本、容量配置和SLA实施验证未被另造阻塞条件。题231/262按正常地址规划配置peering；397按已知资源配置Fargate；267等不在本组，未重跑其他题。103项充分只代表当前卡组的设计支撑，不代表测得学习者正确率。

`source-evidence.json`记录本次7项题源判断的官方正证；其余事实复用冻结的现行独立FACT索引，没有重复派模型审卡。新增读取仅ONTAP现行性能/NONE与Comprehend Medical语言文档。

原题、当前卡体、库存、生产指针、学习记录及历史时钟/预算未修改；CLI/API模型调用0，native用量unknown，未制新卡或练习版，不声称全1018或最终N完成。`readback.json`完成当前必要依赖与所有精确引用的确定性回读。

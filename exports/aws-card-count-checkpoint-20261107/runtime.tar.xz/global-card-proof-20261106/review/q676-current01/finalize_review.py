# -*- coding: utf-8 -*-
import datetime,hashlib,json,re
from pathlib import Path
V=Path.cwd();R=V/'review/q676-current01';P=R/'input'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
objsha=lambda x:hashlib.sha256(canon(x).encode()).hexdigest()
m=json.loads((P/'manifest.json').read_text());assert all(sha(p)==h for p,h in m.items())
q=json.loads((P/'question.json').read_text());cards={c['ruleId']:c for c in json.loads((P/'cards.json').read_text())}
credentials=json.loads((R/'current-card-credential-bindings.json').read_text())
search=json.loads((R/'targeted-search.json').read_text());suppPath=V/'review/reuse-a/supplemental11.review.json'
supp=json.loads(suppPath.read_text());failed=next(r for r in supp['results']if r['ruleId']=='CUR:XR101')
assert failed['status']=='FAIL' and failed['bodySha256']!=cards['CUR:XR101']['bodySha256']
sources={}
def source(key,phrase):
 s=supp['evidenceRegistry'][key];p=Path(s['snapshotPath']);assert sha(p)==s['snapshotSha256']
 t=json.loads(p.read_text())['text'];match=re.search(r'\s+'.join(re.escape(s)for s in phrase.split()),t);assert match
 a,b=match.span();sources[key]={'url':s['url'],'snapshotPath':str(p.resolve()),'snapshotSha256':sha(p),
  'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':t[a:b],'quoteStart':a,'quoteEnd':b}
source('LOG_SUBSCRIPTIONS','You can use a subscription filter with Amazon Kinesis Data Streams, AWS Lambda, Amazon Data Firehose, or Amazon OpenSearch Service.')
source('FIREHOSE_CWLOGS_UNSUPPORTED','Currently, Firehose does not support the delivery of CloudWatch Logs to Amazon OpenSearch Service destination because Amazon CloudWatch combines multiple log events into one Firehose record and Amazon OpenSearch Service cannot accept multiple log events in one record.')
parts=[
 ('CUR:NA03','answerZH','网络连接元数据看VPC Flow Logs','identify network-interface traffic metadata'),
 ('CUR:NA03','answerZH','VPC Flow Logs也可投递CloudWatch Logs或S3。','Flow Logs to CloudWatch Logs rather than a CloudTrail trail'),
 ('CUR:XR101','answerZH','原文检索用subscription filter，经受支持的转发路径送OpenSearch，例如官方Lambda订阅集成。','subscription and an active Lambda forwarding/writing path to OpenSearch'),
 ('CUR:XR101','keyPointZH','subscription复制匹配日志内容供下游处理','actual log content is forwarded for downstream processing'),
 ('CUR:XB004','answerZH','把交易写入Kinesis Data Streams；各应用作为消费者读取，另用Lambda消费者清理记录并写入DynamoDB。','transfer the already taught stream-to-active-Lambda-consumer-to-destination mechanism'),
 ('CUR:XB004','keyPointZH','流保留记录供消费者读取；Lambda通过事件源映射取得一批记录，再由函数代码完成清理和写库，Kinesis不会自动改写记录。','KDS is retention/streaming; consumer code performs processing and destination writes')]
anchors=[]
for rid,field,quote,role in parts:
 text=cards[rid]['visibleBody'][field];a=text.index(quote)
 anchors.append({'ruleId':rid,'bodySha256':cards[rid]['bodySha256'],'field':field,'quote':quote,'quoteStart':a,'quoteEnd':a+len(quote),'supports':role})
gap={
 'id':'Q676-CURRENT-GAP-001','kind':'decisive_competitor_boundary_not_visible','priority':'P1',
 'missingJudgment':'为什么CloudWatch Logs多事件打包记录不能按B所述直接由Firehose交付OpenSearch，而需选受支持的消费者/处理路径。',
 'whyNotAlreadyTaught':'XR101只保留受支持路径和Lambda例子，未说明这项日志输入/目的地不兼容。XB004教KDS消费者，未教Firehose这个边界。NS01的通用Firehose交付/变换说明也没有该边界。',
 'notAPositivePathGap':'A所需的KDS后消费者并不缺一个新部署清单；当前Lambda消费与写目的地知识可迁移到XR101的OpenSearch写入。',
 'minimumRepairAdvice':'只补或复用能表达该关键输入/目的地边界的可见知识，并定向回测Q676；不要求背完整gzip/base64解析代码、IAM或消费者部署清单。不得采用失败稿的Firehose默认路径。',
 'officialEvidenceId':'FIREHOSE_CWLOGS_UNSUPPORTED',
 'contentAuthoredOrAdoptedByThisReview':False}
out={
 'schemaVersion':1,'reviewer':'/root/domain_primary_audit','reviewId':'q676-current01',
 'completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'inputManifestPath':str((P/'manifest.json').resolve()),'inputManifestSha256':sha(P/'manifest.json'),'inputHashes':m,
 'scope':'One complete original Q676; actual three-card group from the frozen 363-card provisional core and its real declared prerequisite.',
 'qid':676,'status':'INSUFFICIENT_CARDS','wholeQuestionCardGroupStatus':'INSUFFICIENT_CARDS',
 'selectedOptionOrdinals':[],'candidateOptionOrdinals':[1],'technicalAnswerUnderOfficialFacts':[1],
 'positiveAPathFromVisibleCards':'SUFFICIENT_BY_COMPOSITION_UNDER_NORMAL_ARCHITECTURE_SEMANTICS',
 'questionCanonicalSha256':objsha(q),'originalStemUtf8Sha256':hashlib.sha256(q['stem'].encode()).hexdigest(),
 'originalOptionsCanonicalSha256':objsha(q['options']),'fullStemAndEveryOptionRead':True,
 'usedRuleIds':['CUR:NA03','CUR:XR101','CUR:XB004'],
 'actualUsedRuleIdsIncludingRecursivePrerequisites':sorted(cards),
 'cardBindings':[{'ruleId':k,'bodySha256':c['bodySha256'],'prerequisiteRuleIds':c['prerequisiteRuleIds']}for k,c in sorted(cards.items())],
 'recursivePrerequisiteBindings':[{'requiredByRuleId':'CUR:XR101','ruleId':'CUR:NA03','bodySha256':cards['CUR:NA03']['bodySha256']}],
 'necessaryAnchors':anchors,
 'positiveDerivation':'NA03给Flow Logs和CloudWatch Logs目的地。XR101给日志subscription及Lambda转发OpenSearch，XB004给KDS保存记录、Lambda消费者读取和由代码处理/写目的地。按通常架构语义组合A为Flow Logs→CloudWatch Logs subscription→KDS→Lambda消费者→OpenSearch。Lambda是实际处理/写入者，KDS不是自动OpenSearch sink。普通订阅、权限及负载格式处理可以实现，不据省略部署代码把A判成不可行。',
 'whyWholeQuestionStillInsufficient':'A的正向解释已经可迁移，但当前卡面不足以排除强竞争B。官方已确定B的特定批量日志格式/目的地不兼容，现卡却没教这项区别；不能把私有官方原句或失败候选当学习者已经掌握的前提。',
 'optionJudgments':[
  {'ordinal':1,'originalLabel':'A','technicalVerdict':'VALID_WITH_NORMAL_ACTIVE_CONSUMER','visibleSupport':'positive composition supported','reason':'日志订阅把记录送KDS，Lambda消费者处理后写OpenSearch；此处消费者是可由现卡推出的正常架构实现。'},
  {'ordinal':2,'originalLabel':'B','technicalVerdict':'DIRECT_PATH_UNSUPPORTED_FOR_THIS_INPUT','visibleSupport':'decisive exclusion missing','reason':'官方明确CloudWatch将多个事件合入一条Firehose记录，OpenSearch目的地不接受该直接投递；当前可见卡没讲这个特定边界。'},
  {'ordinal':3,'originalLabel':'C','technicalVerdict':'WRONG_LOG_DESTINATION','visibleSupport':'NA03 supports exclusion','reason':'CloudTrail trail记录API活动，不是把VPC Flow Logs作为流量日志目的地接收；A所需Flow Logs→CloudWatch Logs已经在NA03。'},
  {'ordinal':4,'originalLabel':'D','technicalVerdict':'WRONG_LOG_DESTINATION','visibleSupport':'NA03 supports exclusion','reason':'同C，先把Flow Logs送CloudTrail trail这一步不是题述网络流量日志路径；后加Firehose不修复该职责混淆。'}],
 'sourceIssue':None,'originalDefectIndependentlyConfirmed':False,
 'sourceAssessment':'No source error established. A has a valid ordinary consumer implementation. No claim of all options impossible or two effective solutions is made. Missing deployment detail and unmeasured SLA are not treated as source faults.',
 'findings':[gap],'minimumNecessaryMissingJudgments':[gap['missingJudgment']],
 'officialEvidenceRegistry':sources,
 'officialEvidenceUseBoundary':'Official references establish technical feasibility and the missing B boundary. They are not counted as additional learner-visible cards.',
 'failedCandidateExcluded':{'reviewPath':str(suppPath.resolve()),'reviewSha256':sha(suppPath),'ruleId':'CUR:XR101',
   'status':'FAIL','bodySha256':failed['bodySha256'],'actualCurrentBodySha256':cards['CUR:XR101']['bodySha256'],
   'notUsedAsPassedCard':True},
 'currentCardCredentialBinding':{'path':str((R/'current-card-credential-bindings.json').resolve()),'sha256':sha(R/'current-card-credential-bindings.json')},
 'targetedWholeCoreSearchBinding':{'path':str((R/'targeted-search.json').resolve()),'sha256':sha(R/'targeted-search.json'),
   'scope':'Only existing visible teaching of this specific compatibility boundary was searched; no full-core semantic review.'},
 'noCardOriginalSourceInventoryMainLedgerOrGitChanges':True,'newCardsAuthored':0,'contentAdopted':0,
 'externalModelCliApiCalls':0,'nativeUsage':'unknown','clockBudgetReset':False,'finalNVerified':False,
 'stoppingAfterThisInFlightCheckAtParentSaveRequest':True}
(R/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
checks={
 'frozenInputsUnchanged':all(sha(p)==h for p,h in m.items()),
 'fullQuestionHashExact':out['questionCanonicalSha256']==objsha(q),
 'allFourOrdinalsAndLabelsExact':[(x['ordinal'],x['originalLabel'])for x in out['optionJudgments']]==[(x['ordinal'],x['originalLabel'])for x in q['options']],
 'threeActualBodyHashesExact':len(cards)==3 and all(objsha(c['visibleBody'])==c['bodySha256']for c in cards.values()),
 'allNecessaryQuotesExactAtOffsets':all(cards[a['ruleId']]['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']]==a['quote']for a in anchors),
 'onlyDeclaredRecursiveEdgeBound':cards['CUR:XR101']['prerequisiteRuleIds']==['CUR:NA03']and cards['CUR:NA03']['prerequisiteRuleIds']==[]and cards['CUR:XB004']['prerequisiteRuleIds']==[],
 'actualCurrentCardCredentialsPASS':len(credentials['cards'])==3 and all(c['status']=='PASS'and c['currentBodySha256']==cards[c['ruleId']]['bodySha256']for c in credentials['cards']),
 'officialSnapshotHashesExact':all(sha(s['snapshotPath'])==s['snapshotSha256']for s in sources.values()),
 'officialTextHashesExact':all(hashlib.sha256(json.loads(Path(s['snapshotPath']).read_text())['text'].encode()).hexdigest()==s['textSha256']for s in sources.values()),
 'officialQuotesExactAtOffsets':all(json.loads(Path(s['snapshotPath']).read_text())['text'][s['quoteStart']:s['quoteEnd']]==s['quote']for s in sources.values()),
 'failedXR101CandidateExcluded':out['failedCandidateExcluded']['bodySha256']!=out['failedCandidateExcluded']['actualCurrentBodySha256']and out['failedCandidateExcluded']['notUsedAsPassedCard'],
 'privateOfficialEvidenceNotPassedAsTeaching':out['status']=='INSUFFICIENT_CARDS'and out['selectedOptionOrdinals']==[],
 'positiveACompositionSeparatelyRecorded':out['candidateOptionOrdinals']==[1]and out['technicalAnswerUnderOfficialFacts']==[1],
 'noSourceErrorFromMissingDeploymentDetail':out['sourceIssue']is None and not out['originalDefectIndependentlyConfirmed'],
 'targeted363CoreSearchBound':search['coreCount']==363 and sha(R/'targeted-search.json')==out['targetedWholeCoreSearchBinding']['sha256'],
 'singlePreciseMissingJudgment':len(out['findings'])==len(out['minimumNecessaryMissingJudgments'])==1,
 'parentSaveStopRecorded':out['stoppingAfterThisInFlightCheckAtParentSaveRequest'],
}
assert all(checks.values()),checks
readback={'schemaVersion':1,'status':'PASS','checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'qid':676,'resultsPath':str((R/'results.json').resolve()),'resultsSha256':sha(R/'results.json'),'checks':checks,
 'semanticResult':'INSUFFICIENT_CARDS','technicalCandidate':1,'positiveACompositionSupported':True,
 'missingBoundary':'CWL multi-event batch record / Firehose-to-OpenSearch compatibility, needed to exclude B.',
 'sourceIssueConfirmed':False,'newCardsOrContentAdopted':0,'finalNVerified':False,'externalModelCliApiCalls':0,'nativeUsage':'unknown'}
(R/'readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'semanticResult':out['status'],'mechanicalReadback':'PASS','checks':len(checks),'candidate':1},ensure_ascii=False))

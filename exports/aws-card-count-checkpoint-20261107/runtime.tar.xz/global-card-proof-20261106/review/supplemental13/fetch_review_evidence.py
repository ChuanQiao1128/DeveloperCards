import json,pathlib,requests,hashlib,concurrent.futures,datetime
from html.parser import HTMLParser
class Parser(HTMLParser):
 def __init__(self): super().__init__();self.out=[];self.skip=0
 def handle_starttag(self,tag,attrs):
  if tag in ("script","style","nav"): self.skip+=1
 def handle_endtag(self,tag):
  if tag in ("script","style","nav") and self.skip: self.skip-=1
 def handle_data(self,data):
  if not self.skip and data.strip():self.out.append(data.strip())
base=pathlib.Path(__file__).parent/'evidence'
urls={
'lambda-efs-cross-account-news':'https://aws.amazon.com/blogs/aws/new-a-shared-file-system-for-your-lambda-functions/',
'efs-cross-vpc':'https://docs.aws.amazon.com/efs/latest/ug/mount-fs-different-vpc.html',
}

def fetch(kv):
 k,u=kv;r=requests.get(u,timeout=45);r.raise_for_status();s=Parser();s.feed(r.text);t='\n'.join(s.out);d={'url':u,'finalUrl':r.url,'httpStatus':r.status_code,'retrievedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':t,'textSha256':hashlib.sha256(t.encode()).hexdigest(),'htmlSha256':hashlib.sha256(r.content).hexdigest()};f=base/(k+'.snapshot.json');f.write_text(json.dumps(d,ensure_ascii=False,indent=2));return(k,len(t),r.url)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
 for item in urls.items():
  try:print(fetch(item))
  except Exception as e:print(item[0],str(e))

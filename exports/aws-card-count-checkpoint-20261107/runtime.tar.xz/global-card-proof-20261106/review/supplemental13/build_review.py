import json,pathlib,hashlib,collections,datetime,re,copy
O=pathlib.Path(__file__).parent;V=O.parent.parent;I=O/'input';OUT=V/'review/reuse-a'
def sha(b):return hashlib.sha256(b).hexdigest()
def can(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
manifest=json.loads((I/'manifest.json').read_text())
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,p
base=json.loads((I/'visible-pool.frozen.json').read_text());cards={c['ruleId']:dict(c) for c in base};drafts=json.loads((I/'cards.json').read_text());F=['frontZH','answerZH','keyPointZH','watchOutZH']
for c in base:assert sha(can(c['visibleBody']))==c['bodySha256']
# Explicit accepted-context increment. No existing input or production pointer is modified.
p12=OUT/'supplemental12.review.json';r12=json.loads(p12.read_text());b12=OUT/'supplemental12.readback.json';rb12=json.loads(b12.read_text());assert sha(p12.read_bytes())==rb12['reviewSha256'];assert rb12['status'].startswith('PASS')
accepted12=[]
for r in r12['results']:
 assert r['status']=='PASS' and all(r['gates'][k]=='PASS' for k in ['FACT','U1','R1','T1','S1','P1']);assert sha(can(r['visibleBody']))==r['bodySha256']
 rid=r['ruleId'];prior=cards.get(rid,{});cards[rid]={**prior,'ruleId':rid,'visibleBody':r['visibleBody'],'bodySha256':r['bodySha256'],'prerequisiteRuleIds':r['prerequisiteRuleIds'],'acceptedContextFrom':str(p12)};accepted12.append({'ruleId':rid,'bodySha256':r['bodySha256']})
assert len(cards)==362
for d in drafts:
 c=cards[d['ruleId']];assert c['bodySha256']==d['repairOf'],(d['ruleId'],c['bodySha256'],d['repairOf']);body={f:d.get(f,'') for f in F};cards[d['ruleId']]={**c,'visibleBody':body,'bodySha256':sha(can(body)),'candidateOverlay':True}
qcases=json.loads((I/'questions.json').read_text());qs={x['qid']:x['question'] for x in qcases}
E={};inputValidation=[];authorEvidence=json.loads((I/'official-evidence.json').read_text())
for n,e in enumerate(authorEvidence,1):
 p=pathlib.Path(e['snapshotPath']);d=json.loads(p.read_text());t=d['text'];assert sha(p.read_bytes())==e['snapshotSha256'];assert sha(t.encode())==e['textSha256'];a=t.find(e['quote']);assert a>=0,(n,e['url']);inputValidation.append({'ordinal':n,'status':'PASS','url':e['url'],'snapshotPath':str(p),'snapshotSha256':e['snapshotSha256'],'textSha256':e['textSha256'],'quoteStart':a,'quoteEnd':a+len(e['quote'])})
def ev(eid,selector,needles,path=None):
 if path:p=pathlib.Path(path)
 elif selector.startswith('@'):p=O/'evidence'/(selector[1:]+'.snapshot.json')
 else:p=pathlib.Path(next(e['snapshotPath'] for e in authorEvidence if selector in e['url']))
 d=json.loads(p.read_text());t=d['text'];quotes=[]
 for n in needles:
  m=re.search(r'\s+'.join(re.escape(w) for w in n.split()),t,re.I);assert m,(eid,n);a=max(0,m.start()-70);b=min(len(t),m.end()+230);quotes.append({'quote':t[a:b],'start':a,'end':b})
 E[eid]={'url':d['url'],'snapshotPath':str(p),'snapshotSha256':sha(p.read_bytes()),'textSha256':sha(t.encode()),'quotes':quotes}
ev('GLUE_SERVERLESS','what-is-glue',['AWS Glue is a serverless data integration service','catalog'])
ev('GLUE_STREAM','add-job-streaming',['jobs that run continuously','load the results into Amazon S3'])
ev('HTTP_PRICING','api-gateway/pricing',['$1.00/million','$3.50/million'])
ev('HTTP_AUTHORIZER','http-api-lambda-authorizer',['sourceIp','2.0','caching'])
ev('HTTP_COMPARE','', ['lower price','Resource policies'],str(V/'review/supplemental11/evidence/http-compare.snapshot.json'))
ev('LAMBDA_EFS_CONFIG','configuration-filesystem-efs',['mount an Amazon Elastic File System','Local mount path','peered to another VPC'])
ev('EFS_CROSS_ACCOUNT','@lambda-efs-cross-account-news',['You can connect to EFS in the same AZ via cross account VPC'])
ev('EFS_CROSS_VPC','@efs-cross-vpc',['same Availability Zone ID','another AWS account'])
ev('GLACIER_WINDOWS','restoring-objects-retrieval-options',['1–5 minutes','3–5 hours','within 12 hours','within 48 hours'])
ev('S3_SMALL_PRICING','s3/pricing',['40 KB','128 KB'])
# Reuse precisely the valid independent GSC-077 fact proof and its unchanged source quotes.
r077=next(r for r in r12['results'] if r['ruleId']=='GSC-077');reused077=[]
for eid in r077['evidenceIds']:
 e=r12['evidenceRegistry'][eid];p=pathlib.Path(e['sourcePath']);t=json.loads(p.read_text())['text'];assert sha(p.read_bytes())==e['sourceFileSha256'];assert sha(t.encode())==e['sourceTextSha256'];assert t[e['startChar']:e['endChar']]==e['quote']
 if e.get('rawHtmlPath'):assert sha(pathlib.Path(e['rawHtmlPath']).read_bytes())==e['rawHtmlSha256']
 ne='S12-'+eid;E[ne]={'url':e['url'],'snapshotPath':str(p),'snapshotSha256':e['sourceFileSha256'],'textSha256':e['sourceTextSha256'],'quotes':[{'quote':e['quote'],'start':e['startChar'],'end':e['endChar']}],'reusedIndependentFACTProof':{'reviewPath':str(p12),'reviewSha256':sha(p12.read_bytes()),'ruleId':'GSC-077','bodySha256':r077['bodySha256'],'evidenceId':eid}};reused077.append(ne)
p11=OUT/'supplemental11.review.json';r11=json.loads(p11.read_text());prev={r['ruleId']:r for r in r11['results']}
notes={
 'GSC-095':('一个主判断仍是“发现目录不是执行转换”。无服务器执行性质直接解释为什么不用维护转换集群，批/流例子是同一ETL机制的变体。','回答实际ETL及crawler只更新目录；不把列出所有流源/参数或重复给定CSV场景当必答。',['GLUE_SERVERLESS','GLUE_STREAM']),
 'CUR:XA053':('IP准入按API产品匹配机制是主任务；较低HTTP请求单价作为必要能力优先的取舍边界，不把价格变成替代功能检查。','两种API分别说明策略/authorizer；HTTP使用可信上下文及避免跨IP缓存。价格是对选型边界的解释，不另评分全部计价档。',['HTTP_COMPARE','HTTP_PRICING','HTTP_AUTHORIZER']),
 'GCL-030':('一个回忆任务是“网络可达不等于代码已有文件路径”。同物理AZ跨账户支持已在题面收窄，答仍只需挂载接入点和本地目录，权限给定不重复考。','必须答挂载/接入点与本地路径并说明代码文件目录如何出现；不要求复述已给网络/权限或全部安全组配置。',['LAMBDA_EFS_CONFIG','EFS_CROSS_ACCOUNT','EFS_CROSS_VPC']),
 'VC-006':('同一轴是可等多久→具体取回档位与费用。新增Standard 3–5h提供6h场景必要比较，没有加入独立配置事项。','评分具体截止条件下需选类别/档位及等待费用机制；不强制每次把全部数值、已给限制和预置容量提醒一并背出。',['GLACIER_WINDOWS','S3_SMALL_PRICING'])}
cardResults=[]
for d in drafts:
 rid=d['ruleId'];c=cards[rid];why,assessment,eids=notes[rid];reuse=[]
 if rid in prev:
  pr=prev[rid];assert pr['status']=='PASS' and pr['bodySha256']==d['repairOf'];reuse=[{'path':str(p11),'sha256':sha(p11.read_bytes()),'ruleId':rid,'bodySha256':pr['bodySha256'],'scope':'exact unchanged prior clauses only; new serverless/price fact independently checked'}]
 cardResults.append({'ruleId':rid,'status':'PASS','gates':{**{k:'PASS' for k in ['FACT','U1','R1','T1','S1','P1']},'B1':'N/A_CHINESE_ONLY'},'visibleBody':c['visibleBody'],'bodySha256':c['bodySha256'],'fieldSha256':{f:sha(c['visibleBody'][f].encode()) for f in F},'fullDraftSha256':sha(can(d)),'priorBodySha256':d['repairOf'],'namedValidPriorFACTProofs':reuse,'evidenceIds':eids,'teachingAndRecallTaskReason':why,'assessmentCheck':assessment,'prerequisiteRuleIds':c['prerequisiteRuleIds'],'findings':[]})
def cardAnchors(ids):
 used=[]
 def add(r):
  if r in used:return
  assert r in cards,r;used.append(r)
  for p in cards[r]['prerequisiteRuleIds']:add(p)
 for r in ids:add(r)
 a=[]
 for r in used:
  c=cards[r]
  for f,t in c['visibleBody'].items():
   if t:a.append({'ruleId':r,'bodySha256':c['bodySha256'],'field':f,'quote':t,'start':0,'end':len(t)})
 return used,a
QR=[]
def Q(q,status,ids,choice,reason,gap='',eids=()):
 used,a=cardAnchors(ids.split());question=qs[q];QR.append({'qid':q,'status':status,'selectedOptionOrdinals':choice if status=='SUPPORTED' else [],'candidateOptionOrdinals':choice,'questionSha256':sha(can(question)),'originalStemUtf8Sha256':sha(question['stem'].encode()),'originalOptionsCanonicalSha256':sha(can(question['options'])),'completeStemAndEveryOptionRead':True,'directlyUsedRuleIds':ids.split(),'usedRuleIds':used,'necessaryAnchors':a,'recursiveUsedPrerequisiteBindings':[{'ruleId':r,'bodySha256':cards[r]['bodySha256'],'prerequisiteRuleIds':cards[r]['prerequisiteRuleIds']} for r in used],'reasoningAndClosestCompetitor':reason,'minimumRemainingJudgments':gap,'conditions':[] if not gap else [gap],'implementationChecksNotNewCards':'普通路由、挂载、权限、支持配额和配置验证单列，不把未做生产SLA测试或题外绝对无故障要求加为门槛。','officialEvidenceIds':list(eids),'sourceIssues':('HTTP API原选项无所需受支持前门IP准入机制；按HTTP API产品解读，resource policy不支持。有效authorizer需另存最小练习，原题不升级。' if q==1019 else None),'newCardFACTPassDoesNotAutomaticallyPromoteQuestion':True,'noPrivateTargetsOrPrintedAnswersUsed':True})
Q(485,'CONDITIONAL','VC-006 CUR:CMP-M01',[1], 'A的Expedited是分钟级归档恢复方向；新增Standard 3–5h进一步排除B对五分钟目标的适用性。C/D即时读取，但存储/取回费用路线不同。','原文硬五分钟与视频对象大小/实际取回需求仍须匹配。卡明确Expedited通常窗口及小于250MB边界，原题未给对象大小；不能把通常1–5分钟泛化到任何旧视频。仍保留原条件性，不要求题外生产SLA证明，也不把C/D的费用可能性悄悄排尽。',('GLACIER_WINDOWS',))
Q(551,'INSUFFICIENT_CARDS','VC-006 CUR:CMP-M01 GSC-024 VC-012 GSC-025',[1], '新增3–5h让Flexible Standard在通常6h窗口下成为可行方向，Deep Archive Standard通常12h不合窗口；C把Intelligent-Tiering内部访问层写成直接变成独立Standard-IA/Glacier类，不符合卡面分层机制。','50KB是原题明示成本条件。GSC024只教要比较最低计费对象大小和元数据/转换费用，没有给足以对本题A/B作最低总费取舍的可见规则；不能只用“归档通常便宜”忽略小对象开销。VC012的最低计费期不能当成禁止七天转换的规则，本轮未以未经当前官方确认的旧30天转换印象排B。50KB的Lifecycle默认最小尺寸/显式过滤需正常实施核查，不能仅据未配置就宣布原题无解。当前新增取回时长只闭合时间判断，未闭合含50KB的完整费用证明。',('GLACIER_WINDOWS','S3_SMALL_PRICING'))
Q(800,'SUPPORTED','GCL-030 GCL-021 GSC-001 CUR:CB16 CUR:CMP-M10',[2], 'B建立两账户VPC的私网可达；新GCL030给同物理AZ跨账户Lambda→EFS支持路径，配接入点、本地目录和授权后，代码实际读取原文件系统，EFS按数据增长扩展。A复制整份数据并维护同步，C每次经第二函数代理，D静态layer不会随文件系统自动变化；B沿用现有数据和文件接口，最少附加资源。','',('LAMBDA_EFS_CONFIG','EFS_CROSS_ACCOUNT','EFS_CROSS_VPC'))
Q(804,'SUPPORTED','GSC-095 CUR:XB013 GSC-103 GSC-089',[3], 'C的Glue现在明确无服务器执行基础设施，完成每日实际ETL；XB013给MPP仓库并行与Redshift Serverless，GSC103给SQL建模/预测，GSC089给每日调度。B的Aurora不是所问MPP分析仓库，D的Athena表不能替代Redshift ML数据仓库，A没有C的明确无服务器仓库链。原11所记Glue执行性质缺句已定向闭合。','',('GLUE_SERVERLESS','GLUE_STREAM'))
Q(920,'SUPPORTED','GSC-080 CUR:CA17 CUR:XA053',[4], 'SNS给独立订阅者各一份，符合pub/sub，A的竞争队列不能代替；B/D的同一Lambda→SNS功能都可由HTTP请求入口承载，新XA053明确HTTP通常请求单价较低且本题未需要REST独有能力，所以D更合成本。C的WebSocket与KDS增强扇出没有本题必需条件。只比较这些同功能选项，不追加所有Region/免费档绝对最低价证明。','',('HTTP_COMPARE','HTTP_PRICING'))
Q(1019,'SOURCE_ISSUE','CUR:XA053 CUR:CA19 CUR:CMP-M04',[2], '新价格句不改变HTTP API的资源策略能力。按原文HTTP API产品，B的resource policy不支持；A的private integration是后端私网连接，C/D把托管API当可部署子网或直接附SG的实例，均不是该HTTP API所需前门IP准入机制。新卡的Lambda authorizer实际sourceIp判断可行，但不在原选项。','原题不能因现有卡会正确替代方法就升级；若原意只是泛指HTTP协议且实际是REST，须作为另存澄清，而不能静默改变产品。',('HTTP_COMPARE','HTTP_AUTHORIZER'))
# Only the affected failed practice Q659-CV10 is retested against accepted supplemental12 GSC-077.
pv=V/'review/corrected-variants10-current01/results.json';old=json.loads(pv.read_text());old659=next(x for x in old['results'] if x['originalQid']==659);assert old659['status']=='INSUFFICIENT_CARDS';cvp=V/'review/corrected-variants10-current01/input/cases.json';cv=next(x for x in json.loads(cvp.read_text()) if x['originalQid']==659)
assert sha(can(cv['originalQuestion']))==old659['originalQuestionCanonicalSha256'];assert sha(can(cv['correctedQuestion']))==old659['correctedQuestionCanonicalSha256'];used,a=cardAnchors(old659['directlyUsedRuleIds'])
cr=copy.deepcopy(old659);cr.update(status='SUPPORTED',closureEligibleUnderAcceptedCorrectionPolicy=True,selectedOptionOrdinals=[3],independentlySupportedPartialOptionOrdinals=[],necessaryAnchors=a,cardBindings=[{'ruleId':r,'bodySha256':cards[r]['bodySha256'],'prerequisiteRuleIds':cards[r]['prerequisiteRuleIds']} for r in used],actualUsedRuleIdsIncludingRecursivePrerequisites=used,minimumRemainingJudgments='',findings=[],visibleCardReasoning='50TB在100Mbps下理想约46.3天，超过两周；实际设备资格、容量及准备/运输/导入两周已由原练习设定给定，GSC077指向离线路线。新增已独立PASS正文明确设备256位加密和KMS保护密钥，补上securely所需可见数据保护理由；GSC006说明返运导入S3。C满足练习给定条件，其余在线方案不能凭现有100Mbps改变数据量下限。普通路由/文件复制操作不另当缺卡。',officialEvidenceIds=reused077,affectedRetestOnly=True,priorReviewBinding={'path':str(pv),'sha256':sha(pv.read_bytes()),'variantId':'Q659-CV10','priorStatus':'INSUFFICIENT_CARDS','closedFindingId':'CV10-F03'},acceptedIncrementBinding={'reviewPath':str(p12),'reviewSha256':sha(p12.read_bytes()),'ruleId':'GSC-077','bodySha256':r077['bodySha256']},variantQuestionUnchanged=True,originalStatusAfterThisReview='SOURCE_ISSUE',doesNotUpgradeOriginal=True)
for b in old659['cardBindings']:
 if b['ruleId']!='GSC-077':assert cards[b['ruleId']]['bodySha256']==b['bodySha256']
transfer=[{'ruleId':'GSC-095','changedCondition':'只登记目录，不运行任何转换','status':'PASS','reason':'仍无新格式字节；无服务器是ETL执行性质，不使crawler自动成为转换作业。'},{'ruleId':'CUR:XA053','changedCondition':'同一身份从允许IP换成拒绝IP','status':'PASS','reason':'TTL0每次重新读可信sourceIp，不能跨IP复用旧Allow；HTTP较便宜不免除机制配置。'},{'ruleId':'GCL-030','changedCondition':'仅网络已连通，但没本地挂载路径','status':'PASS','reason':'文件路径仍未出现；若跨实际AZ，当前同AZ支持前提不满足，不能由peering存在外推。'},{'ruleId':'VC-006','changedCondition':'取回预算从6h缩为5min','status':'PASS','reason':'Standard 3–5h不再适用；需转Expedited等适用档并实际考虑其对象/容量边界。'}]
additional={'reviewPath':str(p12),'reviewSha256':sha(p12.read_bytes()),'readbackPath':str(b12),'readbackSha256':sha(b12.read_bytes()),'acceptedBodyBindings':accepted12,'mechanism':'Deterministic explicit accepted-context overlay, separate from the immutable 360 input; only GSC-077 proof is semantically reused for this task. No unrelated supplemental12 card is re-reviewed.','usedAcceptedRuleIds':['GSC-077']}
counts={'cardPASS':4,'cardFAIL':0,'originalQuestionStatuses':dict(collections.Counter(x['status'] for x in QR)),'affectedCorrectedPractices':1,'affectedPracticeSUPPORTED':1}
report={'schemaVersion':1,'batch':'supplemental13','reviewer':'independent_native_open_condition_review_agent','status':'PASS_CARDS_WITH_OPEN_ORIGINAL_QUESTIONS','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(I/'manifest.json'),'inputManifestSha256':sha((I/'manifest.json').read_bytes()),'inputHashes':manifest,'frozenVisiblePoolCount':360,'effectiveAcceptedContextPoolCount':362,'candidateOverlayCount':len(cards),'additionalAccepted12Context':additional,'proposedNewCards':0,'revisedExistingCards':4,'appliedToCurrent':False,'counts':counts,'results':cardResults,'questionImpactReview':QR,'affected':{'correctedPracticeResults':[cr],'previousVariantReviewPath':str(pv),'previousVariantReviewSha256':sha(pv.read_bytes()),'unchangedOtherFiveFailedVariantIds':['Q059-CV10','Q501-CV10','Q806-CV10','Q827-CV10','Q1004-CV10'],'originalPromotions':0},'correctedPracticeResults':[cr],'evidenceRegistry':E,'officialInputRecordValidation':inputValidation,'transferChecks':transfer,'minimumRepairScope':[],'sourceMetadataAdvice':[{'ruleId':'GCL-030','advice':'把新加入的AWS News Blog同AZ跨账户明确原句及当前Lambda文档的peered-VPC段落登记到私有依据；输入Compute Blog中的“must all reside in same VPC”旧笼统段落不能单独证明新句。正文事实已用更具体官方正证闭合，不要求改卡面。','evidenceIds':['EFS_CROSS_ACCOUNT','LAMBDA_EFS_CONFIG']}],'sourceConflicts':[{'ruleId':'GCL-030','olderBroadStatement':'Input Compute Blog says Lambda functions using EFS must all reside in same VPC.','resolution':'Official AWS News Blog explicitly permits same-AZ cross-account VPC connectivity; current Lambda guide also prices peered-VPC EFS access and permits same-AZ subnets that can route NFS. Scope retained to same physical AZ; no claim of cross-AZ/Region integration.'}],'formalBilingualAcceptance':'N/A_CHINESE_ONLY','privateGradingContractAcceptance':'NOT_PROVIDED; S1 checked visible tasks only','learnerMemoryOrAccuracyMeasured':False,'finalCardCountVerified':False,'originalQuestionStatusesAutomaticallyPromoted':False,'priorFailuresPreserved':True,'currentPointersChangedByReviewer':False,'authoringPerformed':False,'directCliApiCalls':0,'nativeUsage':'unknown'}
out=OUT/'supplemental13.review.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2));checks=collections.Counter()
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h;checks['frozenInputHashes']+=1
assert sha(p12.read_bytes())==rb12['reviewSha256'];checks['accepted12IndependentCredential']=1
for r in cardResults:assert sha(can(r['visibleBody']))==r['bodySha256'];checks['candidateBodyHashes']+=1
for q in QR:
 assert q['questionSha256']==sha(can(qs[q['qid']]));checks['completeOriginalQuestionBindings']+=1
 for a in q['necessaryAnchors']:assert cards[a['ruleId']]['bodySha256']==a['bodySha256'];assert cards[a['ruleId']]['visibleBody'][a['field']][a['start']:a['end']]==a['quote'];checks['exactCardAnchors']+=1
 for b in q['recursiveUsedPrerequisiteBindings']:assert set(b['prerequisiteRuleIds'])<=set(q['usedRuleIds']);checks['recursiveBindings']+=1
for a in cr['necessaryAnchors']:assert cards[a['ruleId']]['bodySha256']==a['bodySha256'];assert cards[a['ruleId']]['visibleBody'][a['field']][a['start']:a['end']]==a['quote'];checks['affectedPracticeCardAnchors']+=1
assert cr['originalStatusAfterThisReview']=='SOURCE_ISSUE' and cr['correctedQuestionCanonicalSha256']==sha(can(cv['correctedQuestion']));assert sha(pv.read_bytes())==cr['priorReviewBinding']['sha256'];checks['affectedVariantOriginalAndVariantPreserved']=1
for e in E.values():
 p=pathlib.Path(e['snapshotPath']);assert sha(p.read_bytes())==e['snapshotSha256'];t=json.loads(p.read_text())['text'];assert sha(t.encode())==e['textSha256'];checks['officialSnapshotBindings']+=1
 for a in e['quotes']:assert t[a['start']:a['end']]==a['quote'];checks['officialQuoteAnchors']+=1
assert json.loads(out.read_text())==report
rb={'status':'PASS','meaning':'deterministic readback only; four cards PASS, three original questions SUPPORTED, two original open conditions and one source issue retained, affected Q659 practice separately SUPPORTED','reviewPath':str(out),'reviewSha256':sha(out.read_bytes()),'inputManifestSha256':report['inputManifestSha256'],'counts':counts,'checks':dict(checks),'frozenInputPool':360,'explicitAcceptedContextPool':362,'originalPromotionsFromCorrectedVariant':0,'otherFiveFailedVariantsNotReevaluated':True,'nativeUsage':'unknown','directCliApiCalls':0}
(OUT/'supplemental13.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2));(O/'readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2));print(json.dumps(rb,ensure_ascii=False,indent=2))

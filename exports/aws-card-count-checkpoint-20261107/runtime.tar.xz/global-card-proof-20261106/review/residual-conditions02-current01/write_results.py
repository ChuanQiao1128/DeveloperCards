# -*- coding: utf-8 -*-
import collections,datetime,hashlib,json,re
from pathlib import Path
V=Path.cwd();R=V/'review/residual-conditions02-current01';P=R/'input';E=R/'evidence';canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((P/'manifest.json').read_text());assert all(sha(p)==h for p,h in m.items());qq=json.loads((P/'questions.json').read_text());qs={x['qid']:x['question']for x in qq};pool=json.loads((P/'visible-pool.frozen.json').read_text());cards={c['ruleId']:c for c in pool};assert len(cards)==362
for c in pool:assert hashlib.sha256(canon(c['visibleBody']).encode()).hexdigest()==c['bodySha256']
frozenCards=cards.copy()
# Only one dependency of the five SUPPORTED questions changed after this immutable input.
# Apply the independently PASSed current body explicitly; do not replace the frozen pool.
proofPath=V/'review/reuse-a/supplemental15.review.json';readbackPath=V/'review/reuse-a/supplemental15.readback.json'
proof=json.loads(proofPath.read_text());receipt=json.loads(readbackPath.read_text())
assert receipt['reviewSha256']==sha(proofPath) and receipt['status'].startswith('PASS')
revised=next(r for r in proof['results'] if r['ruleId']=='GSC-095');assert revised['status']=='PASS'
assert revised['bodySha256']==hashlib.sha256(canon(revised['visibleBody']).encode()).hexdigest()
live={c['ruleId']:c for c in json.loads((V/'deliverables/cards.current.json').read_text())}
assert revised['visibleBody']==live['GSC-095']['visibleBody']
incremental=[{'ruleId':'GSC-095','affectedQids':[258],'frozenBodySha256':cards['GSC-095']['bodySha256'],'currentBodySha256':revised['bodySha256'],'visibleBody':revised['visibleBody'],'proofPath':str(proofPath.resolve()),'proofSha256':sha(proofPath),'readbackPath':str(readbackPath.resolve()),'readbackSha256':sha(readbackPath),'targetedConclusion':'Current visible wording explicitly teaches serverless managed ETL and Spark worker parallelism. Q258 D still supplies the actual CSV-to-Parquet conversion with managed execution; Lambda only triggers it. File size alone is not used to disqualify Lambda.'}]
cards['GSC-095']={**cards['GSC-095'],'visibleBody':revised['visibleBody'],'bodySha256':revised['bodySha256'],'prerequisiteRuleIds':revised['prerequisiteRuleIds']}
cat=json.loads((V/'review/final-core-closure01/input/official-snapshot-catalogue.json').read_text());sources={}
def source(key,path,quote):
 p=Path(path);j=json.loads(p.read_text());t=j['text'];match=re.search(r'\s+'.join(re.escape(x)for x in quote.split()),t);assert match,(key,quote);a,b=match.span();sources[key]={'url':j['url'],'snapshotPath':str(p.resolve()),'snapshotSha256':sha(p),'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':t[a:b],'quoteStart':a,'quoteEnd':b};return key
def src(key,name,quote):return source(key,E/(name+'.json'),quote)
def old(key,index,quote):
 s=cat[index];assert sha(s['snapshotPath'])==s['snapshotSha256'];return source(key,s['snapshotPath'],quote)
# Only official snapshot metadata is reused; no old answer/status is adopted.
past=json.loads((V/'review/remaining-source10/results.json').read_text())['officialSources']
for k in ['SNOW_ELIGIBILITY','SNOW_GPU_RETIRED','SNOW_SHIPPING','VOLUME_CACHED','S3_OVERHEAD','IO1_RATIO','EC2_RI','RDS_RI','EC2_T3_RATES','AURORA_SERVERLESS']:
 s=past[k];assert sha(s['snapshotPath'])==s['snapshotSha256'];sources[k]=s
src('FSX_GATEWAY_QUALIFICATION','fsx-client-eligibility','Amazon FSx File Gateway is no longer available to new customers. Existing customers of FSx File Gateway can continue to use the service normally.')
src('FSX_LOCAL_CACHE','fsx-client-eligibility','FSx for Windows File Server also supports the use of Amazon FSx File Gateway to provide low latency, seamless access')
src('OBJECT_LAMBDA_QUALIFICATION','objectlambda-eligibility','existing customers that are currently using the service as well as to select AWS Partner Network (APN) partners.')
src('OBJECT_LAMBDA_READ','objectlambda-eligibility','you can add your own code to Amazon S3 GET , LIST , and HEAD requests')
src('FORECAST_QUALIFICATION','forecast-eligibility','Amazon Forecast is no longer available to new customers. Existing customers of Amazon Forecast can continue to use the service as normal.')
src('FORECAST_MANAGED','forecast-eligibility','Amazon Forecast is a fully managed service')
src('ADS_QUALIFICATION','ads-availability','Existing customers can continue to use the service as normal.')
src('ADS_NEW_CLIENTS','ads-availability','Application Discovery Service will stop accepting new customers starting November 7, 2025.')
src('MIGRATION_HUB_NEW','migrationhub-eligibility','AWS Migration Hub is no longer open to new customers as of November 7, 2025.')
src('A2C_QUALIFICATION','app2container-what','is no longer open to new customers. If you would like to use the service, sign up prior to November 7, 2025.')
src('A2C_LINUX','app2container-support','ASP.NET applications (Windows, Linux)')
src('A2C_CONTAINER','app2container-what','AWS App2Container (A2C) is a command line tool to help you lift and shift applications')
src('SNOWMOBILE_FULL_SHUTDOWN','full-shutdown','AWS Snowmobile March 14, 2024')
src('SHUTDOWN_MEANING','full-shutdown','Services and features in full shutdown are completely removed from the AWS portfolio and are no longer available or supported in any capacity.')
src('GLUE_PARQUET','glue-formats','AWS Glue supports using the Parquet format.')
src('GLUE_CSV','glue-csv','AWS Glue supports using the comma-separated value (CSV) format.')
source('GLUE_SERVERLESS',V/'review/reuse-a/sources/3d0f63987febb279fd22.json',"It's also serverless, which means there's no infrastructure to manage.")
src('LAMBDA_API_REST','lambda-api-proxy','HTTP APIs and REST APIs are both RESTful APIs that process HTTP requests and return responses.')
src('LAMBDA_API_ENDPOINT','lambda-api-proxy','You can create a web API with an HTTP endpoint for your Lambda Event Function by using Amazon API Gateway.')
src('DDB_EXPORT','dynamodb-export',"Exports are asynchronous, they don't consume read capacity units (RCUs) and have no impact on table performance and availability.")
src('DDB_PITR_FOR_EXPORT','dynamodb-export','You need to enable PITR on your table to use the export functionality.')
src('DDB_EXPORT_INTERVAL','dynamodb-incremental-export','The export period duration must be at least 15 minutes and be no longer than 24 hours.')
old('DDB_PITR',236,'Amazon DynamoDB point-in-time recovery (PITR) provides automatic continuous backups of your DynamoDB table data.')
old('DDB_STREAMS',229,'A DynamoDB stream is an ordered flow of information about changes to items in a DynamoDB table.')
src('FARGATE_SPOT','fargate-spot','With Fargate Spot, you can run interruption tolerant Amazon ECS tasks at a rate that\'s discounted compared to the Fargate price.')
src('FARGATE_SPOT_WARNING','fargate-spot','When AWS needs the capacity back, your tasks are interrupted with a two-minute warning.')
src('FARGATE_OPTIMIZER','fargate-optimizer','The information that\'s provided includes the recommended CPU and memory size within an Amazon ECS service')
src('DMS_SOURCES','dms-sources','The following sections contain the lists of supported source data stores for each AWS DMS feature.')
src('DMS_MONGODB','dms-sources','MongoDB versions 3.x, 4.0, 4.2, 4.4, 5.0, 6.0, 7.0 and 8.0.')
src('TRANSCRIBE_LANGUAGES','transcribe-languages','The languages supported by Amazon Transcribe are listed in the following table')
src('TRANSLATE_LANGUAGES','translate-languages','Amazon Translate supports text translation between the languages listed in the following table.')
src('AUTOPILOT','sagemaker-autopilot','Model training and evaluation: Autopilot automates the process of training and evaluating various model candidates.')
src('HOST_RESERVATION','host-billing','Dedicated Host Reservations provide a billing discount compared to running On-Demand Dedicated Hosts.')
src('HOST_CORE_LICENSES','host-overview','They allow you to use your existing per-socket, per-core, or per-VM software licenses')
src('BACKUP_LIFECYCLE','backup-lifecycle','The number of days after creation that a recovery point is deleted.')
src('BACKUP_RETENTION_TARGET','backup-lifecycle','Specifies the time period, in days, before a recovery point transitions to cold storage or is deleted.')
src('LOG_RETENTION','cloudwatch-retention','Sets the retention of the specified log group.')
src('AUDIT_POSTGRES','aurora-audit','In addition to the standard PostgreSQL logs discussed in this topic, Aurora PostgreSQL also supports the PostgreSQL Audit extension ( pgAudit ).')
src('IT_90','s3-intelligent','If an object is not accessed for 90 consecutive days, the object moves to the Archive Instant Access tier.')
src('IT_128','s3-intelligent','If the size of an object is less than 128 KB, it is not monitored and is not eligible for automatic tiering.')
old('RED_SHIFT_ENCRYPTION',138,'Use client-side encryption – You can encrypt data client-side and upload the encrypted data to Amazon Redshift.')
old('REDSHIFT_SERVER_ENCRYPTION',138,'Use server-side encryption – You request Amazon Redshift to encrypt your data before saving it on disks in its data centers and decrypt it when you download the objects.')
old('REDSHIFT_COPY_RETIREMENT',57,'After April 30, 2026, you won\'t be able to use client-side encryption for COPY and UNLOAD.')
src('REDSHIFT_PAUSE','redshift-pause','You can schedule actions to pause and resume a cluster.')
src('REDSHIFT_RESTORE','redshift-restore','If you restore your cluster from a snapshot, Amazon Redshift uses the cluster information to create a new cluster.')
src('REDSHIFT_API','redshift-api','You can run SQL statements using the Data API operations with the AWS SDK.')
src('GATEWAY_STILL_PUBLIC','s3-gateway-public','When your instances access Amazon S3 or DynamoDB through a gateway endpoint, they access the service using its public endpoint.')
src('INTERFACE_PRIVATE_IP','s3-interface-private','Use private IP addresses from your VPC to access Amazon S3')
src('VPN_5GBPS','vpn-limits','Maximum bandwidth per large bandwidth VPN tunnel Up to 5 Gbps')
src('AURORA_STOP_COST','aurora-stop','While your cluster is stopped, you are charged for cluster storage, manual snapshots, and automated backup storage within your specified retention window, but not for DB instance hours.')
src('CDK_DEFAULT_MIN','cdk-cluster-props','ServerlessV2MinCapacity ? optional *float64 = 0.5')
src('AURORA_SET_ZERO','aurora-pause','specifying a minimum ACU value of zero for your DB cluster.')
old('GLACIER_EXPEDITED',256,'Objects under 250 megabytes in size are typically made available within 1–5 minutes')
old('GLACIER_CAPACITY',256,'Each unit of capacity provides that at least three Expedited retrievals can be performed every 5 minutes, and it provides up to 300 megabytes per second of retrieval throughput.')
old('TRANSITION_GIR_TO_GDA',205,'The S3 Glacier Instant Retrieval storage class to the S3 Glacier Flexible Retrieval or S3 Glacier Deep Archive storage classes.')
source('EARLY_TRANSITION_BILLING',V/'review/remaining-source10/evidence/s3-pricing.json','Objects that are deleted, overwritten, or transitioned to a different storage class before the minimum storage duration will incur the normal storage usage charge')
# Specific source table checks, rather than an unbounded claim that all languages or source engines work.
lang=json.loads((E/'translate-languages.json').read_text())['text'];assert 'Fijian'not in lang and ' fj 'not in lang
costs=json.loads((E/'cost-counterexamples.json').read_text());pricebind={'path':str((E/'cost-counterexamples.json').resolve()),'sha256':sha(E/'cost-counterexamples.json')}
rows=[]
def close_prereqs(ids):
 found=set(ids);queue=list(ids)
 while queue:
  for d in cards[queue.pop()].get('prerequisiteRuleIds',[]):
   assert d in cards,d
   if d not in found:found.add(d);queue.append(d)
 return sorted(found-set(ids))
def row(qid,status,selected,summary,ids,verdicts,refs,issue=None,gaps=None,normal=None):
 q=qs[qid];assert len(verdicts)==len(q['options']);pre=close_prereqs(ids)
 e=[{'ruleId':k,'bodySha256':cards[k]['bodySha256'],'visibleQuotes':[{'field':f,'quote':cards[k]['visibleBody'][f]}for f in ['frontZH','answerZH','keyPointZH','watchOutZH']if cards[k]['visibleBody'][f]]}for k in ids]
 out={'qid':qid,'status':status,'questionSha256':hashlib.sha256(canon(q).encode()).hexdigest(),'questionHashMethod':'SHA256 UTF-8 canonical full frozen question JSON including qid, exact stem and every option ordinal/label/text; sorted keys, compact separators, ensure_ascii=false','selectedOptionOrdinals':selected,'summary':summary,'usedRuleIds':ids,'necessaryCardEvidence':e,'recursivePrerequisiteBindings':[{'ruleId':k,'bodySha256':cards[k]['bodySha256']}for k in pre],'optionJudgments':[{'ordinal':o['ordinal'],'originalLabel':o['originalLabel'],'judgment':v}for o,v in zip(q['options'],verdicts)],'officialEvidenceRefs':refs,'sourceIssue':issue,'knownVisibleCardGaps':gaps or [],'normalImplementationScope':normal or '路由、授权、事件接入和受支持资源配置等普通实施步骤可以落实；不要求部署后实测生产SLA，不以任意隐藏配置制造题源错误。','allOriginalOptionsRead':True,'originalModified':False}
 assert all(k in sources for k in refs),(qid,refs)
 rows.append(out);return out

def missing(field,cases,correction,basis=None):
 assert len(cases)>=2
 return {'confirmed':True,'subtype':'decisive_input_missing','missingDecisiveInput':field,'positiveTechnicalBasis':basis,'counterfactualScenarios':cases,'minimalCorrectionFields':correction,'newValuesAreExerciseInputsNotRecoveredOriginalFacts':True}
def qualification(service,oldout,newout,correction,extra=None):
 return missing(f'{service}的实际使用资格', [{'condition':f'公司是当前仍获准使用{service}的既有合格客户，所需功能/Region受支持。','outcome':oldout},{'condition':f'公司是尚无{service}既有资格的新客户，且不具备官方另列的特殊资格（如适用的APN例外）。','outcome':newout}],correction,extra or '官方明确区分既有客户可继续使用与新客户不能开通；两种账户状态都未被原题排除，不能当全面退役。')
def costissue(field,key,correction,labels):
 cases=[]
 for i,c in enumerate(costs[key]):cases.append({'condition':labels[i],'calculatedCase':c,'outcome':c.get('lowerCostOriginalOption',c.get('lowerCost'))})
 x=missing(field,cases,correction,'官方当前价格和能力均已查明；计算用两个符合原文的具体输入得到相反成本排序，参数不是原题隐藏事实。');x['calculationArtifact']=pricebind;return x

row(64,'SOURCE_ISSUE',[], 'D的云端FSx加机房缓存路径仍为既有合格客户提供低延迟Windows文件访问，但新客户不能开通FSx File Gateway。原文没有给资格，不能无条件选D或把它判成全面退役。', ['CUR:CA15','GCL-008','GSC-012'], ['云端FSx保留Windows共享语义，但机房读取仍经过VPN；不提供D的本地热点缓存。','两边都访问机房S3 File Gateway，会把云端访问拉回机房，且S3对象映射不能自动等同原Windows后端。','云端改直接S3 API改变原文件访问方式。','对既有合格客户可用，符合当前GCL-008已限定的教学范围；新客户不能照此开通。'], ['FSX_GATEWAY_QUALIFICATION','FSX_LOCAL_CACHE'],qualification('FSx File Gateway','D可按云端共享后端+机房缓存部署。','D不可开通；A只有直接远程访问，不能冒充同样机房缓存方案，需当前替代架构。',{'qualification':'若练习D，仅补明已具有FSx File Gateway有效使用资格；不要把新客户注册当既成事实。'}))
row(107,'SUPPORTED',[2], 'B提供业务REST入口和处理逻辑；存储可沿既有分析平台或以已学S3对象层承载，API入口本身不被当成持久数据库。原题是在给多层REST处理入口选项，未给必须用某一数据库的硬约束。', ['CUR:CA17','CUR:NA05','CUR:CMP-M06'], ['Athena/S3可分析持久对象，但不是本题所需的业务REST处理入口层。','API Gateway把REST请求交给Lambda，函数执行位置记录的存取逻辑；对象持久化与API计算分工可由当前卡组解释。','新建QuickSight/Redshift可视化仓库不是复用现有分析平台的REST接入层。','流式分析处理不自动成为保存和按REST读取业务位置记录的后端。'], ['LAMBDA_API_REST','LAMBDA_API_ENDPOINT'],normal='B没有声称API Gateway或Lambda本身保存持久状态；实际持久存储是正常多层实现。当前NA05已教S3对象持久化，CA17已教API/Lambda业务逻辑，权限由CMP-M06说明；未强加时序库、毫秒SLA或未问的数据库配置。')
row(153,'SOURCE_ISSUE',[], 'D是已知年龄分界的常见规则，但B的Intelligent-Tiering有按对象监控费及更低的即时归档层。即使所有文件都≥128KB，256KiB与2MiB两种铃声大小可反转整个成本排序。', ['GSC-025','GSC-024','CUR:CMP-M01'], ['一开始放IA会对前期活跃读取收取取回费，不是优先处理90天后变冷的策略。','有效IT路径可在连续未访问90天后进入即时归档层；监控费使它不对所有对象大小都更便宜。','Inventory提供对象清单，不负责迁移生命周期动作。','Lifecycle可按年龄移动到IA，但其总费不必然低于B。'], ['IT_90','IT_128'],costissue('对象大小、实际读取分布和比较保存期','Q153',{'sizeAndAccess':'仅补对象大小/访问及保存期等实际费用输入，或提供相同工作负载下的总费用；保留即时访问和最小成本目标。'},['两百万256KiB铃声，前90天每天读取，后续275天不读，保存一年；全部满足原文。','相同访问与保存期，两百万2MiB铃声；对象仍都≥128KB，最常访问文件仍即时可用。']))
row(157,'SOURCE_ISSUE',[], 'D+E解释日志长期留存与五年备份恢复点，但题面还要求五年后删除“所有数据”。备份过期删除的是恢复点，不会自动删除仍在Aurora中的业务行，也可能在新备份里继续保留旧记录。', ['CUR:XB008','CUR:NS03','CUR:NB04'], ['手工快照不自动满足五年后清理，更不删除源库行。','备份生命周期只处理恢复点，不是业务数据删除策略。','Aurora自动备份不能据此设为五年，更不能替代数据库记录删除。','导出审计日志到CloudWatch并保持不失效是正确日志方向。','AWS Backup可按五年保留备份，但它不单独完成源库业务数据五年后删除。'], ['BACKUP_LIFECYCLE','BACKUP_RETENTION_TARGET','LOG_RETENTION','AUDIT_POSTGRES'],{'confirmed':True,'subtype':'incomplete_actions_for_literal_retention_constraint','originalAnchor':'must delete all the data after 5 years','positiveTechnicalBasis':'官方DeleteAfterDays作用对象明确是recovery point；它不是源数据库数据生命周期。五个选项没有源库数据清理动作。','minimalCorrectionFields':{'retentionScope':'如果考备份，将义务明确为备份恢复点保存五年后过期，并说明源库业务数据清理由既有合规流程处理；若真要求所有业务数据删除，应补明确清理动作，不靠D+E冒称已满足。'},'newValuesAreExerciseInputsNotRecoveredOriginalFacts':True})
# Qualification cases for offline transport: arithmetic is a deterministic lower bound, not a guessed production SLA.
for qid,oldchoice,bytesTB,mbps,deadline_days,newout in [(215,1,700,500,30,'A不可开通；B/C/D即便不计协议开销也受500Mbps限制，最少约129.6天，超过一月。'),(398,3,600,100,14,'C不可开通；A/B约需555.6天。D只能在新专线和足够VPN实际容量及时可用时评估；不能沿用C作新客户答案。'),(763,2,150,100,30,'B不可开通；A已全面关闭；C/D无法突破夜间100Mbps上传的物理上限，不能在一月内完成。'),(778,2,1000,2000,28,'B不可开通；C已全面关闭；D受原互联网带宽限制至少约46.3天/办公室。A需新的10Gbps连接，在未能于四周内交付的真实场景下没有现成有效选项。')]:
 ids=['GSC-077','CUR:CMP-M01'] if qid==215 else ['GSC-077','CUR:NB01']
 if qid==763:ids=['GSC-077','GSC-023']
 summaries={215:'700TB/500Mbps的理想在线下限已超过一月，资格决定离线A能否采用。',398:'600TB/100Mbps的理想在线下限远超两周；既有合格客户可用C，不能把新客禁入误称全服务退役。',763:'夜间100Mbps即便每天24小时开放也不足一月搬150TB；既有Snowball资格决定B是否实际可用。',778:'每办公室1PB即便2Gbps满速也需约46天，超过四周；离线B的资格是实际决定输入。'}
 opts={215:['合格客户使用足够容量设备并在一月内完成离线链路后，Deep Archive适合多年极少读取。','VPN不会使500Mbps链路变快。','新建500Mbps专线也不能改变700TB传输的129.6天物理下限。','DataSync不突破现有500Mbps可用速率。'],398:['HTTPS/分块保证方式不改变100Mbps瓶颈。','VPN加密不提高100Mbps源链路。','受支持且合格的现行Storage Optimized设备可并行运输，设备加密保护离线数据。','10Gbps专线与VPN是另一路径，必须按实际VPN吞吐判断；现行大带宽隧道最高5Gbps，不能一概当作旧1.25Gbps或自动当10Gbps。'],763:['Snowmobile已在官方full shutdown目录，不是新客户资格限制。','对既有合格Snowball客户可订足够当前设备；新客户不能按此订单。','加速不能突破机房100Mbps夜间可用上传速率。','VPC端点和VPN不创造上传带宽。'],778:['10Gbps能够改变速率，但80处新建连接的交付窗口和一次性建设费不能假定为零。','现行合格客户可并行使用足够设备运输，避免逐办公室建设新的高速网络。','Snowmobile已全面关闭。','Volume Gateway仍要经现有1–2Gbps链路，不会突破四周期限。']}
 issue=qualification('AWS Snowball Edge',f'所需Snowball资格已存在，所订当前设备合计可用容量满足题量，且准备/运输/导入窗口已安排在{deadline_days}天内，选项{oldchoice}可行。',newout,{'qualification':'仅补现有Snowball Edge合格客户身份；如按新客户练习，另给当前可用在线/物理传输选项，不更名为仍可新购的旧设备。'},'AWS明确Snowball现行设备仍供既有客户；Snowmobile及停订旧型号另有全面关闭证据。')
 issue['counterfactualScenarios'][0]['condition']+=f' 合计实际可用容量≥{bytesTB}TB，全部离线作业已订在窗口内；在有新建DX选项的题中，客户新专线承运交付需六周，不能用于原短窗口。'
 issue['counterfactualScenarios'][1]['condition']+=' 相同数据、带宽、截止日；若有新DX选项，仍处在六周承运交付周期，原文未排除这种现实项目状态。'
 issue['onlineIdealLowerBoundDaysEven24Hours']=bytesTB*10**12*8/(mbps*10**6)/86400
 issue['nightOnlyMakes763Worse']=qid==763
 row(qid,'SOURCE_ISSUE',[],summaries[qid],ids,opts[qid],['SNOW_ELIGIBILITY','SNOW_GPU_RETIRED','SNOW_SHIPPING','SNOWMOBILE_FULL_SHUTDOWN','SHUTDOWN_MEANING']+(['VPN_5GBPS']if qid==398 else[]),issue)
row(258,'SUPPORTED',[4], 'D把CSV→Parquet交给原生ETL服务，Lambda只接对象事件启动作业。1GB并不必然超过Lambda限制；选择D的依据是少维护转换执行代码及依赖，而非编造超时或要求先做生产实测。', ['GSC-095','GSC-029','GSC-133'], ['在资源与900秒内时技术上可行，但需自己在函数中管理下载、转换库及输出；1GB本身不是必失败证据。','自建或维护Spark执行环境比托管ETL增加运行职责。','Crawler只发现结构，周期查询再自行转换多一段调度与转换逻辑。','Glue原生读CSV/写Parquet，事件Lambda只启动所需托管作业。'], ['GLUE_PARQUET','GLUE_CSV'],normal='普通S3事件授权、Glue job参数及job触发可以落实。没有把所有1GB文件断言为Lambda无法处理，也没有加入未给的15分钟实测门槛。')
for qid,choice in [(295,2),(756,1)]:
 verdicts={295:['自建代理需要维护计算与脱敏逻辑。','对既有合格客户可按请求返回脱敏视图，无需预存多份。','衍生桶可以提供隔离数据，但要维护生成与更新；不能自动与每次读取原始对象等价。','复制三套表也增加同步与存储，不能替代按读请求生成视图。'],756:['对已获准的账户，读取时脱敏可覆盖当时最新对象。','批量复制会有更新间隔，不能直接冒称已覆盖最新会话。','自建EC2读取脱敏网页可满足另一条路径，但增加常驻系统维护。','对象事件驱动的衍生数据会有处理窗口，且DynamoDB接口也改变访问方式；不能直接当同步最新对象视图。']}
 row(qid,'SOURCE_ISSUE',[], 'Object Lambda不是全面退役，既有使用者及特定APN伙伴仍可使用；普通新客户不能开通该按读取转换路径，原文资格缺失会改变可采用方案。', ['CUR:XR001','CUR:NA05','GSC-029'],verdicts[qid],['OBJECT_LAMBDA_QUALIFICATION','OBJECT_LAMBDA_READ'],qualification('S3 Object Lambda',f'当前账户仍合格，选项{choice}可在GET返回前按需要脱敏原始对象，减少衍生数据维护。',f'普通新客户且不是获选APN伙伴，不能新建{choice}所需服务；须从自建按读代理/事件衍生等当前路径重选。',{'qualification':'若练习Object Lambda，仅补明确既有合格使用资格或官方获选APN资格；不要把“账户在用AWS”当该项资格。'}))
row(373,'SOURCE_ISSUE',[], '每天读近30日、全年另读四次不等于一个固定的成本排序。四次读取可集中，IT仍使用即时层；即使都≥128KB，逐对象监控费与数据取回费也可因对象大小反转A/D总费。', ['GSC-025','GSC-024','CUR:CMP-M01'], ['A有效：即时自动层保留一年可读，Lifecycle再转真正Deep Archive；是否最便宜须算监控和访问。','IT的Deep Archive Access tier不是把对象storage class改为Glacier Deep Archive；若配置异步层在一年内还会影响最小等待。','初始即IA会对前30天每日读数据收取取回费用。','D有效：前30天Standard，再IA一年后Deep Archive；与A的总价不能只凭“已知冷热”作万能断言。'], ['IT_90','IT_128'],costissue('对象大小和全年四次训练的实际时点','Q373',{'sizeAndTrainingSchedule':'仅补对象大小及四次读取的实际时点/总取回量，并按同一规模计算完整费用；保留一年最小等待与一年后归档。'},['每天生成60亿128KiB对象，全年2.19万亿；每天读近30天，每年第90、91、92、360天另读前12个月所有数据；滚动稳态，不启用异步IT层。','相同每天生成量、滚动读取时点与时效，每个对象2MiB；每年四次并不要求平均按季度分布，原文没有排除此训练安排。']))
row(383,'SUPPORTED',[1], '按socket/core许可需主机可见性与控制；Dedicated Host而非Dedicated Instance提供这一层。容量及使用可预测时采用匹配的Host Reservation折扣。无需把正常授权匹配审查变成另一个未知AWS能力。', ['GSC-149','VC-007'], ['提供专属物理主机控制并有适用预留折扣。','有正确的主机层能力，但在题述可预测使用下没有预留折扣。','Dedicated Instance不自动提供同等socket/core主机控制。','同C，还没有预留折扣。'], ['HOST_RESERVATION','HOST_CORE_LICENSES'],normal='按题面已有软件授权及可预测容量选择匹配Host预留。具体厂商条款和资源尺寸仍在实施时匹配，不据此推翻该主判断。')
row(424,'SOURCE_ISSUE',[], '后台只运行很短时间、数量波动，并不证明可被Spot中断。可中断的EC2任务与不能中断且适合容器的任务，会分别导向B和A。', ['GSC-146','CUR:CB02','CUR:XB019'], ['前台预留合理；适合容器且不能承受中断的后台可用Fargate。','后台若可安全重试/恢复，可用Spot节省费用；短任务不等于已满足。','把长期前台交给可回收容量、把波动后台绑预留，与两层条件相反。','前台也使用可回收Spot，且原文没给其容错余量。'], ['FARGATE_SPOT_WARNING','EC2_RI'],missing('后台的中断可接受性及容器/宿主控制需求',[{'condition':'后台是已有幂等检查点的短批任务，任意实例丢失后可安全重做，前台是稳定基线。','outcome':'B的EC2预留前台+Spot后台成立，利用可中断折扣。'},{'condition':'后台处理不能丢失/重放且正在执行时不能被强制停掉，已经能放入受支持容器，不需内核控制。','outcome':'B不能保证该任务约束；A的稳定Fargate后台可以采用，前台仍预留。'}],{'interruptionAndRuntime':'仅补后台是否可中断/恢复，以及Fargate运行条件；不要从“短时间”自行推断。'},'AWS明确Spot任务需具备中断容忍，Fargate/EC2的宿主控制职责也不同。'))
row(485,'SOURCE_ISSUE',[], '对象均在Expedited通常1–5分钟适用大小内时，取回请求频度和保障容量费用仍可令A或D更便宜；“rarely”不是完整费用输入。未要求多AZ，不能凭审查者偏好排除One Zone-IA。', ['VC-006','CUR:CMP-M01','GSC-024'], ['受适用对象大小及取回容量约束，保留多年且请求极少时可更省。','Standard取回需数小时，不能满足五分钟访问目标。','即时访问可满足时间，但单AZ被允许时存储单价高于D。','即时One Zone-IA可满足访问条件；其费用与A还要合计取回、请求和预置容量。'], ['GLACIER_EXPEDITED','GLACIER_CAPACITY'],costissue('每年实际恢复请求数量、对象大小及取回容量配置','Q485',{'retrievalProfile':'仅补对象大小、请求频度/并发和是否允许单AZ；用相同价格与等待目标核总费。'},['一百万100MiB档案，每年恢复5万次，均匀且不超过单预置容量单元支持的请求率；允许单AZ，12个月留存。','同一档案与五分钟目标，每年每个档案恢复一次（对每个文件仍属少量）；四单元覆盖均匀请求，其他条件相同。']))
row(490,'SOURCE_ISSUE',[], 'PITR连续备份、时间段导出和持续变化归档是不同产物。B原生导出不消耗RCU，但不是客户S3桶的逐条实时镜像；题面未给S3恢复点/新鲜度，不能把它们合并为同一保证。', ['GSC-043','GSC-042','CUR:NB04'], ['Hive通常要额外处理表数据/任务，不是原生免代码恢复点导出。','PITR作为导出来源是正确能力；原生导出任务异步，单靠启用PITR不会持续更新客户桶。','Streams/Lambda可建立变化归档，但需要维护消费与恢复语义；不能把流开启等同已有完整备份。','定期Lambda可自动提交PITR导出，提供周期S3恢复点，仍不是逐条连续镜像。'], ['DDB_EXPORT','DDB_PITR_FOR_EXPORT','DDB_PITR','DDB_EXPORT_INTERVAL','DDB_STREAMS'],missing('客户S3桶需要的恢复点类型与最大允许滞后',[{'condition':'要求DynamoDB按秒PITR持续保护，并把时间点/时间段恢复数据定期导出S3；例如一天一次S3恢复点，允许该导出窗口。','outcome':'原生PITR+Export的B路径可成立，需周期自动提交时D可实现；不需要自己逐条消费表变化，且不消耗表RCU。'},{'condition':'客户S3必须按持续到达的每项业务修改保留增量日志，用于接近实时重放；已有初始一致基线，不接受周期快照替代变化日志。','outcome':'B/D的异步定期导出不是所需持续日志；应评估C的Streams消费与归档，读流不等于扫描在线表。'}],{'bucketRecoveryRequirement':'仅明确S3桶要求的恢复点/变化日志及容许滞后；不要把“continuous”偷偷改为实时镜像或把周期导出冒称实时。'},'官方明确PITR连续保护、export异步且不消耗RCU、增量export时段最短15分钟；Streams捕获项目变化。'))
row(493,'SOURCE_ISSUE',[], 'D→E→F是支持语言范围内的正确服务顺序，但D/E写“any language”超出官方完整支持集合，四种语言只给了English并承诺未来扩展，不能保证全部覆盖。', ['CUR:CMP-M15','GSC-106','GSC-105'], ['Comprehend不是把音频翻成英文的转录服务。','Lex提供会话交互，不是此处文字情感分析服务。','Polly把文字变语音，方向相反。','Transcribe转录正确，但不能保证任意语言。','Translate把文字变英文正确，但不覆盖任意语言。','英文文字的情感分析用Comprehend，需匹配支持能力。'], ['TRANSCRIBE_LANGUAGES','TRANSLATE_LANGUAGES'],missing('当前及未来客户服务语言是否在每个环节的官方支持集合',[{'condition':'四种录音为受支持的英语、西班牙语、法语、德语，新增语言也在相应转录和翻译支持集合。','outcome':'D/E/F按转录→译为英文→情感分析组成有效托管流程。'},{'condition':'四种包含English及Fijian等实际未列入当前Amazon Translate支持表的语言，或未来新增此类语言。','outcome':'E的“任意语言”保证不成立，不能用该三步原样覆盖全部录音；需要受支持替代路径或限定练习语言。'}],{'supportedLanguages':'把D/E的any language限定为给定且当前受支持的具体语言；保留未来语言须逐一核验，不承诺服务不存在的无限支持。'},'完整官方语言表是能力白名单；本次本地核对Fijian及代码fj均不在Translate表中，不是仅搜索没找到。'))
row(515,'INSUFFICIENT_CARDS',[], 'A的Data API可由当前卡定位。当前卡仍未明确教会本题B的Redshift通用客户端/服务端加密与已退出COPY/UNLOAD旧CSE集成的边界，或F的快照恢复副本与持续read replica差别，不能仅凭旧答案凑三项。', ['GSC-102','CUR:XB013','GSC-101'], ['Data API是当前受支持的访问接口。','官方通用安全文档仍说明客户端/服务端加密；不能把COPY/UNLOAD特定旧CSE停止误称为所有客户端密文都禁止。','按计划安排分析及支持的暂停/恢复是可行用途。','缓存数据库压力是另一类内存/缓存职责，不是Redshift的主要查询接口。','MPP分析与全球毫秒级海量在线请求不是同一需求。','官方可从snapshot在console恢复一个独立新cluster，但不等于自动同步的read replica；原词replica应精确解释。'], ['RED_SHIFT_ENCRYPTION','REDSHIFT_COPY_RETIREMENT','REDSHIFT_PAUSE','REDSHIFT_RESTORE','REDSHIFT_API'],gaps=['学习者可见卡没有教出B当前具体加密范围及F复本语义；当前判题不能用审查者刚查到的官方事实补缺。'],normal='不把COPY/UNLOAD旧CSE全面停止放大成全部客户端加密不可能，也不把普通snapshot恢复成新cluster篡写为持续复制。原题可用具体含义明确后回测，当前不报SOURCE_ISSUE或三项充分。')
row(687,'SOURCE_ISSUE',[], '既有Forecast客户可用专用预测器路径；普通新客户不能开通。SageMaker也有托管自动建模能力，所以“没有ML经验”不能无条件把A+B排除；原题缺资格且没有写明排除支持的托管AutoML。', ['GSC-109','CUR:XB012','CUR:CMP-M06'], ['训练后部署托管推理端点可以与B组成SageMaker路径。','SageMaker/Autopilot能从S3训练适用模型，不能仅凭服务名断言必须人工维护所有模型。','额外Lambda入口可包装端点，但没有替代先行训练和部署。','合格Forecast客户可通过适用API生成/查询预测并由Lambda入口承载调用；不是任意同步实时预测器端点。','合格Forecast客户的专用托管训练步骤，新客户不可开通。'], ['FORECAST_QUALIFICATION','FORECAST_MANAGED','AUTOPILOT'],qualification('Amazon Forecast','D+E的专用时序预测路径可用；在允许Autopilot等托管建模时A+B也可用，不能无依据唯一排除。','D/E不能开通；可评估A+B的受支持SageMaker托管AutoML路径。',{'qualificationAndValidPairs':'补Forecast实际资格；在未要求专用Forecast路径时可改为选择所有有效的训练/推理组合，保留无需人工维护ML模型的目标。'}))
row(693,'SOURCE_ISSUE',[], '跨AZ的D方向正确，但“embedded NoSQL”不是一个DMS源类型。已支持MongoDB与应用内未受支持的嵌入式存储，会改变D是否实际能迁移。', ['CUR:CB03','CUR:XB013','GSC-037','GSC-060'], ['改NLB不修单AZ故障域，仍保留自管嵌入库。','托管数据库方向也没有修单AZ计算层。','跨AZ计算加现有库原生复制可作为保留该库时的方案，但仍需自管。','源类型和映射受支持时，跨AZ计算加DynamoDB减少数据库维护；不能对任意内嵌NoSQL直接假定DMS支持。'], ['DMS_SOURCES','DMS_MONGODB'],missing('实际嵌入/随应用部署NoSQL数据库的引擎、版本与迁移映射',[{'condition':'应用本地部署的NoSQL为DMS源白名单中的受支持MongoDB版本，已有可转换到DynamoDB的记录与访问模型。','outcome':'D的受管迁移及跨三AZ计算可以采用。'},{'condition':'应用内是LevelDB类键值库，由应用自带复制组件保存/同步文件；没有DMS该原生源端点，也没有已建出的S3/其他受支持中间源。','outcome':'D不能按原文直接建立DMS源连接；C保留现有复制方式或另行迁移适配应评估，不能声称D已完成最少维护迁移。'}],{'sourceEngine':'仅补实际引擎/版本以及已确认DMS源和目标访问模型适配；不要把任意NoSQL都改写成MongoDB。'},'DMS官方列的是特定源引擎列表，MongoDB在其中；LevelDB不在该完整源列表，新增自定义导出是另一条未写出的迁移工序。'))
row(786,'SOURCE_ISSUE',[], 'B的现有ADS发现项目可采配置、利用率与依赖；新客户的ADS及Migration Hub入口均已关闭，当前应评估Transform。不能永久笼统等待资格，也不能把旧项目当全面停服。', ['GSC-066'], ['Systems Manager可采管理清单/执行命令，但未给使用量与依赖的专用发现方案；且仍依赖Migration Hub资格。','对既有合格ADS/Migration Hub项目，是专用发现路径。','SCT与Trusted Advisor不是机房任意服务器的配置/使用数据发现组合。','SCT/DMS负责数据库转换与迁移，不是一般服务器利用率与依赖发现。'], ['ADS_QUALIFICATION','ADS_NEW_CLIENTS','MIGRATION_HUB_NEW'],qualification('Application Discovery Service及Migration Hub','公司正在受支持的既有发现项目内，B可接续采集所需数据。','未有两个入口资格的新客户不能按B（或依赖新Hub的A）开通；须给当前Transform等选项。',{'qualification':'仅补明既有Discovery/Migration Hub项目的有效使用资格；新项目练习另列当前入口。'}))
row(851,'SOURCE_ISSUE',[], 'C泛称Serverless默认值，不能自动得到零ACU暂停或已实施的容量上限。即使采用文档化0.5ACU默认下限，开发者数量和停启方式也能使B或C总费更低。', ['CUR:XA020','CUR:XB027','GSC-057'], ['可停启但未集中限制可选规格，也未说明全球工作时间。','Catalog可限制规格并按需开通；不因未写Serverless就永远比共享集群贵。','Serverless并非默认就暂停到零；实际模板/引擎/容量设置与并发开发者数决定费用。','先识别闲置再终止不等于提供有限规格且可用的数据开发环境，还涉及恢复数据。'], ['CDK_DEFAULT_MIN','AURORA_SET_ZERO','AURORA_STOP_COST'],costissue('实际默认容量/引擎、开发者数量与开发库停启生命周期','Q851',{'frozenProductInputs':'仅补产品的实际容量范围与暂停行为、开发者/并发量及保留/停启方式；不能用“默认”替代未冻结的成本行为。'},['两个低量开发者，各用8小时；Catalog限制到db.t3.medium，工作后停用计算并保留十GB存储。共享Serverless采用文档化0.5ACU下限、未启用零暂停。','十个同样低量开发者，总负荷仍适合0.5ACU共享集群；相同8小时/人、容量和存储规则。']))
row(926,'SUPPORTED',[4], 'D是当前已明确支持ECS Fargate的Compute Optimizer托管规格建议。高可用客户Web并未声明突发部分可中断，不能仅凭短峰把Spot当作必选最省方案。', ['GSC-151','GSC-146','GSC-137'], ['负载测试可有用，但CloudWatch提供指标，不是取代托管规格建议的自动优化引擎。','若突发任务可中断可另评估Spot；原文客户Web/HA没有给这种容忍。','关键基线放可回收Spot不符合已教的稳定基线选择。','受支持Fargate服务的CPU/内存建议可优化规格并保留稳定Fargate容量。'], ['FARGATE_OPTIMIZER','FARGATE_SPOT','FARGATE_SPOT_WARNING'],normal='需要足够监控数据才产生建议是正常接入条件；不要求以未做负载实测为由增加新知识卡，也不把建议当已经实测达到SLA。')
row(930,'SUPPORTED',[3], 'C保留EC2程序执行模型及原门户接口，最少改造；Savings Plan按适用稳定基线承诺。A/D把既有功能改为Lambda/API/静态前端，并不自动满足不改代码。100%是业务持续服务目标，不能据此声称AWS合同保证绝无故障。', ['CUR:CB02','CUR:CB03','GSC-146','CUR:CA16','GSC-133'], ['Lambda需要适配执行入口与运行模型，不能把未知既有程序当已可无代码迁成函数。','前台可回收Spot不适合该持续客户入口；短程序也未声明可中断。','沿现有EC2执行模型与伸缩组部署，按稳定的已知计算需求购买匹配Savings Plan，最少应用实现改动。','把现有动态门户改成S3/API/Lambda是更大的接口与执行方式改造。'], ['EC2_RI','LAMBDA_API_ENDPOINT'],normal='ASG跨AZ、健康检查及部署授权是普通架构配置。此判题只证明在选项中C最少实现改动，不宣称任何选项已量测或合同保证100%生产正常运行。')
row(940,'SOURCE_ISSUE',[], 'D在确有三年稳定用量且能预付时通常有最深折扣；“long-running”没有给三年使用期限。实际只运行一年与运行三年，即使是同样数据库和实例，也会反转C/D整个承诺费用。', ['GSC-054','CUR:CB02','VC-007'], ['RDS按需未利用长期适用预留折扣，Compute SP也不是数据库折扣。','一年无预付是一个承诺选择，单价通常不如匹配的更多预付。','一年部分预付可避免为未使用的第三年买单。','三年全预付承担完整三年费用，不能只比较低有效小时价而丢掉期限。'], ['RDS_RI','EC2_RI','EC2_T3_RATES'],costissue('计划稳定利用期限，而非单纯单次作业运行很久','Q940',{'duration':'仅补预期可持续三年稳定利用且接受对应付款约束，或给真实一年/三年总承诺成本比较。'},['同一批100个db.r5.large PostgreSQL和两个微型EC2应用，连续运行一年后该业务按确定计划结束；一年也属于long-running。','相同规格和低波动用量，已确定连续使用三年，其他费用与需求一致。']))
row(956,'SOURCE_ISSUE',[], 'Spot被“cannot be disrupted”排除，但D与B的最低费仍取决于首30天实际读了多少字节。GIR的90天最低计费不禁止30天后转Deep Archive；已计入剩余60天费用，少量Range读仍可使B更省。', ['GSC-146','CUR:CMP-M01','GSC-024'], ['Spot可回收，与不能中断冲突。','即时读取有效，但要计GIR90天最低计费及读取字节费用，不可只称其必定错误。','仍使用Spot，和不可中断任务冲突。','Standard支持活跃读取，30天后归档/两年删除是有效方案；总费与B要按真实首月读量比较。'], ['TRANSITION_GIR_TO_GDA','EARLY_TRANSITION_BILLING'],costissue('首30天实际读取的字节比例/次数','Q956',{'readVolume':'仅补首30天读写请求及实际取回字节量；若意图D可明确每天需要读取整个生成数据集，保留非中断与两年保留条件。'},['每个输出1GiB，连续30天每天完整读一次；On-Demand计算相同，之后归档到两年。','每个输出仍1GiB，连续30天每天只读取64KiB头部/索引，正文留作两年存档；数据确实被访问，但取回字节远少于全量。']))
row(969,'SOURCE_ISSUE',[], '已有App2Container资格且ASP.NET/Linux在支持范围时A可封装并交Fargate托管运行；新客户不能开通该工具。App Runner是运行服务，不是替代容器化工具后再部署到ECS/EKS。', ['GCL-032','CUR:XB019','GSC-137'], ['合格客户可用A2C工件部署ECS/Fargate，减少主机维护。','同样依赖A2C资格，EC2又保留主机管理职责。','App Runner运行源/镜像服务，不是把应用容器化后发布ECS的工具。','同C，且EKS/EC2增加维护而非最少运维。'], ['A2C_QUALIFICATION','A2C_LINUX','A2C_CONTAINER'],qualification('App2Container','既有有效资格、受支持ASP.NET/Linux程序可用A包装并交Fargate承载。','普通新客户不能按A/B开通A2C；C/D也没有变成有效等价容器化路径，须给当前工具选项。',{'qualification':'仅补A2C既有有效资格与适用环境；新客户练习另写当前可用的容器化入口，不把App Runner误当打包工具。'}))
row(998,'SOURCE_ISSUE',[], '官方明确gateway endpoint仍使用服务public endpoint。A能避免IGW/NAT/互联网承载，却不能被改写成S3公有endpoint/地址完全不使用；原文没有把这两个不同安全目标分清。', ['CUR:CMP-M02','CUR:CMP-M04'], ['私有路由可绕过互联网，但仍按S3公有endpoint/地址访问；不满足严格禁公有endpoint的字面条件。','S3桶不能搬进VPC成为私有IP资源。','S3 access point提供访问策略入口，不自动建立PrivateLink私有网卡路径。','Direct Connect不是在VPC与S3之间按此方式建立的服务端点，且不自动让S3目的endpoint变私有地址。'], ['GATEWAY_STILL_PUBLIC','INTERFACE_PRIVATE_IP'],missing('禁止的是互联网承载，还是S3公有endpoint/公有目的地址本身',[{'condition':'安全要求只是S3流量不得经过IGW/NAT/公共互联网，但允许使用S3公有DNS及其服务地址。','outcome':'A的gateway endpoint满足该网络路径要求；原文public endpoint必须最小澄清为public internet。'},{'condition':'审计明确禁止调用S3公有endpoint/目标IP，须让调用解析到VPC内的私有接口地址。','outcome':'A仍使用public endpoint，不能满足；需要未列出的S3 interface endpoint方案，不能把它暗加到A。'}],{'networkRequirement':'若意图A，仅把要求改为不经过public internet/IGW/NAT；若真禁公有endpoint，保留要求并提供interface endpoint选项。'},'两种控制目标在官方架构上不同：gateway仍public endpoint，interface使用VPC私有IP。不是拿未做生产测量制造问题。'))
# Independently adjudicate the source even where visible cards also have teaching gaps.
q515=next(r for r in rows if r['qid']==515)
q515['status']='SOURCE_ISSUE'
q515['officialEvidenceRefs'].append('REDSHIFT_SERVER_ENCRYPTION')
q515['summary']='A Data API、B通用客户端/服务端加密、C安排分析时段有当前官方正证。F按原文未排除的“控制台从快照建立独立副本”理解也有正证，至少四项合理能力与Choose three冲突。若F想指持续同步read replica，须明写。B/F可见卡教学缺口另记，不阻止独立确认题源问题。'
q515['sourceIssue']={
 'confirmed':True,
 'subtype':'at_least_four_valid_capability_readings_for_choose_three',
 'originalAnchor':'Which use cases are suitable for Amazon Redshift in this scenario? (Choose three.) / Creating a secondary replica of the cluster by using the AWS Management Console',
 'positiveTechnicalBasis':'官方分别确认Data API运行SQL、通用客户端/服务端加密、可安排暂停/恢复的分析用途、从snapshot在控制台恢复独立新cluster。原文未把replica限定为持续自动同步，F的独立时间点副本读法与A/B/C共同形成至少四项合理能力。',
 'replicaMeaningScenarios':[
  {'meaning':'secondary replica表示从snapshot通过console建立独立时间点cluster副本，不要求后续自动同步。','consequence':'F有官方正证，A/B/C/F至少四项合理，Choose three不能表达全部有效能力。'},
  {'meaning':'作者想表达独立、持续自动同步的read replica，而不是snapshot时间点副本。','consequence':'snapshot恢复只证明独立新cluster，不能证明持续复制；此不同限定没有写在原题，不能由Reviewer暗加来强行排F。'}
 ],
 'minimalCorrectionFields':{
  'replicaMeaning':'明确F是否指从snapshot建立独立时间点cluster副本，避免混为持续同步能力。',
  'selectionCount':'采用有官方正证的独立副本语义时，改为选择全部有效项A/B/C/F；若坚持三项，须明确F要求持续自动同步，并另核该具体声明。'
 },
 'newValuesAreExerciseInputsNotRecoveredOriginalFacts':True
}
q515['knownVisibleCardGaps']=['可见卡未明确教出B当前具体加密范围及F复本语义；教学缺口与已确认的源选项计数/复制语义问题分别记录。']
q515['normalImplementationScope']='不把COPY/UNLOAD旧CSE停止放大成全部客户端加密不可能，不把snapshot恢复成新cluster冒称持续复制。官方事实的独立题源判断与可见卡的支撑能力分别记录。'
q515['visibleCardGroupStatus']='INSUFFICIENT_CARDS'
q778=next(r for r in rows if r['qid']==778)
q778['sourceIssue']['counterfactualScenarios'][0]['condition']=q778['sourceIssue']['counterfactualScenarios'][0]['condition'].replace('合计实际可用容量≥1000TB','每个办公室已安排至少1PB实际可用设备容量，80处合计至少80PB')
q778['sourceIssue']['counterfactualScenarios'][0]['outcome']='80处均有现行Snowball使用资格，每处设备可用容量覆盖1PB，所有准备、运输和导入作业已订在28天内，选项B可行。'
q258=next(r for r in rows if r['qid']==258)
q258['officialEvidenceRefs'].append('GLUE_SERVERLESS')
q258['explicitCurrentIncrementalRuleIds']=['GSC-095']
for case in next(r for r in rows if r['qid']==851)['sourceIssue']['counterfactualScenarios']:
 case['condition']=case['condition'].replace('8','6')
q998=next(r for r in rows if r['qid']==998)
q998['sourceIssue']={
 'confirmed':True,
 'subtype':'no_valid_listed_option_for_literal_public_endpoint_prohibition',
 'originalAnchor':'ensure that traffic to Amazon S3 does not use the public endpoint',
 'positiveTechnicalBasis':'官方明确gateway endpoint访问S3仍使用服务public endpoint，interface endpoint则使用VPC私有IP。A避免公共互联网承载，但不满足原文明示禁止public endpoint的字面条件；B/C/D也不提供所需S3私有接口地址。',
 'scopeDistinction':'public internet与public endpoint是不同控制目标。只禁Internet的解释会改变原文明示条件，故仅列作最小纠错方向，不作为满足原文的反例。',
 'minimalCorrectionFields':{'networkRequirement':'若意图A，仅把要求改为不经过public internet/IGW/NAT；若真禁public endpoint，保留原要求并提供S3 interface endpoint选项。'},
 'newValuesAreExerciseInputsNotRecoveredOriginalFacts':True
}
q998['summary']='原文明示不得使用S3 public endpoint，但官方确认gateway endpoint仍访问服务public endpoint。A能避免IGW/NAT/公共互联网，不能满足该字面要求；B/C/D也无所需私有接口路径。应改为禁public internet，或保留原约束并提供interface endpoint选项。'
# Bind and explicitly separate candidate choices from support. Sort to frozen question order, retaining duplicate printed labels by ordinal.
by={r['qid']:r for r in rows};assert set(by)==set(qs)and len(rows)==28;rows=[by[q['qid']]for q in qq]
for r in rows:
 r['candidateChoiceMeaning']='Accepted original choice only for SUPPORTED; all other selected entries are withheld, not counted as solved.'
 r['cardGroupSupportAccepted']=r['status']=='SUPPORTED'
 if r['status']=='SOURCE_ISSUE':assert r['sourceIssue'] and r['sourceIssue']['confirmed']
 if r['sourceIssue']and r['sourceIssue'].get('subtype')=='decisive_input_missing':assert len(r['sourceIssue']['counterfactualScenarios'])>=2
out={'schema':'independent-residual-conditions28-current-review-v1','reviewer':'/root/domain_primary_audit','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETE_WITH_CONFIRMED_SOURCE_ISSUES_AND_ONE_CARD_GAP','scope':'28 frozen complete originals and 362 current visible Chinese candidate bodies','inputManifest':{'path':str((P/'manifest.json').resolve()),'sha256':sha(P/'manifest.json'),'allBindingsVerified':True},'ruleBindings':{k:{'path':str((V/k).resolve()),'sha256':sha(V/k)}for k in ['rules.md','inputs/teaching-standard.md','inputs/source-ambiguity-rule-clarification-20261107.md','inputs/user-knowledge-scope-accepted.json','inputs/user-source-correction-policy-accepted.json']},'officialSources':sources,'costCounterexampleBinding':pricebind,'results':rows,'counts':dict(collections.Counter(r['status']for r in rows)),'independence':{'externalModelCliApiCalls':0,'nativeUsage':'unknown','newAuthorsSpawned':0,'productionMainRunAndOriginalQuestionsModified':False,'priorResidualUnusedSnapshotsNotAdopted':True},'limits':['362 is the frozen candidate pool, not final N.','Source issues are not exemptions or original SUPPORTED; any corrected exercise must be separately frozen and independently retested.','No learner memory, measured accuracy or production SLA is claimed.','All hypothetical case inputs are clearly labeled counterexamples, never recovered hidden original values.']}
out['explicitCurrentIncrementalDependencies']=incremental
(R/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('WROTE',out['counts'])

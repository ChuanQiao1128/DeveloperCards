import concurrent.futures,datetime,hashlib,html,json,re,subprocess
from pathlib import Path
root=Path.cwd();out=root/'review/residual-conditions02-current01/evidence';cat=json.loads((root/'review/final-core-closure01/input/official-snapshot-catalogue.json').read_text());known={x['url']:x for x in cat}
urls={
'fsx-client-eligibility':'https://docs.aws.amazon.com/fsx/latest/WindowsGuide/supported-fsx-clients.html',
'fsx-gateway-what':'https://docs.aws.amazon.com/filegateway/latest/filefsxw/what-is-file-fsx.html',
'app2container-what':'https://docs.aws.amazon.com/app2container/latest/UserGuide/what-is-a2c.html',
'ads-availability':'https://docs.aws.amazon.com/application-discovery/latest/userguide/application-discovery-service-availability-change.html',
'migrationhub-eligibility':'https://docs.aws.amazon.com/migrationhub-home-region/latest/APIReference/API_GetHomeRegion.html',
'full-shutdown':'https://docs.aws.amazon.com/general/latest/gr/elastictranscoder.html',
'host-billing':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/dedicated-hosts-billing.html',
'host-overview':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/dedicated-hosts-overview.html',
's3-intelligent':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/intelligent-tiering-overview.html',
's3-gateway-public':'https://docs.aws.amazon.com/vpc/latest/privatelink/gateway-endpoints.html',
's3-interface-private':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/privatelink-interface-endpoints.html',
'vpn-limits':'https://docs.aws.amazon.com/vpn/latest/s2svpn/vpn-limits.html',
'forecast-query':'https://docs.aws.amazon.com/forecast/latest/dg/API_QueryForecast.html',
'backup-lifecycle':'https://docs.aws.amazon.com/aws-backup/latest/devguide/API_Lifecycle.html',
'cloudwatch-retention':'https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutRetentionPolicy.html',
'aurora-audit':'https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/USER_LogAccess.Concepts.PostgreSQL.html',
'lambda-api-proxy':'https://docs.aws.amazon.com/lambda/latest/dg/services-apigateway.html',
'lambda-nochange':'https://docs.aws.amazon.com/lambda/latest/dg/gettingstarted-package.html',
'cf-rds-capacity':'https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-properties-rds-dbcluster-serverlessv2scalingconfiguration.html'
}
def fetch(item):
 k,u=item;p=out/(k+'.json')
 if p.exists():return k,'existing'
 if u in known:
  z=known[u];p.write_bytes(Path(z['snapshotPath']).read_bytes());return k,'reused'
 rawp=out/(k+'.html')
 try:
  r=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','30','--output',str(rawp),'--write-out','%{url_effective}\n%{http_code}',u],capture_output=True,check=True)
  final,status=r.stdout.decode().splitlines();raw=rawp.read_bytes();s=raw.decode('utf-8');s=re.sub(r'<(script|style)\b.*?</\1\s*>','',s,flags=re.I|re.S);s=html.unescape(re.sub(r'<[^>]+>',' ',s));s=re.sub(r'\s+',' ',s).strip()
  p.write_text(json.dumps({'url':u,'finalUrl':final,'httpStatus':int(status),'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':s,'textSha256':hashlib.sha256(s.encode()).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest()},ensure_ascii=False,indent=2)+'\n');return k,len(s)
 except Exception as e:return k,str(e)
for r in concurrent.futures.ThreadPoolExecutor(5).map(fetch,urls.items()):print(json.dumps(r),flush=True)

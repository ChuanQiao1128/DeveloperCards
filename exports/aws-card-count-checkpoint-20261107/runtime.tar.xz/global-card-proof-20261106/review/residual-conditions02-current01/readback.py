# -*- coding: utf-8 -*-
import collections, datetime, hashlib, json
from pathlib import Path
from urllib.parse import urlparse

V=Path.cwd(); R=V/'review/residual-conditions02-current01'; P=R/'input'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
bodyhash=lambda x:hashlib.sha256(canon(x).encode()).hexdigest()
o=json.loads((R/'results.json').read_text()); rr=o['results']
qs={x['qid']:x['question'] for x in json.loads((P/'questions.json').read_text())}
frozen={x['ruleId']:x for x in json.loads((P/'visible-pool.frozen.json').read_text())}
cards=frozen.copy(); m=json.loads((P/'manifest.json').read_text())
refs=o['officialSources']; costbind=o['costCounterexampleBinding']
costs=json.loads(Path(costbind['path']).read_text())

incremental_checks=[]
for d in o['explicitCurrentIncrementalDependencies']:
    proof=json.loads(Path(d['proofPath']).read_text())
    receipt=json.loads(Path(d['readbackPath']).read_text())
    proofcard=next(x for x in proof['results'] if x['ruleId']==d['ruleId'])
    incremental_checks.append(
        sha(d['proofPath'])==d['proofSha256'] and sha(d['readbackPath'])==d['readbackSha256']
        and receipt['reviewSha256']==d['proofSha256'] and receipt['status'].startswith('PASS')
        and proofcard['status']=='PASS' and proofcard['bodySha256']==d['currentBodySha256']
        and proofcard['visibleBody']==d['visibleBody'] and bodyhash(d['visibleBody'])==d['currentBodySha256']
        and frozen[d['ruleId']]['bodySha256']==d['frozenBodySha256'])
    cards[d['ruleId']]={**frozen[d['ruleId']], 'visibleBody':d['visibleBody'],
                       'bodySha256':d['currentBodySha256'], 'prerequisiteRuleIds':proofcard['prerequisiteRuleIds']}

def prerequisites(ids):
    seen=set(ids); stack=list(ids)
    while stack:
        for dep in cards[stack.pop()].get('prerequisiteRuleIds',[]):
            if dep not in seen: seen.add(dep); stack.append(dep)
    return seen-set(ids)

price_raw=[json.loads(Path(x['path']).read_text()) for x in costs['rawPriceBindings']]
price_dimensions={}
for raw in price_raw:
    for termtype, skus in raw['terms'].items():
        for sku, terms in skus.items():
            for term in terms.values():
                for ratecode, dimension in term['priceDimensions'].items():
                    price_dimensions[(sku,ratecode)]=(raw['products'][sku]['attributes'],term.get('termAttributes',{}),dimension)

def rate_signature(key):
    return sorted((float(x['dimension']['beginRange']),x['dimension']['endRange'],
                   float(x['dimension']['pricePerUnit']['USD'])) for x in costs['priceFacts'][key])

checks={
 'allFrozenInputHashesUnchanged':all(sha(p)==h for p,h in m.items()),
 'resultsManifestBindingExact':o['inputManifest']['sha256']==sha(P/'manifest.json'),
 'all28QidsExactlyFrozen':set(qs)=={r['qid'] for r in rr} and len(rr)==28,
 'questionIdsUnique':len({r['qid'] for r in rr})==28,
 'fullOriginalQuestionHashesExact':all(r['questionSha256']==bodyhash(qs[r['qid']]) for r in rr),
 'allOptionOrdinalsAndPrintedLabelsExact':all(
     [(x['ordinal'],x['originalLabel']) for x in r['optionJudgments']]
     ==[(x['ordinal'],x['originalLabel']) for x in qs[r['qid']]['options']] for r in rr),
 'allOptionJudgmentsNonempty':all(x['judgment'] for r in rr for x in r['optionJudgments']),
 'all362FrozenBodyHashesExact':len(frozen)==362 and all(bodyhash(c['visibleBody'])==c['bodySha256'] for c in frozen.values()),
 'usedRuleIdsExactlyMatchCardEvidence':all(r['usedRuleIds']==[p['ruleId'] for p in r['necessaryCardEvidence']] for r in rr),
 'allEffectiveCardBodyHashesExact':all(p['bodySha256']==cards[p['ruleId']]['bodySha256'] for r in rr for p in r['necessaryCardEvidence']),
 'allCardQuotesActuallyVisible':all(x['quote']==cards[p['ruleId']]['visibleBody'][x['field']] for r in rr for p in r['necessaryCardEvidence'] for x in p['visibleQuotes']),
 'recursivePrerequisiteClosureExact':all({p['ruleId'] for p in r['recursivePrerequisiteBindings']}==prerequisites(r['usedRuleIds']) for r in rr),
 'recursivePrerequisiteBodyHashesExact':all(p['bodySha256']==cards[p['ruleId']]['bodySha256'] for r in rr for p in r['recursivePrerequisiteBindings']),
 'acceptedIncrementalCurrentProofBound':bool(incremental_checks) and all(incremental_checks),
 'q258TargetedCurrentGSC095Bound':next(r for r in rr if r['qid']==258)['explicitCurrentIncrementalRuleIds']==['GSC-095'],
 'allRuleAndPolicyBindingsExact':all(sha(b['path'])==b['sha256'] for b in o['ruleBindings'].values()),
 'allOfficialSnapshotHashesExact':all(sha(s['snapshotPath'])==s['snapshotSha256'] for s in refs.values()),
 'allOfficialTextHashesExact':all(hashlib.sha256(json.loads(Path(s['snapshotPath']).read_text())['text'].encode()).hexdigest()==s['textSha256'] for s in refs.values()),
 'allOfficialQuotesExactAtOffsets':all(json.loads(Path(s['snapshotPath']).read_text())['text'][s['quoteStart']:s['quoteEnd']]==s['quote'] for s in refs.values()),
 'allOfficialReferenceUrlsBound':all(json.loads(Path(s['snapshotPath']).read_text())['url']==s['url'] and urlparse(s['url']).hostname in {'docs.aws.amazon.com','aws.amazon.com'} for s in refs.values()),
 'allQuestionOfficialRefsResolve':all(r['officialEvidenceRefs'] and all(x in refs for x in r['officialEvidenceRefs']) for r in rr),
 'priceArtifactHashExact':sha(costbind['path'])==costbind['sha256'],
 'allOfficialPriceRawHashesExact':all(sha(s['path'])==s['sha256'] for s in costs['rawPriceBindings']),
 'allUsedPriceDimensionsExact':all(price_dimensions[(f['sku'],f['dimension']['rateCode'])]==(f['attributes'],f['termAttributes'],f['dimension']) for fs in costs['priceFacts'].values() for f in fs),
 'itFAAndIAPricesExplicitlyVerified':rate_signature('S3_FA')==rate_signature('IT_FA') and rate_signature('S3_IA')==rate_signature('IT_IA'),
 'allSixCostOrderingsReverse':all(len({x.get('lowerCost',x.get('lowerCostOriginalOption')) for x in costs[k]})==2 for k in ['Q153','Q373','Q485','Q956','Q940','Q851']),
 'q373SteadyRollingStreamAndNoncommonTransitionCostIncluded':all(x['newObjectsPerDay']*365==x['objectsPerYear'] and len(x['annualAllDataTrainingDays'])==4 and x['transitionCosts_USD']['Lifecycle']>0 for x in costs['Q373']),
 'costCasesExactlyEmbeddedAndBound':all(
     r['sourceIssue']['calculationArtifact']==costbind
     and [x['calculatedCase'] for x in r['sourceIssue']['counterfactualScenarios']]==costs['Q'+str(r['qid'])]
     for r in rr if r['sourceIssue'] and 'calculationArtifact' in r['sourceIssue']),
 'allSourceIssuesSpecificAndConfirmed':all(r['sourceIssue']['confirmed'] and r['sourceIssue']['subtype'] and r['sourceIssue']['positiveTechnicalBasis'] and r['sourceIssue']['minimalCorrectionFields'] for r in rr if r['status']=='SOURCE_ISSUE'),
 'allDecisiveMissingInputsHaveTwoExplicitCases':all(len(r['sourceIssue']['counterfactualScenarios'])>=2 and all(c['condition'] and c['outcome'] for c in r['sourceIssue']['counterfactualScenarios']) for r in rr if r['status']=='SOURCE_ISSUE' and r['sourceIssue']['subtype']=='decisive_input_missing'),
 'q515SourceAndTeachingGapsSeparated':next(r for r in rr if r['qid']==515)['status']=='SOURCE_ISSUE' and next(r for r in rr if r['qid']==515)['visibleCardGroupStatus']=='INSUFFICIENT_CARDS',
 'q998LiteralConstraintPreserved':next(r for r in rr if r['qid']==998)['sourceIssue']['subtype']=='no_valid_listed_option_for_literal_public_endpoint_prohibition',
 'onlySupportedOriginalsHaveAcceptedSelections':all(bool(r['selectedOptionOrdinals'])==bool(r['cardGroupSupportAccepted'])==(r['status']=='SUPPORTED') for r in rr),
 'allAcceptedOrdinalsBelongToOriginal':all(all(x in {p['ordinal'] for p in qs[r['qid']]['options']} for x in r['selectedOptionOrdinals']) for r in rr),
 'countsMatchRows':o['counts']==dict(collections.Counter(r['status'] for r in rr)),
 'originalsUnmodifiedByReviewer':all(not r['originalModified'] for r in rr),
}
assert all(checks.values()), {k:v for k,v in checks.items() if not v}
notes=['# 28题当前卡组与题源独立收束','',
 '5题原题卡组SUPPORTED；23题SOURCE_ISSUE。Q515另有可见卡B/F教学缺口，源问题与缺卡分别记录。没有把源问题、最小纠错建议或新增练习输入计为原题充分。',
 '', '冻结范围为28份完整原题、362个候选正文；后续仅GSC-095通过supplemental15的独立PASS凭证显式增量绑定，定向核查Q258保持D。362不是最终N。',
 '', '| 题号 | 原题状态 | 已接受选项 | 结论 |','|---|---|---|---|']
for r in rr:
    selected=','.join(str(x) for x in r['selectedOptionOrdinals']) or '—'
    notes.append(f"| Q{r['qid']} | {r['status']} | {selected} | {r['summary']} |")
notes+=['', '关键证据边界：', '',
 '- Q515：A/B/C及F独立snapshot副本读法均有官方正证，Choose three欠准确；未声称Redshift snapshot等同持续read replica。',
 '- Q998：gateway endpoint仍使用S3 public endpoint。只禁public internet是纠错后的不同约束，不能充作原文兼容情境。',
 '- Snowball、FSx File Gateway、Object Lambda、Forecast、ADS/Migration Hub和App2Container按既有/新增使用资格区分；未把新客户禁入写成全面停服。',
 '- Q153/Q373/Q485/Q851/Q940/Q956附当前官方价目与两组成本反例；Q373用每日新增、滚动近30天及固定四次全年训练，含非共同IA迁移费。',
 '- Q258不因1GB就断言Lambda超时；Q926使用当前Compute Optimizer确已支持Fargate CPU/内存建议的事实。',
 '', f"确定性回读{len(checks)}项全部PASS；完整原题哈希、选项序号、实际卡句和正文哈希、递归先修、官方原句/偏移/文件哈希、价格维度与计算绑定见results.json/readback.json。",
 '', '外部模型CLI/API调用0，native用量unknown。未修改原题、生产库存或主run；未制卡、发布或恢复自动化。没有学习者记忆、独立作答正确率或生产SLA验收。']
(R/'readback.md').write_text('\n'.join(notes)+'\n')
readback={
 'schema':'independent-residual28-current-mechanical-readback-v1','status':'PASS',
 'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/domain_primary_audit',
 'resultsFile':{'path':str((R/'results.json').resolve()),'sha256':sha(R/'results.json')},
 'checks':checks,'counts':o['counts'],
 'supportedQids':[r['qid'] for r in rr if r['status']=='SUPPORTED'],
 'sourceIssueQids':[r['qid'] for r in rr if r['status']=='SOURCE_ISSUE'],
 'knownVisibleCardGapQids':[r['qid'] for r in rr if r['knownVisibleCardGaps']],
 'explicitIncrementalRuleIds':[d['ruleId'] for d in o['explicitCurrentIncrementalDependencies']],
 'externalModelCliApiCalls':0,'nativeUsage':'unknown',
 'mainRunProductionAndOriginalsModifiedByReviewer':False,'notFinalN':True,
 'mechanicalReadbackDoesNotIndependentlyProveSemanticConclusions':True,
}
(R/'readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks),'counts':o['counts'],'supportedQids':readback['supportedQids'],'knownVisibleCardGapQids':readback['knownVisibleCardGapQids']},ensure_ascii=False,indent=2))

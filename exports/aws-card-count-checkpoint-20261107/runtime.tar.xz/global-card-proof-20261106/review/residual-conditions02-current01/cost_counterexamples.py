# -*- coding: utf-8 -*-
import json,hashlib
from pathlib import Path
R=Path.cwd()/'review/residual-conditions02-current01';P=Path.cwd()/'review/remaining-source10/evidence';G=1024**3
s3=json.loads((P/'s3-price-list-us-east-1.raw.json').read_text());rds=json.loads((P/'amazonrds-price-list-us-east-1.raw.json').read_text());gda=json.loads((P/'s3gda-price-list-us-east-1.raw.json').read_text());glacier=json.loads((P/'amazonglacier-price-list-us-east-1.raw.json').read_text());facts={}
def get(key,j,pred,unit=None,term='OnDemand',attrs=None):
 hits=[]
 for sku,z in j['products'].items():
  if pred(z['attributes']):
   for o in j['terms'][term].get(sku,{}).values():
    if attrs and any(o['termAttributes'].get(k)!=v for k,v in attrs.items()):continue
    for d in o['priceDimensions'].values():
     if unit and d['unit']!=unit:continue
     hits.append({'sku':sku,'attributes':z['attributes'],'termAttributes':o.get('termAttributes',{}),'dimension':d})
 assert hits,key;facts[key]=hits
 return float(hits[0]['dimension']['pricePerUnit']['USD'])
fa=get('S3_FA',s3,lambda a:a.get('usagetype')=='TimedStorage-ByteHrs');ia=get('S3_IA',s3,lambda a:a.get('usagetype')=='TimedStorage-SIA-ByteHrs');aia=get('IT_AIA',s3,lambda a:a.get('usagetype')=='TimedStorage-INT-AIA-ByteHrs');monitor=get('IT_MONITOR',s3,lambda a:a.get('usagetype')=='Monitoring-Automation-INT');gia=get('GIR_STORAGE',s3,lambda a:a.get('usagetype')=='TimedStorage-GIR-ByteHrs');gir_retr=get('GIR_RETR',s3,lambda a:a.get('usagetype')=='Retrieval-GIR');exp_req=get('EXP_REQUEST',s3,lambda a:a.get('usagetype')=='Requests-Tier6');exp_bytes=get('EXP_BYTES',s3,lambda a:a.get('usagetype')=='Expedited-Retrieval-Bytes');flex=get('FLEX_STORAGE',s3,lambda a:a.get('usagetype')=='TimedStorage-GlacierByteHrs');zia=get('ZIA_STORAGE',s3,lambda a:a.get('usagetype')=='TimedStorage-ZIA-ByteHrs');cap=get('PROVISIONED_RETRIEVAL',glacier,lambda a:a.get('usagetype')=='ProvisionedCapacityUnit');
itfa=get('IT_FA',s3,lambda a:a.get('usagetype')=='TimedStorage-INT-FA-ByteHrs');itia=get('IT_IA',s3,lambda a:a.get('usagetype')=='TimedStorage-INT-IA-ByteHrs')
def tier_rates(key):return sorted((float(x['dimension']['beginRange']),x['dimension']['endRange'],float(x['dimension']['pricePerUnit']['USD']))for x in facts[key])
assert tier_rates('S3_FA')==tier_rates('IT_FA')
assert ia==itia
get_standard=get('GET_STANDARD',s3,lambda a:a.get('usagetype')=='Requests-Tier2');get_it=get('GET_IT',s3,lambda a:a.get('usagetype')=='Requests-INT-Tier2');get_ia=get('GET_IA',s3,lambda a:a.get('usagetype')=='Requests-SIA-Tier2');get_gir=get('GET_GIR',s3,lambda a:a.get('usagetype')=='Requests-GIR-Tier2')
transition_ia=get('TRANSITION_IA',s3,lambda a:a.get('operation')=='S3-SIATransition');transition_it=get('TRANSITION_IT',s3,lambda a:a.get('operation')=='S3-INTTransition')
put_standard=get('PUT_STANDARD',s3,lambda a:a.get('usagetype')=='Requests-Tier1');put_it=get('PUT_IT',s3,lambda a:a.get('usagetype')=='Requests-INT-Tier1');put_gir=get('PUT_GIR',s3,lambda a:a.get('usagetype')=='Requests-GIR-Tier1');put_flex=get('PUT_FLEX',s3,lambda a:a.get('usagetype')=='Requests-GLACIER-Tier1');put_zia=get('PUT_ZIA',s3,lambda a:a.get('usagetype')=='Requests-ZIA-Tier1')
assert get_standard==get_it and put_standard==put_it and transition_ia==transition_it
# First 50TB, next 450TB, remainder: exact tiered public rate for a cohort held in Frequent/Standard.
def standard_month(gb):return min(gb,51200)*.023+max(0,min(gb-51200,460800))*.022+max(0,gb-512000)*.021

def it_vs_lifecycle(size,n,read_days,transition_day,initially_standard=False,read_fee=.01):
 gb=size/G;last=None;IT=0;LF=0;tierdays={'FA':0,'IA':0,'AIA':0}
 # Storage is charged per cohort per day; GET requests equal where possible and small extra IA GET difference is explicitly added.
 for d in range(365):
  if d in read_days:last=d
  idle=d-(last if last is not None else 0)
  tier='FA' if idle<30 else ('IA'if idle<90 else'AIA');tierdays[tier]+=1
  IT+=(standard_month(n*gb) if tier=='FA' else n*gb*(itia if tier=='IA'else aia))*12/365
  LF+=(standard_month(n*gb) if d<transition_day else n*max(gb,128*1024/G)*ia)*12/365
 IT+=n*monitor*12
 retrievals=sum(d>=transition_day for d in read_days)
 LF+=n*gb*read_fee*retrievals
 # Bind the actual Standard/IT and IA request rates; common Standard-equivalent GET bill cancels.
 LF+=n*(get_ia-get_it)*retrievals
 # Existing Standard objects pay equal transitions to IT / IA. Newly written cohorts pay a lifecycle IA transition only in LF.
 transition_it_cost=n*transition_it if initially_standard else 0
 transition_lf_cost=n*transition_ia
 IT+=transition_it_cost;LF+=transition_lf_cost
 return {'bytesPerObject':size,'objectCount':n,'readDays':sorted(read_days),'IT_USD':IT,'Lifecycle_USD':LF,'IT_tierDays':tierdays,'lowerCost':'IT' if IT<LF else'Lifecycle','transitionCosts_USD':{'IT':transition_it_cost,'Lifecycle':transition_lf_cost},'initiallyStandard':initially_standard,'commonCostsExcluded':'equal initial PUT where applicable, common GET request component and eventual common Deep Archive transition/storage; no asynchronous IT archive tiers enabled','storageProration':'365 equal daily slices of 12 monthly rates; cost witnesses have material margins, not exact monthly invoice forecasts'}
q153=[it_vs_lifecycle(z,2_000_000,set(range(90)),90,initially_standard=True)for z in [256*1024,2*1024**2]]
def rolling_iot(size):
 n=2_190_000_000_000;daily=n//365;gb=size/G;global_reads={90,91,92,360};cohorts={};IT=0.;LF=0.;tierdays={'FA':0,'IA':0,'AIA':0};ia_read_objects=0
 for d in range(-365,365):
  cohorts[d]=d
  cohorts={birth:last for birth,last in cohorts.items()if d-birth<365}
  for birth,last in list(cohorts.items()):
   if d-birth<30 or d%365 in global_reads:cohorts[birth]=d
  if d<0:continue
  tiers={'FA':0,'IA':0,'AIA':0}
  for birth,last in cohorts.items():
   idle=d-last;tier='FA'if idle<30 else('IA'if idle<90 else'AIA');tiers[tier]+=daily;tierdays[tier]+=daily
  IT+=(standard_month(tiers['FA']*gb)+tiers['IA']*gb*itia+tiers['AIA']*gb*aia)*12/365
  LF+=(standard_month(daily*30*gb)+daily*335*gb*ia)*12/365
  if d in global_reads:ia_read_objects+=daily*335
 IT+=n*monitor*12
 LF+=ia_read_objects*(gb*.01+get_ia-get_it)+n*transition_ia
 return {'bytesPerObject':size,'objectsPerYear':n,'newObjectsPerDay':daily,'dailyTraining':'read all data aged 0 through 29 days every morning','annualAllDataTrainingDays':sorted(global_reads),'window':'rolling steady state; retain instant-access classes for ages 0..364, common Deep Archive afterward','IT_USD':IT,'Lifecycle_USD':LF,'IT_objectTierDays':tierdays,'Lifecycle_IA_readObjectsPerYear':ia_read_objects,'transitionCosts_USD':{'IT':0,'Lifecycle':n*transition_ia},'lowerCost':'IT'if IT<LF else'Lifecycle','commonCostsExcluded':'equal initial PUT, common GET components, same eventual Deep Archive transition/storage; no asynchronous IT archive tiers enabled','storageProration':'365 equal daily slices of 12 monthly rates; steady state includes the previous-year cohorts before the measured year'}
q373=[rolling_iot(z)for z in [128*1024,2*1024**2]]
assert [x['lowerCost']for x in q153]==['Lifecycle','IT'];assert[x['lowerCost']for x in q373]==['Lifecycle','IT']
# Q485 compare a one-million-file archive. Both use 100MiB files (<250MB); restores are evenly spaced within provisioned capacity.
q485=[]
for reads,units in [(50_000,1),(1_000_000,4)]:
 n=1_000_000;size=100*1024**2;gb=size/G
 astore=12*n*(gb*flex+8*1024/G*.023+32*1024/G*flex)
 a=astore+n*put_flex+units*cap*12+reads*(exp_req+gb*exp_bytes+gb*.023/30+get_standard)
 d=12*n*gb*zia+n*put_zia+reads*(gb*.01+get_ia)
 q485.append({'objectCount':n,'bytesPerObject':size,'retrievalRequestsPerYear':reads,'provisionedUnits':units,'maxDemand':'evenly spaced, no more than 3 requests/5min per provisioned unit','A_USD':a,'D_USD':d,'lowerCostOriginalOption':'A'if a<d else'D','singleAZ':'allowed in both counterfactual scenarios; not silently added as a required original constraint'})
assert[x['lowerCostOriginalOption']for x in q485]==['A','D']
# Q956: 1GiB output, one GET on each of the first 30 days. Rest of 2-year DA storage/compute cost identical; include GIR early transition minimum 90 days.
q956=[]
for name,readbytes in [('whole_object_each_day',G),('64_KiB_header_each_day',64*1024)]:
 b=gia*3+30*readbytes/G*gir_retr+30*get_gir+put_gir
 d=.023+30*get_standard+put_standard
 q956.append({'case':name,'objectBytes':G,'readDays':30,'bytesReadEachDay':readbytes,'B_firstStage_USD':b,'D_firstStage_USD':d,'lowerCostOriginalOption':'B'if b<d else'D','commonCostsExcluded':'same On-Demand compute, same Deep Archive storage from day30 through 2-year expiry, identical GDA transition fee; GIR 90-day minimum is included rather than ignored'})
assert[x['lowerCostOriginalOption']for x in q956]==['D','B']
# Q940 exact RDS price difference dwarfs the maximum charge of a tiny EC2 application; does not assume any undocumented Savings Plan percentage.
pred=lambda a:a.get('databaseEngine')=='PostgreSQL' and a.get('instanceType')=='db.r5.large' and a.get('deploymentOption')=='Single-AZ' and a.get('usagetype')=='InstanceUsage:db.r5.large'
y1hr=get('RDS_ONE_YEAR_HOURLY',rds,pred,'Hrs','Reserved',{'LeaseContractLength':'1yr','PurchaseOption':'Partial Upfront'});y1fee=get('RDS_ONE_YEAR_UPFRONT',rds,pred,'Quantity','Reserved',{'LeaseContractLength':'1yr','PurchaseOption':'Partial Upfront'});y3fee=get('RDS_THREE_YEAR_UPFRONT',rds,pred,'Quantity','Reserved',{'LeaseContractLength':'3yr','PurchaseOption':'All Upfront'})
y1=y1fee+y1hr*8760
q940=[{'plannedUseYears':1,'rdsInstances':100,'rdsEngine':'PostgreSQL','rdsInstance':'db.r5.large','C_RDS_commitment_USD':100*y1,'D_RDS_commitment_USD':100*y3fee,'EC2_upperBound_USD':'2 t3.micro On-Demand at 0.0104/hr cost at most 546.624 over the complete 3-year horizon; applicable Savings Plans cannot make this enough to reverse a 117731.2 USD RDS gap','lowerCostOriginalOption':'C'}, {'plannedUseYears':3,'rdsInstances':100,'rdsEngine':'PostgreSQL','rdsInstance':'db.r5.large','C_RDS_commitment_USD':100*y1*3,'D_RDS_commitment_USD':100*y3fee,'EC2_upperBound_USD':'same bound, far smaller than RDS saving of 123206.4 USD','lowerCostOriginalOption':'D'}]
# Q851 same explicitly modeled default 0.5ACU floor; no scale-to-zero is invented. Two/ten low-volume developers reverse shared-vs-separate running cost.
acu=get('AURORA_ACU',rds,lambda a:a.get('databaseEngine')=='Aurora PostgreSQL'and a.get('usagetype')=='Aurora:ServerlessV2Usage')
inst=get('AURORA_SMALL_INSTANCE',rds,lambda a:a.get('databaseEngine')=='Aurora PostgreSQL'and a.get('instanceType')=='db.t3.medium'and a.get('deploymentOption')=='Single-AZ'and a.get('usagetype')=='InstanceUsage:db.t3.medium')
aurora_storage=get('AURORA_STORAGE',rds,lambda a:a.get('databaseEngine')=='Aurora PostgreSQL'and a.get('usagetype')=='Aurora:StorageUsage')
q851=[]
for n in [2,10]:
 b=n*inst*6;c=.5*acu*24
 # Each stopped/deprovisioned separate development environment keeps ten GB through a 30-day month; conservatively add the excess $0.1/GB-month storage relative to shared cluster.
 extra_storage_b=max(0,n-1)*10*aurora_storage/30
 q851.append({'developers':n,'activeHoursPerDayEach':6,'C_sharedClusterFloorACU':.5,'C_scaleToZero':'not enabled by this modeled default; no lack of connections changes the 0.5 floor','C_totalDemand':'combined low-volume demand fits 0.5 ACU, no async archive','B_dayComputeAndExcessStorage_USD':b+extra_storage_b,'C_dayCompute_USD':c,'lowerCostOriginalOption':'B'if b+extra_storage_b<c else'C','IOWitnessBound':'toy development data and low request volume keep extra I/O/start effects under $0.01/day, too small to reverse either margin','B_lifecycle':'catalogue product restricts small instance; launch/use while active, stop/release compute when finished; no automatic unmentioned scaling promise','notUniversalAWSDefault':'The original failed to freeze actual default engine/tool/capacity settings. This is one documented 0.5-minimum default configuration, not a claim every current console defaults to 0.5.'})
assert[x['lowerCostOriginalOption']for x in q851]==['B','C']
for c in q940:c['priceHorizonAssumption']='The counterfactual holds the currently published rates constant over its planning horizon; this is not a prediction or guarantee of future AWS prices.'
out={'schema':'residual28-official-price-counterexamples-v1','region':'us-east-1','calculatedAt':'2026-11-07','notOriginalFacts':True,'Q153':q153,'Q373':q373,'Q485':q485,'Q956':q956,'Q940':q940,'Q851':q851,'priceFacts':facts,'rawPriceBindings':[{'path':str((P/f).resolve()),'sha256':hashlib.sha256((P/f).read_bytes()).hexdigest(),'publicationDate':json.loads((P/f).read_text())['publicationDate']}for f in ['s3-price-list-us-east-1.raw.json','amazonrds-price-list-us-east-1.raw.json','s3gda-price-list-us-east-1.raw.json','amazonglacier-price-list-us-east-1.raw.json']]}
(R/'evidence/cost-counterexamples.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for q in ['Q153','Q373','Q485','Q956','Q940','Q851']:print(q,[x.get('lowerCost',x.get('lowerCostOriginalOption'))for x in out[q]])

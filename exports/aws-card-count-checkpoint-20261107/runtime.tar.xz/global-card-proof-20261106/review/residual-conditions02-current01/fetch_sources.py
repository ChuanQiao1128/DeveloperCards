import concurrent.futures,datetime,hashlib,html,json,re,subprocess
from pathlib import Path
root=Path.cwd();out=root/'review/residual-conditions02-current01/evidence';cat=json.loads((root/'review/final-core-closure01/input/official-snapshot-catalogue.json').read_text());known={x['url']:x for x in cat}
urls={
'fsx-gateway-eligibility':'https://docs.aws.amazon.com/filegateway/latest/filefsx/what-is-file-fsx.html',
'objectlambda-eligibility':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/transforming-objects.html',
'forecast-eligibility':'https://docs.aws.amazon.com/forecast/latest/dg/what-is-forecast.html',
'ads-eligibility':'https://docs.aws.amazon.com/application-discovery/latest/userguide/what-is-appdiscovery.html',
'app2container-eligibility':'https://docs.aws.amazon.com/app2container/latest/UserGuide/what-is-app2container.html',
'app2container-support':'https://docs.aws.amazon.com/app2container/latest/UserGuide/supported-applications.html',
'dynamodb-export':'https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/S3DataExport.HowItWorks.html',
'dynamodb-pitr':'https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Point-in-time-recovery.html',
'dynamodb-incremental':'https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/S3DataExport.Requesting.html',
'redshift-encrypted-copy':'https://docs.aws.amazon.com/redshift/latest/dg/c_loading-encrypted-files.html',
'redshift-copy':'https://docs.aws.amazon.com/redshift/latest/dg/r_COPY.html',
'redshift-pause':'https://docs.aws.amazon.com/redshift/latest/mgmt/rs-mgmt-pause-resume-cluster.html',
'redshift-restore':'https://docs.aws.amazon.com/redshift/latest/mgmt/working-with-snapshot-restore-cluster-from-snapshot.html',
'redshift-api':'https://docs.aws.amazon.com/redshift/latest/mgmt/data-api.html',
'glue-formats':'https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-format-parquet-home.html',
'glue-csv':'https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-format-csv-home.html',
'glue-startjob':'https://docs.aws.amazon.com/glue/latest/dg/aws-glue-api-jobs-runs.html',
'forecast-autopredictor':'https://docs.aws.amazon.com/forecast/latest/dg/API_CreateAutoPredictor.html',
'sagemaker-autopilot':'https://docs.aws.amazon.com/sagemaker/latest/dg/autopilot-automate-model-development.html',
'lambda-runtime':'https://docs.aws.amazon.com/lambda/latest/dg/gettingstarted-limits.html',
'fargate-spot':'https://docs.aws.amazon.com/AmazonECS/latest/developerguide/fargate-capacity-providers.html',
'fargate-optimizer':'https://docs.aws.amazon.com/compute-optimizer/latest/ug/view-ecs-recommendations.html',
'dms-sources':'https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Introduction.Sources.html',
'dms-mongodb':'https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Source.MongoDB.html',
'backup-retention':'https://docs.aws.amazon.com/aws-backup/latest/devguide/plan-options-and-configuration.html',
'aws-s3gateway':'https://docs.aws.amazon.com/vpc/latest/privatelink/vpc-endpoints-s3.html',
'athena-api':'https://docs.aws.amazon.com/athena/latest/APIReference/Welcome.html',
'lambda-runtimes':'https://docs.aws.amazon.com/lambda/latest/dg/lambda-runtimes.html',
'translate-languages':'https://docs.aws.amazon.com/translate/latest/dg/what-is-languages.html',
'transcribe-languages':'https://docs.aws.amazon.com/transcribe/latest/dg/supported-languages.html',
'host-reservations':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/dedicated-hosts-reservations.html',
'aurora-pause':'https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/aurora-serverless-v2-auto-pause.html'
}
def fetch(item):
 k,u=item;p=out/(k+'.json')
 if p.exists():return k,'existing'
 if u in known:
  z=known[u];p.write_bytes(Path(z['snapshotPath']).read_bytes());return k,'reused'
 rawp=out/(k+'.html')
 try:
  r=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','30','--output',str(rawp),'--write-out','%{url_effective}\n%{http_code}',u],capture_output=True,check=True)
  final,status=r.stdout.decode().splitlines();raw=rawp.read_bytes();s=raw.decode('utf-8');s=re.sub(r'<(script|style)\b.*?</\1\s*>','',s,flags=re.I|re.S);s=html.unescape(re.sub(r'<[^>]+>',' ',s));s=re.sub(r'\s+',' ',s).strip()
  p.write_text(json.dumps({'url':u,'finalUrl':final,'httpStatus':int(status),'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':s,'textSha256':hashlib.sha256(s.encode()).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest()},ensure_ascii=False,indent=2)+'\n');return k,len(s)
 except Exception as e:return k,str(e)
for r in concurrent.futures.ThreadPoolExecutor(5).map(fetch,urls.items()):print(json.dumps(r),flush=True)

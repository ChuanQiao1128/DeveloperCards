# 28题当前卡组与题源独立收束

5题原题卡组SUPPORTED；23题SOURCE_ISSUE。Q515另有可见卡B/F教学缺口，源问题与缺卡分别记录。没有把源问题、最小纠错建议或新增练习输入计为原题充分。

冻结范围为28份完整原题、362个候选正文；后续仅GSC-095通过supplemental15的独立PASS凭证显式增量绑定，定向核查Q258保持D。362不是最终N。

| 题号 | 原题状态 | 已接受选项 | 结论 |
|---|---|---|---|
| Q64 | SOURCE_ISSUE | — | D的云端FSx加机房缓存路径仍为既有合格客户提供低延迟Windows文件访问，但新客户不能开通FSx File Gateway。原文没有给资格，不能无条件选D或把它判成全面退役。 |
| Q107 | SUPPORTED | 2 | B提供业务REST入口和处理逻辑；存储可沿既有分析平台或以已学S3对象层承载，API入口本身不被当成持久数据库。原题是在给多层REST处理入口选项，未给必须用某一数据库的硬约束。 |
| Q153 | SOURCE_ISSUE | — | D是已知年龄分界的常见规则，但B的Intelligent-Tiering有按对象监控费及更低的即时归档层。即使所有文件都≥128KB，256KiB与2MiB两种铃声大小可反转整个成本排序。 |
| Q157 | SOURCE_ISSUE | — | D+E解释日志长期留存与五年备份恢复点，但题面还要求五年后删除“所有数据”。备份过期删除的是恢复点，不会自动删除仍在Aurora中的业务行，也可能在新备份里继续保留旧记录。 |
| Q215 | SOURCE_ISSUE | — | 700TB/500Mbps的理想在线下限已超过一月，资格决定离线A能否采用。 |
| Q258 | SUPPORTED | 4 | D把CSV→Parquet交给原生ETL服务，Lambda只接对象事件启动作业。1GB并不必然超过Lambda限制；选择D的依据是少维护转换执行代码及依赖，而非编造超时或要求先做生产实测。 |
| Q295 | SOURCE_ISSUE | — | Object Lambda不是全面退役，既有使用者及特定APN伙伴仍可使用；普通新客户不能开通该按读取转换路径，原文资格缺失会改变可采用方案。 |
| Q373 | SOURCE_ISSUE | — | 每天读近30日、全年另读四次不等于一个固定的成本排序。四次读取可集中，IT仍使用即时层；即使都≥128KB，逐对象监控费与数据取回费也可因对象大小反转A/D总费。 |
| Q383 | SUPPORTED | 1 | 按socket/core许可需主机可见性与控制；Dedicated Host而非Dedicated Instance提供这一层。容量及使用可预测时采用匹配的Host Reservation折扣。无需把正常授权匹配审查变成另一个未知AWS能力。 |
| Q398 | SOURCE_ISSUE | — | 600TB/100Mbps的理想在线下限远超两周；既有合格客户可用C，不能把新客禁入误称全服务退役。 |
| Q424 | SOURCE_ISSUE | — | 后台只运行很短时间、数量波动，并不证明可被Spot中断。可中断的EC2任务与不能中断且适合容器的任务，会分别导向B和A。 |
| Q485 | SOURCE_ISSUE | — | 对象均在Expedited通常1–5分钟适用大小内时，取回请求频度和保障容量费用仍可令A或D更便宜；“rarely”不是完整费用输入。未要求多AZ，不能凭审查者偏好排除One Zone-IA。 |
| Q490 | SOURCE_ISSUE | — | PITR连续备份、时间段导出和持续变化归档是不同产物。B原生导出不消耗RCU，但不是客户S3桶的逐条实时镜像；题面未给S3恢复点/新鲜度，不能把它们合并为同一保证。 |
| Q493 | SOURCE_ISSUE | — | D→E→F是支持语言范围内的正确服务顺序，但D/E写“any language”超出官方完整支持集合，四种语言只给了English并承诺未来扩展，不能保证全部覆盖。 |
| Q515 | SOURCE_ISSUE | — | A Data API、B通用客户端/服务端加密、C安排分析时段有当前官方正证。F按原文未排除的“控制台从快照建立独立副本”理解也有正证，至少四项合理能力与Choose three冲突。若F想指持续同步read replica，须明写。B/F可见卡教学缺口另记，不阻止独立确认题源问题。 |
| Q687 | SOURCE_ISSUE | — | 既有Forecast客户可用专用预测器路径；普通新客户不能开通。SageMaker也有托管自动建模能力，所以“没有ML经验”不能无条件把A+B排除；原题缺资格且没有写明排除支持的托管AutoML。 |
| Q693 | SOURCE_ISSUE | — | 跨AZ的D方向正确，但“embedded NoSQL”不是一个DMS源类型。已支持MongoDB与应用内未受支持的嵌入式存储，会改变D是否实际能迁移。 |
| Q756 | SOURCE_ISSUE | — | Object Lambda不是全面退役，既有使用者及特定APN伙伴仍可使用；普通新客户不能开通该按读取转换路径，原文资格缺失会改变可采用方案。 |
| Q763 | SOURCE_ISSUE | — | 夜间100Mbps即便每天24小时开放也不足一月搬150TB；既有Snowball资格决定B是否实际可用。 |
| Q778 | SOURCE_ISSUE | — | 每办公室1PB即便2Gbps满速也需约46天，超过四周；离线B的资格是实际决定输入。 |
| Q786 | SOURCE_ISSUE | — | B的现有ADS发现项目可采配置、利用率与依赖；新客户的ADS及Migration Hub入口均已关闭，当前应评估Transform。不能永久笼统等待资格，也不能把旧项目当全面停服。 |
| Q851 | SOURCE_ISSUE | — | C泛称Serverless默认值，不能自动得到零ACU暂停或已实施的容量上限。即使采用文档化0.5ACU默认下限，开发者数量和停启方式也能使B或C总费更低。 |
| Q926 | SUPPORTED | 4 | D是当前已明确支持ECS Fargate的Compute Optimizer托管规格建议。高可用客户Web并未声明突发部分可中断，不能仅凭短峰把Spot当作必选最省方案。 |
| Q930 | SUPPORTED | 3 | C保留EC2程序执行模型及原门户接口，最少改造；Savings Plan按适用稳定基线承诺。A/D把既有功能改为Lambda/API/静态前端，并不自动满足不改代码。100%是业务持续服务目标，不能据此声称AWS合同保证绝无故障。 |
| Q940 | SOURCE_ISSUE | — | D在确有三年稳定用量且能预付时通常有最深折扣；“long-running”没有给三年使用期限。实际只运行一年与运行三年，即使是同样数据库和实例，也会反转C/D整个承诺费用。 |
| Q956 | SOURCE_ISSUE | — | Spot被“cannot be disrupted”排除，但D与B的最低费仍取决于首30天实际读了多少字节。GIR的90天最低计费不禁止30天后转Deep Archive；已计入剩余60天费用，少量Range读仍可使B更省。 |
| Q969 | SOURCE_ISSUE | — | 已有App2Container资格且ASP.NET/Linux在支持范围时A可封装并交Fargate托管运行；新客户不能开通该工具。App Runner是运行服务，不是替代容器化工具后再部署到ECS/EKS。 |
| Q998 | SOURCE_ISSUE | — | 原文明示不得使用S3 public endpoint，但官方确认gateway endpoint仍访问服务public endpoint。A能避免IGW/NAT/公共互联网，不能满足该字面要求；B/C/D也无所需私有接口路径。应改为禁public internet，或保留原约束并提供interface endpoint选项。 |

关键证据边界：

- Q515：A/B/C及F独立snapshot副本读法均有官方正证，Choose three欠准确；未声称Redshift snapshot等同持续read replica。
- Q998：gateway endpoint仍使用S3 public endpoint。只禁public internet是纠错后的不同约束，不能充作原文兼容情境。
- Snowball、FSx File Gateway、Object Lambda、Forecast、ADS/Migration Hub和App2Container按既有/新增使用资格区分；未把新客户禁入写成全面停服。
- Q153/Q373/Q485/Q851/Q940/Q956附当前官方价目与两组成本反例；Q373用每日新增、滚动近30天及固定四次全年训练，含非共同IA迁移费。
- Q258不因1GB就断言Lambda超时；Q926使用当前Compute Optimizer确已支持Fargate CPU/内存建议的事实。

确定性回读36项全部PASS；完整原题哈希、选项序号、实际卡句和正文哈希、递归先修、官方原句/偏移/文件哈希、价格维度与计算绑定见results.json/readback.json。

外部模型CLI/API调用0，native用量unknown。未修改原题、生产库存或主run；未制卡、发布或恢复自动化。没有学习者记忆、独立作答正确率或生产SLA验收。

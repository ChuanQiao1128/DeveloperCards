import pathlib,json,hashlib,datetime
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106')
R=V/'review/corrected-variants02';I=R/'input'
def ca(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
mp=I/'manifest.json';manifest=json.loads(mp.read_text())
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,(p,h)
cases=json.loads((I/'cases.json').read_text());by={c['variantId']:c for c in cases}
pool={c['ruleId']:c for c in json.loads((I/'core-visible.frozen.json').read_text())}
assert len(pool)==351
for c in pool.values():assert sha(ca(c['visibleBody']))==c['bodySha256']
for c in cases:
 assert sha(ca(c['originalQuestion']))==c['originalQuestionCanonicalSha256']
 assert sha(ca(c['correctedQuestion']))==c['correctedQuestionCanonicalSha256']
 assert c['originalQuestion']['options']==c['correctedQuestion']['options']
 assert len(c['deltas'])==2
 old,new=c['deltas']
 assert c['originalQuestion']['stem'].count(old['old'])==1
 replay=c['originalQuestion']['stem'].replace(old['old'],old['new'],1)
 marker=replay[replay.rfind('Which solution'):]
 replay=replay.replace(marker,new['new']+marker,1)
 assert replay==c['correctedQuestion']['stem'],'No hidden stem changes'
 for ic in c['initialVisibleCards']:assert pool[ic['ruleId']]['bodySha256']==ic['bodySha256']

def card(rid,field,quote,supports):
 c=pool[rid];text=c['visibleBody'][field];start=text.index(quote)
 return {'premiseType':'visible_card','cardId':rid,'ruleId':rid,'bodySha256':c['bodySha256'],
  'field':field,'quote':quote,'quoteStart':start,'quoteEnd':start+len(quote),'supports':supports,
  'poolOrigin':'frozen core351; no supplemental03 overlay'}
def given(vid,field,quote,supports):
 c=by[vid];q=c['correctedQuestion']
 if field=='stem':text=q['stem']
 else:text=next(o['text'] for o in q['options'] if o['ordinal']==int(field.split(':')[1]))
 start=text.index(quote)
 return {'premiseType':'explicit_corrected_exercise_given','variantId':vid,'correctedQuestionCanonicalSha256':c['correctedQuestionCanonicalSha256'],
  'field':field,'quote':quote,'quoteStart':start,'quoteEnd':start+len(quote),'supports':supports,
  'notAClaimAboutOriginalQuestion':True,'notPrivateSourceFinding':True}
official=[]
for c in cases:
 for e in c['sourceFinding']['officialEvidence']:
  p=pathlib.Path(e['sourcePath']);d=json.loads(p.read_text());t=d['text']
  assert sha(p.read_bytes())==e['fileSha256'] and sha(t.encode())==e['textSha256']
  assert t[e['quoteStart']:e['quoteEnd']]==e['quote']
  official.append({'variantId':c['variantId'],'sourcePath':str(p),'sourceFileSha256':e['fileSha256'],
   'textSha256':e['textSha256'],'url':e['url'],'quote':e['quote'],'quoteStart':e['quoteStart'],'quoteEnd':e['quoteEnd'],
   'reuseScope':'independent original capacity defect and absence of corrected-capacity contradiction only',
   'usedAsVisibleLearningPremise':False,
   'notGeneralCurrentClaimAboutEveryUnrelatedQuota':True})

v='Q052-CV02'
p52=[
 given(v,'stem','output files that vary in size from tens to hundreds of gigabytes. The total dataset can grow to hundreds of terabytes.','纠正单文件/总量混淆；保留大数据集规模'),
 given(v,'stem','Assume that the individual file sizes and total storage capacity are within the applicable quotas for the candidate services.','对所有候选相同的容量适用性前提，不要求学习者从私有证据背47.9TiB'),
 given(v,'stem','stored in a standard file system structure.','要求文件系统语义，不是仅对象API'),
 card('GSC-001','answerZH','把文件放在同一个EFS文件系统，让实例共同挂载。','EFS提供共享文件系统'),
 card('GSC-001','keyPointZH','EFS以NFS提供同一份共享文件，并随文件增减自动伸缩容量，无需预先买定磁盘大小；各实例独立块卷不会自动同步写入。','共享文件、自动容量与低磁盘管理负担'),
 card('GSC-002','answerZH','选Regional，并为客户端所在AZ安排挂载路径。','高可用选择Regional EFS'),
 card('GSC-002','keyPointZH','Regional文件系统跨多个AZ保存数据；One Zone的数据保存在单个AZ，不能承担AZ整体故障保护。','跨AZ数据可用性'),
 card('CUR:CB03','answerZH','在多个AZ各设子网并分散实例，由跨AZ Auto Scaling组维持容量。','跨AZ计算冗余'),
 card('GSC-112','answerZH','不会只因设置上下限就按CPU伸缩；应配置适用的动态策略，例如target tracking。','ASG按实际负载伸缩还要使用动态策略，不能把建组自动当流量策略'),
 card('GSC-020','keyPointZH','它共享的是同一块设备，不替应用管理并发文件写入，也不会把卷变成跨AZ文件服务。','EBS块共享不等于跨AZ文件服务'),
 card('CUR:NA05','keyPointZH','区域对象存储把文件作为独立对象保存，应用按API访问，','S3原生对象接口与本题文件系统接口区别'),
 card('GCL-021','keyPointZH','mount target给客户端可连接的NFS地址；access point限定怎样使用文件系统，不能代替网络路径。','EFS跨AZ客户端实际挂载路径')
]
v='Q324-CV02'
p324=[
 given(v,'stem','The file storage volume holds 10 tebibytes (TiB) of data, within the applicable Storage Gateway and EBS capacity limits.','明确可用单卷/恢复容量，不从私有配额补答'),
 given(v,'stem','mounted\nfrom an Internet Small Computer Systems Interface (iSCSI) device on a local storage server.','原有块接口必须尽量保留'),
 given(v,'stem','end users retain immediate access to all file types from the on-premises systems','所有文件的本地日常访问条件'),
 given(v,'stem','The company has no existing backup application or tape workflow and does not want to introduce separate backup software.','新练习明确的新运维约束；不是原题恢复出来的事实'),
 given(v,'option:2','Use a data backup solution to back up all existing data to a virtual tape library.','B明示需要独立备份软件，与新给定条件直接冲突'),
 given(v,'option:4','Mount the Volume Gateway stored volume to the existing file server by using iSCSI,','D保留给定块接口的方案动作'),
 card('GSC-010','frontZH','Volume Gateway要求完整主数据始终留在机房，容量符合配额。','本卡的适用范围；容量由练习明示'),
 card('GSC-010','answerZH','选stored volumes。','全量本地选择stored'),
 card('GSC-010','keyPointZH','stored把完整主数据留在本地，日常访问使用本地存储，并经加密连接把数据异步备份到AWS。','全量数据本地访问与云端异步备份的因果'),
 card('GSC-010','watchOutZH','cached以S3为主存，只在本地保留缓存；缓存未命中时需要从云端读取。','cached不能保证任意文件始终本地读取'),
 card('GSC-012','watchOutZH','本地缓存不是完整主数据必须常驻的保证，也不是给应用提供iSCSI块卷。','File Gateway既改接口又不能给全量本地保证'),
 card('GSC-013','keyPointZH','它向备份软件提供虚拟磁带库和磁带设备接口，写入的虚拟磁带数据由AWS保存。','磁带入口依赖备份软件工作流；不把Tape错误说成必须替换主存'),
 card('GSC-011','answerZH','从快照创建EBS卷，再把卷挂到合适的EC2实例。','题目所给兼容容量内的备份恢复路径'),
 card('GSC-011','keyPointZH','快照是卷的恢复点；创建EBS卷后才得到EC2能挂载的块设备。','恢复点与可挂块设备分工'),
 card('GSC-011','watchOutZH','须核对快照和目标卷的容量、Region及AZ要求；存储在S3中的备份不是普通可直接读取的文件桶。','不能把备份桶直接挂作恢复卷')
]
results=[]
for c,premises,opt in [(by['Q052-CV02'],p52,3),(by['Q324-CV02'],p324,4)]:
 rid=c['variantId']
 q52=rid=='Q052-CV02'
 row={
  'variantId':rid,'originalQid':c['originalQid'],
  'originalQuestionCanonicalSha256':c['originalQuestionCanonicalSha256'],
  'correctedQuestionCanonicalSha256':c['correctedQuestionCanonicalSha256'],
  'originalQuestion':c['originalQuestion'],'correctedQuestion':c['correctedQuestion'],'deltas':c['deltas'],
  'allOriginalStemAndOptionsRead':True,'allCorrectedStemAndOptionsRead':True,
  'minimalityVerdict':'PASS','learningTargetPreserved':True,'allOptionsUnchanged':True,
  'minimalityReason':(
   '两处题干改动只修正单文件容量与总数据量混淆，并显式给出全候选中性配额前提；文件语义、自动伸缩、高可用和少维护的原判断保留。不是把EFS上限写进题面来排他提示。'
   if q52 else
   '容量改为适用范围以消除原单卷矛盾；另加一条明示为新练习的运维约束来区分原先未给的备份软件前提。它收窄练习场景，但仍训练原有iSCSI、全量本地访问、云端灾备及少改造取舍；没有移除有效原要求。'),
  'originalLearningTarget':(
   '在适用容量内，为持续增长输出选择原生文件系统、自动容量与跨AZ可用性较少维护的组合。'
   if q52 else
   '尽量保留现有iSCSI文件服务器、让所有日常主数据本地可用，并以云端备份卷实现灾备。'),
  'newPracticeScopeNarrowed':not q52,
  'newOperationalGivenNotClaimedAsOriginalIntent':not q52,
  'quotaGivenNeutralAcrossCandidateServices':q52,
  'originalStatus':'SOURCE_ISSUE_PRESERVED','originalNeverUpgradedByVariant':True,
  'sourceFindingUsedAsLearningPremise':False,
  'variantVerdict':'PASS','cardGroupSufficiency':'SUPPORTED',
  'selectedOptionOrdinals':[opt],'candidateOptionOrdinals':[],
  'usedRuleIds':list(dict.fromkeys(p['ruleId'] for p in premises if p['premiseType']=='visible_card')),
  'necessaryPremises':premises,
  'reasoningAndClosestCompetitor':(
   {'selection':'C；EFS提供真正共享NFS文件与自动容量，Regional存储加多AZ ASG满足故障域分散。必要的ASG负载策略及EFS挂载路径已有可见规则可据目标配置。',
    'optionComparison':{
     '1':'S3原生按对象API访问，未提供标准共享文件系统。不能给A私加File Gateway等未列组件后声称等价。',
     '2':'EBS是AZ范围块设备，需要自管文件共享、写入协调/跨AZ复制等才能补足；容器编排本身不提供这些存储语义。',
     '3':'按已教规则配置Regional EFS/挂载路径及适用ASG动态策略，原生获得共享文件与存储自动容量。',
     '4':'与C同样有计算层ASG，但EBS不会因此成为跨AZ共享文件服务，仍有文件/磁盘管理负担。'},
    'closestCompetitorOrdinal':4,
    'decisiveDifference':'同一计算方案下，EFS托管共享文件和自动容量；EBS块卷不会随ASG自动同步为跨AZ文件系统。'}
   if q52 else
   {'selection':'D；stored保留完整本地主数据和iSCSI接口，异步备份后以快照创建EBS/EC2恢复。新增运维约束直接排除需备份软件的B。',
    'optionComparison':{
     '1':'改iSCSI为NFS增加应用变化，且缓存不保证所有主数据始终本地；S3桶也不是直接可挂块设备。',
     '2':'Tape Gateway本可备份现有主存并保持它供本地读取，不能据旧假设排除；现在B所需独立备份软件明确违反新练习条件。',
     '3':'协议保留，但cached主数据在S3，未命中仍需云端。不能只看配置10TB缓存就保证10TiB全部本地。',
     '4':'完整主数据留本地、保留iSCSI；给定容量适用且无需另引磁带备份软件。'},
    'closestCompetitorOrdinal':3,
    'decisiveDifference':'cached的云端主存与stored的全量本地主存决定任意文件日常读取是否可能回源；B则由明示的新运维条件独立排除。'}),
  'uniquenessVerdict':'PASS','missingJudgments':[],
  'nextAction':'Only this separately identified practice may be accepted; original and CV01 failure remain unchanged.',
  'implementationChecks':(
   ['采用Regional EFS并配置实际mount target/网络/权限；ASG使用适用动态伸缩策略。上述动作由可见规则支持，未承诺任意峰值SLA。']
   if q52 else
   ['日常本地访问的判断不承诺物理零延迟或灾难恢复瞬间完成；恢复时仍按已教规则匹配EBS卷的Region/AZ与初始化。']),
  'notMeasuredLearnerAccuracy':True
 }
 results.append(row)
out=R/'results.json';assert not out.exists()
result={'schemaVersion':1,'reviewer':'actual_cards_review independent corrected-variants02',
 'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'frozenManifestPath':str(mp),'frozenManifestSha256':sha(mp.read_bytes()),'frozenInputFiles':manifest,
 'scopePolicy':{'path':str(V/'inputs/user-source-correction-policy-accepted.json'),
  'sha256':manifest[str(V/'inputs/user-source-correction-policy-accepted.json')],
  'actuallyRead':True,'onlySeparatelyIdentifiedPracticeMayPass':True,'unknownOriginalsNotExempted':True},
 'visiblePoolCount':351,'visiblePoolProvisionalNotFinalN':True,
 'counts':{'variants':2,'PASS':2,'FAIL':0,'SUPPORTED':2,'originalQuestionsPromoted':0},
 'results':results,'supplementaryOfficialEvidence':official,
 'mechanicalReadback':{'status':'PASS','allManifestHashesMatch':True,'allCanonicalFourFieldHashesMatch':True,
  'allQuestionHashesMatch':True,'allOptionsUnchanged':True,'deltaReplayMatchesExactly':True},
 'priorFailureHistory':{'path':str(V/'review/corrected-variants01/results.json'),
  'sha256':manifest[str(V/'review/corrected-variants01/results.json')],'preservedUnchanged':True,
  'priorConclusionsNotUsedToDeriveNewSelection':True},
 'originalQuestionsModified':False,'correctedQuestionsModifiedByReviewer':False,
 'formalInventoryModified':False,'currentPointersModified':False,'cardsAuthored':False,
 'externalModelCliApiCalls':0,'nativeUsage':'unknown',
 'supplemental03NotAppliedOrBorrowed':True,'fullLibraryNStillUnknown':True}
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
read=json.loads(out.read_text())
for c in read['results']:
 q=c['correctedQuestion']
 for p in c['necessaryPremises']:
  if p['premiseType']=='visible_card':
   pc=pool[p['ruleId']];assert sha(ca(pc['visibleBody']))==pc['bodySha256']==p['bodySha256']
   text=pc['visibleBody'][p['field']]
  else:
   text=q['stem'] if p['field']=='stem' else next(o['text'] for o in q['options'] if o['ordinal']==int(p['field'].split(':')[1]))
   assert p['correctedQuestionCanonicalSha256']==sha(ca(q))
  assert text[p['quoteStart']:p['quoteEnd']]==p['quote']
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h
rb={'status':'PASS','resultsPath':str(out),'resultsSha256':sha(out.read_bytes()),
 'variantIds':[c['variantId'] for c in results],'allOriginalAndCorrectedHashesMatch':True,
 'allOptionsUnchanged':True,'allDeclaredDeltaReplaysMatch':True,'allCardAndGivenQuotesOffsetsMatch':True,
 'allCanonicalFourFieldCardHashesMatch':True,'officialCapacityEvidenceQuoteHashesAndOffsetsMatch':True,
 'sourceFindingNotUsedAsLearningPremise':True,'corePoolCount':351,
 'noSupplemental03Borrowing':True,'priorCV01FailuresUnchanged':True,
 'originalQuestionsAndCurrentPointersUnchanged':True,'modelCliApiCalls':0,'nativeUsage':'unknown'}
(R/'readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
(R/'results.md').write_text(
 '# CV02独立复核\n\n'
 'Q052-CV02：PASS，当前核心卡组支撑选C。单文件/总量分开，配额前提中性适用于所有候选；文件系统、自动容量、跨AZ可用性及低维护目标保留。\n\n'
 'Q324-CV02：PASS，当前核心卡组支撑选D。10TiB显式满足适用配额；新增“不引入独立备份软件”的条件排除B，stored/cached的本地主数据差异仍是主要判断。该新运维条件仅属于新练习，不是恢复出的原意。\n\n'
 '两条均保持原选项，实际卡句/给定条件的field、四字段哈希和逐字偏移回读通过。只使用冻结core351，未借supp03或私有sourceFinding补学。原题不升级，CV01旧失败不改，最终N仍未知。模型CLI/API 0，native unknown。\n')
print(json.dumps({'path':str(out),'sha256':sha(out.read_bytes()),'counts':result['counts'],'readback':'PASS'},ensure_ascii=False))

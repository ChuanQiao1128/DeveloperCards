# repair08 independent review

All five Chinese repaired bodies PASS. No card FAIL or UNKNOWN. B1 is not applicable. The reviewer did not change any current-body pointer.

| Card | Canonical four-field body SHA-256 | Result |
|---|---|---|
| GSC-045 | `656332e0c4e48b8f75703ad00f83a1fe5de67e7ce08240cea8d87d794358fe39` | PASS |
| CUR:NB08 | `6f262aa9b635e0297bad43fef2cf089f83afc784c34cb925a8b13fd2827e1ea9` | PASS |
| GSC-076 | `1b4c108947d98a9c8151b0f7d638ef773fd52472d475378c89dc55a047c36730` | PASS |
| CUR:CB01 | `32e05ac21a8128c52dca74318c82e6bf330555cbe2bf2d059d64f3914421de72` | PASS |
| GCL-023 | `b118a83049afc1bbe3e0e084c830217b92388b310af2944faf00b61887f89c3e` | PASS |

| Question | Current overlay status | Selected ordinal |
|---|---|---|
| Q209 | SUPPORTED | 1 |
| Q241 | SUPPORTED | 3 |
| Q296 | INSUFFICIENT_CARDS | unproved |
| Q348 | SUPPORTED | 2 |
| Q390 | INSUFFICIENT_CARDS | unproved |
| Q420 | SUPPORTED | 4 |

Q296: /32 is now ruled out by visible text. Same-VPC secondary-CIDR non-overlap does not establish the different cross-VPC peering non-overlap requirement; old CB16 only assumes non-overlap in its front. D remains a candidate.

Q390: External session storage explains survival of Web-instance replacement. The visible cards still do not teach Redis persistence/recovery, so shared state and replication cannot establish the explicit durable-storage requirement. B/D remain candidates.

Q420: Built-in readers, reader endpoint and typical failover below 35 seconds directly support the selection for most scenarios below 40 seconds. This is selection knowledge, not a measured production SLA.

Official quotes, URLs, exact snapshot hashes/offsets and actual visible-card anchors are in repair08.review.json. Only named old unchanged-claim excerpts were reused.

Current Skill byte hash: `e84a061a98b24c24cea65f8240bece23d91b6c6cecee79dbda10701c48e1c624`. No deletion/merge/domain-assignment action was performed.

All manifest files matched at review write time. The mutable cards.current.json changed afterwards; this review remains bound to the frozen repair08 input plus the old355 snapshot and does not revalidate new integrated current question proofs.

Model CLI/API calls: 0. Native usage: unknown. No publication, production pointer, budget or study-record change by this reviewer.

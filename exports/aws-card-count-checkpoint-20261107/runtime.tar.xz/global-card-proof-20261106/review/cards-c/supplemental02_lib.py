import pathlib,json,hashlib,datetime,collections
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106')
I=V/'review/supplemental02/input';R=V/'review/cards-c';E=V/'evidence/cards-c';MP=I/'manifest.v2.json';M=json.loads(MP.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def ca(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
raw=json.loads((I/'cards.v2.json').read_text());questions=json.loads((I/'questions.json').read_text());qby={x['qid']:x['question'] for x in questions}
P=E/'supplemental02-current357.snapshot.json';assert sha(P.read_bytes())==M[str(V/'deliverables/visible-knowledge-current.json')]
pool={c['ruleId']:c for c in json.loads(P.read_text())};assert len(pool)==357 and 'GCL-020' not in pool
fields=['frontZH','answerZH','keyPointZH','watchOutZH'];nb={c['ruleId']:{f:c[f] for f in fields} for c in raw};nh={r:sha(ca(b)) for r,b in nb.items()}
assert len(raw)==6 and 'VC-003' not in pool
for c in raw:
 if 'repairOf' in c:assert c['repairOf']==pool[c['ruleId']]['bodySha256']
overlay={r:{'visibleBody':c['visibleBody'],'bodySha256':c['bodySha256']} for r,c in pool.items()}
overlay.update({r:{'visibleBody':b,'bodySha256':nh[r]} for r,b in nb.items()})
registry={}
def ev(path,quote,supports,receipt=None):
 p=pathlib.Path(path);d=json.loads(p.read_text());t=d['text'];i=t.index(quote);eid=sha(ca([str(p),quote,supports]))
 registry[eid]={'sourcePath':str(p),'sourceFileSha256':sha(p.read_bytes()),'textSha256':sha(t.encode()),'url':d['url'],'quote':quote,'quoteStart':i,'quoteEnd':i+len(quote),'supports':supports,'reusedReceipt':receipt};return eid
provided=json.loads((I/'official-evidence.json').read_text());pids=[]
for x in provided:
 p=pathlib.Path(x['snapshotPath']);d=json.loads(p.read_text());assert sha(p.read_bytes())==x['snapshotSha256'];assert sha(d['text'].encode())==x['textSha256'];assert d['text'][x['quoteStart']:x['quoteEnd']]==x['quote']
 pids.append(ev(p,x['quote'],'frozen supplied official excerpt'))
def source(n):return pathlib.Path(provided[n]['snapshotPath'])
api0=ev(source(8),'If your Lambda function is not performing custom logic while integrating with other AWS\nservices, chances are that it may be unnecessary.','CA17: backend Lambda unnecessary for no custom logic')
api1=ev(source(6),'This pattern creates a REST API endpoint by using Amazon API Gateway to send a message to Amazon Simple Queue Service (Amazon SQS).','CA17: actual API Gateway to SQS path')
api2=ev(source(6),"API Gateway posts a message, which is received on the request's body, on the queue.",'CA17: direct queue request')
api3=ev(source(8),'In this scenario, API Gateway will execute a Lambda function that will simply ingest the\nincoming record into Firehose, which subsequently batches records before storing into a S3\nbucket.','CA17: API Gateway Lambda integration')
ddb=ev(source(2),"After you enable AWS Backup's advanced features in your AWS Region, you unlock the following\nfeatures for all new for DynamoDB table backups you create:\nCost savings and optimization:\nTiering backups to cold storage to reduce storage costs",'NS03: advanced new-DDB-backup cold tier gate')
ddbcopy=ev(source(2),'Additional copy options:\nCross-Region\ncopy\nCross-account\ncopy','NS03: supported cross-Region copy')
rds0=ev(E/'supp02-rds-retaining.json','Retained automated backups contain system snapshots and transaction logs from a DB instance.','GSC047: snapshot and log assets')
rds1=ev(source(5),'RDS uploads transaction logs for DB instances to Amazon S3 every five\nminutes.','GSC047: DB-instance log cadence')
rds2=ev(source(5),'To see the latest restorable time for a DB instance, use the AWS CLI describe-db-instances command\nand look at the value returned in the LatestRestorableTime field for the DB instance.','GSC047: actual restorable progress')
rds3=ev(source(4),'You can set the backup retention period of a DB instance to between 0 and 35 days.','GSC047: finite PITR window')
cf=ev(source(10),'Invalidate the file from edge caches. The next time a viewer requests the\nfile, CloudFront returns to the origin to fetch the latest version of the file.','GSC131: invalidate and next origin fetch')
tag0=ev(source(11),"Only a management account in an organization and single accounts that aren't members of an\norganization have access to the cost allocation tags manager in\nthe Billing and Cost Management console.",'GSC154: management-account activation authority')
tag1=ev(source(11),'After you\nhave created and applied the user-defined tags, you can activate by using the Billing and Cost Management\nconsole for cost allocation tracking.','GSC154: resource tags need Billing activation')
aur0=ev(source(3),'The primary instance and the Aurora\nReplicas in the DB cluster all see the data in the cluster volume as a single logical\nvolume.','VC003: shared logical regional volume')
aur1=ev(source(3),'Aurora Replicas have two main purposes. You can issue queries to them to scale the read\noperations for your application.','VC003: reader queries')
aur2=ev(source(9),'If the primary instance fails,\nAmazon RDS promotes the Aurora Replica with the highest priority to the new primary instance.','VC003: reader promotion')
aur3=ev(source(1),'When data is written to the primary DB instance, Aurora synchronously replicates the data\nacross Availability Zones to six storage nodes associated with your cluster volume.','VC003: cross-AZ cluster data protection')
aur4=ev(source(3),'This lag is usually much less than 100 milliseconds after the primary\ninstance has written an update.','VC003: typical regional reader lag')
aur5=ev(source(3),'Replica lag varies depending on the rate of database\nchange. That is, during periods where a large amount of write operations occur for the\ndatabase, you might see an increase in replica lag.','VC003: heavy-write lag boundary')
reused={}
wanted={'CUR:NS03':('review/reuse-a/batch07.review.json','results'),'GSC-047':('review/reuse-a/repair07.review.json','results'),'GSC-131':('review/cards-c/repair04.review.json','cards'),'GSC-154':('review/reuse-a/batch18.review.json','results')}
for rid,(rel,key) in wanted.items():
 rp=V/rel;d=json.loads(rp.read_text());c=next(c for c in d[key] if c['ruleId']==rid);assert c['bodySha256']==pool[rid]['bodySha256'];ids=[]
 for x in c.get('evidence',[])+[d.get('evidenceRegistry',{})[k] for k in c.get('evidenceIds',[]) if k in d.get('evidenceRegistry',{})]:
  p=pathlib.Path(x['sourcePath']);assert sha(p.read_bytes())==x['sourceFileSha256']
  ids.append(ev(p,x['quote'],'unchanged prior FACT claim',{'reviewPath':str(rp),'reviewSha256':sha(rp.read_bytes()),'oldBodySha256':c['bodySha256']}))
 reused[rid]=ids
manual=ev('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/retrieval-v3/corpus/sources/1d55ef02f6fb91fea3351a23c7b4c2e130508c5d9688519adc91ee279f1cd988.json',"Unlike automated backups, manual snapshots aren't subject to the backup retention period. Snapshots don't expire.",'GSC047: long-lived manual snapshot independent retention')
eids={'CUR:CA17':[api0,api1,api2,api3,pids[7],pids[8]],'CUR:NS03':reused['CUR:NS03']+[ddb,ddbcopy,pids[2]],'GSC-047':reused['GSC-047']+[rds0,rds1,rds2,rds3,manual],'GSC-131':reused['GSC-131']+[cf],'GSC-154':reused['GSC-154']+[tag0,tag1],'VC-003':[aur0,aur1,aur2,aur3,aur4,aur5]}
reasons={
'CUR:CA17':[
'SQS实际Architecture说明API Gateway直接Post消息；Kinesis PutRecord与Firehose service proxy原句明确。仅指转发后端，不把身份authorizer排除。',
'有业务处理时安排计算，纯交付由HTTP入口代理AWS API，减少无用转发层。',
'一个是否需要额外后端函数的判断；三个目标是同一代理规则的例子，不评三套配置。',
'只入队/入流可去掉转发函数；需自定义业务处理时仍可保留函数。',
'只评业务处理与纯代理，不追加IAM、模板及所有目标参数为必答。',
'队列/数据流用途由已有可见卡解释，HTTP到目标请求路径在同卡明确。'],
'CUR:NS03':[
'原DLM EBS范围与跨服务Backup旧凭证匹配；新DDB章节明确高级功能的冷层与跨Region复制。启用可默认/自动完成，未要求人人手工opt-in。',
'先按保护资源范围选工具，统一计划再安排恢复点和支持的副本。',
'主要仍是EBS专用与跨服务计划的选择；DDB冷层是一个适用边界，不评成部署清单。',
'从EBS专用变跨服务应改工具；DDB冷层要满足高级功能，不把规则泛化到所有资源。',
'题面只问工具时必答工具和保护范围，不强制复述未问的跨Region/冷层项。',
'高级功能随DDB冷层用途给出，是明确开关前提；没有隐藏权限/格式清单。'],
'GSC-047':[
'原文分别支持快照与日志、35天窗口、DB实例每5分钟传日志及LatestRestorableTime；未当绝对RPO或套所有Aurora恢复行为。',
'近期恢复由窗口和日志进度决定；多年另保快照，因果明确。',
'一个近期连续恢复与多年恢复点的区别，周期用于解释进度边界。',
'90天留存而14天PITR应拆成两种恢复策略，不配置90天PITR。',
'只评近期PITR加长期恢复点；未问上传周期时不强制背数。',
'快照/日志的作用在卡内解释，不要求日志格式或后台API先修。'],
'GSC-131':[
'新invalidation原文支持下次回源；未变no-cache、零有效期和minTTL边界沿匹配旧凭证。',
'一次清旧与每次复用前验证，都由源更新不自动清边缘解释。',
'单次/持续两个条件下选缓存动作，一个取舍；未变成部署/审计/版本清单。',
'一次部署可失效；持续防未验证旧响应用适当重验证，保留minTTL边界。',
'只评题面两种动作和原因，不追加其他缓存配置。',
'invalidation随使旧对象失效的用途解释，后续回源机制明确。'],
'GSC-154':[
'官方限定组织管理账户或独立账户可访问成本分配标签manager，同章支持创建应用后激活；旧回填边界保留有效凭证。',
'资源标识不自动成为账单维度，管理账户激活后使用可用费用数据。',
'一个由谁在Billing激活的动作，没有堆报表/回填配置。',
'成员已打标签仍应由组织管理账户激活。',
'答管理账户激活对应成本标签即可，不评全部历史回填条件。',
'主体和动作明确，没有把权限责任藏进术语。'],
'VC-003':[
'共享逻辑卷、读扩展/提升、跨AZ保护、通常低于100ms及高写入lag均有实际原句；不保证任意读取最新。',
'存储与计算分离，writer失败后reader可沿用既有集群数据并改变角色，高可用因果可理解。',
'一个共享存储/可接管reader机制；100ms为相关典型边界，不把六节点、15副本等参数塞入回忆。',
'writer计算故障不等于数据消失；高写入仍可lag，不能从共享存储推导写后立即可见。',
'必答共用区域集群存储和适用reader可提升；不评未问的复制数字/故障配置。',
'writer/reader在题面解释为写/读实例。进一步使用lag概念可复用GSC045，不靠私有附录补答案。']}
cardrows=[]
for c in raw:
 rid=c['ruleId'];checks={k:{'status':'PASS','reason':why} for k,why in zip(['FACT','U1','R1','T1','S1','P1'],reasons[rid])}
 checks['B1']={'status':'NOT_APPLICABLE','reason':'仅审冻结中文四字段，不作双语封装通过。'}
 cardrows.append({'ruleId':rid,'verdict':'PASS','bodySha256':nh[rid],'priorBodySha256':c.get('repairOf'),'inputCardSha256':sha(ca(c)),'checks':checks,'evidenceIds':list(dict.fromkeys(eids[rid])),'evidence':[registry[e] for e in dict.fromkeys(eids[rid])],'minimalCorrection':None,'findings':[]})
def an(rid,quote,support):
 c=overlay[rid];f,i=next((f,t.index(quote)) for f,t in c['visibleBody'].items() if quote in t)
 return {'cardId':rid,'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':quote,'quoteStart':i,'quoteEnd':i+len(quote),'supports':support,'origin':'supplemental02.v2 overlay' if rid in nb else 'frozen current357 prerequisite'}
qrows=[]
def add(q,s,sel,aa,why,n,comp,missing=None,candidates=None,impl=None):
 anchors=[an(*a) for a in aa]
 qrows.append({'qid':q,'status':s,'selectedOptionOrdinals':sel,'candidateOptionOrdinals':candidates or [],'questionSha256':sha(ca(qby[q])),'fullStemAndAllOptionsRead':True,'usedRuleIds':list(dict.fromkeys(a['ruleId'] for a in anchors)),'necessaryAnchors':anchors,'reasoning':why,'nearestCompetitor':{'optionOrdinal':n,'explanation':comp},'missingJudgments':missing or [],'conditionsAndSourceIssues':[],'implementationValidationNotNewKnowledge':impl or [],'scope':'Original-question selection knowledge, not measured learner accuracy or production SLA.'})
if __name__=='__main__':print(json.dumps({'factAndTeachingPreflight':'PASS','cards':len(cardrows),'officialEvidenceCount':len(registry),'bodyHashes':nh},ensure_ascii=False))

# 首批当前中文卡独立审查

冻结输入：`/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106/review/cards-c/input/batch01.manifest.json`
输入manifest SHA-256：`7625918715ca167330536f630398b05b2ae9674de43e6a69f51932a47dbe8e45`

10张逐卡事实及教学审查：9 PASS，1 FAIL，0 UNKNOWN。B1不适用；原题卡组充分性、全库复用与学习者实际效果未验收。

| 卡 | 结果 | 主要判断 |
|---|---|---|
| GSC-001 | FAIL | “立即看到写入”超过EFS默认close-to-open语义；仅收窄题面时效条件。 |
| GSC-002 | PASS | 一个取舍：要求经受AZ整体故障时选Regional并解释跨AZ保存数据。 |
| GSC-005 | PASS | 回忆Lustre SSD这一个选型及为什么全量低延迟需要SSD；介质比较围绕同一个任务。 |
| GSC-006 | PASS | 单个数据衔接任务：关联S3并把结果导出；是同一流程的必要两端，不是多服务配置清单。 |
| GCL-022 | PASS | 一个取舍：按能否容忍文件服务器故障丢数据选择persistent或scratch。 |
| GSC-007 | PASS | 单个选型判断：需要NFS与SMB访问同一数据时考虑ONTAP。 |
| GSC-009 | PASS | 一个决定：访问冷热分明时采用分层；没有把各种分层策略压成配置清单。 |
| GSC-010 | PASS | 一个取舍和关键原因；容量符合配额已给定，不纳入必答。 |
| GSC-011 | PASS | 一个恢复任务：快照→EBS卷→EC2；没有要求执行完整灾备部署。 |
| GSC-013 | PASS | 一个接口适配选型：现有磁带备份软件需要Tape Gateway。 |

两项代表迁移：stored→热点缓存条件、persistent→可重算临时数据条件，均可由当前可见正文解释选择变化。

GSC-001官方反证：AWS文档明确“Amazon EFS provides the close-to-open consistency semantics that applications expect from NFS.” 对同步且非追加写入才说明read-after-write保证。应删除无条件“立即”或明确关闭/重新打开等前提。

完整逐卡七项记录、AWS原句/URL/本地快照哈希/字符偏移、当前正文哈希均在同名JSON。旧审查未代替当前事实核对；未改卡面、库存、生产指针或预算。

import json,pathlib,hashlib,shutil,datetime
V=pathlib.Path(__file__).resolve().parents[2]; E=V/'evidence/cards-c';R=V/'review/cards-c'
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
mp=R/'input/batch01.manifest.json';manifest=json.loads(mp.read_text());assert all(sha(pathlib.Path(p).read_bytes())==h for p,h in manifest.items())
cards=json.loads((V/'drafts/batch01.json').read_text());catalog=json.loads(next(pathlib.Path(p).read_text() for p in manifest if 'catalog' in p));sources={}
for key in ['S0076','S0139','S0061','S0405','S0194','S0117','S0416','S0426','S0290']:
 row=next(x for x in catalog if x['sourceKey']==key);orig=pathlib.Path(row['sourcePath']);b=orig.read_bytes();assert sha(b)==row['fileSha256'];local=E/(key+'.json');local.write_bytes(b);d=json.loads(b);assert sha(d['text'].encode())==row['textSha256'];sources[key]=(local,d,orig)
for name in ['EFS-features','ONTAP-storage-capacity','ONTAP-performance','ONTAP-multiprotocol','Lustre-export-current','EBS-create']:
 p=E/(name+'.json');d=json.loads(p.read_text());assert d['status']==200 and len(d['text'])>100;sources[name]=(p,d,p)
def q(key,start,end,claims):
 p,d,o=sources[key];t=d['text'];a=t.index(start);b=t.index(end,a)+len(end);quote=t[a:b]
 return {'sourceKey':key,'url':d.get('url'),'sourcePath':str(p),'sourceFileSha256':sha(p.read_bytes()),'originalSourcePath':str(o),'textSha256':sha(t.encode()),'quote':quote,'quoteStart':a,'quoteEnd':b,'offsetUnit':'Unicode code points in source JSON text, zero-based half-open','supports':claims}
def ck(status,reason):return {'status':status,'reason':reason}
notes={
'GSC-001':[
'共享文件与每台单独复制块卷的差异是同一份数据是否被共同访问，机制可理解；但不能从共享直接推出任意写入立即可见。',
'一个主要任务：为共享持续更新文件选择共同文件系统，并说明独立副本不能自动互相更新；不要求背NFS配置。',
'当前正文足以迁移共享与副本的差异，但若改变为文件仍打开且未同步，原题面的立即可见承诺不成立。',
'答出共同挂载EFS及共享一份文件的原因即可；网络配置和协议版本不属于题面必答。',
'Linux和共同文件访问由场景给出；严格“立即可见”所需的NFS关闭/打开或同步写前提未给定。'],
'GSC-002':[
'因果是Regional数据跨AZ冗余，而多个客户端AZ不能改变One Zone的数据位置；不是只背两种名称。',
'一个取舍：要求经受AZ整体故障时选Regional并解释跨AZ保存数据。',
'若只要求抵御单盘或主机故障且接受AZ级损失，当前提醒足以说明原来的Regional必要条件已改变；不把One Zone说成毫无冗余。',
'自评核心是Regional加跨AZ数据冗余；安排挂载路径是使用前提，不新增完整网络部署评分项。',
'AZ通过场景里的故障域直接说明用途；挂载承接本批GSC-001共同访问文件，不隐藏IAM/路由等配置知识。'],
'GSC-005':[
'完整数据集持续亚毫秒是选择SSD的决定条件；并行文件处理解释Lustre用途，HDD及热点缓存的差异说明边界。',
'回忆Lustre SSD这一个选型及为什么全量低延迟需要SSD；介质比较围绕同一个任务。',
'把条件改为仅热点低延迟，卡面可解释原来的全量SSD必要性减弱；没有要求仅凭本卡选出未教的具体替代存储类型。',
'须答Lustre和SSD以及全数据集一致亚毫秒理由；小随机I/O是辅助适配说明，不是题面额外问项。',
'计算节点并行处理、SSD热读由文字说明，不要求已会配置Lustre客户端或条带参数。'],
'GSC-006':[
'S3对象映射为文件供HPC访问、处理结果通过导出回S3，输入和结果的路径清楚。',
'单个数据衔接任务：关联S3并把结果导出；是同一流程的必要两端，不是多服务配置清单。',
'若只要求读取S3且无新结果持久化，当前导出说明可推出无需为不存在的新结果安排导出；关联本身不保证自动回写。',
'自评包括关联S3供文件访问及明确导出结果；不要求同时启用自动导出和手动任务。',
'S3和文件访问已在题面给定，“关联”的作用在考点解释；未隐藏必须会某一种导出策略配置的先修。'],
'GCL-022':[
'复制数据和替换故障服务器解释persistent为何适合长期数据；scratch不复制解释风险。',
'一个取舍：按能否容忍文件服务器故障丢数据选择persistent或scratch。',
'改为短期可重算中间数据后，卡面足以解释scratch可被考虑；不把高性能与持久性混为一谈。',
'须答persistent及复制/故障保护的原因；不要求恢复步骤或异地容灾。',
'scratch/persistent各自行为在背面解释，文件服务器故障由题面给定，无未教组合步骤。'],
'GSC-007':[
'Linux/Windows使用不同接口但访问同一份数据，说明多协议存储的用途；权限不会因支持协议而自动一致。',
'单个选型判断：需要NFS与SMB访问同一数据时考虑ONTAP。',
'若两个客户端都用NFS，当前卡面可推出多协议不再是必要条件；并未宣称ONTAP是所有共享文件场景唯一服务。',
'选ONTAP并说明同一数据可通过NFS和SMB访问即可；“配置权限”是访问前提，未强求背身份映射命令。',
'两个协议各自服务哪个客户端由正面直接给定；数据接口的作用已解释，用户身份/文件权限提醒不要求独立管理知识。'],
'GSC-009':[
'热点留性能层、冷数据去容量层的机制解释减少SSD容量与保留热读性能如何兼容。',
'一个决定：访问冷热分明时采用分层；没有把各种分层策略压成配置清单。',
'若改为所有冷数据也必须始终SSD级低延迟，提醒直接说明容量层不再满足该保证。',
'答出冷数据分层及活跃数据由SSD承担的因果即可；不要求背具体冷却天数或费率。',
'性能层和容量层在卡内分别通过用途解释，SSD在本批已用于低延迟，不依赖未教策略名。'],
'GSC-010':[
'主数据位置决定全量本地读取能力；cached仅保留热点的差异与已认可stored/cached基准一致。',
'一个取舍和关键原因；容量符合配额已给定，不纳入必答。',
'代表迁移见transferTests：只需热点本地并接受未命中云端时，可考虑cached，原因由当前可见提醒直接给出。',
'须答stored与完整数据本地及AWS异步备份的机制；不用复述配额前提。',
'Volume Gateway作为比较对象已给定，stored/cached的数据位置在卡内解释，不要求先学iSCSI。'],
'GSC-011':[
'从恢复点创建真正可挂载的块卷，再交给EC2使用，解释快照与S3普通文件桶的区别。',
'一个恢复任务：快照→EBS卷→EC2；没有要求执行完整灾备部署。',
'若已有可挂载EBS卷，当前创建卷步骤的目的可解释为什么可从挂载开始；不从本卡推出任何S3桶可直接挂盘。',
'必须说出从快照创建EBS卷并附加EC2，原因是快照不是可直接挂载的磁盘；警告中的容量/Region/AZ核对不是额外必答。',
'“已有兼容EBS快照”明确给定恢复兼容前提；块设备用EC2能挂载的设备解释。本卡不承担容量、跨Region复制或AZ详细配置教学。'],
'GSC-013':[
'虚拟磁带库和磁带设备接口解释怎样保留原备份软件流程而摆脱实体磁带。',
'一个接口适配选型：现有磁带备份软件需要Tape Gateway。',
'若原软件要文件接口而非磁带设备，当前提醒可推出应按文件接口另选；不因都叫Gateway混用。',
'选Tape Gateway并说出向原软件呈现虚拟磁带设备即可；不要求背磁带数量、归档层或检索时限。',
'“虚拟磁带库”的用途通过原软件看到磁带设备说明；File/Volume的不同接口已随文解释。']}
ev={}
ev['GSC-001']=[q('S0076','With Amazon EFS,','(NFSv4) protocol.',['answerZH共同挂载EFS','keyPointZH通过NFS读写']),q('S0076','You can access your EFS','share a common data source.',['keyPointZH同一份共享文件']),q('EBS-create','If you create a volume from a snapshot,','used to create that snapshot.',['独立副本只是创建时复制，非共同访问同一文件系统；与共享源比较的推导']),q('EFS-features','Amazon EFS provides the close-to-open','read-after-write consistency for data access.',['反证frontZH绝对立即可见：需要关闭/重新打开或特定同步访问条件'])]
ev['GSC-002']=[q('EFS-features','Regional – Regional file systems','file systems might be lost.',['answerZH Regional','keyPointZH跨AZ与单AZ数据保护边界']),q('S0076','To access your EFS file system','Availability Zone share that mount target.',['answerZH安排客户端AZ挂载路径']),q('S0076','The following illustration shows multiple EC2 instances accessing a One Zone','single mount target.',['watchOutZH多AZ访问不改变One Zone数据范围'])]
ev['GSC-005']=[q('S0139','The Lustre file system is designed','millions of IOPS.',['answerZH Lustre','keyPointZH并行高性能文件用途']),q('S0139','The SSD storage class is optimized','20% of your HDD storage capacity.',['answerZH SSD','keyPointZH全量亚毫秒/小随机操作','watchOutZH HDD与热点SSD缓存的延迟区别'])]
ev['GSC-006']=[q('S0139','When linked to an Amazon S3 bucket,','its durable data repository on Amazon S3.',['answerZH关联S3、按文件访问并回写','keyPointZH S3对象呈现成文件']),q('Lustre-export-current','You can export changes','When you export files or directories using an export data repository task, your file system exports only data files and metadata that were created or modified since the last export.',['answerZH导出结果','keyPointZH导出任务','watchOutZH关联不等于无条件自动回写，必须选择导出方法'])]
ev['GCL-022']=[q('S0139','Scratch file systems are ideal','if they fail.',['answerZH persistent','keyPointZH复制与替换/ scratch不复制','watchOutZH短期可重算与持久保护区别'])]
ev['GSC-007']=[q('ONTAP-multiprotocol','Concurrent access to this data requires','using both the AWS Management Console and NetApp ONTAP CLI .',['answerZH选ONTAP多协议','keyPointZH同一份数据由Linux NFS与Windows SMB访问']),q('ONTAP-multiprotocol','User identity mapping is the process','vice versa.',['watchOutZH跨系统用户身份配置']),q('ONTAP-multiprotocol','Security style determines','any security style can be used for concurrent Windows and Linux access.',['answerZH文件权限前提','watchOutZH支持协议不等于权限自动正确'])]
ev['GSC-009']=[q('ONTAP-storage-capacity','SSD tier –','cost-optimized for your infrequently accessed data.',['keyPointZH性能层与容量层各自用途']),q('ONTAP-storage-capacity','A tiering policy ,','each volume on your file system.',['answerZH数据分层','keyPointZH减少为冷数据买SSD']),q('ONTAP-performance','Amazon FSx for NetApp ONTAP provides sub-millisecond','latency for capacity pool storage.',['watchOutZH容量层性能与SSD不同']),q('S0061','Capacity pool storage consumption','Capacity pool requests (per read and write)',['watchOutZH容量层访问费用'])]
ev['GSC-010']=[q('S0405','By using stored volumes,','offsite backups.',['answerZH stored','keyPointZH本地完整数据和AWS异步备份']),q('S0405','By using cached volumes,','frequently accessed data.',['watchOutZH S3主存与热点本地缓存']),q('S0405','If your application requests data,','before checking Amazon S3.',['watchOutZH缓存未命中访问云端'])]
ev['GSC-011']=[q('S0405','You can also use the snapshot','an Amazon EC2 instance.',['answerZH从Volume Gateway快照创建EBS卷再附加EC2']),q('S0416','When creating a volume from a snapshot,','that specific point intact.',['keyPointZH快照是恢复点']),q('S0426','After you attach an Amazon EBS volume','exposed as a block device.',['keyPointZH附加EBS得到块设备']),q('S0405','All gateway data and snapshot data for cached volumes','such as the Amazon S3 Management Console.',['watchOutZH备份不是普通可直接读取S3桶']),q('S0117','The volume and instance must be','the same Availability Zone.',['watchOutZH AZ约束；兼容前提已给定，不要求背核对清单'])]
ev['GSC-013']=[q('S0194','Tape Gateway offers','applications as iSCSI devices.',['answerZH Tape Gateway','keyPointZH现有磁带备份软件使用虚拟磁带设备']),q('S0194','Virtual tape –','Amazon Web Services Cloud.',['keyPointZH虚拟磁带数据由AWS保存']),q('S0290','AWS Storage Gateway offers','application servers.',['watchOutZH文件、块卷和磁带接口不同'])]
results=[]
for card in cards:
 rid=card['ruleId']; n=notes[rid];checks={'FACT':ck('FAIL' if rid=='GSC-001' else 'PASS','EFS默认close-to-open，题面无关闭/同步写前提却承诺“立即看到彼此写入”；核心EFS共享选型正确，绝对时效条件不成立。' if rid=='GSC-001' else '已逐句核对答、机制及提醒；下列官方原句分别绑定相关声明。'),'B1':ck('NOT_APPLICABLE','本轮仅冻结中文短稿，无英中文本对齐验收。'),'U1':ck('PASS',n[0]),'R1':ck('PASS',n[1]),'T1':ck('FAIL' if rid=='GSC-001' else 'PASS',n[2]),'S1':ck('PASS',n[3]),'P1':ck('FAIL' if rid=='GSC-001' else 'PASS',n[4])}
 body={k:card.get(k,'') for k in ['frontZH','answerZH','keyPointZH','watchOutZH']}
 entry={'ruleId':rid,'bodySha256':sha(canon(body)),'inputCardSha256':sha(canon(card)),'verdict':'FAIL' if rid=='GSC-001' else 'PASS','checks':checks,'evidence':ev[rid],'minimalCorrection':None}
 if rid=='GSC-001':entry['minimalCorrection']={'affectedFields':['frontZH'],'instruction':'删除无条件“立即”，将任务明确为多实例需要共享持续更新的一份文件；如确需验证即时可见，则给定写端关闭文件、读端重新打开等适用前提，不暗示所有未同步写入立即可见。','reason':'仅修实际一致性条件；无需另加协议配置清单或新卡。'}
 results.append(entry)
report={'schemaVersion':1,'reviewer':'actual_cards_review independent current-body review','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(mp),'inputManifestSha256':sha(mp.read_bytes()),'inputFiles':manifest,'hashAlgorithm':'SHA-256; body/inputCard canonical JSON ensure_ascii=False, sort_keys=True, separators=(comma,colon), UTF-8; body fields frontZH, answerZH, keyPointZH, watchOutZH','scope':{'rules':['V1','V2','V6 bindings only'],'checks':['FACT','U1','R1','T1','S1','P1'],'B1':'NOT_APPLICABLE Chinese-only draft','V3':'NOT_EVALUATED: this packet has no frozen original stems/options and related visible card groups; no full-question support upgrade','V4':'NOT_EVALUATED globally: no deletion/merging decision or global reuse sufficiency proof','V5':'No original question conditions rewritten; only current-card factual conditions checked','learnerMemoryOrCorrectness':'NOT_MEASURED','publication':'none'},'summary':{'total':10,'pass':9,'fail':1,'unknown':0,'defectCount':1},'cards':results,'transferTests':[{'ruleId':'GSC-010','status':'PASS','changedCondition':'不要求全量主数据本地；只需热点低延迟，接受未命中云端读取。','expectedReasoning':'可考虑cached，因为当前提醒明确S3为主存、缓存命中本地、未命中回云端；完整数据本地条件取消后，stored不再是唯一满足条件的模式。','visibleBasis':cards[7]['watchOutZH']},{'ruleId':'GCL-022','status':'PASS','changedCondition':'工作集是短期中间结果，文件服务器故障后可从持久源重新计算。','expectedReasoning':'scratch可被考虑，因为不复制带来的丢失风险在可重算条件下可接受；persistent的长期保护不再是必须。','visibleBasis':cards[4]['keyPointZH']+' '+cards[4]['watchOutZH']}],'sourceAccessNotes':['Prior PASS was not used as semantic proof. Existing official snapshots verified against catalog file/text SHA-256 and copied unchanged into evidence/cards-c.','Online supplementary sources downloaded with curl TLS verification, full HTML plus normalized-text JSON retained. Failed/redirected EFS-architecture and Lustre-export snapshots are not cited or accepted as fact evidence.','No authoring, CLI/API model call, formal inventory or production pointer mutation.']}
for e in report['cards']:
 for z in e['evidence']:
  d=json.loads(pathlib.Path(z['sourcePath']).read_text());assert d['text'][z['quoteStart']:z['quoteEnd']]==z['quote'];assert sha(pathlib.Path(z['sourcePath']).read_bytes())==z['sourceFileSha256']
(R/'batch01.review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
md=['# 首批当前中文卡独立审查','',f'冻结输入：`{mp}`',f'输入manifest SHA-256：`{report["inputManifestSha256"]}`','','10张逐卡事实及教学审查：9 PASS，1 FAIL，0 UNKNOWN。B1不适用；原题卡组充分性、全库复用与学习者实际效果未验收。','','| 卡 | 结果 | 主要判断 |','|---|---|---|']
for c in results:md.append(f'| {c["ruleId"]} | {c["verdict"]} | '+('“立即看到写入”超过EFS默认close-to-open语义；仅收窄题面时效条件。' if c['verdict']=='FAIL' else notes[c['ruleId']][1])+' |')
md+=['','两项代表迁移：stored→热点缓存条件、persistent→可重算临时数据条件，均可由当前可见正文解释选择变化。','','GSC-001官方反证：AWS文档明确“Amazon EFS provides the close-to-open consistency semantics that applications expect from NFS.” 对同步且非追加写入才说明read-after-write保证。应删除无条件“立即”或明确关闭/重新打开等前提。','','完整逐卡七项记录、AWS原句/URL/本地快照哈希/字符偏移、当前正文哈希均在同名JSON。旧审查未代替当前事实核对；未改卡面、库存、生产指针或预算。']
(R/'batch01.review.md').write_text('\n'.join(md)+'\n')
print(json.dumps(report['summary']));print('review',R/'batch01.review.json')

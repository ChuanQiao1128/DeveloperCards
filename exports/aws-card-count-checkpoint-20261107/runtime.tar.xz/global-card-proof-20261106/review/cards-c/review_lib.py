import json,pathlib,hashlib,datetime
V=pathlib.Path(__file__).resolve().parents[2];R=V/'review/cards-c';E=V/'evidence/cards-c'
CAT=V.parent/'domain1-final-card-catalog-20261105/official-sources.catalog.json'
CAT_SHA='075e4ccb5950c71686a18dd9187c0efb5986252a513836a0eeb23b3288d6854f'
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
assert sha(CAT.read_bytes())==CAT_SHA
catalog=json.loads(CAT.read_text())
def source(key):
 p=E/(key+'.json');orig=p
 row=next((r for r in catalog if r['sourceKey']==key),None)
 if row:
  orig=pathlib.Path(row['sourcePath']);b=orig.read_bytes();assert sha(b)==row['fileSha256']
  if not p.exists():p.write_bytes(b)
  assert p.read_bytes()==b
 d=json.loads(p.read_text());assert len(d['text'])>100
 if row:assert sha(d['text'].encode())==row['textSha256']
 return p,d,orig
def q(key,start,end,claims):
 p,d,o=source(key);t=d['text'];assert start in t,(key,'start',start);a=t.index(start);assert end in t[a:],(key,'end',end);b=t.index(end,a)+len(end)
 return {'sourceKey':key,'url':d.get('url'),'sourcePath':str(p),'sourceFileSha256':sha(p.read_bytes()),'originalSourcePath':str(o),'textSha256':sha(t.encode()),'quote':t[a:b],'quoteStart':a,'quoteEnd':b,'offsetUnit':'Unicode code points in source JSON text, zero-based half-open','supports':claims}
def ck(status,reason):return {'status':status,'reason':reason}
def write_review(batch,notes,evidence,transfers,failures=None,qualifications=None):
 failures=failures or {};qualifications=qualifications or {};mp=R/'input'/f'{batch}.manifest.json';manifest=json.loads(mp.read_text());assert all(sha(pathlib.Path(p).read_bytes())==h for p,h in manifest.items())
 cp=next(pathlib.Path(p) for p in manifest if '/drafts/' in p or p.endswith('.cards.json'));cards=json.loads(cp.read_text());results=[]
 for card in cards:
  rid=card['ruleId'];n=notes[rid];assert len(n)==5;f=failures.get(rid);checks={'FACT':ck('PASS','逐句核对答、因果与边界，见本卡完整官方摘录绑定。'),'B1':ck('NOT_APPLICABLE','仅冻结中文短稿，无双语对齐验收。')}
  for k,note in zip(['U1','R1','T1','S1','P1'],n):checks[k]=ck('PASS',note)
  if f:
   for k,reason in f['checks'].items():checks[k]=reason if isinstance(reason,dict) else ck('FAIL',reason)
  body={k:card.get(k,'') for k in ['frontZH','answerZH','keyPointZH','watchOutZH']}
  results.append({'ruleId':rid,'bodySha256':sha(canon(body)),'inputCardSha256':sha(canon(card)),'verdict':'FAIL' if f else 'PASS','checks':checks,'evidence':evidence[rid],'minimalCorrection':f.get('minimalCorrection') if f else None,'qualifications':qualifications.get(rid,[])})
 report={'schemaVersion':1,'reviewer':'actual_cards_review independent current-body review','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(mp),'inputManifestSha256':sha(mp.read_bytes()),'inputFiles':manifest,'sourceCatalogBinding':{'path':str(CAT),'fileSha256':CAT_SHA,'basis':'same official-source catalog explicitly supplied by parent task'},'hashAlgorithm':'SHA-256; body/inputCard canonical JSON ensure_ascii=False, sort_keys=True, separators=(comma,colon), UTF-8; body fields frontZH, answerZH, keyPointZH, watchOutZH','scope':{'rules':['V1','V2','V6 bindings only'],'checks':['FACT','U1','R1','T1','S1','P1'],'B1':'NOT_APPLICABLE Chinese-only draft','P1':'Prerequisite comprehension, not full-question support','V3':'NOT_EVALUATED: no frozen original stems/options plus related visible card group in this packet','V4':'NOT_EVALUATED globally: no global deletion/reuse proof','V5':'No original question conditions rewritten; current-card conditions checked','learnerMemoryOrCorrectness':'NOT_MEASURED','publication':'none'},'summary':{'total':len(results),'pass':sum(x['verdict']=='PASS' for x in results),'fail':len(failures),'unknown':0,'defectCount':len(failures)},'cards':results,'transferTests':transfers,'sourceAccessNotes':['Existing catalog sources verified against file/text SHA-256; sourceKeys used only as retrieval clues, not semantic evidence.','Each technical claim checked against actual quoted source text; supplementary official sources retain complete HTML and extracted-text JSON.','No prior semantic PASS substituted, no authoring/model CLI/API, no original source/question/inventory/pointer/study-record/budget mutation.']}
 for x in results:
  for z in x['evidence']:
   p=pathlib.Path(z['sourcePath']);d=json.loads(p.read_text());assert sha(p.read_bytes())==z['sourceFileSha256'];assert d['text'][z['quoteStart']:z['quoteEnd']]==z['quote']
 (R/(batch+'.review.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 md=[f'# {batch} 当前中文卡独立审查','',f'输入manifest SHA-256：`{report["inputManifestSha256"]}`','',f'{len(results)}张逐项：{report["summary"]["pass"]} PASS，{len(failures)} FAIL，0 UNKNOWN。B1不适用，整题支撑/全库复用/学习者表现未验收。','','| 卡 | 结果 | 审查重点 |','|---|---|---|']
 for x in results:md.append(f'| {x["ruleId"]} | {x["verdict"]} | '+(str(next(iter(failures[x['ruleId']]['checks'].values()))) if x['ruleId'] in failures else notes[x['ruleId']][0])+' |')
 md+=['',f'代表条件迁移{len(transfers)}项，结果见JSON。逐卡原句、URL、来源路径/哈希/字符偏移及当前正文哈希均已绑定；未改正文或生产状态。']
 (R/(batch+'.review.md')).write_text('\n'.join(md)+'\n');print(json.dumps(report['summary']));return report

from review_lib import *
notes={
'GSC-085':['同一订单ID归同一消息组已成为明确动作；消息组的用途与端到端顺序因果清楚。','一个按业务键保持顺序的判断，未扩成完整消息配置。','换不同订单ID后，提醒明确不要求全局串行；组内消息顺序仍须相关环节共同保留。','须答SNS FIFO到SQS FIFO及同订单同组，解释末端不能恢复已打乱顺序；分组动作现可自评。','message group随中文消息组用途解释，原术语先修缺口已闭合。'],
'GSC-087':['跨AZ适用副本在节点/AZ故障后继续服务，已补出为什么集群提供保护。','一个高可用部署取舍，不考完整RabbitMQ HA配置。','单个AZ故障而其他适用副本可用时，正文直接解释仍能继续；单节点不具相同AZ保护。','须答跨AZ多节点及适用队列复制，并说副本提供继续服务；不背所有队列类型。','提醒明确版本/队列复制机制必须适用，不把任意集群队列都假定同样复制；新增机制在卡内说明。'],
'GCL-028':['已移除原题/覆盖账本提醒；当前只讲静态PV/PVC与Fargate动态供给限制。','一个EKS Fargate存储接入判断，回忆负担没有未问审计任务。','换离Fargate的支持环境时，当前限定不能外推为所有EKS都不支持动态供给。','答静态PV/PVC并说明Fargate限制即可，已移除提醒无评分项。','PV/PVC用途随文解释，无突现的StorageClass先修。'],
'GSC-108':['已明确既有A2I资格；低置信度由人工判断补充，当前审核与未来训练区别清楚。','一个不确定样本复核判断，服务例被限定为已有资格。','改为新客户时，当前提醒明确不能假设能开通A2I；人工复核需求仍可用其他合适流程实现。','答按条件送人工审核及补判断的原因，不把重训当当前样本已经确认。','已有资格在正面给定，human review loop紧随人工审核流程解释，不再隐去现行资格条件。']}
e={
'GSC-085':[q('SNS-FIFO-order-current','An Amazon SNS FIFO topic always delivers','more than once.',['answerZH端到端FIFO顺序']),q('SNS-FIFO-groups','Messages that belong to the same group','subscribed Amazon SQS FIFO queues.',['answerZH同订单消息归同组','keyPointZH组内有序']),q('SNS-FIFO-groups','Amazon SNS FIFO topics deliver messages from different message groups','within each message group.',['watchOutZH非跨所有订单全局串行'])],
'GSC-087':[q('MQ-rabbitmq-architecture','A cluster deployment is a logical grouping','different Availability Zones for better durability.',['answerZH跨AZ集群与队列复制','keyPointZH适用副本提供故障保护']),q('S0133','An active/standby broker\nis comprised','configured in a redundant pair.',['frontZHActiveMQ主备另一部署模式'])],
'GCL-028':[q('EKS-EFS-CSI','You can’t use dynamic provisioning','but you can use static provisioning .',['answerZH Fargate静态路径及动态不支持']),q('EKS-PV-PVC','A PersistentVolume (PV) is a piece of storage','ReadWriteMany).',['keyPointZH PV/PVC用途'])],
'GSC-108':[q('A2I-human-review-current','Amazon SageMaker A2I is no longer open to new customers.','continue to use the service as normal.',['frontZH既有资格','watchOutZH新客户不能假设开通']),q('A2I-human-review-current','When you use AI applications such as Amazon Rekognition,','human review of low-confidence predictions or random prediction samples.',['answerZH低置信度人工复核','keyPointZH人工补当前判断']),q('A2I-human-review-current','Use Amazon A2I to review real-time ML inferences','incrementally train your model using Amazon A2I output data.',['watchOutZH复核当前结果与增量训练不同'])]}
t=[{'ruleId':'GSC-085','status':'PASS','changedCondition':'两条消息属于不同订单ID，不要求彼此顺序。','expectedReasoning':'可归不同消息组并独立处理，组内顺序仍有保证；不用令所有订单全局串行。','visibleBasis':'顺序只在相应消息组内保证，不要求所有订单ID之间全局串行。'},{'ruleId':'GSC-087','status':'PASS','changedCondition':'一个AZ不可用，但其他AZ中适用的队列副本仍健康。','expectedReasoning':'当前机制说明这些副本可继续提供队列服务；若没有适用复制的单节点则存在单点风险。','visibleBasis':'适用副本分散在不同AZ，一个节点或AZ失效后，其他副本可继续提供队列服务。'}]
r=write_review('repair03',notes,e,t)
lineage=[]
for rid,batch in [('GSC-085','batch10'),('GSC-087','batch10'),('GCL-028','batch11'),('GSC-108','batch13')]:
 prior=R/(batch+'.review.json');lineage.append({'ruleId':rid,'repairOf':batch+':'+rid,'priorReviewPath':str(prior),'priorReviewSha256':sha(prior.read_bytes()),'priorVerdict':'FAIL','currentVerdict':'PASS','currentBodySha256':next(c['bodySha256'] for c in r['cards'] if c['ruleId']==rid)})
r['repairLineage']=lineage;r['reReviewScope']='Only four changed cards; unchanged prior accepted cards not rerun; original failures retained.'
(R/'repair03.review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')

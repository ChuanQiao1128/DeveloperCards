import pathlib,json,hashlib,datetime,collections
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106')
I=V/'review/supplemental06/input';R=V/'review/cards-c';E=V/'evidence/cards-c/supplemental06'
def ca(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
mp=I/'manifest.json';M=json.loads(mp.read_text())
for p,h in M.items():assert sha(pathlib.Path(p).read_bytes())==h,p
raw=json.loads((I/'cards.json').read_text());pool={c['ruleId']:c for c in json.loads((I/'visible-pool.frozen.json').read_text())}
qs=json.loads((I/'questions.json').read_text());qby={q['qid']:q['question'] for q in qs}
provided=json.loads((I/'official-evidence.json').read_text())
cat=json.loads((V/'inputs/supplemental-catalogue06.proposed.json').read_text())
assert len(raw)==9 and len(pool)==351 and len(qs)==12
for c in pool.values():assert sha(ca(c['visibleBody']))==c['bodySha256']
fields=['frontZH','answerZH','keyPointZH','watchOutZH']
bodies={c['ruleId']:{f:c[f] for f in fields} for c in raw}
hashes={rid:sha(ca(b)) for rid,b in bodies.items()}
for c in raw:
 if 'repairOf' in c:assert pool[c['ruleId']]['bodySha256']==c['repairOf']
 else:assert c['ruleId'] not in pool
for e in provided:
 p=pathlib.Path(e['snapshotPath']);d=json.loads(p.read_text());t=d['text']
 assert sha(p.read_bytes())==e['snapshotSha256'] and sha(t.encode())==e['textSha256']
 assert t[e['quoteStart']:e['quoteEnd']]==e['quote']
registry={}
def ev(p,quote,support,receipt=None):
 p=pathlib.Path(p);d=json.loads(p.read_text());t=d['text'];i=t.index(quote)
 k=sha(ca([str(p),quote,support]))
 registry[k]={'sourcePath':str(p),'sourceFileSha256':sha(p.read_bytes()),'textSha256':sha(t.encode()),
 'url':d['url'],'quote':quote,'quoteStart':i,'quoteEnd':i+len(quote),'supports':support,'reusedReceipt':receipt}
 return k
def src(n):return pathlib.Path(provided[n]['snapshotPath'])
def new(name):return E/(name+'.json')
evidence={}
evidence['instant']=ev(src(6),'S3 Glacier Instant Retrieval ( GLACIER_IR ) – Use for long-term data that\'s rarely accessed and requires milliseconds retrieval.','GIR长期低频且即时读取')
evidence['onezone']=ev(src(6),'Amazon S3 stores the object data in only one Availability Zone,','One Zone-IA单AZ范围')
evidence['archive']=ev(src(6),'These storage classes require minimum storage durations and retrieval fees making them most effective for rarely accessed data.','归档层要比较最低保留与取回费')
evidence['expedited']=ev(src(0),'Objects under 250 megabytes in size are typically made available within 1–5 minutes,','Expedited的<250MB和通常1-5分钟边界')
evidence['large']=ev(src(0),'objects 250 megabytes or larger in size are typically retrieved with up to 300 megabytes per second of retrieval throughput.','大对象取回受吞吐影响')
evidence['standard12']=ev(src(0),'Standard retrievals typically finish within 12 hours for the S3 Glacier Deep Archive storage class','Deep Archive Standard典型12小时')
evidence['bulk48']=ev(src(0),'these retrievals typically finish within 48 hours.','Deep Archive Bulk典型48小时')
evidence['capacity']=ev(src(0),'Provisioned Capacity helps ensure that Expedited retrieval capacity is available when you need it.','预置取回容量保证可用容量而非任意端到端SLA')
oldrp=V/'review/reuse-a/batch18.review.json';oldd=json.loads(oldrp.read_text())
oldcard=next(c for c in oldd['results'] if c['ruleId']=='GSC-078')
assert oldcard['bodySha256']==pool['GSC-078']['bodySha256'] and oldcard['status']=='PASS'
oe=oldd['evidenceRegistry'][oldcard['evidenceIds'][0]];op=pathlib.Path(oe['sourcePath'])
assert sha(op.read_bytes())==oe['sourceFileSha256']
evidence['colocate']=ev(op,"Minimize data movement between services by processing data close to where it's stored when possible.",'GSC078未改的靠近数据处理事实',
 {'reviewPath':str(oldrp),'reviewSha256':sha(oldrp.read_bytes()),'oldBodySha256':oldcard['bodySha256'],'claimLevelOnly':True})
evidence['dxprice']=ev(src(1),'Data transfer out rate $0.02 per GB','官方DX适用路径的付费出站示例，不泛化全部Region')
evidence['freeInternet']=ev(new('ec2-egress-pricing'),'AWS customers receive 100 GB of free data transfer out to the internet free each month,','Internet免费额度使最低出站费需要总量/剩余额度')
evidence['emr']=ev(new('emr-what'),'simplifies running big data frameworks, such as Apache Hadoop and Apache Spark, on AWS','EMR托管Hadoop/Spark框架')
evidence['outposts']=ev(src(9),'Beginning with Amazon EMR 5.28.0, you can create and run EMR clusters on AWS Outposts.','EMR支持适用Outposts')
evidence['onsite']=ev(src(9),'AWS Outposts enables native AWS services, infrastructure, and operating models in on-premises facilities.','Outposts现场基础设施')
evidence['lor']=ev(new('alb-routing'),'routes requests to the targets with the\nlowest number of in progress requests.','LOR按实际在途请求数路由')
evidence['request']=ev(src(10),'RequestCount The number of requests processed over IPv4 and IPv6.','RequestCount请求计数')
evidence['response']=ev(src(10),'TargetResponseTime The time elapsed, in seconds, after the request leaves the load balancer until the target starts to send the response headers.','TargetResponseTime到响应头开始，不误称完整响应体耗时')
evidence['connections']=ev(src(10),'ActiveConnectionCount The total number of concurrent TCP connections active from clients to the load balancer and from the load balancer to targets.','连接数不是响应耗时')
evidence['replicate']=ev(src(11),'The destination buckets can be in different AWS Regions or within the same Region as the source bucket.','SRR/CRR位置边界')
evidence['crossaccount']=ev(src(11),'Buckets that are configured for object replication can be owned by the same AWS account or by different accounts.','同/跨Region可跨账户')
evidence['historical']=ev(src(11),"Live replication doesn't replicate any objects that existed in the bucket before you set up replication.",'live不补历史')
evidence['batch']=ev(src(11),'use S3 Batch Replication.','历史对象补复制')
evidence['srrlogs']=ev(src(11),'Aggregate logs into a single bucket','SRR同Region集中日志用途')
evidence['ioprice']=ev(src(4),'with no additional charges for read and write I/O operations.','Aurora I/O-Optimized不另收存储读写I/O请求费')
evidence['io25']=ev(src(4),'Aurora I/O-Optimized is the best choice when your I/O spending is 25% or more of your total Aurora database spending.','I/O费用比例而非仅总流量决定选择')
evidence['standard25']=ev(src(4),'Aurora Standard is the best choice when your I/O spending is less than 25% of your total Aurora database spending.','Standard适用另一分支')
t=json.loads(src(8).read_text())['text'];section=t.rfind('Amazon RDS Reserved Instance purchase recommendations');end=t.find('Amazon Redshift reserved node',section)
assert section>=0
scopequote='This check generates recommendations at payer scope for the payer account and at linked scope for a linked account .'
scopeidx=t.index(scopequote,section);assert scopeidx<end
evidence['taScope']=ev(src(8),t[section:scopeidx+len(scopequote)],'现行RDS RI purchase recommendations明确payer/linked范围')
prereqquote='To use this check, you must opt in to Cost Optimization Hub .'
prereqidx=t.index(prereqquote,section);assert prereqidx<end
evidence['taPrereq']=ev(src(8),t[section:prereqidx+len(prereqquote)],'RDS RI检查所需COH前提；直接绑定同一RDS章节')
evidence['taId']=ev(src(8),t[t.index('Check ID c1z7kmr11n',section):t.index('Check ID c1z7kmr11n',section)+len('Check ID c1z7kmr11n')],'当前RDS RI检查ID')
evidence['riCharge']=ev(src(7),'The remaining hours in the term are billed at a discounted hourly rate, regardless of usage.','RDS RI合同费用不按实际开机取消')
evidence['rdsUpfront']=ev(new('rds-ri-payments'),'All Upfront RIs offer the highest discount of all of the RI payment options','RDS RI匹配供给下全预付折扣最深')
evidence['spUpfront']=ev(new('savingsplans-payments'),'With the All Upfront option, you will receive the lowest prices and your entire commitment will be charged in one payment.','适用SP全预付价最低')
evidence['spLonger']=ev(new('savingsplans-commitment'),'you can choose the 3-year Savings Plans for even deeper cost savings.','较长期限的SP比较示例')
evidence['spCommit']=ev(new('savingsplans-commitment'),"The hourly financial commitment can't be canceled or changed during the term of your plan,",'SP小时承诺不能因停机取消')
evidence['spException']=ev(new('savingsplans-payments'),'exception: Database Savings Plans only offers one payment option','不是每类SP都能选三种付款/三年')
evidence['scheduled']=ev(src(3),'You can no longer purchase Scheduled Instances.','Scheduled Instances不能新购')
evidence['ec2riCharge']=ev(new('ec2-ri-billing'),'With Reserved Instances, you\npay for the entire term regardless of actual use.','EC2 RI也按整个承诺期限收费')
evidence['fgRestore']=ev(new('filegateway-storage-classes'),'After the object is restored to S3,\nyour file share clients can access and update them successfully through the file share.','File Gateway归档对象经恢复后重新可读，不额外虚构必须RefreshCache')

card_eids={
 'CUR:CMP-M01':['instant','onezone','archive'],
 'GSC-078':['colocate','dxprice'],
 'GSC-097':['emr','outposts','onsite'],
 'GSC-123':['lor','request','response','connections'],
 'CUR:NEW04':['replicate','crossaccount','historical','batch','srrlogs'],
 'GSC-059':['ioprice','io25','standard25'],
 'GSC-156':['taScope','taPrereq','taId'],
 'VC-006':['expedited','large','standard12','bulk48','capacity'],
 'VC-007':['riCharge','rdsUpfront','spUpfront','spLonger','spCommit','spException','scheduled','ec2riCharge']}
reasons={
 'CUR:CMP-M01':[
 'GIR即时读取、长期极少访问、最低保留/取回费与One Zone单AZ均有官方正证；没有以Glacier名字断定都需恢复。',
 '以等待容忍度及冗余先筛选，再解释存储/取回费用取舍。',
 '一个低频数据的存储层选择；即时和先恢复是同一决定条件的两分支，未堆恢复API或参数。',
 '把允许等待改为立即读取，应排除异步归档；长留极少读可比较GIR而非只背Standard-IA。',
 '评所问两种访问条件的选择和原因，不强制背完整S3费用表。',
 'Instant Retrieval的用途已随文解释为即时读；多AZ和One Zone边界来自原场景。'],
 'GSC-078':[
 '旧靠近数据减少字节的事实凭证按旧body精确复用；新增仅要求比较真实DX/Internet适用价格，不声称专线总更便宜。',
 '费用=计费字节×单价，先少搬原始数据，再对剩余路径比较价格。',
 '仍以计算靠近大数据为一个主要判断；DX价格为已存在连接时的条件边界，不另考配置。',
 '原始数据/结果大小互换时，计算位置建议可随需移动的字节改变。',
 '只评计算位置与少传字节的理由；未问专线时不追加具体Region费率必答。',
 'Direct Connect已为现卡覆盖概念；没有把端口、VIF、报价表变成隐藏先修。'],
 'GSC-097':[
 'EMR托管Hadoop/Spark与适用Outposts现场运行均有直接官方原句；不承诺Outposts无限容量。',
 '多节点拆分可并行工作；数据计算必须留现场时，用本地AWS基础设施承载同类框架。',
 '同一并行处理平台选择增加位置条件分支，未加入部署/权限/计费清单。',
 '移除现场处理要求可评估Region内EMR；保留该要求则不能仅用网络把数据送Region计算。',
 '评可拆分工作和适用平台/位置，不评Outposts硬件型号或所有前提。',
 'Outposts的作用在同卡解释为把受支持AWS基础设施放现场，Hadoop/Spark是题面既有框架。'],
 'GSC-123':[
 '指标定义和LOR均正确；TargetResponseTime按目标开始返回响应头计时，不把CloudWatch阈值误当算法输入。',
 '能解释诊断信息与请求路由控制的区别。',
 'FAIL：题面明确要求两项独立回忆——请求量/耗时的指标对，以及路由算法。知道LOR仍须额外背指标配对才答全；指标又不是算法因果输入，超过原单一路由判断及stored/cached记忆基准。',
 '改变目标积压/请求复杂度后能解释LOR选择，但诊断指标属于另一学习判断。',
 '答案与题面的两个显式问题相符；没有私加未问评分项，问题在任务本身已经变成两项。',
 'LOR含义已用未完成请求解释，指标职责也有文字说明；不另缺技术先修。'],
 'CUR:NEW04':[
 '官方明确同/跨Region、跨账户、新旧复制范围与Batch Replication；没有把Lifecycle当跨桶复制。',
 '按位置选择SRR/CRR，再按新旧范围补历史，因果清楚。',
 '一个复制范围判断，位置与历史范围是此任务的必要条件；无权限、版本号或所有配置清单。',
 '相同Region改跨Region时改SRR/CRR；规则开启前的存量仍须单独补。',
 '评所问位置/历史两条件，不加IAM/版本控制等部署清单必答。',
 'live/Batch的用途随文解释为新版本与历史补复制；不依赖私有制作记录。'],
 'GSC-059':[
 'I/O-Optimized不另收适用存储I/O请求费，Standard与I/O-Optimized由费用结构选择；不会给Aurora套普通RDS的gp3/PIOPS。',
 '较高其他单价可由省去大量I/O费抵消，说明比较总费用的原因。',
 '一个I/O成本占比与配置费用取舍，未增加独立性能参数或部署动作。',
 '只有流量增大而I/O费用比例不高时，不能自动改I/O-Optimized。',
 '只评比较两种Aurora配置总费用，不要求记25%等未问数字。',
 'I/O在题面已指存储读写费用，cluster配置范围与普通RDS卷区别已解释。'],
 'GSC-156':[
 '现行RDS RI purchase recommendations段落、check ID c1z7kmr11n、payer/linked与COH前提直接核对；未用旧检查范围覆盖新检查。',
 '合并付款视图与建议服务授权是两种控制，现行检查范围是具体实例。',
 '一个付款组织与建议可见范围的判断；例子解释条件，不考所有服务接入步骤。',
 '拥有payer权限并完成现行检查前提时可看付款范围；linked仍是本账户，不能据旧单账户规则否定payer。',
 '只评合并账单不自动给全部建议权限；例子的全部账户设置不作为未问清单。',
 '先修为既有组织/合并账单概念；COH只作为该检查明确数据来源前提，不要求在本卡学完其工作流。'],
 'VC-006':[
 '<250MB、通常1-5分钟、Deep Archive Standard12/Bulk48和预置取回容量各有官方正证；没有无条件推广分钟数。',
 '类别与档位共同决定等待，低取回费往往以时间换取，能用于期限判断。',
 '一个按期限匹配取回档位的判断，分钟/一天是同一机制的两种窗口；不拆成孤立数字卡或完整档位矩阵。',
 '把一天窗口改为两天可重新考虑Bulk；分钟场景对象变大时要重新评估吞吐，不能死背1-5分钟。',
 '评给定窗口对应档位与等待机制，不要求每次复述全部档位/数字。',
 '依赖本批CMP-M01解释即时/需恢复类别，目录已声明此依赖；不借私有sourceFinding补知识。'],
 'VC-007':[
 'RDS/EC2 RI及适用SP承诺费用、全预付折扣、较长期限比较与Scheduled退役均有官方正证；“匹配条件/先核服务”不泛化到仅一种付款的Database SP。',
 '折扣交换未来用量与付款灵活性，停机不取消合同费用，因果可理解。',
 '期限、预付、利用率都是一个承诺换折扣判断；没有把服务覆盖、规格、Region等独立配置塞入必答。',
 '未来利用率不再稳定时，不能继续因名义折扣深就买更多长期承诺。',
 '评承诺非按实际开机计费及匹配条件下较长/多预付的取舍，不评未问产品表。',
 'RI/SP费用机制在卡内解释；用于整题时服务覆盖复用GSC054/CB02，未把这些知识隐入此卡。']}
cardrows=[]
for c in raw:
 rid=c['ruleId'];checks={}
 for gate,why in zip(['FACT','U1','R1','T1','S1','P1'],reasons[rid]):
  checks[gate]={'status':'FAIL' if why.startswith('FAIL') else 'PASS','reason':why}
 checks['B1']={'status':'NOT_APPLICABLE','reason':'仅冻结中文四字段，不作双语包通过。'}
 fail=rid=='GSC-123'
 cardrows.append({'ruleId':rid,'bodySha256':hashes[rid],'priorBodySha256':c.get('repairOf'),
  'verdict':'FAIL' if fail else 'PASS','checks':checks,
  'evidenceIds':[evidence[k] for k in card_eids[rid]],
  'minimalCorrection':('保留路由选择为唯一回忆任务；把必要指标名称/用途作为题面给定的诊断背景，或复用现有知识解释，不要求在同卡额外回忆指标对；不为此自动新增一张指标卡。' if fail else None),
  'findings':[{'findingId':'S06-R1-001','gate':'R1','severity':'P1','status':'OPEN',
    'reason':'将诊断指标对和路由算法合为两个必须回忆的任务；须局部收窄。'}] if fail else []})

# Failed candidate does not replace its retained base body in question proofs.
usable={rid:{'visibleBody':c['visibleBody'],'bodySha256':c['bodySha256'],'origin':'frozen retained visible pool'} for rid,c in pool.items()}
for c in cardrows:
 if c['verdict']=='PASS':
  rid=c['ruleId'];usable[rid]={'visibleBody':bodies[rid],'bodySha256':hashes[rid],'origin':'supplemental06 PASS candidate overlay'}
assert len(usable)==353 and usable['GSC-123']['bodySha256']==pool['GSC-123']['bodySha256']
def anchor(rid,quote,support):
 c=usable[rid];hits=[(f,t.index(quote)) for f,t in c['visibleBody'].items() if quote in t];assert hits,(rid,quote)
 f,i=hits[0]
 return {'cardId':rid,'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':quote,'quoteStart':i,'quoteEnd':i+len(quote),'supports':support,'origin':c['origin']}
qrows=[]
def add(q,status,selected,anchors,reason,comparison,missing=None,source=None,eids=None,conditions=None):
 aa=[anchor(*a) for a in anchors]
 qrows.append({'qid':q,'status':status,'questionSha256':sha(ca(qby[q])),
  'fullStemAndAllOptionsRead':True,'selectedOptionOrdinals':selected if status=='SUPPORTED' else [],
  'candidateOptionOrdinals':selected if status!='SUPPORTED' else [],
  'usedRuleIds':list(dict.fromkeys(a['ruleId'] for a in aa)),'necessaryAnchors':aa,
  'reasoning':reason,'optionComparison':comparison,'missingJudgments':missing or [],
  'sourceIssues':source or [],'officialSourceIssueEvidenceIds':eids or [],
  'conditionsAndUnresolved':conditions or [],'failedCardCandidateUsed':False,
  'learnerPerformanceOrProductionSLAMeasured':False})
STORAGE=('CUR:CMP-M01','立即读取可选Standard-IA或Glacier Instant Retrieval等适用即时层；能等待恢复时，才考虑Glacier Flexible Retrieval或Deep Archive，并按阶段用Lifecycle转换。','先按读取等待选择类别并按阶段迁移')
GIR=('CUR:CMP-M01','Glacier Instant Retrieval仍能即时读，适合长保留且极少读取；存储单价更低也须比较读取费和最低保留计费。','GIR的长期极少访问条件与费用边界')
TIER=('VC-006','Flexible Retrieval的Expedited对小于250MB的对象通常1–5分钟；Deep Archive的Standard通常12小时，Bulk通常48小时，24小时预算不能选Bulk。','时限、对象大小与取回档位')
COMMIT=('VC-007','承诺期内约定费用仍需支付；在匹配条件下，较长期限、更多预付通常换取更深折扣，可比较三年全预付。','承诺全期付费与折扣取舍')
add(240,'SOURCE_ISSUE',[2,4],[
 ('GSC-078','优先让计算靠近大数据所在位置，只把较小结果传往需要的地方。','50MB结果留Region，只把500KB页面送办公室'),
 ('GSC-078','传输费用是计费路径的数据量与单价共同决定。','出站量和单价都影响最低费用'),
 ('GSC-078','须按实际路径和适用计费量比较；','不能默认任意数据量DX必便宜')],
 'B/D都将跨边界字节从每查询约50MB降为500KB。D在已用完Internet免费额度且相应DX付费费率更低时通常更省；但原文没有总月量/剩余免费额度。当前Internet每月100GB免费：例如100000次查询仅50GB页面，B可为零，而D仍可能按DX示例费率收费。无法无条件唯一选D。',
 {'1':'每次大结果出Internet。','2':'只出小页面，适用免费额度时可为零。','3':'每次大结果出DX，仍比相同费率的小页面多约100倍字节。','4':'只出小页面且利用已有DX，付费档中是强候选。'},
 source=['原文缺总量/免费额度与适用费率，不能由已有DX推导D永远最低。'],
 eids=[evidence['freeInternet'],evidence['dxprice']],
 conditions=['这是确定费用条件的缺失，不是要求实测部署SLA。'])
add(485,'UNKNOWN',[1,3,4],[STORAGE,TIER,
 ('VC-006','通常时长不是硬保证；大对象还受取回吞吐影响，严格分钟级需求要评估预置取回容量及实际对象大小。','明确的对象大小/容量边界')],
 'A的Expedited是小对象的分钟级归档方向，但原题没给视频对象大小或并发恢复容量；不能把<250MB的通常1-5分钟推成全部视频硬上限。C/D即时层也满足读取等待，D的单AZ是否可接受及恢复费用/保留时长也未说明。当前不能唯一确认最便宜。',
 {'1':'对象大小和取回容量适用时可考虑。','2':'Standard需小时，不能满足五分钟。','3':'即时访问可行，成本条件未与A/D唯一化。','4':'即时且单AZ，原文没明确可否承受AZ数据风险。'},
 conditions=['保留的是对象大小等真实条件；不因未做响应测试本身判缺卡。'])
add(673,'UNKNOWN',[2],[STORAGE,TIER,
 ('GSC-012','它在本地提供文件共享接口，把文件保存为S3对象，并缓存经常访问的数据，减少每次都从云端取回。','SMB/File Gateway与S3对象衔接')],
 'B能组织热文件本地缓存与七日后Deep Archive，选择Standard恢复档位通常12小时符合一天窗口；官方也明确恢复S3对象后共享客户端可重新访问，不能虚构必须新学RefreshCache才能恢复。但原题没有明确必须保留SMB、卸载本地历史数据或最低成本/最少维护；A复制后仍可从原SMB访问，D改为直接S3也未被明文禁止，唯一性仍不足。',
 {'1':'只说复制到AWS，未指定目的地/归档和移除本地；不能据未给目的地断言DataSync不支持。','2':'符合SMB延伸与归档方向，恢复档位需正确选择。','3':'FSx File Gateway的后端不是S3，S3生命周期不能作用于FSx文件。','4':'改变客户端直接访问S3，是否允许未写清。'},
 source=['仍需明确预期的SMB延续/本地释放/完整目标范围，未独立判某项不支持。'],
 eids=[evidence['fgRestore']],
 conditions=['不把制作补证当可见卡新知识；已有“先恢复再读”及File Gateway后端机制足以解释B的条件路径。'])
add(714,'CONDITIONAL',[4],[
 ('GSC-123','评估least outstanding requests算法，把新请求导向未完成请求较少的适用目标。','保留旧版单一路由规则'),
 ('GSC-123','它依据当前未完成工作数，而不是只按固定顺序给每个目标一轮。','路由内部依据是未完成请求而非轮流/CloudWatch阈值')],
 '按“用计数/耗时诊断，选择LOR缓解积压”的通常架构阅读，D最贴切，C/A的round robin不照顾当前积压，B的连接数也不对应响应耗时。但全部选项的based on若字面解释为算法依赖这两个CloudWatch指标，就不正确：LOR直接按未完成请求数。新GSC123因R1失败未用于支撑，只保留原算法规则和原文诊断信息。',
 {'1':'round robin且连接数不是响应耗时。','2':'算法方向对，诊断指标不匹配响应耗时。','3':'指标名方向对，算法不处理忙闲差异。','4':'诊断+算法组合方向匹配，不能把指标当路由输入。'},
 source=['based on的诊断/算法输入解释需要区分。'],
 eids=[evidence['lor'],evidence['request'],evidence['response'],evidence['connections']])
add(718,'SUPPORTED',[3],[
 ('GSC-097','若处理必须留在机房，可在受支持的Outposts上运行EMR集群。','处理地点保留现场'),
 ('GSC-097','分布式框架把可拆分计算分给多个节点；Outposts把受支持AWS基础设施放在现场，','已有Hadoop/Spark可并行处理并由本地AWS基础设施承载')],
 '原工作负载已经是Hadoop/Spark，要减少自管复杂度又保留现场计算；EMR on适用Outposts与此匹配。网络接入或搬数据不会把Region里的EMR计算变成本地计算。',
 {'1':'Region EMR计算不因VPN变为本地。','2':'DataSync搬输入不改变计算地点。','3':'现场基础设施上运行托管EMR框架。','4':'把数据搬S3再Region处理违背现场处理。'})
add(736,'SUPPORTED',[2],[
 ('CUR:NEW04','同Region选SRR，跨Region选CRR；两者可用于受支持的跨账户目标。','us-west-2跨账户集中'),
 ('CUR:NEW04','live replication处理符合规则的新版本，历史对象用Batch Replication等有效补复制。','当前已有日志补历史，后续继续复制'),
 ('CUR:NEW04','Lifecycle也不是跨桶复制器。','排除生命周期复制')],
 '选SRR将日志复制至同一Region中央桶，跨账户是支持的。已有存量按可见规则补Batch Replication，后续新版本用live；不用每次自写函数或整桶脚本。',
 {'1':'Lifecycle不复制桶间对象。','2':'支持同Region跨账户集中，按已教范围处理新旧。','3':'重复自管整桶脚本增加维护与重复操作。','4':'自写事件复制函数增加代码维护。'},
 conditions=['B是复制机制选择，不限于“只开live”；不悄悄把历史日志漏掉后宣称覆盖。'])
add(827,'SOURCE_ISSUE',[1,4],[
 ('GSC-059','I/O-Optimized不另收适用存储读写I/O请求费；I/O费用占比很高时，较高的其他单价仍可能换来更低合计。','按I/O费用占比比较'),
 ('GSC-059','仅流量大不证明总费更低；仍要按计算、存储和I/O合计比较。','原题给的流量不能代替I/O成本结构')],
 'Aurora真实配置为Standard与I/O-Optimized；原题只给大量流量，没有I/O费用比例。高流量可能是计算/缓存命中占主导，也可能存储I/O占主导，官方给出的两种成本分支不同，不能无条件选D。',
 {'1':'中低I/O费用占比时可更经济。','2':'不是给Aurora选择普通RDS Provisioned IOPS卷。','3':'同样不是普通RDS General Purpose卷选择。','4':'I/O费用占比高时可更经济。'},
 source=['缺决定性I/O费用结构，不能把traffic high替换为I/O cost high。'],
 eids=[evidence['io25'],evidence['standard25']])
add(859,'SOURCE_ISSUE',[1,2,3],[
 ('GSC-156','现行Trusted Advisor的RDS预留购买建议，payer看到付款范围、linked账户看到本账户范围，并须启用其Cost Optimization Hub前提。','当前payer与linked建议范围'),
 ('GSC-054','RDS预留折扣面向适用数据库实例；','高利用率Oracle实例可评估RDS RI')],
 '现行检查c1z7kmr11n在payer账户生成付款范围建议，在linked账户生成该账户建议，财务两侧都有权限。A+C和B+C均可用于高利用率RDS RI机会；原题Choose two没有约束必须成员逐个查询或必须单一组织汇总入口。不能拿旧单账户检查规则排除A。',
 {'1':'当前payer范围可用。','2':'当前linked自身范围也可用。','3':'购买/优化RI方向匹配高利用率。','4':'Idle DB与高利用率场景不匹配。','5':'不能用泛化Compute Optimizer代替所问RDS Oracle RI购买建议。'},
 source=['原旧Optimization名称与现行purchase recommendations的命名/范围应保留版本差异；按当前标准有不止一组可行账户选择。'],
 eids=[evidence['taScope'],evidence['taPrereq'],evidence['taId']])
add(890,'SUPPORTED',[1],[STORAGE,GIR,
 ('CUR:CMP-M01','One Zone-IA只有单AZ，不能仅因低频就替代要求多AZ的数据。','不可重建唯一数据不应退到单AZ'),
 ('GSC-024','还须满足最短保留时间及取回要求，不能把不满足访问条件的层拿来比价。','四年保留且即时读，不能改异步归档')],
 '四年长期保留、30天后极低访问且仍要即时读，符合GIR。5MB对象不是微小元数据主导案例；不能重建的文件保留多AZ，四年后应删除而不是转到需等待恢复的Flexible Retrieval。',
 {'1':'GIR长期少读但毫秒访问，按阶段到期删除。','2':'单AZ风险不适合不可重建唯一数据。','3':'也是即时多AZ，但长期极少读取时优先比较GIR的低存储费用。','4':'到四年转Flexible不能完成到期删除且改变即时读取条件。'},
 conditions=['接受的是题面长期极少访问的选型，不声明任何访问频率下GIR账单都低。'])
add(940,'CONDITIONAL',[4],[COMMIT,
 ('GSC-054','符合购买属性的RDS Reserved DB Instances。','RDS数据库与Compute SP覆盖不同'),
 ('CUR:CB02','Compute SP不自动覆盖RDS或SageMaker；','不把计算SP泛化为数据库折扣'),
 ('VC-007','先核对服务、属性和未来利用率；','长期合同要匹配未来用量')],
 'D在未来适用用量可稳定持续三年且全预付可行时，提供所列组合中更深折扣。原文long-running没有明确承诺业务会持续三年；不能把未用完承诺费用忽略后作无条件总成本结论。',
 {'1':'RDS仍On-Demand且EC2较短无预付，不是稳定三年时的最深折扣。','2':'一年无预付较浅。','3':'一年部分预付进一步降价但承诺更短。','4':'匹配持续三年及资金条件时折扣最深。'},
 conditions=['缺的是实际业务期限/利用率条件，不要求部署实测，也不新增卡片去填题干。'])
add(956,'CONDITIONAL',[4],[STORAGE,GIR,
 ('GSC-146','Spot价格优惠伴随容量被回收的风险，是否能重做或续跑决定适用性，不能只看工作负载运行多久。','短批任务不能中断时不选Spot')],
 '不能被中断的短批任务应选On-Demand。D是初期活跃访问用Standard、之后无访问长期Deep Archive的合理路线。B同样不使用Spot且GIR可即时读取；原文只说accessed for30days而非频繁读取，未给第一阶段读量，不能仅凭“30天”断言GIR取回费/最低保留总成本一定更差。',
 {'1':'Spot可被回收，违背任务不能中断。','2':'功能上即时读取也可；第一阶段费用需看读量与最低保留。','3':'同样有Spot中断风险。','4':'初期活跃读取、后期长期不读时的强候选。'},
 conditions=['若第一阶段是正常频繁/充分读取，D更匹配；没有把未给的频率私自写入原题。'])
add(1013,'UNKNOWN',[2],[
 ('VC-007','承诺期内约定费用仍需支付；','RI不会只计周日12小时'),
 ('VC-007','Scheduled Instances已不能新购，不能用旧产品名代替现行方案。','当前不能新买A的Scheduled'),
 ('GSC-146','Spot价格优惠伴随容量被回收的风险，','C/D不满足不能中断')],
 'A含不能新购的Scheduled，C/D含Spot中断风险；B是所列当前不引入Spot的候选，不能仅因A退役就宣布整题无可行项。但B给“周日12小时的实例”另购全年Convertible费用，原文又描述同一环境周一至六常开、周日运行半天，未澄清同一批实例还是两批。须避免重复承诺或把Sunday-only RI误作只付12小时；最低成本结论仍不能独立确认。',
 {'1':'Scheduled不能新购。','2':'可保持非Spot执行，但须按全承诺期及真实实例匹配评估成本。','3':'周日Spot不能满足不可中断。','4':'同样不能。'},
 source=['退役的是一个候选，不因此自动判原题源错；保留舰队/合同覆盖歧义。'],
 eids=[evidence['scheduled'],evidence['ec2riCharge']],
 conditions=['若确为同一批实例，周运行156/168≈92.86%，不应再假造独立周日实例组来替题目作答。'])
assert len(qrows)==12
new_assessment=[
 {'ruleId':'VC-006','bodySha256':hashes['VC-006'],'cardVerdict':'PASS','primaryDomain':'4','primaryTask':'4.1',
  'necessity':'核心CMP-M01只教即时/需恢复类别，不能推出取回档位的真实时间；485分钟、673一天两种现有原题均需该判断。',
  'existingRuleDerivation':'Cannot derive tier timing or<250MB boundary from names or generic archive rule.',
  'prerequisiteRuleIds':['CUR:CMP-M01'],'prerequisiteBodySha256':hashes['CUR:CMP-M01'],
  'metadataNote':'raw card prerequisiteRuleIds=[]; frozen proposed catalogue explicitly declares CMP-M01. Review binds catalogue prerequisite; downstream keep that actual dependency.',
  'finalCoreInclusionNotDecided':True},
 {'ruleId':'VC-007','bodySha256':hashes['VC-007'],'cardVerdict':'PASS','primaryDomain':'4','primaryTask':'4.2',
  'necessity':'CB02/GSC054教服务覆盖，GSC147教容量保障，GSC155教已购利用率；它们不能推出全年合同付费和期限/预付折扣关系。940与1013都需要该共用判断。',
  'existingRuleDerivation':'Related rules do not state whole-term billing or payment/term tradeoff; no independent extra card for each parameter is needed.',
  'sharedTaskReferences':['4.3'],'primaryTaskReason':'承诺购买方案与计算费用为主判断，RDS同用一条合同规则跨任务引用，不复制正文。',
  'prerequisiteRuleIds':[],'applicationPrerequisitesForQ940':['GSC-054','CUR:CB02'],
  'scopeBoundary':'Three-year/all-upfront comparisons only for matching offerings; Database Savings Plans has one payment option and must not be generalized.',
  'finalCoreInclusionNotDecided':True}]
summary={'cardCount':9,'cardPass':8,'cardFail':1,'cardUnknown':0,'FACTPass':9,'newCandidateCount':2,'newCandidatePass':2,
 'questionCount':12,**dict(collections.Counter(q['status'] for q in qrows))}
out=R/'supplemental06.review.json';assert not out.exists()
result={'schemaVersion':1,'reviewer':'actual_cards_review independent supplemental06',
 'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'inputManifestPath':str(mp),'inputManifestSha256':sha(mp.read_bytes()),'inputFiles':M,
 'bodyHashContract':'canonical four Chinese fields, sorted compact UTF8 JSON, SHA256',
 'summary':summary,'cards':cardrows,'evidenceRegistry':registry,'affectedQuestions':qrows,
 'newCandidateAssessments':new_assessment,
 'proofPoolBinding':{'frozenBasePath':str(I/'visible-pool.frozen.json'),'frozenBaseSha256':M[str(I/'visible-pool.frozen.json')],
  'baseCount':351,'candidateOverlayCount':9,'PASSCandidateOverlayRuleIds':[c['ruleId'] for c in cardrows if c['verdict']=='PASS'],
  'failedCandidateNotOverlaid':['GSC-123'],'retainedOldGSC123BodySha256':pool['GSC-123']['bodySha256'],
  'effectiveVisibleProofCount':353,'notFinalNOrInventoryAcceptance':True},
 'noPrivateSourceFindingUsedAsLearningPremise':True,'all12FullOriginalsAndOptionsRead':True,
 'cardAcceptanceOriginalSufficiencyAndLearnerEffectSeparated':True,
 'originalQuestionsChanged':False,'cardsAuthoredOrEditedByReviewer':False,'currentPointersChanged':False,
 'approvalTableChanged':False,'modelCliApiCalls':0,'nativeUsage':'unknown',
 'oldFailuresVersionsAndCountsPreserved':True,'contentRepairRequests':1,
 'reviewAssemblyCorrections':1,
 'priorAssembly':{'path':str(R/'supplemental06.assembly01.review.json'),
  'reason':'COH prerequisite quote was narrowed to the exact RDS section rather than the first identical sentence elsewhere on the same page; no card or question verdict changed.'},
 'finalNUnknown':True}
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for q in qrows:
 assert q['questionSha256']==sha(ca(qby[q['qid']]))
 for a in q['necessaryAnchors']:
  c=usable[a['ruleId']]
  assert a['bodySha256']==c['bodySha256']==sha(ca(c['visibleBody']))
  assert c['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']]==a['quote']
for e in registry.values():
 p=pathlib.Path(e['sourcePath']);d=json.loads(p.read_text())
 assert sha(p.read_bytes())==e['sourceFileSha256'] and sha(d['text'].encode())==e['textSha256']
 assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
for p,h in M.items():assert sha(pathlib.Path(p).read_bytes())==h
rb={'status':'PASS','reviewPath':str(out),'reviewSha256':sha(out.read_bytes()),'cardCount':9,'questionCount':12,
 'allFrozenInputHashesMatch':True,'allCanonicalFourFieldHashesMatch':True,'allCardQuotesAndOffsetsMatch':True,
 'allOriginalQuestionHashesMatch':True,'allOfficialSnapshotsAndOffsetsMatch':True,
 'failedGSC123NotUsedAsNewOverlay':True,'allCurrentPointersAndOriginalsUnchanged':True,
 'modelCliApiCalls':0,'nativeUsage':'unknown'}
(R/'supplemental06.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
(R/'supplemental06.review.md').write_text(
 '# supplemental06独立复核\n\n'
 '9卡：8 PASS，GSC123因R1（诊断指标对和路由算法两个独立回忆）FAIL；9张FACT均通过。VC006/007通过事实与教学，主归4.1/4.2适当，当前只认候选知识，不据此确定最终N。\n\n'
 '12原题：3 SUPPORTED（718/736/890），3 CONDITIONAL（714/940/956），3 UNKNOWN（485/673/1013），3 SOURCE_ISSUE（240/827/859）。未把典型时长当无条件分钟保证，也未套旧TA单账户范围。\n\n'
 '已补LOR算法、承诺计费/折扣、File Gateway归档恢复和Internet免费额度等真正缺失正证。GSC123失败版本没有进入题目overlay，原可见算法卡继续保留；不因原题未充分就无条件加卡或拉长卡面。所有四字段哈希、卡句偏移、原题哈希和官方快照回读PASS；current及批准表未改。模型CLI/API0，native unknown。\n')
print(json.dumps({'path':str(out),'sha256':sha(out.read_bytes()),'summary':summary,'readback':'PASS'},ensure_ascii=False))

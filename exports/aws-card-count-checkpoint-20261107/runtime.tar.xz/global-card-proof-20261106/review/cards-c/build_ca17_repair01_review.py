import pathlib, json, hashlib, datetime, collections

V = pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106')
I = V / 'review/supplemental02-ca17-repair01/input'
R = V / 'review/cards-c'
def canon(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
def sha(x):
    return hashlib.sha256(x).hexdigest()
mp = I / 'manifest.json'
manifest = json.loads(mp.read_text())
checks = {}
frozen_pool = V / 'evidence/cards-c/supplemental02-current357.snapshot.json'
for p, expected in manifest.items():
    actual_path = frozen_pool if p == str(V / 'deliverables/visible-knowledge-current.json') else pathlib.Path(p)
    actual = sha(actual_path.read_bytes())
    assert actual == expected, (p, expected, actual)
    checks[p] = {'sha256': actual, 'resolvedPath': str(actual_path), 'status': 'PASS'}
raw = json.loads((I / 'cards.json').read_text())
assert len(raw) == 1 and raw[0]['ruleId'] == 'CUR:CA17'
c = raw[0]
fields = ['frontZH', 'answerZH', 'keyPointZH', 'watchOutZH']
body = {f: c[f] for f in fields}
body_sha = sha(canon(body))
prior = json.loads((V / 'review/cards-c/supplemental02.review.json').read_text())
prior_ca17 = next(x for x in prior['cards'] if x['ruleId'] == 'CUR:CA17')
assert prior_ca17['verdict'] == 'PASS'
assert c['repairOf'] == prior_ca17['bodySha256'] == '551d06bd057fc625b378ee704e301aa3688ceae0e37a52a022ffa666a54c1a8e'
pool = {x['ruleId']: x for x in json.loads(frozen_pool.read_text())}
assert len(pool) == 357 and 'GCL-020' not in pool
for x in pool.values():
    assert sha(canon(x['visibleBody'])) == x['bodySha256']
restored = '入口和计算由托管服务按请求承载，不必自己维持始终运行的Web服务器容量'
assert restored in pool['CUR:CA17']['visibleBody']['keyPointZH']
assert restored in body['keyPointZH']
overlay = dict(pool)
overlay['CUR:CA17'] = {'ruleId': 'CUR:CA17', 'visibleBody': body, 'bodySha256': body_sha}
qs = json.loads((I / 'questions.json').read_text())
qby = {x['qid']: x['question'] for x in qs}
assert sorted(qby) == [77,94,107,114,171,183,220,226,316,351,463,513,516,541,587,721,769,911,1005]

registry = {}
def evidence(path, quote, supports, receipt=None):
    p = pathlib.Path(path)
    d = json.loads(p.read_text())
    text = d['text']
    start = text.index(quote)
    eid = sha(canon([str(p), quote, supports]))
    registry[eid] = {
        'sourcePath': str(p), 'sourceFileSha256': sha(p.read_bytes()),
        'textSha256': sha(text.encode()), 'url': d['url'],
        'quote': quote, 'quoteStart': start, 'quoteEnd': start + len(quote),
        'supports': supports, 'reusedReceipt': receipt
    }
    return eid
provided = json.loads((I / 'official-evidence.json').read_text())
for x in provided:
    p = pathlib.Path(x['snapshotPath'])
    d = json.loads(p.read_text())
    assert sha(p.read_bytes()) == x['snapshotSha256']
    assert sha(d['text'].encode()) == x['textSha256']
    assert d['text'][x['quoteStart']:x['quoteEnd']] == x['quote']
source = lambda n: pathlib.Path(provided[n]['snapshotPath'])
eids = [
    evidence(source(6), 'This pattern creates a REST API endpoint by using Amazon API Gateway to send a message to Amazon Simple Queue Service (Amazon SQS).', 'API Gateway direct SQS request path'),
    evidence(source(6), "API Gateway posts a message, which is received on the request's body, on the queue.", 'request body posted to SQS directly'),
    evidence(source(7), provided[7]['quote'], 'API Gateway HTTP PUT integrates directly with Kinesis PutRecord'),
    evidence(source(8), 'If your Lambda function is not performing custom logic while integrating with other AWS\nservices, chances are that it may be unnecessary.', 'custom-business-logic versus unnecessary forwarding Lambda'),
    evidence(source(8), provided[8]['quote'], 'API Gateway service proxy directly integrates with Firehose'),
]
reuse_path = V / 'review/reuse-a/reuse-results.json'
reuse = next(x for x in json.loads(reuse_path.read_text())['results'] if x['ruleId'] == 'CUR:CA17')
fact_proof = next(x for x in reuse['proofs'] if x['gate'] == 'FACT_original')
fp = pathlib.Path(fact_proof['path'])
assert sha(fp.read_bytes()) == fact_proof['sha256']
old_fact = next(x for x in json.loads(fp.read_text())['rules'] if x['ruleId'] == 'CA17')
assert old_fact['status'] == 'SUPPORTED'
old_source = pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/retrieval-v3/corpus/sources/17504bf7c9e9f244ff0162f12af7e8968c60a10d0c6f6b72fa6e025d6ffa022d.json')
for citation in old_fact['citations']:
    d = json.loads(old_source.read_text())
    assert sha(d['text'].encode()) == citation['sourceTextSha256']
    assert sha(citation['quote'].encode()) == citation['quoteSha256']
    assert d['url'] == citation['url']
    eids.append(evidence(old_source, citation['quote'],
        'unchanged CA17 claim: managed API entrance and Lambda execution/administration of compute',
        {'reviewPath': str(fp), 'reviewSha256': fact_proof['sha256'],
         'reuseIndexPath': str(reuse_path), 'reuseIndexSha256': manifest[str(reuse_path)],
         'originalRuleId': 'CA17', 'originalBodySha256': reuse['bodySha256'],
         'currentFrozenBodySha256': pool['CUR:CA17']['bodySha256'],
         'reusedClaimOnly': restored, 'wholeNewBodyReuseClaimed': False}))

def anchor(rid, quote, supports):
    x = overlay[rid]
    found = [(f, s.index(quote)) for f, s in x['visibleBody'].items() if quote in s]
    assert found, (rid, quote)
    f, start = found[0]
    return {'cardId': rid, 'ruleId': rid, 'bodySha256': x['bodySha256'],
            'field': f, 'quote': quote, 'quoteStart': start, 'quoteEnd': start+len(quote),
            'supports': supports, 'origin': 'CA17 repair01 candidate' if rid == 'CUR:CA17' else 'frozen current357 visible prerequisite'}

HTTP = ('CUR:CA17', '不必。有业务计算时可由API Gateway调用Lambda；纯转发可用受支持的AWS服务集成直接调用目标服务。', 'HTTP业务计算由Lambda承担，单纯入队/入流可以直接代理')
MANAGED = ('CUR:CA17', restored+'；', '托管服务按请求承担入口/计算，不需自维持常驻Web服务器')
EVENT = ('GSC-029', '使用S3对象创建事件，按需要通知Lambda、送入SQS队列，或经EventBridge路由到受支持目标。', '新对象触发计算或进入队列')
POLL = ('VC-001', '配置SQS事件源映射：Lambda服务轮询队列并批量调用函数，整批成功后删除消息。', 'SQS到Lambda的实际取消息/调用/确认路径')
NOPOLLER = ('VC-001', '队列保存待办，函数处理业务；取任务和确认完成由受管连接承担，不需另养一台EC2来循环取消息。', '免自管EC2消息轮询器')
OBJECT = ('CUR:NA05', '区域对象存储把文件作为独立对象保存，应用按API访问，不受单个实例和其块卷的生命周期约束；多AZ类别还分散单AZ故障风险。', '文件作为S3对象持久保存并供应用访问')
STATIC = ('CUR:CA16', '可用S3静态网站托管或适配的托管静态前端服务。', '静态前端由对象/托管服务交付')
CF = ('CUR:CA13', '边缘位置就近承接连接，适用内容可从缓存返回，未命中或动态请求再到源站，减少远距离访问的影响。', 'CloudFront交付静态或动态源内容')
FIREHOSE = ('CUR:NS01', 'Firehose是AWS托管的交付流，缓冲后写目的地并按配置转换受支持格式；底层主机或AZ可用性问题由服务自动迁移处理，无需自管交付服务器。', 'Firehose负责托管缓冲/目的地交付，不把Kinesis数据流当S3写入器')
DELIVERY = ('CUR:NS01', '不够。使用配置了实际目的地的Data Firehose交付流；S3场景可启用受支持的JSON到Parquet格式转换。', '配置Firehose实际S3目的地')
RECORD = ('CUR:XB013', 'DynamoDB针对大规模在线操作型负载提供低延迟键值/文档访问；Redshift的数据仓库面向分析查询。', '在线记录访问与分析仓库分工')
DURATION = ('GSC-133', '标准Lambda调用通常受900秒上限；特殊执行产品模式另按其限制判断，不能把一种模式的规则推给全部计算。', '常规调用的时长边界，不单靠任务短就推定任何资源兼容')

rows = []
def add(q, status, selected, anchors, reason, competitors, missing=None, notes=None, implementation=None):
    aa = [anchor(*x) for x in anchors]
    rows.append({'qid': q, 'status': status, 'selectedOptionOrdinals': selected if status == 'SUPPORTED' else [],
        'candidateOptionOrdinals': selected if status != 'SUPPORTED' else [],
        'questionSha256': sha(canon(qby[q])), 'fullStemAndAllOptionsRead': True,
        'usedRuleIds': list(dict.fromkeys(a['ruleId'] for a in aa)),
        'necessaryAnchors': aa, 'reasoning': reason,
        'optionComparison': competitors, 'missingJudgments': missing or [],
        'conditionsAndSourceIssues': notes or [],
        'implementationValidationNotNewKnowledge': implementation or [],
        'scope': '冻结原题的选型知识支撑；不等于学习者测验结果或生产SLA保证。'})

add(77,'INSUFFICIENT_CARDS',[3],[HTTP,MANAGED,FIREHOSE,DELIVERY],
    'API Gateway可直接入Kinesis、Firehose托管送S3，足以确定C的入口方向。但C还明确要求Firehose路径用Lambda转换流中数据；当前可见卡只教通用Lambda业务计算及Firehose支持格式转换，没有Firehose调用Lambda执行自定义内联转换的连接知识。',
    {'1':'与C共有流/存储结构，但自管EC2入口多维护。','2':'未提供可靠的流入Glue路径，EC2 source/destination checking与此转换要求无关。','3':'最强候选，但还缺内联变换的学习前提。','4':'通用Lambda计算不能证明所述Glue流入与交付链已成立。'},
    ['Firehose使用Kinesis数据流为来源并在交付过程中调用Lambda进行自定义记录转换；不能用私有官方摘录替代卡面。'])
add(94,'SUPPORTED',[3],[EVENT,POLL,NOPOLLER,MANAGED,RECORD],
    '对象创建事件把小文件待办送SQS，受管事件源映射调用Lambda完成一次短转换并保存文档记录；事件触发避免轮询S3，受管连接免常驻EC2轮询。',
    {'1':'EMR集群加Aurora并非这里小文件短处理的低维护路径。','2':'与C相近，但仍需管理EC2队列消费者。','3':'完整事件/队列/短函数链。','4':'增添流和Aurora并未比已教的S3事件到SQS/Lambda路径减少维护。'},
    implementation=['真实上传峰值仍须配置函数并发和队列参数；没有把未经实测的峰值吞吐当新知识缺口。'])
add(107,'SUPPORTED',[2],[HTTP,MANAGED,RECORD,
    ('CUR:CC03','用Athena查询S3数据并建立相应表定义，不必先搬进自管数据库；','Athena是已落地数据的SQL分析入口'),
    ('CUR:NA02','BI层把查询数据组织成业务图表；','QuickSight解决可视化'),
    ('CUR:NC01','流处理代码持续消费输入记录；','流处理不同于每次REST业务请求处理')],
    '题目要求现有分析平台之外的REST存取应用层。API Gateway接HTTP请求并用Lambda执行业务处理，符合多层接口；数据持久层仍按访问模式配置，不把Lambda本身当数据库，也不要求选项未给出的新数据库产品。',
    {'1':'Athena/S3是SQL分析组合，不是所需REST业务计算层。','2':'给出HTTP入口和业务处理层。','3':'QuickSight/Redshift面向BI/分析。','4':'流处理不是所需请求驱动的存取业务函数。'},
    implementation=['B没有指定具体持久层。这里验的是所问的接口/计算层选择，不声称B已是一套无须数据库实现的完整部署。'])
add(114,'SUPPORTED',[3],[MANAGED,HTTP,OBJECT,
    ('GSC-031','对象存储负责保存文件，索引负责按业务条件找到对象；','照片对象与可查询元数据分工'),
    ('GSC-041','正文放S3，数据库或消息保留元数据和对象引用，读取方按引用取回正文。','文件正文与元数据分开保存')],
    '用按请求运行的函数承担图片处理，照片作为S3对象保存，原DynamoDB继续保留元数据。正文/索引的职责分开，避免将照片数据和元数据都当DynamoDB项目；不借本题未给出的照片大小作事实前提。',
    {'1':'把图片正文也放DynamoDB，没有采用已教的文件对象/元数据分工。','2':'交付流不是图片处理与存储二者的替代品。','3':'函数计算、对象存储、元数据表各担其职。','4':'固定增加到三台并不能按时段变化自动弹性扩展。'})
add(171,'SUPPORTED',[2],[HTTP,MANAGED],
    '税额计算是每次API请求触发的短业务逻辑；托管入口加函数计算减少对固定服务器容量的依赖，适应季节请求变化。',
    {'1':'单EC2仍是固定计算主机。','2':'入口/业务计算均采用按请求的托管路径。','3':'两台固定EC2没有给出弹性动作。','4':'只换入口，计算仍落在单EC2。'})
add(183,'SUPPORTED',[1],[STATIC,HTTP,MANAGED,CF,
    ('GSC-038','难预测的负载考虑on-demand；稳定且可规划时比较provisioned配合自动伸缩。','不可预测读写选择按需DynamoDB'),
    ('GSC-038','按需模式减少预配管理，预置模式按购买的容量收费，稳定利用可更经济。','减少容量预估管理'),
    ('GSC-057','Serverless v2调整适用实例的计算容量；Aurora Auto Scaling按读负载指标自动增减reader副本。','Aurora Auto Scaling扩reader'),
    ('GSC-057','读副本数量增加不会把写操作自动分摊到多个writer。','不能用reader自动伸缩覆盖写容量弹性')],
    '静态前端/CloudFront加API Gateway/Lambda减少服务器维护。数据库需读写都随不可预测需求变化；on-demand匹配，而Aurora Auto Scaling仅增加读副本，不能据此满足写扩展。',
    {'1':'静态/动态/数据库分工且按需处理读写。','2':'与A最近，数据库Auto Scaling只扩读副本。','3':'需管理EC2，预置写容量也需规划。','4':'EC2维护且数据库写扩展前提同B。'},
    implementation=['快速扩展是选型要求；不把未做生产峰值测试本身判为缺卡，仍保留按需模式的配额/突增边界。'])
add(220,'SUPPORTED',[2],[HTTP,MANAGED,DURATION],
    '有长时间无请求、每次几秒的短处理，使用按请求承担计算的Lambda，避免为闲置的容器节点维持容量。题面明确异步，所问是计算服务，不强行新增前端同步等待义务。',
    {'1':'Glue ETL作业不是这里每次API短业务处理的匹配计算模型。','2':'短函数按请求执行。','3':'EKS容器服务仍需运行/管理应用服务容量。','4':'ECS加EC2保留节点容量管理。'},
    implementation=['数秒端到端延迟须验证实际函数初始化和排队；未将这一未实测SLA单独列为知识缺口。'])
add(226,'SUPPORTED',[1,5],[HTTP,MANAGED,FIREHOSE,DELIVERY,
    ('GSC-095','不够；应运行实际ETL转换，如适用的Glue ETL job。','Glue ETL实际读入、转换并写出S3数据'),
    ('GSC-095','crawler发现数据结构并更新目录；ETL作业才读取、转换并写出新格式的数据。','落地后的Glue处理职责')],
    '把HTTP接入和入流从EC2迁给API Gateway，Firehose配置S3目的地承担当下原始数据交付；再由Glue对S3原始数据执行实际ETL。这里无需声称Firehose已有内联Lambda变换，A承担转换。',
    {'1':'提供实际S3数据转换步骤。','2':'路由到EC2仍保留主机处理。','3':'扩EC2仍需自管。','4':'队列可缓冲，但消费者仍EC2。','5':'提供托管接入/交付链，与A组合。'})
add(316,'SUPPORTED',[3],[POLL,NOPOLLER,MANAGED],
    '迁到具备适用运行时的Lambda并使用SQS事件源映射，由服务拉取、调用和删除成功批次，去掉原常驻EC2轮询脚本的服务器运维。',
    {'1':'只垂直扩大同一主机。','2':'关闭消费者时消息增长仍需处理，且没有受管消费替代。','3':'受管队列函数连接承担消费。','4':'Run Command不是持续随消息到达消费队列的替代连接。'},
    implementation=['原题已限定appropriate runtime；本题没有指定一种尚待证明的语言，因此不新增语言兼容缺口。'])
add(351,'SUPPORTED',[4],[MANAGED,
    ('GSC-088','不应；使用Step Functions等适用的持久工作流编排。','持久工作流选择'),
    ('GSC-088','工作流管理步骤状态、等待和重试，单次业务函数只完成自己的处理，不必一直运行来保存整条流程的进度。','步骤状态与函数计算分离'),
    ('GSC-089','一个按时钟触发，一个按实际事件内容触发；定时扫描会引入等待并检查大量没有变化的数据。','不能把按计划函数当事件驱动工作流'),
    ('GSC-095','crawler发现数据结构并更新目录；ETL作业才读取、转换并写出新格式的数据。','Glue知识针对ETL而非本题通用步骤编排')],
    'Step Functions承担整条流程状态，Lambda承担独立步骤，既分布式也免自管EC2；事件流转不同于定时运行函数。',
    {'1':'Glue ETL不是所问通用持久步骤状态编排。','2':'引入EC2步骤仍需主机维护。','3':'按schedule不等于按业务事件编排有状态多步工作。','4':'状态机管理流程，函数完成步骤。'})
add(463,'INSUFFICIENT_CARDS',[3],[EVENT,MANAGED,DURATION,
    ('GSC-133','执行时长符合只是一个条件，操作系统、运行模型和资源不兼容时，短任务也不能运行。','不能把30秒满足等同于资源兼容'),
    ('GSC-136','不一定；内存配置也影响分配的CPU资源，应比较配置变化后的运行时长和总费用。','内存是须配置的实际计算条件')],
    '2MB新对象与30秒短任务使事件触发Lambda成为最强候选，避免Glue/EMR作业模型。但原题还明确要求1GB内存；当前卡面只说检查资源和内存影响CPU，未给出足以确认该内存配置可用的边界。不能由“短函数”或评审记忆补这一硬条件。',
    {'1':'Scala Glue作业较重，但相对排名不能补齐候选Lambda资源可行性。','2':'EMR集群不适合为这种短对象处理保留计算。','3':'最强候选，1GB内存可行性尚无卡面前提。','4':'PySpark作业同样未体现短请求函数的低维护模型。'},
    ['Lambda能配置至少1GB内存这一明确资源兼容判断未在冻结可见卡面找到；30秒符合900秒边界不能抵扣。'],
    implementation=['不因没有负载测试或精确账单测算单独判缺卡；此处缺口是明示1GB的服务资源可行性。'])
add(513,'SUPPORTED',[1],[STATIC,HTTP,MANAGED,EVENT,OBJECT,
    ('CUR:CA16','存储直接返回页面文件，脚本在浏览器运行；PHP等服务器端代码需要计算后端，不能由S3静态托管执行。','前端文件与真正图片计算分离')],
    '静态前端只交付页面，Lambda执行图片缩放，S3存图片。请求或上传事件触发短业务计算，按需求承载且文件对象不依赖单个EC2。',
    {'1':'页面、函数处理、对象存储分工。','2':'CloudFront是交付入口，不是服务器端网站/图片计算宿主，RDS也非这里的文件对象目的地。','3':'单EC2 Web与缩放进程形成固定容量。','4':'入口ECS伸缩没有消除单EC2缩放消费者。'},
    implementation=['静态页面调用后端需配置实际API/权限；A所给的是组件选型，不把API未逐项配置当独立学习目标。'])
add(516,'SUPPORTED',[2],[HTTP,MANAGED,
    ('GSC-134','reserved concurrency预留并限制并发额度；provisioned concurrency预先初始化相应执行环境。','低初始化延迟选预置而非只保留并发额度'),
    ('GSC-134','只设置reserved concurrency不会自动把所有环境预热。','排除reserved当预热')],
    '托管API和函数减少集群维护，预置并发提前初始化执行环境，针对季节峰值下初始化延迟；预留并发只是额度，不解决环境冷启动。',
    {'1':'ALB/ECS仍需运行容器服务。','2':'按需业务计算并预先初始化环境。','3':'EKS集群运维更重。','4':'最近竞争项，但reserved不自动预热。'},
    implementation=['真实低延迟仍须合理设置预置并发并监测；不把卡片选型支撑等同于任意负载的端到端低延迟保证。'])
add(541,'SUPPORTED',[1,3,5],[HTTP,MANAGED,STATIC,CF,RECORD,
    ('CUR:CA11','不能。用户池负责客户登录；需要调用S3等AWS API时，通过Cognito身份池取得受IAM角色权限约束的临时AWS凭证。','用户池认证客户，身份池换AWS凭证'),
    ('CUR:CA19','Cognito令牌用适用的Cognito authorizer；自定义验证用Lambda authorizer；IAM凭据用AWS_IAM并签名请求。','登录身份在入口校验'),
    ('CUR:CA16','存储直接返回页面文件，脚本在浏览器运行；PHP等服务器端代码需要计算后端，不能由S3静态托管执行。','HTML/CSS/JS托管与PHP服务器代码区别')],
    'A的函数读取用户信息并承担请求业务逻辑，C的用户池负责客户认证，E的HTML/CSS/JS是可托管静态前端并由CloudFront交付。长期空闲时无需维持容器应用容量。付费状态是应用从用户记录判定的业务条件，不能把“认证成功”误说成自动获得订阅资格。',
    {'1':'按请求读取用户信息的计算层。','2':'ECS/RDS常驻服务较重，且选项末句引用Lambda并不形成其自身完整链。','3':'用户池负责客户登录。','4':'身份池主要换AWS临时凭证。','5':'客户端HTML/CSS/JS由托管前端交付。','6':'S3静态托管不能执行PHP。'},
    notes=['B末句指向未在该选项中建立的Lambda，保留原文，不将其机械修正。'],
    implementation=['付费订阅检查须由应用逻辑读取用户记录并拒绝未付费身份；Cognito认证本身不替应用完成计费授权。本判定为题目组合选型支撑，不声称所列组件无需业务代码便能执行订阅策略。'])
add(587,'SUPPORTED',[3],[HTTP,MANAGED,FIREHOSE,DELIVERY,
    ('CUR:CA19','Cognito令牌用适用的Cognito authorizer；自定义验证用Lambda authorizer；IAM凭据用AWS_IAM并签名请求。','自定义API鉴权由Lambda authorizer'),
    ('CUR:XB002','GWLB在网络层把IP流量分配给检查设备；','GWLB是网络检查链而非HTTP API身份入口')],
    '活动数据通过HTTP入口直接代理到Firehose，Firehose负责S3交付；入口在业务数据转发前使用Lambda authorizer完成自定义验证。纯转发不需业务Lambda，并不删除独立鉴权Lambda。',
    {'1':'GWLB做网络检查且EFS不是所需托管流交付链。','2':'Kinesis数据流本身没有把数据写S3的交付步骤。','3':'HTTP接入、受管S3交付与入口授权职责齐全。','4':'在GWLB后加Lambda不把GWLB变为API入口authorizer。'})
add(721,'INSUFFICIENT_CARDS',[4],[HTTP,MANAGED,
    ('GSC-133','不能；先匹配运行环境和资源，再检查时长。Windows容器应选择当前支持该环境的平台，如适用的ECS/Fargate。','运行环境兼容是先决条件')],
    'Lambda的按请求托管执行最符合serverless、自动扩展和少基础设施的方向。但Python是原题明确的运行时硬条件；冻结可见卡没有Python支持声明。不能由“custom developed code”或评审常识推定运行时兼容。',
    {'1':'仍需EC2/Spot实例维护。','2':'托管环境并非无服务器函数计算，仍有Web服务器环境。','3':'明确要求自管EC2节点。','4':'最强候选，Python运行时前提尚缺卡面说明。'},
    ['Lambda提供适用Python运行时/支持此Python组件的可见知识前提未找到。'],
    implementation=['未把hundreds requests/second尚未实测本身列为缺卡；缺口只针对明示语言兼容，不要求背完整运行时目录。'])
add(769,'SUPPORTED',[2],[EVENT,MANAGED,DURATION],
    '文件新增事件直接调用函数，处理不足5秒；相比固定扫描或先构建流，已教路径只响应新增对象，免维持常驻处理主机。',
    {'1':'CloudTrail记录API活动不是对象处理的原生触发/计算链。','2':'精确的对象创建事件到函数路径。','3':'先上Kinesis不是已上传S3文件发现/触发的必要步骤。','4':'SNS主题负责分发，不执行文件处理，选项未给出S3上传到SNS的完整触发链。'})
add(911,'SUPPORTED',[3],[EVENT,MANAGED,OBJECT,
    ('GSC-089','一个按时钟触发，一个按实际事件内容触发；定时扫描会引入等待并检查大量没有变化的数据。','小量新增照片用事件而非每分钟扫存量')],
    '每次照片上传触发一次短函数生成缩略图并写第二桶，免整日运行集群/EC2并定时扫描；第二桶也隔离处理输出与原触发范围。',
    {'1':'长驻EMR加每分钟扫描为每天约150张照片维持多余容量。','2':'常开EC2同样付闲置容量/扫描。','3':'实际新增事件调用计算再写对象。','4':'Storage Lens是存储分析能力，未提供所教对象创建通知路径。'})
add(1005,'SUPPORTED',[1],[HTTP,MANAGED,POLL,NOPOLLER,RECORD,
    ('GSC-105','使用适用的文本理解能力，如Amazon Comprehend。','调查文本的情绪分析选择'),
    ('GSC-105','输入已经是文字，所缺的是理解文字内容的特征；转录解决音频到文字，OCR解决图像到文字，不能代替情绪分析。','文本理解与其他识别职责区分'),
    ('GSC-040','TTL属性存过期时刻的Unix epoch秒值，不是保留天数；后台按此时刻异步清理，不能用它实现到秒的访问控制。','365天以未来过期时刻表示，非把365当TTL数值')],
    'API Gateway直接入SQS，受管Lambda映射消费，函数调用Comprehend分析文字并保存DynamoDB记录。过期值计算为365天后的epoch时刻，异步删除不会让仍在12个月窗口内的记录提前过期；题目没有要求到秒删除。',
    {'1':'队列/计算/文本理解/记录保留职责齐全。','2':'单EC2 API是自管计算入口。','3':'Rekognition不是所教文本情绪分析服务。','4':'Lex对话机器人不能替代Comprehend文本情绪分析。'},
    implementation=['精确保留的应用时间语义需按实际日期计算；原“365 days in the future”按未来时刻理解，不偷偷改成TTL属性值365。'])

assert len(rows) == 19
status_counts = collections.Counter(x['status'] for x in rows)
card_checks = {
    'FACT': {'status':'PASS','reason':'新直接代理结论有SQS、Kinesis与Firehose实际请求路径原句；恢复的托管入口/计算说明逐句匹配旧CA17已核实官方来源，重新绑定当前四字段哈希。未作请求延迟、无限伸缩或任意后端集成承诺。'},
    'B1': {'status':'NOT_APPLICABLE','reason':'本次只审冻结中文四字段，不升级双语封装。'},
    'U1': {'status':'PASS','reason':'以是否真正执行业务计算区分函数与直接代理，解释省去无用转发函数及常驻服务器维护的原因。'},
    'R1': {'status':'PASS','reason':'仍是“后端是否必须Lambda”一个比较任务。恢复句是该选择的托管机制说明，不新增配置或参数清单。'},
    'T1': {'status':'PASS','reason':'若从仅入队变为要执行业务计算，应增加计算函数；若只是入流，支持的直接代理可省函数。恢复句不改变此边界。'},
    'S1': {'status':'PASS','reason':'自评仅需是否必须函数、两种情形的选择和关键原因；不要求复述入口维护、IAM、模板、目标参数等补充配置。'},
    'P1': {'status':'PASS','reason':'同卡明确HTTP到计算或队列/流目标的路径；SQS/交付流用途可复用当前可见先修，不用私有目标补答案。'}
}
result = {
    'schemaVersion':1,
    'reviewer':'actual_cards_review independent CA17 repair01 and 19 frozen-original review',
    'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'authorVersion':'supplemental02-ca17-repair01; only one card rereviewed',
    'inputManifestPath':str(mp), 'inputManifestSha256':sha(mp.read_bytes()),
    'inputFiles':manifest, 'frozenInputChecks':checks,
    'skill':{'path':'/Users/qc/.codex/skills/aws-card-count-verify/SKILL.md',
        'sha256':'e84a061a98b24c24cea65f8240bece23d91b6c6cecee79dbda10701c48e1c624',
        'previouslyActuallyRead':True},
    'userKnowledgeScope':{'path':str(V/'inputs/user-knowledge-scope-accepted.json'),
        'sha256':sha((V/'inputs/user-knowledge-scope-accepted.json').read_bytes()),
        'policy':'current_AWS','sourceQuestionsPreserved':True,'notBlanketExemption':True},
    'userCorrectionPolicy':{'path':str(V/'inputs/user-source-correction-policy-accepted.json'),
        'sha256':sha((V/'inputs/user-source-correction-policy-accepted.json').read_bytes()),
        'appliedHere':'Only frozen originals reviewed; no corrected exercise produced or substituted.'},
    'bodyHashContract':'SHA-256 canonical UTF-8 JSON of exactly frontZH/answerZH/keyPointZH/watchOutZH, sorted keys, ensure_ascii=False, compact separators',
    'summary':{'cardCount':1,'cardPass':1,'cardFail':0,'cardUnknown':0,
        'questionCount':19,'SUPPORTED':status_counts['SUPPORTED'],
        'INSUFFICIENT_CARDS':status_counts['INSUFFICIENT_CARDS'],'CONDITIONAL':0,'SOURCE_ISSUE':0},
    'cards':[{'ruleId':'CUR:CA17','cardId':'CA17','verdict':'PASS',
        'bodySha256':body_sha,'priorBodySha256':c['repairOf'],'inputCardSha256':sha(canon(c)),
        'checks':card_checks,'evidenceIds':eids,'evidence':[registry[e] for e in eids],
        'unchangedClaimFactReuse':{'exactRestoredVisibleQuote':restored,
            'frozenPreviousBodySha256':pool['CUR:CA17']['bodySha256'],
            'reuseIsClaimLevelNotWholeNewBodyApproval':True},
        'minimalCorrection':None,'findings':[]}],
    'evidenceRegistry':registry,
    'affectedQuestions':rows,
    'overlayPoolBinding':{'baseSnapshotPath':str(frozen_pool),'baseSnapshotSha256':sha(frozen_pool.read_bytes()),
        'baseVisibleCount':357,'onlyOverlayRuleIds':['CUR:CA17'],
        'overlayBodySha256ByRule':{'CUR:CA17':body_sha},'overlayVisibleCount':357,
        'otherFiveSupplemental02CardsReReviewed':False,'otherFivePriorPassesPreserved':True,
        'otherFiveNeededByTheseQuestionProofs':False,'GCL020Excluded':True},
    'mutableConvenienceResolution':'Frozen immutable current357 snapshot used; convenience pointer changes after review do not rebind these proofs.',
    'scope':'One repaired Chinese card and 19 unchanged original questions; no full-library count, bilingual pack, learner accuracy, production SLA, publishing or inventory acceptance.',
    'originalReviewHistoryPreserved':True,'modelCliApiCalls':0,'nativeUsage':'unknown',
    'currentPointersChangedByReviewer':False,'authoringPerformed':False,
    'reviewAssemblyCorrections':0,'contentRepairRequests':0,
    'newlyObservedQuestionGapsAreNotCA17ContentFailures':[
        {'qid':463,'gap':'1GB memory compatibility not taught on current visible faces'},
        {'qid':721,'gap':'Python runtime compatibility not taught on current visible faces'}]
}
out = R/'supplemental02-ca17-repair01.review.json'
assert not out.exists(), 'Preserve prior output; never overwrite an existing review.'
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')

# Deterministic readback verifies the semantic decisions above were assembled against exact frozen bytes.
rd = json.loads(out.read_text())
for q in rd['affectedQuestions']:
    assert q['questionSha256'] == sha(canon(qby[q['qid']]))
    assert q['fullStemAndAllOptionsRead']
    for a in q['necessaryAnchors']:
        x = overlay[a['ruleId']]
        assert a['bodySha256'] == x['bodySha256'] == sha(canon(x['visibleBody']))
        assert x['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']] == a['quote']
for e in rd['evidenceRegistry'].values():
    p = pathlib.Path(e['sourcePath']); d = json.loads(p.read_text())
    assert sha(p.read_bytes()) == e['sourceFileSha256']
    assert sha(d['text'].encode()) == e['textSha256']
    assert d['text'][e['quoteStart']:e['quoteEnd']] == e['quote']
readback = {'status':'PASS','reviewPath':str(out),'reviewSha256':sha(out.read_bytes()),
    'cardCount':1,'originalQuestionCount':19,'all19FullQuestionHashesMatch':True,
    'allVisibleQuotesAndOffsetsMatch':True,'allCanonicalFourFieldHashesMatch':True,
    'allOfficialQuoteSnapshotsMatch':True,'priorFiveCardsNotReReviewed':True,
    'historyAndCurrentPointersUntouched':True,'modelCliApiCalls':0,'nativeUsage':'unknown'}
(R/'supplemental02-ca17-repair01.readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n')
(R/'supplemental02-ca17-repair01.review.md').write_text(
    '# CA17 repair01 独立复核\n\n'
    'CA17：PASS；七项中 FACT/U1/R1/T1/S1/P1 通过，B1 不适用（仅中文）。恢复句解释托管按请求承担入口和计算，仍服务于同一个“业务计算或纯代理”判断。\n\n'
    '19 道冻结原题：16 SUPPORTED，3 INSUFFICIENT_CARDS（Q77、Q463、Q721）。Q77 缺 Firehose 内联 Lambda 变换；Q463 缺明示 1GB 内存可行性；Q721 缺 Python 运行时兼容的可见卡面前提。后两项是本次逐题复核发现的硬条件缺口，不是 CA17 修订失败，也不要求为其直接新增独立卡。\n\n'
    '其余五张 supplemental02 既有 PASS 未重审。卡片通过、原题设计支撑、学习者表现和生产 SLA 分开；未修改现行指针、库存、历史失败、预算或学习记录。全部原句偏移、四字段哈希和官方快照回读通过；CLI/API 调用 0，native 用量 unknown。\n')
print(json.dumps({'reviewPath':str(out),'bodySha256':body_sha,'summary':result['summary'],'readback':'PASS'},ensure_ascii=False))

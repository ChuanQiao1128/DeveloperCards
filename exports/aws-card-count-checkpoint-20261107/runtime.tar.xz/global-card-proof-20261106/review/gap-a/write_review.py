import json, pathlib, hashlib, datetime
V=pathlib.Path(__file__).resolve().parents[2]
I=V/'review/gap-a/input'
CARDS={x['ruleId']:x for x in json.loads((I/'visible-cards355.v2.json').read_text())}
CASES={x['qid']:x for x in json.loads((I/'cases104.json').read_text())}
def sha(b): return hashlib.sha256(b).hexdigest()
def write(part,spec):
 rows=[]
 for q,s,opts,ids,reason,reqs,checks in spec:
  cards=[CARDS[i] for i in ids]
  rows.append(dict(qid=q,status=s,selectedOptionOrdinals=opts if s=='SUPPORTED' else [],candidateOptionOrdinals=opts if s!='SUPPORTED' else [],usedRuleIds=ids,necessaryAnchors=[dict(ruleId=x['ruleId'],bodySha256=x['bodySha256'],field=f,quote=x['visibleBody'][f]) for x in cards for f in ('answerZH','keyPointZH','watchOutZH') if x['visibleBody'].get(f)],reasoningAndClosestCompetitor=reason,revisionRequestIds=reqs,implementationChecks=checks,questionSha256=sha(json.dumps(CASES[q]['question'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),originalReportedMissingJudgments=CASES[q]['reportedMissingJudgments'],basis='frozen manifest.v2;355 visible cards; original complete stem/options; no old solution or printed answer'))
 d=dict(schemaVersion=1,reviewer='actual_gap_review',reviewKind='independent_reverse_gap_check',inputManifest=str(I/'manifest.v2.json'),inputManifestSha256=sha((I/'manifest.v2.json').read_bytes()),reviewedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Only 104 previously unpassed cases; factual and learning-design proofs remain separate from question sufficiency.',results=rows)
 p=V/f'review/gap-a/results-part{part:02}.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(p,len(rows))
if __name__=='__main__': pass

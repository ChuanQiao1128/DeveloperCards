from write_review import V,I,CARDS,CASES,sha
from requests import ev,rows
import json,re,collections,datetime,pathlib
D=V/'review/gap-a'
# Preserve all initial part files. These are explicit, evidence-driven final dispositions.
overrides={
138:dict(status='UNKNOWN',candidateOptionOrdinals=[3],reasoningAndClosestCompetitor='官方确认Amazon MQ RabbitMQ的HA是三节点跨AZ集群，B/A明确active/standby pair是错误模式。C保留自管RabbitMQ但可另外配置真实跨AZ持久队列集群；不能仅因选项没写配置证明它绝对不可行。现卡教跨AZ队列复制而非ASG替代状态复制，仍不能把未配置的C直接升级唯一充分。保留唯一最佳方案待题源澄清；不是已证明所有选项技术上都不可能。'),
366:dict(status='UNKNOWN',candidateOptionOrdinals=[4],reasoningAndClosestCompetitor='完整官方usage-plan文档同时说明API key可分配产品API访问，又明确不要把它当authentication/authorization。已有Cognito认证下，D若只是额外产品key门槛在功能上可限制有key的请求，不能仅凭不推荐就证明绝对无法访问控制；但它未绑定已认证用户的实际订阅授权。C也未说明如何让共享Lambda执行身份按用户订阅限制DynamoDB。当前卡面不足证明严格用户订阅且最少运维的唯一项，保留UNKNOWN，撤回首轮“无有效选项”的过强结论。'),
299:dict(status='SOURCE_ISSUE',candidateOptionOrdinals=[2,4],reasoningAndClosestCompetitor='当前官方完整性能范围证实B/D均能按题干配置：B可用persistent SSD 1000 MBps/TiB、购买例如12TiB，吞吐12GBps且SSD亚毫秒；D选第二代Single-AZ ONTAP、NONE策略让全数据留SSD，最多12HA pairs，单pair SSD读取6144MBps，亦可多pair聚合，匹配>=6GBps及亚毫秒；存储量可购买大于8TB，题干没给成本上限、HA或限定第一代。原题通常语义下没有排除D的硬条件，不能把第一代性能限制套到未限定代际的当前题。保留题源年代/代际澄清，不增一张“只有Lustre能6GBps”的错误卡。'),
1013:dict(status='INSUFFICIENT_CARDS',candidateOptionOrdinals=[2],revisionRequestIds=['R55'],reasoningAndClosestCompetitor='官方Scheduled Instance API明确最低1200小时/年，weekly最小24小时；A仅周日12小时即使历史也不满足最低计划，不能用A作预期答案。C/D Spot与不能中断冲突；B为四项中可行的非Spot候选。现卡未教Scheduled最低计划及Standard/Convertible完整承诺期计费，故不足从当前卡直接唯一选B；不据B比未列出的On-Demand昂贵判它在四项中无效。现行可购状态另待核，不用未证实的退役说法当唯一证据。'),
}
(D/'final-disposition-overrides.json').write_text(json.dumps(dict(reason='More complete AWS scope checks; initial parts preserved.',overrides=[dict(qid=k,**v) for k,v in overrides.items()]),ensure_ascii=False,indent=2)+'\n')
# Source/condition records. UNKNOWN remains UNKNOWN unless two valid paths or a hard conflict are established.
specs=[
('S01',[52],'CONFIRMED_HARD_CAPACITY_CONFLICT','单文件hundreds TB与EFS单文件47.9TiB硬冲突；EBS单卷最高64TiB且不是跨AZ共享自动文件层。不得把单文件改成总量。',[('efs/latest/ug/limits','Size of a single file',350),('ebs-volume-types','Volume size',700)]),
('S02',[64],'QUALIFICATION_CONDITION','FSx File Gateway只对既有客户开放。现有卡已教该限制；这不是新教学任务，也未证明历史试题无答案。',[('filefsxw/what-is','no longer available to new customers',500)]),
('S03',[138],'CONFIRMED_MODE_ERROR_UNIQUE_CHOICE_UNRESOLVED','RabbitMQ pair/active-standby是明确错误，但未写配置不等于C绝对无法做自管HA，维持UNKNOWN。',[('rabbitmq-broker-architecture','cluster deployment is a logical grouping of three',700)]),
('S04',[157],'LITERAL_RETENTION_GAP','Backup恢复点到期只删备份，不删仍在线业务表。D+E缺原文all data after5y的在线删除。若data实指备份则须源题明确。',[('aws-backup/latest/devguide/creating-a-backup-plan','lifecycle',800)]),
('S05',[177],'WORDING_CONDITION','DAX可少改业务逻辑，但客户端需DAX client/endpoint，字面零重配与最少改逻辑不可混为一谈。',[('DAX.client.run-application-python','Install the DAX Python client',650)]),
('S06',[235],'WRITE_DIRECTION_CONDITION','分批应用双库同表写入需要明确复制方向与冲突策略；不能据单向CDC自动保证任意双写。C比D全表复制/结构转换完整，内存口诀非必要差异。',[('dms/latest/userguide/CHAP_Task.CDC','source',700)]),
('S07',[255],'CONFIRMED_BUSINESS_ORDERING_GAP','选项先创建unique order，再按不同order number发FIFO；不能防止前置重复订单。已教稳定业务ID幂等，不缺新卡。',[('FIFO-queues-exactly-once-processing','deduplication',900)]),
('S09',[324],'CONFIRMED_HARD_CAPACITY_CONFLICT','单stored volume仅16TiB；原题单volume数百TB不能悄拆多卷。',[('resource-gateway-limits','Maximum size of a volume',900)]),
('S10',[299],'CONFIRMED_CURRENT_MULTIPLE_CAPABLE_DESIGNS','B与D当前都可按容量/吞吐配置达标，原文未限代际；证据包含SSD延迟、Lustre每TiB1000MBps、ONTAP6144MBps/pair、最多12pair与NONE不分层。',[('LustreGuide/ssd-storage','PERSISTENT-1000',500),('LustreGuide/what-is','sub-millisecond',500),('ONTAPGuide/performance','Second-generation Single-AZ file systems are powered by up to 12 HA pairs',900),('ONTAPGuide/performance','Maximum throughput from SSD storage per HA pair',600),('ONTAPGuide/volume-storage-capacity','None – This policy keeps',600),('ONTAPGuide/supported-fsx-clients','Nfs',550)]),
('S11',[366],'AUTHORIZATION_CHOICE_UNRESOLVED','不把官方“不应当作认证授权”直接转成“API key在已有Cognito验证后完全不能作额外产品门槛”。严格订阅者身份绑定未给，保留UNKNOWN。',[('api-gateway-api-usage-plans','Don.t use API keys for authentication',700),('api-gateway-api-usage-plans','configure usage plans and API keys',800),('lambda-intro-execution-role','execution role is an AWS',650)]),
('S12',[373],'COST_INPUT_UNRESOLVED','可比较A/D，但缺大小与监控/转换费用，当前不宣布确定多解或确定最优。',[('storage-class-intro','S3 Intelligent-Tiering \\(INTELLIGENT_TIERING\\)\\nData',800)]),
('S13',[426],'CONFIRMED_TWO_FEASIBLE_PATHS','A DataSync和C Transfer Acceleration+S3客户端均可迁移且有对象data events；题干无优化条件可排除C，不因DataSync更习惯就伪造唯一。',[('transfer-acceleration','fast, easy, and secure transfers',650),('datasync/latest/userguide/encryption-in-transit','Your storage data',900)]),
('S14',[435],'WORKFLOW_AND_UNIT_UNRESOLVED','DMS/Snowball具体代际流程、1GB单位和两周链路交付需核；未找到完备证据前UNKNOWN，不宣称Snowball已证伪或D绝对不可行。',[('snowball/latest/developer-guide/whatisedge','no longer available to new customers',700)]),
('S15',[443],'APPLICATION_AND_COST_INPUT_UNRESOLVED','静态客户端应用与需要服务器执行的应用导向不同；TA可双向传输，不把未提到下载当不支持。',[('transfer-acceleration','secure transfers',700),('aws.amazon.com/s3/faqs','download.*?S3 Transfer Acceleration|S3 Transfer Acceleration.*?download',800)]),
('S16',[451],'COMPUTE_PROVIDER_CONDITION','C宿主组件责任仅在ECS使用EC2等客户承载时；Fargate并非同样宿主责任，原题未限定。',[('ECS|ecs','Fargate',800)]),
('S17',[969],'LINUX_SUPPORT_CONFIRMED_QUALIFICATION_REMAINS','完整官方支持ASP.NET Linux及.NETCore3.1/.NET5/6/7/8。不能因旧Windows摘录判Linux不支持；既有客户资格与原运行时仍按当前卡限制核对。',[('app2container/latest/UserGuide/supported-applications','ASP.NET applications \\(Windows, Linux\\)',650),('app2container/latest/UserGuide/supported-applications','Supported .NET Core runtime versions',1000),('app2container/latest/UserGuide/supported-applications','no longer open to new customers',650)]),
('S18',[992],'CONFIRMED_CLUSTER_TOPOLOGY_CONFLICT','正式RDS Multi-AZ DB cluster要求3AZ writer+2readers，选项只有2subnets；若题源泛指Aurora或DBinstance须明确，不能默改。',[('multi-az-db-clusters-concepts.html','three separate Availability Zones',850)]),
('S19',[995],'COMPUTE_COST_UNRESOLVED','20分钟排除标准Lambda；不从TB字样推Fargate不能流式处理，B/C成本需实际资源/利用率，UNKNOWN。',[('lambda/latest/dg/gettingstarted-limits','900',600)]),
('S20',[1002],'CAPACITY_COST_UNRESOLVED','A和D均global table可用，on-demand/provisioned最省取决于未给负载。当前已教该条件，不另造固定口诀。',[('dynamodb/pricing','steady and predictable',650)]),
('S21',[1004],'CACHE_SEMANTICS_AND_COST_UNRESOLVED','CachingOptimized不含query/cookies；公共可缓存GET与用户/参数特定ERP响应不同，未给缓存语义不宣称B/C唯一。',[('using-managed-cache-policies','CachingOptimized',2500)]),
('S22',[1008],'CONFIRMED_RESOURCE_RELATION_ERROR','launch template可带Spot购买选项，但不是Spot Fleet控制器；ASG和Fleet各消费模板。D原话把资源关系写反，不能机械改词后给原题PASS。',[('API_RequestLaunchTemplateData','InstanceMarketOptions',650),('ec2-auto-scaling-mixed-instances-groups','Spot',1400),('AWSEC2/latest/UserGuide/Fleets','Spot Fleet',1600)]),
('S23',[1013],'HISTORICAL_EXPECTED_A_DISQUALIFIED_CURRENT_CARD_GAP','仅周日12h不足Scheduled最小24h周/1200h年，已有官方API足以排除A；当前仍缺该教学，不依未证实停售断言。',[('API_DescribeScheduledInstanceAvailability','minimum required duration',800)]),
('S24',[1019],'PRODUCT_WORDING_CONDITION','REST API支持资源策略，HTTP API产品不支持；泛称HTTP接口与产品名须区分。',[('http-api-vs-rest','Resource policies',450)]),
]
findings=[]
for sid,qids,status,ex,refs in specs:
 evidence=[e for u,p,w in refs if (e:=ev(u,p,w))]
 findings.append(dict(findingId=sid,qids=qids,disposition=status,explanation=ex,officialEvidence=evidence,evidenceCompleteForDisposition=bool(evidence) if status.startswith('CONFIRMED') else False,knownLimits='Evidence is outside the learned visible cards; it checks source/scope and does not retroactively teach the learner.'))
(D/'source-findings.json').write_text(json.dumps(dict(findings=findings),ensure_ascii=False,indent=2)+'\n')
parts=[]
for p in sorted(D.glob('results-part*.json')):
 x=json.loads(p.read_text());parts.extend(x['results'])
for x in parts:
 if x['qid'] in overrides:x.update(overrides[x['qid']]);x['selectedOptionOrdinals']=[]
 x['sourceFindingIds']=[y['findingId'] for y in findings if x['qid'] in y['qids']]
 x['reportedGapDisposition']='already derivable or implementation-only' if x['status']=='SUPPORTED' else ('necessary visible teaching missing' if x['status']=='INSUFFICIENT_CARDS' else ('confirmed hard conflict or multiple viable designs' if x['status']=='SOURCE_ISSUE' else 'original condition/scope unresolved; do not add cards to hide it'))
reqs=rows()
# Final requests are scoped to the final dispositions; obsolete diagnostic source IDs remain only in initial parts.
for r in reqs:r['affectedQids']=[x['qid'] for x in parts if r['requestId'] in x['revisionRequestIds']]
sourcepath=V.parent/'domain1-final-card-catalog-20261105/questions.all.json';original=json.loads(sourcepath.read_text());batchq={k:original[str(k)] for k in [369,1014]}
(D/'batch-rule-cross-question-lookup.json').write_text(json.dumps(dict(fullOriginalFileSha256=sha(sourcepath.read_bytes()),method='deterministic AWS Batch text lookup followed by original-stem/options check; no old solutions read',directComparableOriginals=batchq,conclusion='Q369 and Q1014 both require independent batch-job scheduling; this is candidate reuse, not a new full-question sufficiency proof for Q369. Other Batch mentions were distractors or separate tasks.',existingVisibleRulePoolSha256=sha((I/'visible-cards355.v2.json').read_bytes()),newRuleCandidate='R56',doNotAutoAddCard=True),ensure_ascii=False,indent=2)+'\n')
for r in reqs:
 if r['requestId']=='R56':r['crossQuestionDedupEvidencePath']=str(D/'batch-rule-cross-question-lookup.json');r['additionalNecessaryJudgmentCandidateQids']=[369];r['productionDecision']='independent task candidate; only 2 direct questions shown, so preserve long-tail obligation and evaluate core selection before automatic production'
(D/'revision-requests.json').write_text(json.dumps(dict(requestKind='Minimal proposed clarifications and one independent task candidate; not a new card count.',requests=reqs),ensure_ascii=False,indent=2)+'\n')
counts=dict(collections.Counter(x['status'] for x in parts));result=dict(schemaVersion=1,reviewer='actual_gap_review',completedReviewScope=104,allOriginalCasesRead=True,visibleCardCount=355,initial356Preserved=True,excludedKnownFactFailureRuleIds=['GCL-020'],basis='manifest.v2 frozen input; parent author changes after that snapshot are not silently included',inputManifest=str(I/'manifest.v2.json'),inputManifestSha256=sha((I/'manifest.v2.json').read_bytes()),sourceManifest=json.loads((I/'manifest.v2.json').read_text()),statusCounts=counts,results=parts,revisionRequestsPath=str(D/'revision-requests.json'),sourceFindingsPath=str(D/'source-findings.json'),initialPartFilesPreserved=True,finalOverridesPath=str(D/'final-disposition-overrides.json'),limits=['This is only reverse gap review of 104 previously unpassed cases, not all1018 sufficiency or current updated-author acceptance.','Source evidence outside visible cards never counts as already learned.','Implementation tests are recorded separately and are not automatic new card requests.','52 proposed clarification requests are not 52 new cards; request IDs are grouped by missing mechanism/scope, mostly existing cards.','No card body, production pointer, original question, budget clock, model CLI/API, or automation was changed.'])
(D/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(counts,'requests',len(reqs),'sourceFindings',len(findings),'findings without evidence',[x['findingId'] for x in findings if not x['officialEvidence']])

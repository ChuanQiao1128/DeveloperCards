from write_review import V,I,CASES,CARDS,sha
import json,collections,pathlib
D=V/'review/gap-a';r=json.loads((D/'results.json').read_text());a=r['results'];errs=[]
assert len(a)==104 and {x['qid'] for x in a}==set(CASES)
assert len({x['qid'] for x in a})==104
assert dict(collections.Counter(x['status'] for x in a))==r['statusCounts']
manifest=json.loads((I/'manifest.v2.json').read_text())
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,(p,'manifest hash changed')
for x in a:
 assert x['questionSha256']==sha(json.dumps(CASES[x['qid']]['question'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
 assert all(k in CARDS for k in x['usedRuleIds'])
 assert not ('GCL-020' in x['usedRuleIds'])
 assert bool(x['selectedOptionOrdinals'])==(x['status']=='SUPPORTED')
 for y in x['necessaryAnchors']:
  c=CARDS[y['ruleId']];assert y['bodySha256']==c['bodySha256'];assert y['quote']==c['visibleBody'][y['field']]
reqs=json.loads((D/'revision-requests.json').read_text())['requests'];rr={x['requestId']:x for x in reqs}
findings=json.loads((D/'source-findings.json').read_text())['findings'];ff={x['findingId']:x for x in findings}
for x in a:
 assert all(k in rr or k in ff for k in x['revisionRequestIds']),(x['qid'],x['revisionRequestIds'])
 assert all(k in ff for k in x['sourceFindingIds'])
for x in [*reqs,*findings]:
 for e in x.get('sourceEvidence',x.get('officialEvidence',[])):
  p=pathlib.Path(e['snapshotPath']);assert sha(p.read_bytes())==e['snapshotSha256'];s=json.loads(p.read_text())['text'];assert s[e['quoteStart']:e['quoteEnd']]==e['quote'];assert sha(s.encode())==e['textSha256']
for x in reqs:
 assert all(CARDS[k]['bodySha256']==h for k,h in x['existingBodyHashes'].items())
summary=dict(status='PASS',checks=['104 unique cases exact denominator','frozen manifest.v2 input files hashes','every original full stem/options hash','all visible anchors exact field/body hash','no quarantined GCL-020 reasoning','selected ordinals only on supported proofs','all revision/source IDs defined','all official quotes exact offsets and full text/snapshot hashes','initial six part files retained'],statusCounts=r['statusCounts'],requestCount=len(reqs),newRuleCandidateCount=sum(x['newRuleRequest'] for x in reqs),noFinalCardCountClaim=True,modelCliApiCalls=0,nativeUsage='unknown; parent accounting retained',resultsSha256=sha((D/'results.json').read_bytes()),revisionRequestsSha256=sha((D/'revision-requests.json').read_bytes()),sourceFindingsSha256=sha((D/'source-findings.json').read_bytes()))
(D/'final-readback.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))

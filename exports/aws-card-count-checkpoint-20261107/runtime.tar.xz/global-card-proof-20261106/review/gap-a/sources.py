import pathlib,json,hashlib,re,sys
V=pathlib.Path(__file__).resolve().parents[2]; OUT=V/'evidence/gap-a';OUT.mkdir(parents=True,exist_ok=True)
def sha(x):return hashlib.sha256(x).hexdigest()
def pool():
 cat=json.loads((V.parent/'domain1-final-card-catalog-20261105/official-sources.catalog.json').read_text());paths=[pathlib.Path(x['sourcePath']) for x in cat if x.get('sourcePath')]
 paths+=list((V/'evidence/cards-c').glob('*.json'))
 paths+=list(OUT.glob('fetch-*.json'))
 out=[];seen=set()
 for p in paths:
  try:d=json.loads(p.read_text());t=d.get('text','');u=d.get('finalUrl') or d.get('url','')
  except:continue
  if not t or not re.match(r'https://(?:docs\.)?aws\.amazon\.com/',u) or (u,sha(t.encode())) in seen:continue
  seen.add((u,sha(t.encode())));out.append(dict(url=u,text=t,path=str(p),fileSha256=sha(p.read_bytes()),textSha256=sha(t.encode())))
 return out
if __name__=='__main__':
 pat=sys.argv[1];matches=[x for x in pool() if re.search(pat,x['url'],re.I)]
 for x in matches:
  print(x['url'],x['path'])
  if len(sys.argv)>2:
   for m in list(re.finditer(sys.argv[2],x['text'],re.I))[:6]:print(repr(x['text'][max(0,m.start()-150):m.end()+350]))

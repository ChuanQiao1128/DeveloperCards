# -*- coding: utf-8 -*-
import pathlib,json,hashlib,datetime,collections,re
D=pathlib.Path(__file__).resolve().parent;V=D.parents[2];I=V/'review/supplemental05/input';O=V/'review/reuse-a'
sha=lambda b:hashlib.sha256(b).hexdigest();canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode();read=lambda p:json.loads(pathlib.Path(p).read_text())
manifest=read(I/'manifest.json');draft=read(I/'cards.json');pool=read(I/'visible-pool.frozen.json');C={x['ruleId']:x for x in pool};Q={x['qid']:x['question'] for x in read(I/'questions.json')};AE=read(I/'official-evidence.json');idxpath=V/'validation/current-card-review-index.json';idx=read(idxpath);IX={x['ruleId']:x for x in idx['cards']};Fields=['frontZH','answerZH','keyPointZH','watchOutZH'];R={};E={}
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,p
for c in pool:assert sha(canon(c['visibleBody']))==c['bodySha256'],c['ruleId']
for e in AE:
 p=pathlib.Path(e['snapshotPath']);s=read(p);assert sha(p.read_bytes())==e['snapshotSha256'];assert sha(s['text'].encode())==e['textSha256'];assert s['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
def evidence(n,start,end,supports):
 e=AE[n];p=pathlib.Path(e['snapshotPath']);d=read(p);t=d['text'];a=t.index(start);b=t.index(end,a)+len(end);x=dict(sourcePath=str(p),sourceFileSha256=sha(p.read_bytes()),textSha256=sha(t.encode()),url=e['url'],quote=t[a:b],quoteStart=a,quoteEnd=b,supports=supports);k=sha(canon(x));E[k]=x;return k
def own(n,start,end,supports):
 p=D/(n+'.json');d=read(p);t=d['text'];a=t.index(start);b=t.index(end,a)+len(end);x=dict(sourcePath=str(p),sourceFileSha256=sha(p.read_bytes()),textSha256=sha(t.encode()),url=d['url'],quote=t[a:b],quoteStart=a,quoteEnd=b,supports=supports);k=sha(canon(x));E[k]=x;return k
sched=evidence(10,'Automated backup schedules and retention management','Encrypted backups','NS03: all supported resources have automated schedule/retention features')
efs=evidence(10,'Amazon EFS ✓','FSx for Lustre','NS03: EFS row, resolved by independently retained table header/cells, not checkmark count')
# Table grid is independently parsed from full official HTML, keeping empty cells.
bt=read(D/'backup-availability.tables.json');br=next(x for x in bt['tables'][0] if x[0]=='Amazon EFS');bh=bt['tables'][0][0];assert len(br)==len(bh);assert br[bh.index('Cross-Region backup')]=='✓';assert br[bh.index('Continuous backup and point-in-time restore')]==''
E[efs]['tableBinding']=dict(tablePath=str(D/'backup-availability.tables.json'),tableSha256=sha((D/'backup-availability.tables.json').read_bytes()),htmlPath=bt['htmlPath'],htmlSha256=bt['htmlSha256'],headers=bh,row=br,checkedColumns={'Cross-Region backup':'✓','Continuous backup and point-in-time restore':''},scope='EFS supported backup and cross-Region copy; no EFS continuous PITR claim')
sns=evidence(6,'A dead-letter queue is an Amazon SQS queue','held in the dead-letter queue for further analysis or reprocessing.','GSC083: SNS subscription delivery failures go to SQS')
lam=evidence(5,'Lambda can send records of asynchronous invocations','events that fail all processing attempts.','GSC083: async Lambda on-failure record and supported SQS destination')
ret=evidence(4,'Message retention','The maximum is 1,209,600 seconds (14 days).','GSC083: SQS retention maximum')
ecs=evidence(17,'There is no additional charge for Amazon ECS orchestration.','For ECS Managed Instances, there is an additional management fee per instance for the operational management provided by AWS.','GSC139: ECS Fargate orchestration has no ECS fee; underlying compute still billed')
eks=evidence(18,'Amazon EKS cluster pricing All Amazon EKS clusters','per cluster per hour fee based on the cluster’s Kubernetes version.','GSC139: EKS cluster control-plane fee')
eksf=evidence(18,'If you are using AWS Fargate, pricing is calculated','A minimum charge of one minute applies.','GSC139: EKS also supports Fargate compute')
ddb=evidence(16,'Using deletion protection You can protect a table','When deletion protection is enabled for a table, it cannot be deleted by anyone.','GSC053: table deletion protection and authorized control')
dbr=evidence(19,'Recipe In DataBrew, a recipe','You can also publish multiple versions of a recipe.','GSC096: reusable/downloadable recipe instructions')
dbl=evidence(19,'Data lineage DataBrew tracks','running a data profile job.','GSC096: distinct lineage and profile purposes')
dbp=own('databrew-profile','Profile jobs run a series of evaluations','might want to run in your recipe jobs.','GSC096: profile output to S3 and preparation decision')
dbq=own('databrew-profile','(Optional) You can create Data quality rules','Validating data quality in AWS Glue DataBrew.','GSC096: optional quality evaluation, not default ruleset claim')
co=evidence(14,'Estimated monthly savings (On-Demand)','recommended specifications.','GSC151: EBS approximate monthly savings')
bud=evidence(13,'For Period , choose','All budget times are in UTC.','GSC155/Q715: daily savings-plan budget period')
buda=evidence(13,'For Coverage threshold','email and/or Amazon SNS topic.','GSC155: below coverage threshold can notify')
sp=evidence(15,'Compute Savings Plans provide the most flexibility','They also apply to your Fargate and Lambda usage.','CB02: flexible EC2/Lambda/Fargate Compute plan scope')
sm=evidence(15,'SageMaker AI Savings Plans provide savings','component (for example, Notebook, Training, etc.).','CB02: SageMaker plan service family')
mon=evidence(11,'Monitoring type Description Charges Basic monitoring','You are charged per metric that Amazon EC2 sends to CloudWatch.','GSC145: basic 5m, status exception 1m, detailed 1m')
mt=read(D/'ec2-monitoring.tables.json');assert mt['tables'][0][0]==['Monitoring type','Description','Charges'];assert '5-minute' in mt['tables'][0][1][1] and '1-minute' in mt['tables'][0][2][1];E[mon]['tableBinding']=dict(tablePath=str(D/'ec2-monitoring.tables.json'),tableSha256=sha((D/'ec2-monitoring.tables.json').read_bytes()),htmlPath=mt['htmlPath'],htmlSha256=mt['htmlSha256'],headers=mt['tables'][0][0],rows=mt['tables'][0][1:])
scale=evidence(9,'Automatic scaling is the ability','reduce costs during periods of low utilization.','GSC137: service task count scales from CloudWatch metrics')
a2c=own('a2c-support','App2Container supports identification and containerization','running on Linux.','Q969: explicit Linux ASP.NET support; not Windows-only')
a2cq=own('a2c-support','AWS .NET Modernization Tools','sign up prior to November 7, 2025.','Q969: eligibility boundary, not blanket obsolete exemption')
a2cv=own('a2c-support','For ASP.NET applications running on Linux','Process mode is not supported for ASP.NET applications','Q969: actual Linux runtime versions; keep version compatibility as ordinary condition')
# Verify old review receipts once; only unchanged mechanism portions are reused.
def receipt(k):
 c=C[k];x=IX[k];assert x['status']=='PASS' and x['currentBodySha256']==c['bodySha256'],k
 for p in x['proofs']:assert sha(pathlib.Path(p['path']).read_bytes())==p['sha256'],p['path']
 return dict(ruleId=k,priorBodySha256=c['bodySha256'],indexPath=str(idxpath),indexSha256=sha(idxpath.read_bytes()),proofs=x['proofs'])
notes={
'CUR:NS03':('按自动备份管理工具范围作一项选择；EFS仅是同一范围的实例，不新增第二配置清单。','若要求同RegionEBS专用生命周期，仍用DLM；改为多服务/EFS目标跨Region恢复点则用支持的AWS Backup。',[sched,efs]),
'GSC-083':('失败发生点这条因果正确，但当前回答要同时回忆SQS阈值DLQ、SNS订阅DLQ、Lambda异步destination，再带14天配额。正面没给具体系统，难以只评一个判断。','把失败从SNS投递改成已接收的Lambda业务处理时，保留位置应随失败层变化；卡里有这个有效机制，不能抵扣整张记忆任务的膨胀。',[sns,lam,ret]),
'GSC-139':('一个由Kubernetes接口保留要求决定编排选择的双条件比较；费用解释的是同一取舍。','有Kubernetes对象/API保留约束时选EKS；无该要求且重运营/费用时可ECS Fargate。',[ecs,eks,eksf]),
'GSC-053':('统一的“备份恢复不阻止删除”判断扩展到另一个支持删除保护的资源，不要求多套操作步骤。','误删风险先阻止删除；已发生数据丢失才是恢复。关闭保护的授权主体仍可先关再删。',[ddb]),
'GSC-096':('一个无代码数据准备服务选择与同流程步骤复用；recipe/profile/lineage随文解释用途，自评只需DataBrew与recipe，不要求背三套配置。','若只是扫描schema，crawler可用；若需求含可视化清洗、质量/来源可见与共享步骤，则DataBrew recipe适配；不把profile等同默认跑所有规则。',[dbr,dbl,dbp,dbq]),
'GSC-151':('仍是监控曲线与明确规格建议的选择，预计月节省只是同一建议输出的理解。','需自己看曲线与需服务直接给EBS改规格及预估收益，选择不同；估算不保证迁移后的实际账单。',[co]),
'GSC-155':('原任务比较utilization/coverage与是否加买；新背面额外要求配置coverage budget及告警，正面没有问自动通知。两个独立动作被放进同一答案。','两类分母与加购判断本身可迁移；告警是另一目标，当前正面不能判学习者是否必须答它。',[bud,buda]),
'CUR:CB02':('按服务适用范围给最少两类承诺，仍是一项组合范围判断；不追加价格数字、购买步骤。','去掉SageMaker时只需Compute SP；保留SageMaker时需其专用计划，不能只因都是计算就混入Compute SP。',[sp,sm]),
'GSC-145':('同一时间粒度决策：刷新不能补观测。新增EC2详细监控1分钟与原秒级边界沿同一轴，没有混成部署清单。','2分钟上限时1分钟详细监控满足；若变为秒级则详细监控不足，需受支持的高分辨率自定义采集。状态检查本已1分钟例外准确。',[mon]),
'GSC-137':('服务任务数与可放置这些任务的CPU/内存是同一个两层伸缩辨析，CloudWatch补的是实际触发机制。','换成Fargate时不照搬EC2 ASG步骤；EC2承载任务放不下时要补底层容量。',[scale])}
cards=[];overlay=dict(C)
for c in draft:
 k=c['ruleId'];body={f:c[f] for f in Fields};old=C[k];assert c['repairOf']==old['bodySha256'];changed=[f for f in Fields if body[f]!=old['visibleBody'][f]];h=sha(canon(body));bad=k in ('GSC-083','GSC-155');r=receipt(k);n,t,eids=notes[k]
 checks={x:dict(status='PASS',reason=z) for x,z in [('FACT','新增句已有正向AWS事实；未改变旧机制按有效收据及旧正文哈希复用。'),('U1',n),('R1',n),('T1',t),('S1','只按正面实际所问的结论及关键原因自评，不把原已知前提或实施配置列为必答。'),('P1','必要基础来自冻结351保留池；完整先修在逐题锚点/闭包登记。')]};checks['B1']=dict(status='NOT_APPLICABLE',reason='仅冻结中文四字段；不据此验收双语、导入、发布或学习效果。')
 if bad:
  checks['R1']=dict(status='FAIL',reason=n);checks['S1']=dict(status='FAIL',reason='正面没有给出足够任务边界来判断新增背面事项哪些必须回忆。GSC083新增第三系统与14天数值；GSC155新增未问告警动作。')
 cards.append(dict(ruleId=k,verdict='FAIL' if bad else 'PASS',bodySha256=h,priorBodySha256=old['bodySha256'],inputCardSha256=sha(canon(c)),visibleBody=body,changedFields=changed,unchangedFields=[f for f in Fields if f not in changed],reusedMechanismReceipt=r,checks=checks,evidenceIds=eids,teachingTaskAnalysis=n,transferProbe=t,repairRequest=('保留失败发生点的核心因果，收窄为一个可明确作答的判断；复用已有SQS基础，不靠三种配置及独立配额堆在一张卡中补题。' if k=='GSC-083' else '令正面实际任务与背面自评一致；不要把是否加买承诺与自动告警配置合为一个未标明的必答任务。') if bad else None))
 overlay[k]=dict(old,visibleBody=body,bodySha256=h)
cardV={x['ruleId']:x['verdict'] for x in cards};questions=[]
def a(k,f,why):
 c=overlay[k];return dict(cardId=k,ruleId=k,bodySha256=c['bodySha256'],field=f,quote=c['visibleBody'][f],quoteStart=0,quoteEnd=len(c['visibleBody'][f]),supports=why,origin='supplemental05 proposed overlay' if k in cardV else 'frozen retained351 prerequisite')
def question(q,status,choice,ids,anchors,reason,opts,missing=None,conds=None,proposed=None,impl=None):
 seen=set();group=[]
 def go(k,active):
  assert k in overlay and k not in active,k
  if k in seen:return
  seen.add(k);c=overlay[k];group.append(dict(ruleId=k,bodySha256=c['bodySha256'],visibleBody=c['visibleBody'],prerequisiteRuleIds=c['prerequisiteRuleIds']));receipt(k)
  for p in c['prerequisiteRuleIds']:go(p,active|{k})
 for k in ids:go(k,set())
 questions.append(dict(qid=q,status=status,selectedOptionOrdinals=choice if status=='SUPPORTED' else [],candidateOptionOrdinals=choice if status!='SUPPORTED' else [],questionSha256=sha(canon(Q[q])),originalQuestion=Q[q],fullStemAndAllOptionsRead=True,usedRuleIds=ids,necessaryAnchors=anchors,learnerVisibleGroup=group,reasoning=reason,allOptions=opts,missingJudgments=missing or [],conditionsAndSourceIssues=conds or [],implementationValidationNotNewKnowledge=impl or [],proposedSemanticStatus=proposed or status,failedDraftDependencies=[k for k in ids if cardV.get(k)=='FAIL'],currentPointersChanged=False,scope='Proposed overlay design support only; failed cards cannot upgrade accepted inventory or current question support.'))
question(148,'INSUFFICIENT_CARDS',[4],['GSC-083','GSC-079','VC-001','GSC-080'],[a('GSC-083','keyPointZH','区分SNS交付与Lambda处理'),a('GSC-083','answerZH','Lambda异步最终失败可到SQS'),a('VC-001','answerZH','Lambda服务轮询SQS并确认完成')],'D是保留失败事件再处理的方向；新句技术上补了Lambda on-failure到SQS，但该草稿教学FAIL，不能升级当前支撑。原题network connectivity failure也未明确在SNS投递还是Lambda已接收后访问数据存储，配置须接在实际失败层。',{1:'Lambda多AZ由服务负责，并不保存持续处理失败事件。',2:'增CPU/内存不修网络或保存未处理通知。',3:'SNS投递重试不等同Lambda已接收后的业务失败重试，且只延长重试不保留最终失败任务。',4:'失败保留SQS并由函数消费；需选实际发生失败的SNS redrive或Lambda on-failure层。'},missing=['GSC083须先修复单次回忆任务；不能把新草稿技术句直接当教学接受。'],conds=['若故障是SNS从未成功交付，不能只配置Lambda处理失败目的地就声称已捕获。'],proposed='CONDITIONAL',impl=['失败目的地记录有请求/响应包装；实际消费者需解析、修复并幂等重放。'])
question(475,'SUPPORTED',[3],['GSC-001','GSC-002','CUR:NS03','GSC-067','GSC-070'],[a('GSC-001','answerZH','共享EFS文件'),a('GSC-002','answerZH','Regional及每AZ挂载路径'),a('CUR:NS03','keyPointZH','EFS计划备份并跨Region复制'),a('GSC-070','answerZH','RPO看目标已可用恢复点')],'C满足区域共享文件、跨AZ持久存储及各AZ挂载；AWS Backup EFS跨Region复制已按表头和EFS行逐格确认。8小时RPO由备份/复制计划与目标可用恢复点约束，不把一次启用Backup自动说成8h已实测。',{1:'Windows FSx是SMB/AD多AZ文件服务器，不是题中EFS式每AZ mount target模型。',2:'ONTAP是另一协议/文件服务部署，不满足所述每AZ EFS mount target架构模型。',3:'EFS Regional/Standard共享、多AZ挂载并由支持的Backup复制恢复点。',4:'OpenZFS不是所给每AZ挂载目标的EFS Regional模型。'},impl=['配置足够频繁的备份和跨Regioncopy，监控目标最近可恢复点满足8h；不要求为选存储再新增实测SLA卡。'])
question(486,'SUPPORTED',[1],['CUR:CA16','CUR:XB019','CUR:CC22','GSC-139'],[a('CUR:CA16','answerZH','静态S3'),a('CUR:XB019','keyPointZH','Fargate少管宿主'),a('CUR:CC22','keyPointZH','RDS托管数据库平台'),a('GSC-139','keyPointZH','ECS无编排额外费，EKS有cluster费用')],'A按静态、容器、关系库存放各层，Fargate减少宿主管理；没有Kubernetes接口保留要求，ECS相较EKS去掉额外cluster费用。',{1:'全部层匹配且托管计算减少维护。',2:'CloudFront交付缓存不是原始静态内容存储，EC2还需维护主机。',3:'同样用Fargate，但未要求Kubernetes，额外EKS集群费用无必要。',4:'静态内容与容器都引入EC2/Kubernetes平台维护。'})
question(489,'INSUFFICIENT_CARDS',[3],['GSC-083','GSC-079','GSC-080'],[a('GSC-083','answerZH','SNS订阅投递失败到SQS'),a('GSC-083','keyPointZH','SQS最多14d'),a('GSC-080','keyPointZH','每个SNS订阅独立交付路径')],'C在HTTP订阅失败那层用SNS DLQ的SQS保留14天，技术闭合；但依赖的GSC083当前草稿教学FAIL，不能据此升级正式支撑。',{1:'SNS DLQ目标不是Kinesis data stream。',2:'放在SNS之前的队列不保存后续HTTPS订阅最终投递失败。',3:'对实际失败的SNS订阅配置SQS DLQ，14d内分析。',4:'DynamoDB不是SNS订阅DLQ目标，TTL也不代替支持的失败路径。'},missing=['待GSC083回忆任务收窄并独立通过；事实链已核，不重复提取考点。'],proposed='SUPPORTED')
question(715,'INSUFFICIENT_CARDS',[1],['GSC-155','GSC-152','CUR:CB02'],[a('GSC-155','answerZH','coverage budget和阈值'),a('GSC-155','keyPointZH','低于coverage阈值通知'),a('GSC-152','answerZH','预算阈值与异常检测不同')],'A的Daily Savings Plans coverage budget及email阈值通知有逐句官方正证，最少自建；但GSC155的正面仍只问是否加买，新增告警未形成可自评回忆任务，草稿FAIL使该题当前缺口不闭合。',{1:'直接的coverage budget阈值告警，服务文档明确支持Daily。',2:'自写Lambda/SES能做但维护多于托管预算。',3:'定时预算报告不等于coverage下降到阈值时的条件告警。',4:'泛Savings Plans alert订阅不是所需coverage budget阈值配置。'},missing=['GSC155需对齐正面任务与新增告警答案，不把未问动作塞入原比较卡。'],proposed='SUPPORTED')
question(727,'SUPPORTED',[3],['GSC-053'],[a('GSC-053','answerZH','启用删除保护'),a('GSC-053','keyPointZH','DynamoDB表级保护拒绝删除')],'C直接阻止误删；备份/PITR在删除后恢复不等于避免业务中断。',{1:'检测后自动恢复是事后补救且需代码。',2:'手工恢复不能预防误删中断。',3:'受保护状态直接拒绝DeleteTable。',4:'PITR帮助事后恢复，不拒绝删除请求。'})
question(812,'SUPPORTED',[3],['GSC-096'],[a('GSC-096','answerZH','DataBrew及共享recipe'),a('GSC-096','keyPointZH','profile质量分布、lineage来源与处理经过')],'C是无代码可视化准备、profile/lineage及recipe共享的同一工作流；新增术语已在卡面解释用途。',{1:'Glue Studio是视觉ETL选项，但所给分享jobs不能替代DataBrew的recipe及所需组合可视化准备能力。',2:'EMR Serverless提供计算，不提供题中指定的无代码可视化准备工件与原生recipe共享。',3:'DataBrew recipe保存并共享步骤，profile与lineage各提供所需可见性。',4:'手写SQL不满足no-code，也不直接提供同一准备流程的profile/lineage。'})
question(867,'SUPPORTED',[4],['GSC-151'],[a('GSC-151','answerZH','ComputeOptimizer建议'),a('GSC-151','keyPointZH','EBS预计月节省输出')],'D提供EBS规格优化和预计月节省，卡面明确由曲线到建议的差别。',{1:'Inspector做漏洞/安全发现，不是EBS成本规格优化建议。',2:'SSM主机管理报告不直接给题中Optimizer建议。',3:'CloudWatch提供指标，单纯metrics报告不是该完整推荐/节省输出服务。',4:'ComputeOptimizer EBS建议列出预计月节省。'})
question(885,'SUPPORTED',[3,4],['CUR:CB02'],[a('CUR:CB02','answerZH','Compute及SageMaker两类'),a('CUR:CB02','keyPointZH','Compute服务范围不能吞并SageMaker')],'C+D用两类计划覆盖所有四种给定服务；source plan-types虽现有4类型，但Database SP不改变此计算/ML分组。',{1:'EC2 Instance SP不覆盖SageMaker。',2:'Compute SP不覆盖SageMaker，漏Fargate的描述也不完整。',3:'SageMaker独立计划覆盖ML实例用量。',4:'Compute覆盖EC2/Lambda/Fargate。',5:'EC2 Instance SP不覆盖Fargate。'})
question(910,'SUPPORTED',[2],['GSC-145'],[a('GSC-145','answerZH','EC2详细监控1m'),a('GSC-145','keyPointZH','采集粒度而非刷新决定细度'),a('GSC-145','watchOutZH','状态检查原本1m例外')],'B以1分钟指标满足不超过2分钟；EC2基本/详细监控表的具体行列已独立核验，不把1分钟与1秒混淆。',{1:'转日志到Redshift/QuickSight不自动改变EC2指标采集粒度。',2:'启用详细监控取得1m数据点，由CloudWatch分析。',3:'取Logs不是开启所需EC2标准性能指标粒度。',4:'日志换S3/Redshift路径同样不补标准指标5m间隔。'})
question(969,'CONDITIONAL',[1],['GCL-032','CUR:XB019','GSC-137','GSC-143'],[a('GCL-032','answerZH','分析容器化与运行分工'),a('GCL-032','watchOutZH','A2C新客户资格边界'),a('CUR:XB019','keyPointZH','Fargate减少主机维护'),a('GSC-137','answerZH','CloudWatch驱动任务数伸缩')],'A的容器化→CloudFormation/ECS Fargate及CloudWatch服务伸缩方向已闭合。新官方完整支持页明确ASP.NET on Linux受支持，不沿用Windows-only假设。仍保留GCL032实际客户资格及受支持runtime条件，不能靠这次新增CloudWatch句把当前原题升为无条件充分。',{1:'已具A2C资格且runtime受支持时是最少主机维护方向；自动容器化不等于任意旧代码都已现代化到目标.NET版本。',2:'EC2路径增加宿主维护。',3:'App Runner不是生成A2C工件再部署到ECS的工具。',4:'App Runner也不是把应用打包交EKS/EC2的部署工具，且管理更多。'},conds=['A2C不再开放新客户，原题没有说明已于2025-11-07前取得资格。','按官方Linux受支持.NET runtime核实际版本；兼容性检查不另造一张Windows/Linux服务组合卡。'])
# Final audit is deterministic; it never upgrades the semantic/card verdicts.
omitted={'CUR:XB039','GSC-019','GCL-017','GSC-072','GSC-098','GSC-108','GSC-084','GCL-020'}
assert len(cards)==10 and len(questions)==11
for q in questions:
 assert len(q['allOptions'])==len(Q[q['qid']]['options'])
 assert not omitted&{c['ruleId'] for c in q['learnerVisibleGroup']}
 for x in q['necessaryAnchors']:
  c=overlay[x['ruleId']];assert c['visibleBody'][x['field']][x['quoteStart']:x['quoteEnd']]==x['quote']
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,p
for k,e in E.items():
 p=pathlib.Path(e['sourcePath']);d=read(p);assert sha(p.read_bytes())==e['sourceFileSha256'];assert sha(d['text'].encode())==e['textSha256'];assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
 if e.get('tableBinding'):
  tb=e['tableBinding'];assert sha(pathlib.Path(tb['tablePath']).read_bytes())==tb['tableSha256'];assert sha(pathlib.Path(tb['htmlPath']).read_bytes())==tb['htmlSha256']
now=datetime.datetime.now(datetime.timezone.utc).isoformat();counts=collections.Counter(q['status'] for q in questions);summary=dict(cardCount=10,cardPass=8,cardFail=2,cardUnknown=0,questionCount=11,**dict(counts))
repair=[dict(ruleId=c['ruleId'],request=c['repairRequest'],failedChecks=[k for k,v in c['checks'].items() if v['status']=='FAIL']) for c in cards if c['verdict']=='FAIL']
out=dict(schemaVersion=1,reviewer='actual_gap_review independent supplemental05',reviewedAtUtc=now,authorVersion='supplemental05 frozen input only; not applied',inputManifestPath=str(I/'manifest.json'),inputManifestSha256=sha((I/'manifest.json').read_bytes()),inputFiles=manifest,bodyHashContract='SHA256 canonical UTF-8 JSON of frontZH/answerZH/keyPointZH/watchOutZH, sorted keys and compact separators',summary=summary,cards=cards,evidenceRegistry=E,affectedQuestions=questions,overlayPoolBinding=dict(path=str(I/'visible-pool.frozen.json'),sha256=sha((I/'visible-pool.frozen.json').read_bytes()),retainedCount=351,revisedIdentityCount=10,newIdentityCount=0,omittedCardsBorrowed=0),scope='Chinese FACT/teaching and 11 original question design support under proposed overlay; not formal bilingual/deck import/learner performance/final N',originalReviewHistoryPreserved=True,modelCliApiCalls=0,nativeUsage='unknown',currentPointersChangedByReviewer=False,authoringPerformed=False,contentRepairRequests=repair)
p=O/'supplemental05.review.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
rb=dict(schemaVersion=1,status='PASS',scope='Artifact binding only. Card/teaching FAILs remain FAIL.',checkedAtUtc=now,reviewPath=str(p),reviewSha256=sha(p.read_bytes()),inputManifestPath=str(I/'manifest.json'),inputManifestSha256=sha((I/'manifest.json').read_bytes()),frozenInputsChecked=len(manifest),revisedCards=10,repairOfBindings=10,retainedCorePool=351,allCoreBodyHashesChecked=351,allQuestionsAndOptions=11,cardPass=8,cardFail=2,officialExactExcerpts=len(E),tableHeaderAndRowBindings=2,proofAnchorsExact=True,missingPrerequisites=0,omittedSevenAndGCL020Used=0,oldMechanismReceiptsVerified=True,currentPointersChanged=False,modelCliApiCalls=0,nativeUsage='unknown',finalCardCount=None)
(O/'supplemental05.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False));print('EVIDENCE',len(E))

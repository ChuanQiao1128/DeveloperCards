# -*- coding: utf-8 -*-
import pathlib,subprocess,json,hashlib,datetime
from html.parser import HTMLParser
D=pathlib.Path(__file__).resolve().parent
class Tables(HTMLParser):
 def __init__(self):super().__init__();self.tables=[];self.table=None;self.row=None;self.cell=None
 def handle_starttag(self,tag,attrs):
  if tag=='table':self.table=[]
  elif tag=='tr' and self.table is not None:self.row=[]
  elif tag in ('th','td') and self.row is not None:self.cell=[]
  elif tag=='img' and self.cell is not None:
   a=dict(attrs);self.cell.append(a.get('alt',''))
 def handle_data(self,s):
  if self.cell is not None:self.cell.append(s)
 def handle_endtag(self,tag):
  if tag in ('th','td') and self.cell is not None:self.row.append(' '.join(' '.join(self.cell).split()));self.cell=None
  elif tag=='tr' and self.row is not None:self.table.append(self.row);self.row=None
  elif tag=='table' and self.table is not None:self.tables.append(self.table);self.table=None
url='https://docs.aws.amazon.com/aws-backup/latest/devguide/backup-feature-availability.html'
r=subprocess.run(['curl','-fLsS','--max-time','30',url],capture_output=True,check=True);p=D/'backup-availability.raw.html';p.write_bytes(r.stdout);h=Tables();h.feed(r.stdout.decode());out=dict(url=url,htmlPath=str(p),htmlSha256=hashlib.sha256(r.stdout).hexdigest(),retrievedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tables=h.tables);(D/'backup-availability.tables.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for ix,t in enumerate(h.tables):
 e=[row for row in t if row and row[0]=='Amazon EFS']
 if e:print('TABLE',ix,'HEADER',t[0],'EFS',e)

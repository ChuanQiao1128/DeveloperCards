# -*- coding: utf-8 -*-
import pathlib,json,hashlib,subprocess,datetime,shutil,sys
D=pathlib.Path(__file__).resolve().parent;V=D.parents[2];E=D;E.mkdir(exist_ok=True)
sys.path.insert(0,str(V/'review/gap-b'));from source_tools import Text
sha=lambda b:hashlib.sha256(b).hexdigest()
def fetch(key,url):
 p=E/(key+'.json')
 if p.exists():return p
 r=subprocess.run(['curl','-fLsS','--max-time','30','--write-out','\n%{url_effective}\n%{http_code}',url],capture_output=True,check=True);b,fu,st=r.stdout.rsplit(b'\n',2);h=Text();h.feed(b.decode());t='\n'.join(' '.join(s.split()) for s in ''.join(h.a).splitlines() if s.strip());p.write_text(json.dumps(dict(url=fu.decode(),requestedUrl=url,httpStatus=int(st),text=t,textSha256=sha(t.encode()),htmlSha256=sha(b),retrievedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()),ensure_ascii=False,indent=2)+'\n');return p

def quote(key,p,start,end):
 p=pathlib.Path(p);d=json.loads(p.read_text());t=d['text'];s=t.index(start);e=t.index(end,s)+len(end);dst=E/(key+'.snapshot.json')
 if dst!=p:shutil.copyfile(p,dst)
 return dict(url=d.get('finalUrl') or d['url'],quote=t[s:e],quoteStart=s,quoteEnd=e,snapshotPath=str(dst),snapshotSha256=sha(dst.read_bytes()),textSha256=sha(t.encode()))

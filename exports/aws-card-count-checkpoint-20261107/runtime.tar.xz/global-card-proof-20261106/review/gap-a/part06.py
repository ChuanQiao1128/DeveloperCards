from write_review import write
write(6,[
(1010,'INSUFFICIENT_CARDS',[2,3,4],['GSC-064','GSC-065','GSC-066'],'整机lift-and-shift对应MGN，先测试再停源最终同步并切换是现卡已教生命周期，其他SCT/DMS/A2C不是虚拟机整机复制。当前没教MGN安装Replication Agent后初始块复制→test launch的实际机制；只靠产品名字无法把B/C具体动作视为所学。优先小修GSC064/065而非新增独立原理。',['R54'],['按服务当前客户资格和源平台支持执行；不靠资格待验自动另增卡。']),
(1013,'CONDITIONAL',[2],['GSC-146','CUR:CB02'],'不能中断排除C/D Spot。A Scheduled RI当前已不能购买，且历史购买有最低年度时数，不能默认为周日12小时必适用。若严格在当前可购买的四项中选，B可用但Sunday-only Convertible全年计费通常不经济；原题预期比较与年代须澄清。现卡只教Compute SP而未教RI全年承诺/Standard与Convertible价格和Schedule购买范围，需核事实，不能给A历史资格PASS。',['S23','R55'],[]),
(1014,'INSUFFICIENT_CARDS',[2],['GSC-088','CUR:NA05','CUR:XB019'],'持久Step Functions管步骤、S3保存结果，B；A把SQS当流程编排且自管Spot，C/D仍管EC2。当前没有AWS Batch作业排队/调度和可用Fargate compute environment免宿主维护的教学，不能凭Batch名称补机制。此为真正独立作业调度判断候选，应先检全库跨题复用后决定新增，不能拼进Step Functions卡。',['R56'],['选择适用的Batch托管/Fargate计算环境；AWS Batch支持EC2不表示默认免宿主责任。']),
(1019,'CONDITIONAL',[2],['CUR:XA053','CUR:XB020','CUR:CMP-M04'],'若HTTP API为泛指HTTP接口而实为REST API，B资源策略按来源IP拒绝可成立；若明确指API Gateway HTTP API产品，当前不支持resource policy，B不可执行。A私有集成只控制到后端路径，C/D把API Gateway当放在客户子网内有SG的实例均错。该产品歧义已由现卡教会，不需要再加API卡，只需题源明确产品。',['S24'],[]),
])

from fetch_sources import f
import concurrent.futures
urls={
'rds-retention':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_WorkingWithAutomatedBackups.BackupRetention.html',
'rds-automated':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_ManagingAutomatedBackups.html',
'aurora-replication':'https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/Aurora.Replication.html',
'aurora-backup':'https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/Aurora.Managing.Backups.html',
'ga-components':'https://docs.aws.amazon.com/global-accelerator/latest/dg/introduction-components.html',
'launch-template-schema':'https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_RequestLaunchTemplateData.html',
'fleet-launch':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-fleet-launch-template.html',
'rds-custom-replica':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/custom-rr.html',
'efs-remote':'https://docs.aws.amazon.com/efs/latest/ug/mounting-on-premises.html',
'aws-batch-whatis':'https://docs.aws.amazon.com/batch/latest/userguide/what-is-batch.html',
'shield-cloudfront':'https://docs.aws.amazon.com/waf/latest/developerguide/ddos-protections-by-resource.html',
'lambda-ha':'https://docs.aws.amazon.com/lambda/latest/dg/disaster-recovery-resiliency.html',
'api-ha':'https://docs.aws.amazon.com/apigateway/latest/developerguide/disaster-recovery-resiliency.html',
}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
 for r in ex.map(f,urls.items()):print(r)

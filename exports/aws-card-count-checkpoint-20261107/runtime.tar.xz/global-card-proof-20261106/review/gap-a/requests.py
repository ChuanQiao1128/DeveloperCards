from write_review import V, CARDS, CASES, sha
from sources import pool,OUT
import json,pathlib,re,shutil
P=pool()
def ev(urlpat,pattern,width=650):
 matches=[x for x in P if re.search(urlpat,x['url'],re.I)]
 for x in matches:
  m=re.search(pattern,x['text'],re.I)
  if not m:continue
  st=max(0,m.start()-80);en=min(len(x['text']),m.end()+width);quote=x['text'][st:en]
  name='cache-'+x['fileSha256'][:20]+'.json';dest=OUT/name
  if not dest.exists():shutil.copyfile(x['path'],dest)
  return dict(url=x['url'],snapshotPath=str(dest),snapshotSha256=sha(dest.read_bytes()),textSha256=x['textSha256'],quote=quote,quoteStart=st,quoteEnd=en,originalSnapshotPath=x['path'])
 return None
DEFS={
'R01':(['GSC-057'],'Aurora Auto Scaling依据CloudWatch目标读负载自动增减Aurora Replicas；扩reader数与单实例Serverless容量是两个方向。','当前只说增加reader分担读取，没说明自动调整副本数。','Aurora.Integrating.AutoScaling','dynamically adjusts',650),
'R02':(['CUR:CC22','GSC-057'],'Aurora是MySQL/PostgreSQL兼容关系数据库，须选相应兼容引擎；以区域共享耐久存储支撑副本/接管，Serverless保留该关系引擎模型。','现卡泛称RDS兼容前提，缺Aurora实际引擎对应，不能从服务名补事实。','AuroraUserGuide/','compatible',600),
'R03':(['GSC-029','GSC-079'],'S3对象创建通知可发SQS；Lambda的SQS事件源映射受管轮询队列，按批调用函数，成功后删除消息。','目前分别讲S3→Lambda/EventBridge、EC2消费者，未教这条真实受管连接。保留现有幂等/超时边界；不拼权限配置清单。','lambda/latest/dg/with-sqs','Lambda polls the queue',600),
'R04':(['GSC-025'],'Intelligent-Tiering所用即时层跨至少三个AZ保存，适合冷热不定又需即时访问且承受单AZ故障的数据。','现卡教分层与可选异步归档，不说明所选层多AZ；其他S3类别不能替代该事实。','storage-class-intro','S3 Intelligent-Tiering \\(INTELLIGENT_TIERING\\)\\nData',600),
'R05':(['CUR:NS02'],'Global Accelerator支持TCP/UDP，用户进入附近AWS边缘后走AWS全球网络，依据位置/网络性能与健康选择合适区域端点。','当前GA只教固定IP/健康选区，没有其全球低时延路径；NLB/CloudFront卡不补GA机制。','global-accelerator/faqs','TCP|UDP',650),
'R06':(['CUR:NS01'],'Data Firehose是托管交付流，按目的地持续缓冲交付；其区域冗余/扩展范围须明确，S3选多AZ类别。','现卡教交付/转换却没说明高可用承载，不要求额外SLA演练卡。','firehose/latest/dev/what-is','fully managed',550),
'R07':(['CUR:NC07'],'DataSync agent到AWS服务的传输受TLS保护；专线解决承载可靠性，不能替代加密。','当前DataSync卡仅任务校验/限速，没有传输加密。','datasync/latest/userguide','TLS',650),
'R08':(['GSC-005'],'FSx for Lustre是AWS全托管Lustre文件系统，可经受支持VPN/DX私网从机房Lustre客户端挂载。','当前只教并行SSD用途，没有托管职责和机房接入支持。','fsx/latest/LustreGuide/what-is','fully managed',500),
'R09':(['CUR:CMP-M22','CUR:CA13'],'CloudFront分散承接边缘HTTP流量，作为Shield支持的公网入口可登记增强保护。','当前Shield卡只列GA/EIP登记；CloudFront卡只讲内容交付，缺其DDoS防护作用。','shield/features','CloudFront',650),
'R10':(['GSC-014'],'instance store适用可丢失可重建工作集，10TB需求须有足够本地盘的实例；不能无条件宣称任意处理数据可丢或所有EBS都慢。','Q127缺可重建前提与具体容量，不建议为本题添加孤立实例规格卡；先澄清题源。','instance-store','temporary',550),
'R11':(['GSC-049'],'核RDS Custom Oracle适用版本和跨Region read replica支持，才能在OS访问与低运维DR之间选型。','Custom卡明确必须核对支持范围，原题最新版未锚定，先事实核查，不自动新卡。','rds-custom','Oracle',550),
'R12':(['GSC-060'],'DMS由复制实例/服务器运行全量与持续复制任务；同引擎迁移无需因此机械做异构SCT转换。','现CDC卡没有执行资源与任务关系，不能仅背两个产品名称。','dms/latest/userguide/Welcome','replication instance',600),
'R13':(['GSC-029','GSC-030','CUR:CC17'],'核清S3复制目标对象创建事件与EventBridge目标支持，区别S3直接通知和EventBridge可路由SageMaker Pipelines。','决定B/D的复制事件行为尚待完整官方证据，不将“没提到”当不支持。','eventbridge/latest/userguide/eb-targets','SageMaker',550),
'R14':(['GSC-083'],'Lambda异步执行失败耗尽重试后可把调用记录送SQS on-failure destination，修复后消费恢复；区别SNS向Lambda投递失败。','通用队列DLQ只教坏消息隔离，没教故障发生在异步函数执行阶段的持久恢复路径。','lambda/latest/dg/invocation-async-retain-records','on-failure|on failure|OnFailure',750),
'R15':(['CUR:CA19'],'API key/usage plan用于客户标识、计量限流，不能代替IAM/Cognito/Lambda authorizer的身份认证和授权。','要排除共享API key冒充认证；现卡只介绍真正认证路径，未标关键竞争边界。','api-gateway-api-usage-plans','Don.t use API keys for authentication',650),
'R16':(['CUR:NS03','GCL-014'],'AWS Backup可对受支持EC2、RDS、EFS资源安排跨Region副本；目标副本可恢复才满足异地恢复义务。','现卡讲统一备份和异地需副本，没有明确这些资源的跨区复制支持；只补被实际题使用的范围。','aws-backup/latest/devguide/cross-region-backup','copy backups|Cross-Region',650),
'R17':(['CUR:CMP-M19'],'Transfer Family托管SFTP服务提供区域冗余，入口类型仍按客户端网络范围选择。','当前卡讲协议/后端与权限，没教为何无需自管SFTP集群即可满足HA。','transfer/latest/userguide/what-is','Availability|managed',600),
'R18':(['CUR:NB08','GSC-032'],'Web实例用同一session ID把会话读写外置DynamoDB/Redis，共享状态不随某台实例退出而消失。','当前仅说需要共享存储，却没教应用会话如何进入共享仓库；不是登录身份或ALB粘滞。','elasticache-use-cases','session',700),
'R19':(['CUR:CB06'],'NAT gateway由AWS管理，AZ内冗余并自动扩展带宽；跨AZ容错仍需各AZ出口，容量并非无限。','当前只教每AZ独立路径，缺为何替代自管NAT instance能自动扩展/少维护。','nat-gateway-basics','automatically|redundancy|bandwidth',700),
'R21':(['GSC-045'],'RDS PostgreSQL可建跨Region异步read replica，维持异地在线读副本；Multi-AZ与快照不等价。','当前只教异步滞后，跨Region受支持范围没有明示。','RDS|AmazonRDS','cross-Region read replica',650),
'R22':(['CUR:CA15'],'FSx for Windows是AWS全托管SMB文件服务，AWS管理底层文件服务器平台；AD组/Windows ACL继续决定文件权限。','现卡教SMB/AD与同步接管，没有托管职责；加解释短语，不再造名称卡。','fsx/latest/WindowsGuide/what-is','fully managed',650),
'R24':(['CUR:NS03'],'AWS Backup高级DynamoDB备份可按计划转冷存储并长期保留，普通DynamoDB备份不是任意S3对象。','仅列备份工具不足以判断冷层适用性；低频范围若会挤成长清单应保留为长尾义务，不能硬塞。','advanced-ddb-backup','cold',700),
'R25':(['GSC-010'],'Volume Gateway异步上传使用受保护连接；完整本地主数据与安全云备份是stored模式的因果解释。','当前stored/cached只讲位置与异步备份，缺明确传输安全。','storagegateway/latest/vgw','SSL|TLS',650),
'R26':(['GSC-076','CUR:CB16'],'VPC IPv4 CIDR允许/16至/28，/32主机地址不能建VPC；peering地址不得重叠。','当前只说须合CIDR规则，无法排除/32；作为地址规模边界讲用途，不独立背数字。','vpc-cidr-blocks','/28',650),
'R27':(['CUR:CMP-M03','CUR:CMP-M11'],'S3 bucket policy可按s3:x-amz-server-side-encryption条件拒绝缺少所需SSE头的PutObject；TLS条件与ACL不等于静态加密要求。','当前只讲旧对象批加密和传输TLS，没教上传策略约束；现行默认加密需保留年代说明。','AmazonS3','x-amz-server-side-encryption',700),
'R28':(['CUR:CA17','CUR:XB013'],'API Gateway/Lambda由AWS区域冗余承载，DynamoDB区域多AZ复制提供在线持久记录；不能把托管泛称当所有服务均跨AZ。','高可用是题目明确条件，目前只教伸缩/键值用途，未给实际服务冗余范围。','amazondynamodb/latest/developerguide/Introduction','Availability Zone|replicat|high availability',650),
'R29':(['GSC-045','GSC-055'],'Aurora Replicas共享区域存储，正常低复制延迟不同于普通引擎日志重放；低延迟仍依负载，不能给绝对1秒SLA。','当前只有一般异步复制会滞后，缺改变选型的Aurora低滞后机制。','Concepts.AuroraHighAvailability','replica lag|100 milliseconds|shared',650),
'R30':(['GSC-038','GCL-023'],'DynamoDB reserved provisioned capacity折扣只适用单Region Standard表类，不适用Standard-IA；容量模式与表类是两个维度。','Q348中A的reserved+IA须由实际支持范围排除，不能凭未给存储比例猜账单。','dynamodb/pricing','Available only for provisioned capacity, single-Region, and Standard table class',500),
'R31':(['GSC-051'],'gp2容量与基准IOPS关联：每GiB 3IOPS，1TiB约3000IOPS，先比较足够的General Purpose而非一律io2。','当前教了比较方法却没有该题必要容量性能关系，需一例说明而非新增全部卷型规格表。','CHAP_Storage','3 IOPS',600),
'R32':(['GSC-047'],'RDS自动备份可保留最多35天，提供窗口内PITR，日志通常约5分钟上传；manual快照独立保留，修改自动窗口不等于清manual。','当前只说有限窗口，未教30天与近期恢复点的适用范围；不要求生产演练来背数字。','USER_WorkingWithAutomatedBackups','35 days|five minutes|5 minutes',750),
'R33':(['GSC-032','GSC-034'],'Redis数据保留/停止后重建需要支持的备份快照和恢复路径，副本故障接管不等于永久持久化；分数sorted set与数据保护分开。','当前只教排序或复制，不能据内存缓存推断停止/恢复后保留。','AmazonElastiCache/latest/dg/backups','snapshot|backup',650),
'R34':(['GCL-014','CUR:XA031'],'AMI保存无状态应用的软件/启动镜像用于重建，数据库变化另用PITR；反复备份每台无状态伸缩实例卷通常无额外恢复价值。','当前模板开资源不等于软件镜像，实例级AWS Backup也未明确AMI用途。','AWSEC2/latest/UserGuide','Amazon Machine Image.*information|required to launch',650),
'R35':(['GSC-015','GSC-051'],'gp3独立配置IOPS的范围足以15000；RDS MySQL gp3在2TB时可调至超过20000，必须按RDS而非EC2卷上限选。','当前只说within supported range，没有本题必要范围，不能用普通EBS限额套RDS。','CHAP_Storage','64,000|64,000|12,000|16,000',900),
'R36':(['GSC-077'],'Snowball使用加密密钥保护设备数据，物理运输中的数据为密文；离线避网络瓶颈不等于忽略敏感数据保护。','现卡只教带宽/时间/资格，未教运输加密，敏感条件不能凭记忆补。','snowball/latest/developer-guide','256|encrypt',650),
'R37':(['CUR:CB01'],'RDS Multi-AZ DB cluster有内置reader endpoint与两个readers，多数故障切换通常小于35秒；不套经典DB instance standby。','当前只教副本可读差异，未教<40秒范围和普通RDS cluster端点。','multi-az-db-clusters','35 seconds|reader endpoint',750),
'R38':(['GSC-023'],'Transfer Acceleration面向客户端与S3间的上传/下载跨长距离优化，会产生额外费用；它不是内容缓存或服务器端计算。','当前只教上传路径；Q443应用计算/账单输入未明，先源题澄清再决定补充。','transfer-acceleration','transfers',600),
'R39':(['GSC-075'],'TGW是Regional转接资源，可用跨Region TGW peering连接中心，各端需显式路由；不能把单中心当全球自动互通。','当前TGW只教单区中心拓扑，没有跨区互连支持。','transit-gateway','peering',650),
'R40':(['GSC-033'],'应用写数据库时同步更新缓存的策略称write-through；仅TTL或等读未命中才加载不能保证写后立即新鲜。','现卡已经讲更新机制，只有选项术语别名缺失；仅补名称，不新增卡。','AmazonElastiCache/latest/dg/Strategies','A write-through|write-through strategy|write-through caching',650),
'R41':(['CUR:NC07'],'AWS CLI默认用HTTPS并校验TLS证书；一次小规模sync无需另建VPN才加密。','现卡教CLI何时用，不教安全默认；S3支持HTTPS不自动证明CLI实际默认。','cli/latest/userguide','SSL|HTTPS',650),
'R42':(['CUR:CMP-M01'],'Glacier Flexible Retrieval Expedited通常1–5分钟；严格随时取回须考虑预置取回容量，标准取回不能满足5分钟。','现卡只有小时级分界，缺5分钟决策所需取回范围。','glacier-storage-classes|restoring-objects','1.?5 minutes|1–5 minutes|1-5 minutes',700),
'R43':(['GCL-010','CUR:XB019'],'没有Kubernetes接口保留要求时，ECS Fargate免Kubernetes控制面/平台管理负担，比较EKS控制面费用后选更少管理的编排。','两者Fargate均免宿主；当前卡未教ECS/EKS平台层取舍，不能凭偏好选。','ecs|eks','control plane|Kubernetes|charge',650),
'R44':(['GSC-001','GCL-021'],'EFS按实际文件弹性增长无需预置最小文件系统容量；机房可经适用VPN/DX路径NFS挂载。','当前共享/挂载入口已教，缺容量模式与机房支持范围，须简洁承接用途解释。','efs/latest/ug/whatisefs','automatically|on-premises',750),
'R45':(['GSC-083'],'SNS订阅投递失败可保存在SQS DLQ，SQS消息保留可配置到14天；放在SNS前的队列不保存SNS→HTTPS失败。','当前泛称队列死信未教SNS订阅的具体失败边界和合法DLQ目标。','sns-message-delivery-retries|sns-dead-letter-queues','dead-letter|SQS',750),
'R46':(['GSC-026'],'只保留最新两版=当前版+一个较新非当前版，NewerNoncurrentVersions计数只针对非当前版本，并与年龄阈值同时满足后异步过期。','当前只教noncurrent需要生命周期，没教当前/非当前数目对应；补计数语义而非完整XML。','intro-lifecycle-rules','NewerNoncurrentVersions.*?retain',650),
'R47':(['GSC-074'],'200Mbps在伙伴hosted连接支持范围，不能在控制台自建等速dedicated；带宽与安全承载不是一事。','当前说要核对容量，却未给本题200Mbps适用范围；不追加孤立配额卡。','directconnect','200 Mbps',650),
'R49':(['GSC-047','CUR:NS03'],'AWS Backup对受支持RDS可组合连续PITR(最多35天)与更长期周期恢复点，Aurora自动备份由服务保存S3而非任意导出文件。','现卡分清长短保留但没教具体服务配置支持，不能仅长期BackupPlan=14天内任意点。','point-in-time-recovery','35 days|continuous',850),
'R50':(['GSC-075','GSC-073'],'跨账户共享TGW通过RAM/附件授权；现成DX经DX gateway和transit VIF关联TGW，复用接入非每账户新建物理线。','当前只教VIF泛分和TGW中心，没教跨账户许可与实际DX转接。','direct-connect-transit-gateways','transit virtual interface|Direct Connect gateway',700),
'R52':(['CUR:CA17','GSC-079'],'API Gateway可用AWS service integration直接送SQS，将接收HTTP与异步计算解耦，不需一直运行EC2接口。','当前只教API Gateway直接Lambda，没有HTTP→队列这个实际连接。','apigateway','SQS',650),
'R53':(['GSC-040'],'DynamoDB TTL属性存Unix epoch秒的过期时刻；365天是计算到未来时刻，不是字段填365。','现卡教异步删除与访问过滤，没教过期值语义，避免把天数当时间戳。','amazondynamodb','Unix epoch|epoch.*second',650),
'R54':(['GSC-064','GSC-065'],'MGN安装Replication Agent后做初始块复制，再启动test instances验收，正式cutover先停源写入/最终同步。','当前只有工具选择与最终切换，没教agent和初始复制的连接机制；不重复制卡整个迁移清单。','mgn/latest','Replication Agent|block-level replication',650),
'R55':(['CUR:CB02','GSC-146'],'普通RI按完整承诺期计费，Standard/Convertible价格灵活性不同；Scheduled计划至少1200小时/年、每周至少24小时，周日12小时不满足。现行是否还可购买另待独立事实核查，不能用未证实停售说法作必要前提。','当前只教ComputeSP/Spot中断，Q1013需题源年代与承诺经济性，不可直接给历史预期答案。','AWSEC2','Scheduled Reserved|Scheduled Instances',650),
'R56':([], 'AWS Batch把批作业排队并按资源需求调度到适用计算环境；选择Fargate环境可减少宿主维护，Step Functions另管跨步骤状态。','没有现有Batch作业调度正文；这是独立于工作流编排的真实任务候选，先跨题去重/查实际复用，再决定是否新增。','batch/latest/userguide/fargate','Fargate',750),
}

OVERRIDES={
'R02':('CHAP_AuroraOverview','fully managed relational database',900),
'R05':('global-accelerator/latest/dg/introduction-components','A listener can be configured for TCP',650),
'R29':('Aurora.Replication','lag is usually much less than 100 milliseconds',650),
'R32':('USER_WorkingWithAutomatedBackups.BackupRetention','between 0 and 35 days',700),
'R37':('multi-az-db-clusters-concepts-failover','Failover times are typically under 35',700),
'R41':('cli/latest/userguide/cli-configure-options','By default, the AWS CLI uses SSL',500),
'R47':('directconnect/latest/UserGuide/hosted_connection','possible values are 50 Mbps',650),
'R52':('integrate-amazon-api-gateway-with-amazon-sqs','Amazon API Gateway.*?Amazon SQS',1000),
'R55':('API_DescribeScheduledInstanceAvailability','minimum required duration',600),
}
for k,(url,pat,width) in OVERRIDES.items():
 a=list(DEFS[k]);a[-3:]=[url,pat,width];DEFS[k]=tuple(a)
EXTRA={
'R02':[('Concepts.AuroraHighAvailability','synchronously replicates',650)],
'R03':[('EventNotifications','Amazon S3 can send event notifications',600)],
'R05':[('global-accelerator/latest/dg/what-is','directs traffic over the AWS',600)],
'R06':[('firehose/latest/dev/disaster-recovery-resiliency','serverless mode',650)],
'R32':[('USER_PIT','uploads transaction logs',650)],
'R38':[('aws.amazon.com/s3/faqs','upload.*?download|download.*?Transfer Acceleration',600)],
'R56':[('batch/latest/userguide/what-is-batch','fully managed service',1000)],
}

def rows():
 results=[]
 parts=list((V/'review/gap-a').glob('results-part*.json'))
 allr=[r for p in parts for r in json.loads(p.read_text())['results']]
 for id,(targets,fact,why,url,pat,width) in DEFS.items():
  affected=[r['qid'] for r in allr if id in r['revisionRequestIds']]
  if not affected: continue
  proof=ev(url,pat,width)
  proofs=([proof] if proof else [])+[e for u,p,w in EXTRA.get(id,[]) if (e:=ev(u,p,w))]
  results.append(dict(requestId=id,affectedQids=affected,suggestedExistingRuleIds=targets,existingBodyHashes={x:CARDS[x]['bodySha256'] for x in targets},minimumFactOrMechanism=fact,whyCurrentVisibleCardsDoNotDeriveIt=why,proposedHandling='targeted existing-card clarification; preserve one recall judgment' if targets else 'independent new-rule candidate; defer unless cross-question necessity confirmed',newRuleRequest=not bool(targets),sourceEvidence=proofs,evidenceState='located official scope; author must verify exact proposed wording' if proofs else 'fact/scope confirmation required before authoring',doNotCountAsNewCard=True,fullPoolLookupBoundSha256=sha((V/'review/gap-a/input/visible-cards355.v2.json').read_bytes())))
 return results
if __name__=='__main__':
 rr=rows();out=dict(requestKind='minimal targeted teaching clarifications, not a card count or authoring approval',requests=rr)
 (V/'review/gap-a/revision-requests.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 safe={'R01','R03','R04','R05','R08','R15','R19','R22','R24','R30','R31','R35','R40','R46','R49'}
 partial={**out,'requests':[r for r in rr if r['requestId'] in safe and r['sourceEvidence']]}
 (V/'review/gap-a/revision-requests.partial.json').write_text(json.dumps(partial,ensure_ascii=False,indent=2)+'\n');print('all',len(rr),'partial',len(partial['requests']),'official located',sum(bool(r['sourceEvidence']) for r in rr));print('without quote',[r['requestId'] for r in rr if not r['sourceEvidence']])

from sources import OUT,sha
import urllib.request, concurrent.futures, json, datetime, subprocess
from html.parser import HTMLParser
class Text(HTMLParser):
 def __init__(self): super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ('script','style'):self.skip+=1
  elif t in ('p','div','li','tr','br','h1','h2','h3','h4'):self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ('script','style'):self.skip=max(0,self.skip-1)
  elif t in ('p','li','tr','h1','h2','h3','h4'):self.parts.append('\n')
 def handle_data(self,d):
  if not self.skip:self.parts.append(d)
urls={
'efs-limits':'https://docs.aws.amazon.com/efs/latest/ug/limits.html',
's3-events':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/NotificationHowTo.html',
's3-replication-not':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/replication-what-is-isnot-replicated.html',
'eventbridge-targets':'https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-targets.html',
'api-keys':'https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-api-usage-plans.html',
'dynamodb-reserved':'https://aws.amazon.com/dynamodb/pricing/provisioned/',
'a2c-support':'https://docs.aws.amazon.com/app2container/latest/UserGuide/supported-applications.html',
'a2c-prereqs':'https://docs.aws.amazon.com/app2container/latest/UserGuide/start.html',
'rds-cluster':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/multi-az-db-clusters-concepts.html',
'lambda-sqs':'https://docs.aws.amazon.com/lambda/latest/dg/with-sqs.html',
'lambda-dest':'https://docs.aws.amazon.com/lambda/latest/dg/invocation-async-retain-records.html',
's3-tiers':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/storage-class-intro.html',
'ga-how':'https://docs.aws.amazon.com/global-accelerator/latest/dg/introduction-how-it-works.html',
'datasync-security':'https://docs.aws.amazon.com/datasync/latest/userguide/data-protection.html',
'gateway-security':'https://docs.aws.amazon.com/storagegateway/latest/vgw/data-protection.html',
'snowball-security':'https://docs.aws.amazon.com/snowball/latest/developer-guide/security-data-protection.html',
's3-acceleration':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/transfer-acceleration.html',
'scheduled-ri':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-scheduled-instances.html',
'spot-fleet':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/spot-fleet.html',
'asg-purchasing':'https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-mixed-instances-groups.html',
'backup-dynamo':'https://docs.aws.amazon.com/aws-backup/latest/devguide/advanced-ddb-backup.html',
'backup-continuous':'https://docs.aws.amazon.com/aws-backup/latest/devguide/point-in-time-recovery.html',
'efs-onprem':'https://docs.aws.amazon.com/efs/latest/ug/on-premises.html',
'fsx-lustre-performance':'https://docs.aws.amazon.com/fsx/latest/LustreGuide/performance.html',
'fsx-ontap-performance':'https://docs.aws.amazon.com/fsx/latest/ONTAPGuide/performance.html',
'rds-storage':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_Storage.html',
'dax-client':'https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DAX.client.run-application-python.html',
's3-noncurrent':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/intro-lifecycle-rules.html',
'dx-hosted':'https://docs.aws.amazon.com/directconnect/latest/UserGuide/WorkingWithConnections.html',
'api-comparison':'https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-vs-rest.html',
'cloudfront-cachingoptimized':'https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/using-managed-cache-policies.html',
'efs-whatis':'https://docs.aws.amazon.com/efs/latest/ug/whatisefs.html',
'firehose-whatis':'https://docs.aws.amazon.com/firehose/latest/dev/what-is-this-service.html',
'backup-feature':'https://docs.aws.amazon.com/aws-backup/latest/devguide/backup-feature-availability.html',
'elasticache-cache':'https://docs.aws.amazon.com/AmazonElastiCache/latest/dg/Strategies.html',
'elasticache-backup':'https://docs.aws.amazon.com/AmazonElastiCache/latest/dg/backups.html',
'aws-batch-fargate':'https://docs.aws.amazon.com/batch/latest/userguide/fargate.html',
'mgn-how':'https://docs.aws.amazon.com/mgn/latest/ug/what-is-application-migration-service.html',
}
def f(it):
 key,u=it;p=OUT/f'fetch-{key}.json'
 if p.exists():return key,'cached'
 try:
  r=subprocess.run(['curl','-fLsS','--max-time','30','--write-out','\n%{url_effective}\n%{http_code}',u],capture_output=True,check=True);b,final,status=r.stdout.rsplit(b'\n',2);t=Text();t.feed(b.decode('utf-8'));s='\n'.join(' '.join(z.split()) for z in ''.join(t.parts).splitlines() if z.strip());d=dict(url=final.decode(),requestedUrl=u,httpStatus=int(status),fetchedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),htmlSha256=sha(b),textSha256=sha(s.encode()),text=s)
  p.write_text(json.dumps(d,ensure_ascii=False,indent=2));return key,final.decode(),len(s)
 except Exception as e:return key,str(e)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
  for r in ex.map(f,urls.items()):print(r)

from fetch_sources import f
import concurrent.futures
urls={
'aurora-overview':'https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/CHAP_AuroraOverview.html',
'ga-whatis':'https://docs.aws.amazon.com/global-accelerator/latest/dg/what-is-global-accelerator.html',
'firehose-availability':'https://docs.aws.amazon.com/firehose/latest/dev/disaster-recovery-resiliency.html',
'datasync-tls':'https://docs.aws.amazon.com/datasync/latest/userguide/encryption-in-transit.html',
'gateway-architecture':'https://docs.aws.amazon.com/storagegateway/latest/vgw/StorageGatewayConcepts.html',
'snowball-encryption':'https://docs.aws.amazon.com/snowball/latest/developer-guide/encryption.html',
'efs-mount-onprem':'https://docs.aws.amazon.com/efs/latest/ug/mounting-fs-mount-cmd-ec2.html',
'cli-tls':'https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-options.html',
'cli-reference':'https://docs.aws.amazon.com/cli/latest/reference/s3/sync.html',
's3-faqs':'https://aws.amazon.com/s3/faqs/',
's3-event-types':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/notification-how-to-event-types-and-destinations.html',
'scheduled-api':'https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DescribeScheduledInstanceAvailability.html',
'dx-types':'https://docs.aws.amazon.com/directconnect/latest/UserGuide/WorkingWithVirtualInterfaces.html',
'dx-hosted-list':'https://docs.aws.amazon.com/directconnect/latest/UserGuide/hosted_connection.html',
'rds-pitr':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_PIT.html',
'rds-cluster-failover':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/multi-az-db-clusters-concepts-failover.html',
'api-sqs':'https://docs.aws.amazon.com/prescriptive-guidance/latest/patterns/integrate-amazon-api-gateway-with-amazon-sqs-to-handle-asynchronous-rest-apis.html',
'sns-dlq':'https://docs.aws.amazon.com/sns/latest/dg/sns-dead-letter-queues.html',
'api-lambda-role':'https://docs.aws.amazon.com/lambda/latest/dg/lambda-intro-execution-role.html',
'ecs-spot-asg':'https://docs.aws.amazon.com/autoscaling/ec2/userguide/using-spot-instances.html',
'ebs-types':'https://docs.aws.amazon.com/ebs/latest/userguide/ebs-volume-types.html',
'fsx-lustre-ssd':'https://docs.aws.amazon.com/fsx/latest/LustreGuide/ssd-storage.html',
'ontap-tiering':'https://docs.aws.amazon.com/fsx/latest/ONTAPGuide/volume-storage-capacity.html',
}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
 for r in ex.map(f,urls.items()): print(r)

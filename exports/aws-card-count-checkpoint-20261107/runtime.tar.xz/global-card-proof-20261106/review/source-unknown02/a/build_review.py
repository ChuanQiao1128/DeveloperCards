# -*- coding: utf-8 -*-
import pathlib,json,hashlib,datetime,shutil,collections,re
D=pathlib.Path(__file__).resolve().parent;V=D.parents[2];I=V/'review/source-current-final/input';P=V/'review/source-current-final/a';E=D/'evidence'
sha=lambda b:hashlib.sha256(b).hexdigest();canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode();read=lambda p:json.loads(pathlib.Path(p).read_text())
def save(n,x):
 p=D/n;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return p
m=read(D/'manifest.json');Q={x['qid']:x for x in read(I/'cases1.json')};C={x['ruleId']:x for x in read(I/'core-visible.frozen.json')};old={x['qid']:x for x in read(P/'results.json')['results']};oldfacts=read(P/'official-evidence.json')['facts'];F={}
def reused(k):
 x=dict(oldfacts[k]);ys=[x]+x.get('supportingQuotes',[])
 for ix,y in enumerate(ys):
  p=pathlib.Path(y['snapshotPath']);dst=E/('reused-'+k+'-'+str(ix)+'.json');shutil.copyfile(str(p),str(dst));y['snapshotPath']=str(dst);assert sha(dst.read_bytes())==y['snapshotSha256']
 x['reusedFromFactRegistry']=str(P/'official-evidence.json');F[k]=x
for k in ['macie-full-file-limits','instance-store-temporary','cloudfront-dynamic','route53-latency','aurora-reader-lag','aurora-scheduled-procedures','default-sg-self-reference','new-sg-default-inbound','redis-snapshots','redis-replication-loss','redis-durability-engine-limit','ta-client-upload','aurora-auto-pause','eks-private-api','eks-node-iam','eks-required-sg','redshift-cse-ended','redshift-data-api']:reused(k)
def bind(k,n,start,end):
 p=E/(n+'.json');d=read(p);t=d['text'];a=t.index(start);b=t.index(end,a)+len(end);dst=E/(k+'.snapshot.json');shutil.copyfile(str(p),str(dst));F[k]=dict(url=d.get('finalUrl') or d['url'],quote=t[a:b],quoteStart=a,quoteEnd=b,snapshotPath=str(dst),snapshotSha256=sha(dst.read_bytes()),textSha256=sha(t.encode()))
bind('lambda-s3-streaming','lambda-streaming','The streaming utility handles datasets larger than the available memory as streaming data.','while consuming a few MBs only.')
bind('lambda-current-runtime','lambda-quotas','Lambda is designed for short-lived compute tasks','10,240 MB of memory.')
bind('lifecycle-tag-filter','s3-lifecycle-tags','Object tags\nYou can filter objects based on one or more tags.','the filter will still apply.')
bind('instance-store-performance-capacity','ec2-storage-optimized','This instance family provides dense Non-Volatile Memory Express','High random I/O performance and high sequential disk throughput')
bind('cloudfront-persistent-origin','cloudfront-how','CloudFront also keeps persistent connections with','Dynamic requests, as determined at request time, do not flow through regional edge\ncaches, but go directly to the origin.')
bind('aurora-procedures-transaction-statements','aurora-stored-procedures','Aurora MySQL permits stored routines','START TRANSACTION, COMMIT, and ROLLBACK.')
bind('aurora-functions-no-transactions','aurora-stored-functions','Aurora MySQL supports user-defined scalar functions only.','COMMIT and ROLLBACK.')
bind('default-nacl-allows','default-network-acl','Your virtual private cloud (VPC) automatically comes with a default network ACL.','subnets with which it is associated.')
bind('vpc-local-route-default','vpc-route-local','Every route table contains a local route for communication within the VPC.','route is added by default to all route tables.')
bind('redis-persistence-with-loss-boundary','cache-redis-persistence-ja','Redis supports persistence, including backup and recovery.','better fit for most use cases of long-term data storage.')
bind('aurora-capacity-billing-modes','aurora-billing','Aurora serverless – Aurora serverless provides','combination of Aurora serverless and on-demand or reserved provisioned instances.')
bind('eks-node-creation-two-positive-causes','eks-troubleshoot-join','NodeCreationFailure\nYour launched instances are unable to register','Your nodes and VPC must meet the requirements in Deploy private clusters with limited internet access.')
bind('redshift-general-client-server-encryption','redshift-encryption','You can protect data in transit','manage the encryption process, the encryption keys, and related tools.')
bind('redshift-timed-pause-resume','redshift-pause-current','If you have a cluster that only needs to be available at specific times','The scheduled action names are suffixed\nwith -pause and -resume.')
bind('redshift-snapshot-new-cluster','redshift-restore-current','If you restore your cluster from a snapshot','Then it restores all the databases from the snapshot\ndata.')
bind('redshift-live-sharing-no-copy','redshift-sharing-current','With Amazon Redshift data sharing, you can securely share','without manually moving or copying the data.')
save('evidence.json',dict(schemaVersion=1,reviewer='actual_gap_review',facts=F,count=len(F),limits=['Official facts are reviewer evidence, not extra learner-visible teaching.','The narrow COPY/UNLOAD retirement notice does not override the positive broader client-side encryption paragraph.','Redis backups/replication do not prove zero acknowledged-write loss.','Lambda streaming removes a memory-size prohibition, not all execution limits.']))

def proof(k,field,inference):return dict(ruleId=k,field=field,quote=C[k]['visibleBody'][field],bodySha256=C[k]['bodySha256'],inference=inference)
rows=[]
def add(q,status,choice,ids,new,removed,reason,optionReasons,proofs,facts,blocking=None,proposal=None,impl=None):
 assert set(facts)<=set(F)
 seen=set();group=[]
 def go(k,active):
  assert k in C and k not in active,k
  if k in seen:return
  seen.add(k);group.append(dict(ruleId=k,visibleBody=C[k]['visibleBody'],bodySha256=C[k]['bodySha256'],prerequisiteRuleIds=C[k]['prerequisiteRuleIds']))
  for p in C[k]['prerequisiteRuleIds']:go(p,active|{k})
 for k in ids:go(k,set())
 rows.append(dict(qid=q,previousStatus='UNKNOWN',status=status,selectedOptionOrdinals=choice if status=='SUPPORTED' else [],candidateOptionOrdinals=choice if status!='SUPPORTED' else [],originalQuestion=Q[q]['originalQuestion'],originalQuestionSha256=sha(canon(Q[q]['originalQuestion'])),previousResultPath=str(P/'results.json'),previousResultSha256=sha((P/'results.json').read_bytes()),newEvidenceOrAssumptionResolution=new,removedUnnecessaryAssumptions=removed,reasoning=reason,allOptions=optionReasons,proofTrace=proofs,usedRuleIds=ids,learnerVisibleGroup=group,officialFactKeys=facts,minimalActualBlocker=blocking,sourceCorrectionProposal=proposal,correctionProposalState='PROPOSAL_ONLY_NO_VARIANT_AUTHORED' if proposal else None,ordinaryImplementationChecks=impl or [],newCardCount=None,variantsNeverUpgradeOriginal=True))
add(46,'SUPPORTED',[4],['GSC-029','CUR:CC17','CUR:CMP-M06','GCL-001','CUR:CMP-M16','CUR:XB011','GSC-133'],
'新读取完整核心后补入GCL-001（SES专门邮件）及CMP-M16（Lifecycle安排清理），不再只用初始小组。AWS Powertools Streaming明确S3大对象可按部分读取、只占少量内存；Lifecycle官方支持按对象tag选择子集。',
['撤回“必须先实测200GB扫描算法耗时才能选择架构”的额外门槛。','不将文件大于Lambda内存或临时盘上限等同不可处理；也不承诺任意格式/大小都在一次调用内完成。'],
'按所给方案中同时满足通知与自动补救的完整链路，选D。S3创建事件触发自定义计算；Lambda按实际格式处理对象，SES发邮件；将发现的对象纳入已配置的Lifecycle清理范围，完成自动删除而非等管理员动手。卡组已经分别教触发、代码动作、执行身份、专门邮件与Lifecycle清理，组合的是已学职责。>200GB保留为实施资源边界，使用分段/流式处理而不是把完整文件当调用载荷或必须全部载入内存。',
{'A':'Inspector是漏洞职责，且该项没有完整管理员通知链路；不是对象正文PII发现。','B':'Macie方向适合受支持对象，但该项要求管理员删除，只通知未完成自动补救；无须背大文件配额才能排除。','C':'自定义扫描与通知仍让管理员删除，未完成自动补救。','D':'唯一明确同时包含自定义正文扫描、邮件通知和自动清理的方案。题面meats为原始文本，按同一句PII对象语境理解，不据此改原题。'},
[proof('GSC-029','answerZH','对象创建事件启动Lambda处理。'),proof('CUR:CC17','keyPointZH','真正资源动作由处理函数代码执行。'),proof('CUR:CMP-M06','answerZH','给处理代码实际读取/修改S3所需受限角色。'),proof('GCL-001','answerZH','SES是应用邮件投递的已学服务。'),proof('CUR:CMP-M16','answerZH','Lifecycle已教会安排清理，而非人工逐对象删除。')],
['lambda-s3-streaming','lambda-current-runtime','lifecycle-tag-filter','macie-full-file-limits'],impl=['按数据格式实现扫描并在实际执行限制内流式/分段处理；超过单次执行预算时拆分。','预配置清理规则与选择标记；Lifecycle异步按规则执行，原题没有即时删除期限。','SES身份/发送资格与执行角色是实施配置，不要求另背完整部署清单。'])
add(127,'SUPPORTED',[4],['GSC-014','CUR:NA05','CUR:CMP-M01'],
'官方实例存储正证给出低延迟、高随机I/O及高顺序吞吐用途，并存在最多60TB本地SSD规格，10TB不构成服务能力未知。核心GSC-014就是视频处理工作集与持久原件的取舍。',
['不再把“maximum possible”扩写为必须证明所有EBS配置和所有I/O模型都绝对落后。','不要求部署基准测试；也不新增“instance store对任何工作负载永远最快”的口诀。'],
'选D。题干把性能工作区、持久媒体内容及退役媒体归档分为三个职责：10TB视频处理是本地高I/O工作区，持久媒体原件另由300TB durable存储承担。GSC-014允许可从原件重建的本机处理数据使用instance store；NA05把大量持久文件放多AZ S3对象存储；CMP-M01把不再使用、可接受恢复的媒体放适用Glacier归档层。这里是存储职责选择，不是承诺任意实例规格都够10TB。',
{'A':'EBS是持久块存储方案，但本题已把媒体持久保存单列，性能工作区可采用所教本地临时盘。','B':'把大量独立媒体对象绑定共享文件接口没有给出必要性，且性能层仍未用本地工作区取舍。','C':'媒体持久层改用EFS、归档仅用未分层的S3，未按已给对象/冷档职责匹配。','D':'本地高I/O工作区、S3持久对象和Glacier归档分别匹配三个需求。'},
[proof('GSC-014','answerZH','处理工作集可重建时可使用instance store，不把媒体唯一副本放临时盘。'),proof('CUR:NA05','keyPointZH','媒体原件与实例生命周期分开。'),proof('CUR:CMP-M01','answerZH','退役媒体按可等待恢复的归档层选择。')],
['instance-store-temporary','instance-store-performance-capacity'],impl=['选本地盘总容量至少10TB的实际实例配置。','若未来另加处理工作区也须跨停机持久化的新条件，按GSC-014改用持久存储；这不是当前题干新增要求。'])
add(141,'SUPPORTED',[1],['CUR:CA13','CUR:XB032','GSC-132'],
'CloudFront HowCloudFrontWorks明确保留与origin的持久连接，并区分动态请求直接到origin而非区域缓存。加上原有全球静动态交付正证，可在不虚构动态内容被缓存的情况下完成A的普通架构选型。',
['撤回必须先拿到全球用户分布、动态比例和逐用户实测才允许选择全球HTTP交付架构的额外门槛。','不把“least latency”解释为对任意未来工作负载和任意两Region摆放给数学式支配保证。'],
'选A。需求直接指向同一HTTPS应用的全球静态及动态交付：CloudFront就近承接客户端连接，静态可缓存，动态/未命中经优化连接回ALB origin，既有计算栈无需因此变成多Region业务。CA13已明确动态仍可能回区域源站，故不是把边缘节点误当分布式计算。B可把动态计算部署到两个Region，但只做Regional DNS选择，不给题中两类HTTP内容同一全球边缘交付/缓存路径；按现有需求的普通架构选择，A是完整直接的交付优化。',
{'A':'全部静态/动态HTTP入口使用CloudFront，以ALB为origin，完整对应。','B':'latency routing是合适的多Region入口选择机制，但仅两个Region的ALB入口不等同全球内容边缘交付；题目未新增多Region数据/业务计算需求。','C':'只给静态内容走边缘，动态仍逐用户直接连接ALB，漏掉已教的动态HTTP入口优化。','D':'geolocation按来源地理归属，不按实际网络延迟选择。'},
[proof('CUR:CA13','answerZH','全球静态和动态HTTP内容都可由CloudFront交付。'),proof('CUR:CA13','keyPointZH','边缘连接、缓存及动态回源机制说明A为何同时处理两类内容。'),proof('CUR:CA13','watchOutZH','明确动态计算仍在origin，未借隐藏的分布式业务假设。'),proof('CUR:XB032','answerZH','排除把geolocation当latency routing。')],
['cloudfront-dynamic','cloudfront-persistent-origin','route53-latency'],impl=['HTTPS origin、动态行为缓存和转发按业务配置。','这是设计选型支撑，不是对所有地域/请求的实测延迟或硬SLA验收。'])
add(337,'SOURCE_ISSUE',[1],['VC-003','GSC-045','CUR:CC22','GSC-057'],
'新增AWS迁移手册的正向对照：Aurora MySQL存储过程允许START TRANSACTION/COMMIT/ROLLBACK；存储函数不允许显式COMMIT/ROLLBACK。现有scheduler正证还允许EVENT调用procedure。',
['不再以未做峰值1秒SLA测试为阻断；通常低lag可支撑迁移架构判断。','不把所有存储过程都说成无法转换，而是定位A强制整体替换这一具体缺陷。'],
'A的Aurora与reader Auto Scaling方向由现有卡组支撑，但“Replace the stored procedures with Aurora MySQL native functions”不能作为所有所给routine的保功能、最少改动方案。符合题干的一种正常已调度过程可包含事务COMMIT；迁移到Aurora存储过程可保留，改为函数则官方明确不允许该语句。题干没有限定routine只做可等价替换的标量计算，也没有给某个native function替代物。该正反例使问题落在源选项的额外强制改写，不是无证缺文或事实卡不足。',
{'A':'迁移/reader部分有效，强制过程改函数在已确认的合法routine反例下不保功能且增加不必要改造。','B':'改应用查缓存且把过程改Lambda，不符合最少代码变化；缓存不是关系库复制机制。','C':'保过程但转自管MySQL，增加持续平台运维；大副本仍异步重放，不能据大规格自动消掉lag。','D':'关系与过程模型改为DynamoDB/Streams，显著重写且混淆on-demand与预置RCU配置。'},
[proof('VC-003','keyPointZH','区域reader通常低于100ms，是原题低lag架构方向。'),proof('GSC-057','answerZH','Auto Scaling增减reader，匹配读负载变化。'),proof('CUR:CC22','answerZH','保留兼容关系功能并交平台维护给托管服务。')],
['aurora-reader-lag','aurora-scheduled-procedures','aurora-procedures-transaction-statements','aurora-functions-no-transactions'],blocking='原A的全量“过程→原生函数”强制替换不能据题干证明等价；事务过程是有官方正证的具体反例。',proposal='最小新练习仅将A末句替换为Retain compatible stored procedures and their supported schedules。保留原A与原题不变，另冻结变体后独立回测；不把本提案当PASS。')
add(388,'INSUFFICIENT_CARDS',[4],['CUR:CMP-M10','CUR:CB15'],
'新增完整官方默认NACL与VPC local-route原句，已确定原题不需跨VPC连接或新增同VPC路由。再与default SG self-reference及new SG empty-inbound对照，原先泛泛“未知SG IDs”收窄为具体默认规则教学缺口。',
['不要求先取得实际生产SG ID才能回答普通两层网络题。','不把所有“default states”都强行等同两个资源共享同一个VPC default SG，也不把stateful误当自动允许新入站。'],
'D是按分层安全组配置的普通正确修复：接收端RDS允许Web安全组到数据库端口。现有CMP-M10教会此动作、CB15教会响应不需另开反向SG规则。但当前可见卡组未教“同VPC默认local route已有可达路径、默认NACL全放行、新建SG初始无入站”这组用于排除A/B的决定事实；这些不能从有状态规则逻辑推出。若声称原题全部资源其实共享VPC default SG，其self-reference本就已放行，则应查别的故障，不能由本卡组私下假定。故此轮不再等待SG实测，而保留最小可定位教学缺口。',
{'A':'默认NACL正证已允许双向流量，重复加允许不是该场景所需修复。','B':'同VPC默认local route已存在，不需要为两个tier另加路由。','C':'改两VPC并peering增加不必要网络结构，仍不代替接收端SG许可。','D':'正确的接收端SG许可；目前卡面会动作但未教默认行为以完整解释其它选项。'},
[proof('CUR:CMP-M10','answerZH','RDS是接收端，用Web上一跳安全组及DB端口。'),proof('CUR:CB15','keyPointZH','SG有状态管响应，不能替代新连接的入站许可。')],
['default-nacl-allows','vpc-local-route-default','new-sg-default-inbound','default-sg-self-reference'],blocking='缺少默认本地路由/默认NACL与新SG初始入站规则的学习者可见因果边界；不是要新增一种服务组合卡，也不是缺部署测试。')
add(390,'INSUFFICIENT_CARDS',[2,4],['CUR:NB08','GSC-032','CUR:XB013'],
'新取到完整AWS ElastiCache白皮书：Redis支持包括backup/recovery的persistence，也明确异步复制不能完全避免故障丢失。由此可按普通durability选型保留B/D方向，不再把durably自动扩成零RPO。',
['撤回未给RPO=0就不能讨论Redis方案的过严前提。','不把Valkey9+新增transactional-log特性的限制推广成所有Redis方案完全没有持久化。'],
'B/D是可选的外置会话存储方向；NB08直接教两者跨Web实例保存状态，GSC032教适用Redis副本和接管。A只改变请求分配，C是用户身份认证，E是应用资源管理，均不替代会话数据存储。真正剩余的是当前卡只教共享状态与副本，未教Redis的持久化/backup与异步副本的关系；不能把缓存进程内存或复制组自动当成已经满足durably。私有白皮书能验证方案能力，但未成为学习者已学的必要判断，因此是最小教学缺口，不是未知Redis是否存在持久化。',
{'A':'sticky sessions不复制或持久保存实例本机会话。','B':'DynamoDB外置在线记录符合会话访问模型。','C':'Cognito user pool管理用户身份/令牌，不是应用任意购物会话状态仓库。','D':'Redis可外置会话，并有持久化/恢复路径；但当前卡还没教该边界。','E':'Application Manager不是应用会话数据存储。'},
[proof('CUR:NB08','answerZH','直接给DynamoDB或Redis作为共享会话方向，排A。'),proof('CUR:NB08','keyPointZH','解决Web实例退出后的接续。'),proof('GSC-032','keyPointZH','复制接管是HA能力；这句没有教磁盘持久化或零丢失。'),proof('CUR:XB013','keyPointZH','DynamoDB适合在线按键会话记录。')],
['redis-persistence-with-loss-boundary','redis-snapshots','redis-replication-loss','redis-durability-engine-limit'],blocking='外置/副本接管与持久化/恢复是不同机制，现有卡缺Redis persistence对durably的实际支撑及边界；优先精炼共享状态规则，不按本题自动新增卡。')
add(443,'INSUFFICIENT_CARDS',[1],['CUR:CA16','GSC-023','CUR:CA13'],
'复核Transfer Acceleration完整官方原句，明确支持transfer data to and from acceleration-enabled bucket，且加速端点支持除三个桶级动作外的所有S3操作。唯一数据的双向传输可用该路径，不是只有上传。',
['撤回必须先额外证明应用有或没有未提到的服务器端代码，才可比较题中文件传输服务的门槛。','不把非下载缓存误解成不能加速下载，也不假定所有用户独有对象能命中CloudFront共享缓存。'],
'原题核心操作是全球用户上传/下载独有大对象，A是最直接的对象托管和双向传输候选；题干未要求服务器执行代码，不应凭“web application”自行添加后端运算义务来排A。B的Cache-Control只管缓存指令，D的ElastiCache不是互联网对象传输加速。C提供计算扩缩和CDN，但对独有大文件的上传并不比专门S3加速路径更直接，且引入未要求的常驻计算。当前GSC023明确只教上传，并说“不建立下载缓存”；CA16只教静态页面托管，CA13教CloudFront。现有卡面还不能据可见知识完整解释TA的双向传输与独有对象场景，因此只留这一最小缺口。',
{'A':'候选最直接匹配大对象双向传输；还需把TA支持to/from的可见规则补齐。','B':'缓存头不会建立全球加速网络，独有对象也不能只靠缓存重复命中获益。','C':'CloudFront/EC2是可用Web设计，题中未给必须有EC2计算，独有对象大文件的双向路径更直接指向A。','D':'后端内存缓存不改善全球用户到对象传输的网络路径。'},
[proof('GSC-023','answerZH','已教跨洲上传使用加速端点。'),proof('GSC-023','watchOutZH','知道加速有费用和适用条件，未伪称一律更便宜。'),proof('CUR:CA16','keyPointZH','静态前端可直接由存储返回，题干未提出必须运行服务端程序。'),proof('CUR:CA13','keyPointZH','能区分CDN缓存与对象传输路径。')],
['ta-client-upload','cloudfront-dynamic'],blocking='当前GSC023只覆盖upload，欠缺同一加速端点也处理download的已学规则；无需补完整动态应用栈或为本组合再出卡。')
add(511,'UNKNOWN',[1,2],['CUR:XB027','GSC-052','CUR:CC22','GSC-057'],
'新核Aurora DB instance billing官方把Serverless ACU计费、on-demand及reserved provisioned实例明确列为不同容量/购买模式。A只写Aurora PostgreSQL，确实没有指定为Serverless，C的On-Demand属于更具体的provisioned购买方式；不能替原文补缺失词。',
['不要求真实账单或部署压测才判断成本。','不把Aurora默认为高成本常开，也不把未指定的A自动翻译成Aurora Serverless。'],
'D不是PostgreSQL数据库。B是无HA开发库的合理经济方案，A如果选支持0ACU自动暂停的Serverless也是已教的闲置降费路径；如果A只是provisioned，则四小时使用不会自己停算力。题干只给一天使用四小时，未定义A模式或闲置停止方式。新的阻断已收窄到原选项的容量/计费含义：不能用通用“开发选Single-AZ”口诀替代A到底是哪种产品配置，也不需为所有单价建新卡。',
{'A':'Aurora PostgreSQL是引擎/服务族，文字未明确serverless或provisioned，不能自动补成0ACU配置。','B':'可用且可避免不需要的多AZ成本，但题干没有给足与A成本模式对比条件。','C':'明确On-Demand但仍需实例容量及idle配置；不能因名称有On-Demand就当只在执行SQL时计费。','D':'S3 Object Select不能托管PostgreSQL schema应用数据库。'},
[proof('CUR:XB027','answerZH','0ACU及auto-pause须主动配置且版本支持。'),proof('CUR:XB027','keyPointZH','只选Serverless名称都不自动为零，更不能给广义Aurora补此模式。'),proof('GSC-057','answerZH','Aurora模式与计算伸缩对象有区分。')],
['aurora-capacity-billing-modes','aurora-auto-pause'],blocking='A究竟是Serverless自动暂停还是provisioned，以及B是否安排闲置停止；这是原方案定义缺失，非AWS事实未知。最少先明确A容量模式，之后按实际文字比较。',proposal='如另建新练习，先把A明确写成支持0ACU且启用自动暂停的Aurora Serverless，或明确为provisioned；再固定题中idle处理方式。尚未指定这些新条件，不作者、不验收变体。')
add(514,'SOURCE_ISSUE',[1,4],['CUR:XB025','CUR:CMP-M06','CUR:CMP-M10'],
'新增官方EKS troubleshooting对NodeCreationFailure的明确原句：常见原因同时包括insufficient node IAM role permissions与lack of outbound internet access；另有ClusterUnreachable/API网络及AccessDenied身份故障分类。现有private-Kubernetes-API正证区分EKS管理端点。',
['不再笼统等待生产错误日志；已用两个具体、符合题干的部署构造证明单选诊断欠定。','不把仅缺少某摘录当作B功能不存在，B只是不能替代已启用的Kubernetes API endpoint。'],
'可构造两种都符合完整题干的状态：①节点有到私有Kubernetes API、STS/ECR等所需路径，安全组出站已通，但node role缺必要AWS权限，A修复；②node role与cluster授权正确，所需私有端点/路由已具备，但节点SG禁止到集群/所需服务的出站，D修复。官方分别正向要求身份权限与网络，且直接列两类为注册失败原因。原文只说node cannot join而未给哪类错误，A/D各自在一个允许场景下是正确修复，其他动作不能互相代替。因此将旧UNKNOWN具体定位为源诊断条件缺失，不宣称两项对每一种故障都同时有效。',
{'A':'权限缺失场景的正当修复；缺网络时单加权限无效。','B':'AWS EKS interface endpoint是管理API；私有Kubernetes API已经启用，不能泛作节点注册通道替身。其它ECR/STS端点需求应按实际目标服务定位。','C':'违反数据面private subnet的既定要求。','D':'出站被挡场景的正当修复；node role缺权限时开放网络不替代身份授权。'},
[proof('CUR:XB025','answerZH','区分Kubernetes API端点与AWS EKS管理API端点，排B泛用修复。'),proof('CUR:CMP-M06','keyPointZH','执行身份及动作权限是独立条件。'),proof('CUR:CMP-M10','watchOutZH','需要限制出站时必须在发起端放行接收端，说明D在具体故障下有效。')],
['eks-node-creation-two-positive-causes','eks-private-api','eks-node-iam','eks-required-sg'],blocking='缺能区别IAM与网络失败的诊断条件；两种互斥根因的有效部署均被官方正证确认。',proposal='最小新练习加入一种具体诊断并确认另一层正常，例如IAM角色权限已核实、节点到私有API的TCP443被SG阻止以核D；或网络已核实、node role缺指定必要权限以核A。保留原题，单独冻结后回测。')
add(515,'UNKNOWN',[1,2,3],['GSC-102','CUR:CMP-M20','CUR:XB013','GSC-089'],
'现行Redshift Data encryption官方明确同时列server-side与client-side encryption，已正面闭合B；只停止COPY/UNLOAD旧CSE路径不能否定该一般能力。又新取scheduled pause/resume以及snapshot restore/new cluster和live sharing/no-copy原句。',
['撤回把COPY/UNLOAD特性退役直接扩成Redshift一切客户端加密都失效。','不要求另学一张Redshift定时触发卡：仓库分析职责可与GSC089按时钟触发规则迁移。','不因没搜到secondary replica这个标题就判F不存在；已有console snapshot restore确实能生成新cluster。'],
'A可由Data API卡直接解释。B可将CMP-M20的“先密文后交存储”共享机制迁移至数据库，官方现行一般加密页面给出具体产品正证。C是数据仓库在指定时段分析，可由XB013仓库职责与GSC089按时钟触发推导；官方也确实提供定时pause/resume。D/E分别是缓存与高并发在线访问职责。剩余唯一阻断是F的“secondary replica”：若指持续跟随主集群的原生读副本，不能用snapshot restore或live sharing偷换；若只是第二份可查询的cluster副本，官方console snapshot restore正好能生成新cluster，F就不能无条件排除。原文没有说明复制的持续性或产品模式，本轮没有凭缺文给F定错。',
{'A':'正向适用；Data API支持不同应用运行环境。','B':'正向适用；现行官方明确一般客户端/服务端加密，不能用窄退役通知排除。','C':'正向适用；仓库分析加时钟调度已教，所需定时能力也有官方正证。','D':'按已教职责属于缓存，而非选择Redshift的用途。','E':'这种在线按键高并发/全球事务诉求更符合XB013的DynamoDB方向；仓库PB规模不等于该请求模型。','F':'已核snapshot restore创建第二cluster及live sharing不复制两种真实能力；原“secondary replica”未指定是哪种，不冒称它就是持续read replica或snapshot。'},
[proof('GSC-102','keyPointZH','Data API减少传统连接维护，支撑A。'),proof('CUR:CMP-M20','keyPointZH','客户端先加密后交数据库的共享机制支撑B的一半，服务端与客户端时序能区分。'),proof('CUR:XB013','keyPointZH','Redshift面向分析，区分D/E在线缓存及事务模型。'),proof('GSC-089','answerZH','时间触发机制迁移到仓库分析，支撑C而不借用省略GSC098。')],
['redshift-general-client-server-encryption','redshift-data-api','redshift-cse-ended','redshift-timed-pause-resume','redshift-snapshot-new-cluster','redshift-live-sharing-no-copy'],blocking='仅F的secondary replica含义未闭合：持续跟随的独立副本，还是由console snapshot restore生成的第二cluster。A/B/C已得到正向推理，不能据choose3要求反推F一定错。',proposal='如另建练习，将F精确写成某种复制/恢复动作并说明是否持续同步；不要静默改原F、也不要把当前ABC候选当已唯一验收。')
assert sorted(x['qid'] for x in rows)==m['questionIds']
for p,h in m['inputBindings'].items():assert sha(pathlib.Path(p).read_bytes())==h,p
for c in C.values():assert sha(canon(c['visibleBody']))==c['bodySha256']
omitted={'CUR:XB039','GSC-019','GCL-017','GSC-072','GSC-098','GSC-108','GSC-084'}
for x in rows:
 assert x['originalQuestionSha256']==old[x['qid']]['originalQuestionSha256']
 assert not omitted&{c['ruleId'] for c in x['learnerVisibleGroup']}
 for a in x['proofTrace']:assert a['quote']==C[a['ruleId']]['visibleBody'][a['field']]
checked=0
for k,x in F.items():
 for y in [x]+x.get('supportingQuotes',[]):
  p=pathlib.Path(y['snapshotPath']);d=read(p);assert sha(p.read_bytes())==y['snapshotSha256'],k
  assert sha(d['text'].encode())==y['textSha256'],k
  assert d['text'][y['quoteStart']:y['quoteEnd']]==y['quote'],k
  assert re.match(r'https://(?:docs\.)?aws\.amazon\.com/',y['url']),k
  checked+=1
now=datetime.datetime.now(datetime.timezone.utc).isoformat();counts=dict(collections.Counter(x['status'] for x in rows));out=dict(schemaVersion=1,reviewer='actual_gap_review',completedAtUtc=now,manifestPath=str(D/'manifest.json'),manifestSha256=sha((D/'manifest.json').read_bytes()),provisionalCorePoolCount=351,finalCardCount=None,questionCount=10,counts=counts,results=rows,externalModelCliApiCalls=0,nativeUsage='unknown',oldResultsUnchanged=True,variantsAuthored=0,cardsAuthored=0)
save('results.json',out)
save('readback.json',dict(schemaVersion=1,status='PASS',scope='Deterministic bindings, not an extra semantic review.',checkedAtUtc=now,inputBindings=len(m['inputBindings']),allOriginalsAndOptionsUnchanged=10,previousResultsUnchanged=True,currentCardPoolCount=351,coreBodyHashesChecked=351,usedCards=len({k for r in rows for k in r['usedRuleIds']}),prerequisiteClosureCards=len({c['ruleId'] for r in rows for c in r['learnerVisibleGroup']}),omittedSevenUse=0,evidenceFactKeys=len(F),evidenceExactQuotes=checked,missingFactKeys=0,proofQuotesMatch=True,counts=counts,externalModelCliApiCalls=0,nativeUsage='unknown',finalCardCount=None))
save('output-manifest.json',dict(schemaVersion=1,inputManifestSha256=sha((D/'manifest.json').read_bytes()),files={str(D/n):sha((D/n).read_bytes()) for n in ['results.json','evidence.json','readback.json']},oldResultsSha256=sha((P/'results.json').read_bytes()),counts=counts))
print(json.dumps(dict(counts=counts,evidenceFacts=len(F),exactQuotes=checked,questions=len(rows)),ensure_ascii=False,indent=2))

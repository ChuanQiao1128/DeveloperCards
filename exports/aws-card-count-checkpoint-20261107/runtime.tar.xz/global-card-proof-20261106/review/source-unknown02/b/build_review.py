import pathlib,json,hashlib,datetime,collections
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106')
R=V/'review/source-unknown02/b';I=R/'input';E=R/'official-evidence';OLD=V/'review/source-current-final/b/evidence'
def ca(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
M=json.loads((R/'manifest.json').read_text())
for p,h in M.items():assert sha(pathlib.Path(p).read_bytes())==h,p
cases=json.loads((I/'cases.json').read_text());by={c['qid']:c for c in cases}
pool={c['ruleId']:c for c in json.loads((I/'core-visible.frozen.json').read_text())}
assert len(pool)==351 and sorted(by)==[571,659,764,801,841,851,977,1002,1004]
for c in pool.values():assert sha(ca(c['visibleBody']))==c['bodySha256']
for c in cases:
 for p in c['visibleCards']:assert pool[p['ruleId']]['bodySha256']==p['bodySha256']
registry={}
def ev(name,quote,support,old=False):
 p=pathlib.Path(name) if str(name).startswith('/') else (OLD if old else E)/(name+'.json')
 d=json.loads(p.read_text());t=d['text'];start=t.index(quote)
 k=sha(ca([str(p),quote,support]))
 registry[k]={'sourcePath':str(p),'sourceFileSha256':sha(p.read_bytes()),'textSha256':sha(t.encode()),
  'url':d['url'],'quote':quote,'quoteStart':start,'quoteEnd':start+len(quote),'supports':support,
  'acquisition':'previous official snapshot re-read and claim-checked' if old else 'new official positive evidence'}
 return k
def an(rid,quote,support):
 c=pool[rid];fs=[(f,t.index(quote)) for f,t in c['visibleBody'].items() if quote in t];assert fs,(rid,quote)
 f,i=fs[0]
 return {'cardId':rid,'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':quote,
  'quoteStart':i,'quoteEnd':i+len(quote),'supports':support}

# Reproducible countermodels establish missing decisive conditions; they are not production measurements.
counter={}
counter['Q659']={
 'originalDataBytes':50*10**12,'deadlineSeconds':14*86400,
 'minimumRequiredBitsPerSecond':50*10**12*8/(14*86400),
 'models':[
  {'vpnCapacityBps':1.25*10**9,'otherTrafficUtilization':0.9,'remainingBps':125*10**6,
   'idealTransferDays':50*10**12*8/(125*10**6)/86400,'deadlineSatisfied':False},
  {'vpnCapacityBps':5*10**9,'otherTrafficUtilization':0.9,'remainingBps':500*10**6,
   'possibleNetTransferBpsAfterOverhead':400*10**6,
   'transferDaysAtIllustrativeNetRate':50*10**12*8/(400*10**6)/86400,'deadlineSatisfied':True}],
 'scope':'Two AWS-supported VPN bandwidth profiles, both 90% utilized, lead to opposite online deadline feasibility. Neither is claimed to be the original deployment.'}
def ebs_model(mode):
 blocks=list(range(20));daily=[];monthly=[]
 for day in range(1,2521):
  ix=0 if mode=='same_hot_5_percent' else (day-1)%20
  blocks[ix]=20+day
  if day>2490:daily.append(tuple(blocks))
  if day%30==0:monthly.append(tuple(blocks))
 baseline=set(x for s in daily for x in s)
 older=monthly[:-1]
 retained=baseline.union(x for s in older for x in s)
 block_size=350/20
 extra_standard=(len(retained)-len(baseline))*block_size
 archive_full=len(older)*350
 return {'dailyChangedBlockFraction':0.05,'volumeTB':350,'monthlyRetentionPoints':84,
  'olderMonthlyPointsCompared':len(older),'commonRecentDailyStorageTB':len(baseline)*block_size,
  'extraStandardRetainedTB':extra_standard,'archiveFullTB':archive_full,
  'standardCostWeight':extra_standard*0.05,'archiveCostWeight':archive_full*0.0125,
  'cheaperOlderMonthlyRetention':'standard' if extra_standard*0.05<archive_full*0.0125 else 'archive'}
counter['Q841']={'models':{m:ebs_model(m) for m in ['same_hot_5_percent','rotating_disjoint_5_percent']},
 'scope':'Exact block-version simulation: 20 equal blocks, one changed to fresh data each day, monthly snapshots every30days, latest30daily. Costs are normalized weights with a common unit conversion; not an actual bill.',
 'commonBaselineCancelled':True,'restoreFeesAssumedZeroForBothCounterexamples':True}
assert counter['Q841']['models']['same_hot_5_percent']['cheaperOlderMonthlyRetention']=='standard'
assert counter['Q841']['models']['rotating_disjoint_5_percent']['cheaperOlderMonthlyRetention']=='archive'
counter['Q1002']={
 'sharedConditions':'Two replicas, DynamoDB Standard, item writes<=1KB; common storage/reads excluded.',
 'officialIllustrativeRates':{'onDemandPerMillionWrites':0.625,'provisionedWcuHour':0.00065},
 'steadyProfile':{'writesPerSecond':100,'hours':730,'targetUtilization':0.7,
  'provisionedPerReplicaWcu':143,'onDemandTwoReplicaWriteCost':100*3600*730/1e6*0.625*2,
  'provisionedTwoReplicaWriteCost':143*0.00065*730*2},
 'variableProfile':'Evolving spikes and long low-utilization periods also fit a growing user base. Official guide states on-demand is cheaper below35% average provisioned utilization.',
 'notOriginalTrafficOrActualBill':True}
counter['Q1004']={
 'safeCloudFrontProfile':'A low-volume API of identical cacheable responses (or supported proxy methods) fits the original text; a free-plan-compatible public origin can cost less than a continuously enabled GA.',
 'unsafeCachingOptimizedProfile':'An API whose GET responses vary by customer Authorization header at the same URL also fits the text. CachingOptimized does not key on that header and has positive minTTL; retaining that policy can mix responses. GA does not HTTP-cache those responses.',
 'notClaimsAboutOriginalERPBehavior':True,'noAssumptionThatEveryAPIIsCacheableOrUncacheable':True}
proof_path=R/'countermodels.json';assert not proof_path.exists()
proof_path.write_text(json.dumps(counter,ensure_ascii=False,indent=2)+'\n')

tls=ev('tls-http','policy accepts TLS 1.2 and TLS 1.3 traffic and rejects TLS 1.0 traffic.','HTTP API确实支持协商TLS1.3；不把最低TLS1.3强加原文',True)
vpn=ev('vpn-options','1.25 Gbps per tunnel, while large supports up to 5 Gbps per tunnel.','两种现行VPN规格使90%利用率不能决定净传输窗口',True)
snow=ev('snowball-history','Effective November 7, 2025, AWS Snowball Edge will only be available to existing customers.','Snowball资格是适用条件，不泛化整体不可用',True)
private=ev('alb-target-private','primary private IP address specified in the primary network interface for the instance.','ALB可路由到目标实例私有IP')
aur=ev('aurora-mysql','Aurora MySQL is a drop-in replacement for\nMySQL','Aurora MySQL同样有低改造兼容方向，不能自动排除',True)
pitr=ev('aurora-pitr','You can restore a DB cluster to a specific point in time, creating a new DB cluster.','Aurora也支持PITR',True)
cse=ev('s3-client-encryption','Client-side encryption is the act of encrypting your data\nlocally to help ensure its security in transit and at rest.','原D的客户端密文可同时保护传输中的数据与落盘数据')
xks=ev('s3-external-macie','You can encrypt a list with a customer managed AWS KMS key in an external key store.','S3数据客户管理KMS key也有实际XKS适用正证')
ebs_price=ev('ebs-tariffs','Archived snapshots are billed at a rate of $0.0125 per GB-month.','归档按完整快照量乘归档单价')
ebs_standard=ev('ebs-tariffs','for snapshots of $0.05 per GB-month.','同一官方例中的标准层单价')
ebs_full=ev('ebs-archive','When you archive a snapshot, the incremental snapshot is converted to a full snapshot,','归档完整量与标准增量共享量不同',True)
pause=ev('aurora-create','Choosing a minimum capacity of 0 ACUs enables the Aurora serverless automatic pause and resume capability.','自动暂停取决于最小0，并不是Serverless这个名字')
default=ev('cdk-rds','serverlessV2MinCapacity: 0.5,\nserverlessV2MaxCapacity: 2,','官方CDK当前给出的默认容量示例并非最小0')
console=ev('aurora-create','For Capacity range, you can accept the default range.','控制台存在默认，但原题没绑定创建接口/产品默认')
acm=ev('acm-integrations','To automate public certificate issuance and renewal outside integrated services such\nas on Amazon EC2 instances, use the ACME protocol.','当前ACM可用于原题已述EC2应用TLS，无需给题目添RDS Proxy')
rdsca=ev('rds-tls','Amazon RDS provides the following CAs to sign the DB server certificate for a\ndatabase.','RDS数据库链路使用其提供的CA体系',True)
rotate=ev('rds-tls','manages the DB server certificate on the database. RDS rotates the DB server\ncertificate automatically before it expires.','RDS原生托管证书维护',True)
on_demand=ev('dynamodb-modes','workloads with average provisioned capacity utilization below 35%.','低利用率按需更省，growing不决定利用率',True)
stable=ev('dynamodb-modes','An ideal workload for provisioned capacity mode is one with a more steady and predictable\nusage pattern','稳定可预测负载的另一成本方向',True)
rate_demand=ev('dynamodb-prices','$0.6250 per million writes','官方请求计价例')
rate_provisioned=ev('dynamodb-prices','$0.00065 * 100','官方预置WCU计价例')
dynamic=ev('cloudfront-dynamic','Dynamic requests, as determined at request time, do not flow through regional edge\ncaches, but go directly to the origin.','CloudFront可转发动态请求，不能因是API就排除')
min_ttl=ev('cache-optimized','Minimum TTL: 1 second.','CachingOptimized为正最小TTL',True)
cache_key=ev('cache-optimized','Headers included in the cache key: None\nare explicitly included.','该策略不含Authorization等任意头',True)
ga_fixed=ev('global-accelerator-prices','you are charged $0.025 until it is deleted.','GA持续启用的固定小时费')
cf_free=ev('cloudfront-prices','Start with the $0/month Free plan','CloudFront有适用免费计划，不能无流量条件就断言GA最便宜')

rows=[]
def add(q,status,options,anchors,eids,reason,comparison,progress,source,gaps=None,proposal=None,conditions=None,proof=None):
 rows.append({'qid':q,'previousStatus':'UNKNOWN','status':status,
  'fullOriginalStemAndEveryOptionReadAgain':True,'questionSha256':sha(ca(by[q]['originalQuestion'])),
  'selectedOptionOrdinals':options if status=='SUPPORTED' else [],
  'candidateOptionOrdinals':options if status!='SUPPORTED' else [],
  'necessaryCardAnchors':[an(*a) for a in anchors],'officialEvidenceIds':eids,
  'reasoning':reason,'optionComparison':comparison,'newProgressBeyondPreviousUnknown':progress,
  'sourceDisposition':source,'necessaryCardFactGaps':gaps or [],
  'minimalCorrectionProposal':proposal,'conditionsAndUnresolved':conditions or [],
  'countermodelKey':proof,'originalNeverModified':True,'correctedExerciseNotAuthoredOrTested':True,
  'architectureSelectionNotDeploymentBenchmark':True,'measuredLearnerAccuracy':False})
add(571,'INSUFFICIENT_CARDS',[1],[
 ('CUR:CB13','将证书导入ACM并绑定实际TLS入口。','外部证书导入绑定'),
 ('CUR:CB13','最低TLS版本另由入口支持的安全策略决定；换证书签发CA，不会改变入口允许的TLS版本。','TLS能力与签发方不同'),
 ('CUR:NEW02','ACM不能代替外部CA签发新证书','指定外部CA须外部签发再导入')],
 [tls],
 '按原文要求支持TLS1.3即可，A在当前AWS事实中能满足；原文没有minimum/only，先前为它另设“必须拒绝1.2”不是必要条件。B/C/D都让ACM代指定第三方CA签发，卡面已能解释其错误。仍不能把官方私有摘录当学习材料：core351没有说明HTTP API当前可协商TLS1.3，完整条件的可见事实前提缺这一项。',
 {'1':'架构事实可行，尚缺HTTP API的TLS1.3可见能力前提。','2':'外部CA签发路径错误。','3':'外部CA路径错误且混入函数URL自定义证书。','4':'同样由ACM代第三方CA签发。'},
 '撤销强加minimum/only的语义疑点；把源题UNKNOWN分解为原选项A事实上可行和一项明确卡面缺口。',
 {'status':'NO_CONFIRMED_SOURCE_ERROR','reason':'官方明示HTTP API支持TLS1.3，原文也未要求仅允许1.3。'},
 gaps=['HTTP API当前端点可协商TLS1.3。不能只教“先查策略”而当学习者已知道支持版本。'],
 conditions=['此缺口不要求新开独立卡或背完整密码套件目录；可在现有相关规则中安排复用，但本任务不作者。'])
add(659,'SOURCE_ISSUE',[1,3],[
 ('GSC-077','先用数据量÷实际可用传输速率估算在线下限；窗口不够时，比较适用的离线设备方案。','计算净带宽窗口'),
 ('GSC-077','链路总带宽不等于迁移可占用带宽；','百分比不是绝对净速率')],
 [vpn,snow],
 '已构造两个都符合“VPN90%利用”的现行规格：标准1.25Gbps只余125Mbps，50TB理想也约37天；5Gbps大带宽余500Mbps，即使只取得400Mbps净速率也约11.57天。后者允许DataSync在线方案，前者需要比较离线或新链路。原文不给绝对带宽，不能唯一推出C；现行Snowball资格/交付也不是原文既定事实。',
 {'1':'在高带宽反例中足以满足在线窗口。','2':'能否两周交付由真实供给决定，原文没有；不以没找到交付时间证明它不支持。','3':'符合资格且设备/交付可用时是低剩余带宽方向。','4':'网关本身不扩大链路。'},
 '由笼统“还需带宽”推进为两种AWS支持规格及精确期限反例，证明原数字无法唯一化。',
 {'status':'CONFIRMED_UNDERDETERMINED_DECISIVE_RATE','reason':'相同给定利用率可以产生相反在线期限结论，具备官方规格正证与可复算反例。'},
 proposal={'kind':'separate_practice_new_givens_not_recovered_intent','target':'stem, append',
  'text':'The remaining usable transfer bandwidth is 100 Mbps and cannot be increased during the move. The company is eligible for an available Snowball job, and suitable device capacity, shipping, and import within the two-week window have been confirmed.',
  'preserves':'安全的大数据期限迁移判断；只明确原来缺的决定性输入','notYetBlindTested':True},
 proof='Q659')
add(764,'SOURCE_ISSUE',[1,2,3],[
 ('CUR:CB04','入口是否面向公网取决于访问者范围；VPN提供办公室到私网的路径，不必把后端公开。','不能凭web字样强制公网子网'),
 ('CUR:CB04','ALB接收入口连接后再连接私有目标。','公网入口可连接私有Web实例'),
 ('CUR:CC22','在引擎和功能兼容的前提下迁移到相应RDS。','保留关系数据库减少改造'),
 ('CUR:NB04','不能；启用该数据库支持的自动备份/point-in-time recovery，恢复到需要时刻的目标，再按计划切换。','RDS恢复点')],
 [private,aur,pitr],
 '以无互联网入口要求的内部三层应用为反例，A和C都用EC2及同一RDS MySQL/PITR，只是web子网路由不同；原文没有任何条件使A的私有Web无效。若需要公网入口，已教ALB也可连接私有目标，不能把主机必须公有当原要求。B的Aurora兼容和PITR另有正证，也不能只按名称断言改造更多。',
 {'1':'内部客户场景下完整满足，未被原文排除。','2':'适用MySQL功能中可保留协议并支持PITR。','3':'同样是EC2/RDS MySQL，公开Web不是原文必需。','4':'公开子网并不自动等于数据库公开，但也没有给出更低维护的决定条件。'},
 '从泛化兼容未知推进为A/C使用完全相同计算/数据库而仅改变未受限web网络位置的具体反例；不再把运行验证当缺口。',
 {'status':'CONFIRMED_NON_UNIQUE_NETWORK_AND_ENGINE_DISPOSITION','reason':'完整原文没有互联网访问限制；A/C均可满足原有关系迁移与PITR目标。'},
 conditions=['未给出可保留全部原学习目标且不捏造客户访问范围/引擎限制的单句唯一化修正。需要来源方提供这些事实；不把指定RDS作为答案前提来省掉原选型目标。'])
add(801,'SOURCE_ISSUE',[1,4],[
 ('CUR:CMP-M20','应用应先用可调用的客户密钥完成客户端加密，再交给存储。','D的数据在上传前已经成为密文'),
 ('CUR:XA029','使用KMS external key store，由外部key manager保留并使用实际密钥。','A的客户管理KMS key可用外部密钥管理器'),
 ('CUR:XA029','KMS经XKS proxy把密码操作交给外部管理器，不能读取、创建或删除其中的外部密钥；这不同于把材料导入AWS。','外部保管并非导入AWS')],
 [cse,xks],
 'D的客户端加密本身可保护在途与静态数据，先前因没写TLS就否定D是误设要求。当前A的客户管理KMS key又包含XKS这一已教、已正式支持S3的外部保管配置。原文没有把A限定为标准AWS key store，也没有要求只能在上传前加密。因此A(XKS)与D(外部本地密钥客户端加密)都是当前可行架构。',
 {'1':'使用XKS时实际密钥由AWS外部管理器保管并使用，符合原目标。','2':'AWS managed key不提供客户外部保管控制。','3':'默认SSE不实现外部密钥管理。','4':'本地客户端密文保护整个上传及静态生命周期。'},
 '新S3官方正证确认CSE覆盖in-transit/at-rest；另用S3/Macie实际XKS例确认A也可行，撤销先前额外TLS条件并正式记录当前多解。',
 {'status':'CONFIRMED_MULTIPLE_CURRENT_KEY_MANAGEMENT_PATHS','reason':'D/CSE与A/XKS均有官方正证，且核心卡已有两套机制；不是没有检索到能力。'},
 proposal={'kind':'separate_practice_distractor_restriction','target':'option A, after customer managed key',
  'text':'that uses AWS-generated key material in the standard AWS KMS key store',
  'preserves':'外部保管密钥与本地客户端加密的原取舍，不删传输/静态要求','notYetBlindTested':True})
add(841,'SOURCE_ISSUE',[2,3],[
 ('GSC-018','不一定，要按归档后的完整快照大小及保留、恢复费用比较。','实际存储量与费用比较'),
 ('GSC-018','标准层快照利用增量块共享；归档时会转成包含该恢复点全部已写数据块的完整快照，计费数据量可能变大。','共享块与完整快照不同')],
 [ebs_price,ebs_standard,ebs_full],
 '新模型按20个等大块、每天改一块精确满足5%。同一热5%每天重写时，83个旧月点仅额外保留1452.5TB增量；归档则为29050TB完整量，以官方0.05/0.0125费率其月点增量费用权重反而高5倍。轮流更新20块时，同样每日5%，旧月点不共享块，归档费用权重变为标准的四分之一。两个数据序列均符合原文，所以5%不能决定B/C成本排序。',
 {'1':'原生EBS恢复点不能直接当自有S3对象改Deep Archive类别。','2':'在低共享块反例中更便宜。','3':'在相同热块反复改写反例中更便宜。','4':'EBS direct API输出原始块并不自动组成最少维护的原生恢复点保留策略。'},
 '由未定量的块重叠疑点推进为两种满足所有原数字的块版本模拟和官方费率，得到相反成本赢家；并非要求真实部署实测。',
 {'status':'CONFIRMED_COST_RANKING_NOT_DETERMINED','reason':'可复算的两种合法数据更新模式给出相反B/C排序。'},
 proposal={'kind':'separate_practice_new_workload_given','target':'stem, append',
  'text':'Each older monthly recovery point contains no blocks shared with any other retained snapshot. Restores are rare and can wait for archive retrieval.',
  'preserves':'七年月点、一个月日点和低维护成本判断；新给块共享/恢复条件而非猜造原数据模式','notYetBlindTested':True},
 proof='Q841')
add(851,'UNKNOWN',[2,3],[
 ('CUR:XA020','把批准配置发布为Service Catalog产品，向开发者开放相应portfolio，并设置开通约束。','规格约束与自助创建'),
 ('CUR:XB027','启用自动暂停，把支持的最小容量设为0 ACU，并设定空闲等待时间。','自动暂停需要实际容量条件'),
 ('CUR:XB027','只是选了Serverless名称，并不等于默认就会降到零或立刻响应。','默认名义不能替代配置事实')],
 [pause,default,console],
 '已核实当前控制台允许选择默认范围，官方CDK给出的默认例为0.5–2 ACU，自动暂停须另满足最小0。故不能把未限定的Service Catalog“default capacity settings”直接视作零空闲算力；但原题也没有硬性禁止闲置费用，不能据此直接判C错误。C共享逻辑数据库与B受限实例产品的实际默认、隔离粒度及活跃分布未明，仍不能独立确认唯一最经济方案。',
 {'1':'可按工作时间启停，但规格限制与全球工作时段具体实现未给。','2':'直接提供规格受限的自助产品，停止/删除策略未写。','3':'Serverless共享方案可以有效，实际产品默认可能暂停也可能不暂停。','4':'终止闲置数据库不是保留开发数据的启停方案。'},
 '补得两个实际创建接口的正证；同时撤销“原题必须零闲置费用”这一先前未被要求的硬化解释。剩余未知是原产品/容量语义和成本条件，非未找到能力。',
 {'status':'GENUINE_UNKNOWN_PRODUCT_DEFAULTS_AND_COST_SCOPE','reason':'默认值取决于产品/接口/版本；未确认原题是哪一种，尚无独立源错结论。'},
 conditions=['请来源方明确Service Catalog产品的Aurora版本、Min/MaxCapacity、暂停配置，以及separate/limited size指逻辑库还是实例边界；未知原题不套最小纠错豁免。'])
add(977,'SUPPORTED',[1],[
 ('CUR:CC08','新建库启用KMS静态加密。','原生受管数据库静态加密'),
 ('CUR:CMP-M11','仍须启用数据库客户端TLS，并使用AWS提供的RDS CA证书包验证服务端证书。','实际SQL连接TLS与RDS身份验证'),
 ('CUR:CMP-M11','真正建立TLS才保护连接。','证书支持的是实际TLS连接'),
 ('CUR:CB13','将证书导入ACM并绑定实际TLS入口。','证书跟随实际入口，不把所有连接混成一个证书绑定')],
 [acm,rdsca,rotate],
 'A是KMS原生静态加密加证书支持TLS的低维护架构。原文没有说把ACM证书安装到RDS服务器；当前ACM可用于题目已经存在的EC2应用TLS，数据库那一段按卡面使用RDS CA并启用客户端TLS。无需引入未列RDS Proxy或替换数据库证书。C自建应用级加密增加密钥/代码运维，B/D另建网络隧道，均不如原生KMS+TLS直接。',
 {'1':'原生KMS静态加密及TLS分别保护两层，卡组可解释实际连接处理。','2':'IPsec也可保护网络，但需要额外隧道/网络配置，不是这里最少运维的应用连接方式。','3':'第三方应用加密增加代码/密钥维护。','4':'另建VPN增加网络路径维护；不能用私网身份替代真实TLS客户端设置。'},
 '解除先前强加“ACM必须直接绑定RDS服务器”的解释。新ACM官方正证支持已有EC2上的证书使用；已有卡面已教RDS链路的实际TLS/RDS CA，因此选型不依赖补出新服务或部署实测。',
 {'status':'NO_CONFIRMED_SOURCE_ERROR','reason':'按原文字面只要求证书支持传输TLS，没有指定错误的RDS自定义证书安装动作。'},
 conditions=['ACM在EC2上的具体ACME/导出自动化是实施方式正证，不把CLI步骤或证书产品目录加为本题回忆义务。','RDS服务器证书使用其受管CA体系；本结论不声称ACM会自动启用任意数据库TLS。'])
add(1002,'SOURCE_ISSUE',[1,4],[
 ('GSC-039','global tables管理跨Region复制，应用可以访问所在Region的副本，减少每次回到单一Region。','托管多Region复制'),
 ('GSC-038','难预测的负载考虑on-demand；稳定且可规划时比较provisioned配合自动伸缩。','容量模式按真实负载选型')],
 [on_demand,stable,rate_demand,rate_provisioned],
 '新费率例中，两个副本每秒100次<=1KB写、按70%目标预置143WCU，730小时写容量约135.71美元；同量按需约328.50美元。另一方面，官方明确低于35%平均预置利用率的负载按需更便宜。稳定递增与间歇突增都符合growing user base，故A/D不能仅凭“增长”唯一排序；A先建一Region再加global replicas并不矛盾。',
 {'1':'按需global tables有效，低利用率/突增条件下更省。','2':'DAX与自建复制不能替代题目已有的托管多Region机制。','3':'自建Streams复制额外管理；不优于给出的global tables。','4':'稳定高利用率下预置自动伸缩可更省。'},
 '从无负载描述推进为官方明确的成本分界和同原目标相容的数值反例；没有把growth误当unpredictable。',
 {'status':'CONFIRMED_UNDERDETERMINED_COST_PROFILE','reason':'两个被官方支持的负载区间及价格产生不同容量模式赢家。'},
 proposal={'kind':'separate_practice_new_workload_given','target':'stem, append',
  'text':'Traffic grows predictably, remains steady within each hour, and sustains high provisioned-capacity utilization with no abrupt idle-to-peak bursts.',
  'preserves':'同一多Region可用性与最低成本目标；新明确负载而非恢复原意','notYetBlindTested':True},
 proof='Q1002')
add(1004,'SOURCE_ISSUE',[2,3],[
 ('CUR:CA13','边缘位置就近承接连接，适用内容可从缓存返回，未命中或动态请求再到源站，减少远距离访问的影响。','CloudFront也能转发动态请求'),
 ('CUR:NS02','Global Accelerator让TCP/UDP流量从附近AWS边缘进入全球网络，再按网络性能与健康状态选择适用区域端点。','GA无需HTTP缓存的加速路径'),
 ('GSC-130','键必须区分实际内容变体。','共享缓存正确性取决于业务请求差异')],
 [dynamic,min_ttl,cache_key,ga_fixed,cf_free],
 '新正证确认CloudFront动态/代理请求也能直达源站，不能只因ERP/API就排除B。低量、相同可缓存响应的API符合原文，适用CloudFront免费计划可能比GA持续小时费低；同一路径按Authorization返回不同客户数据的GET也符合原文，此时CachingOptimized不含该头且正最小TTL，B可能混用响应，C不受HTTP缓存这一问题影响。缺少这些决定条件不能唯一化成本与正确性。',
 {'1':'每客户新专线及public VIF/DX gateway路径还需匹配实际网络，非给定低成本结论。','2':'在可安全缓存/适用低量计划的反例中有效且可能更省；不能把所有API一概判不适合CloudFront。','3':'非缓存网络加速有效，在不能使用给定缓存策略的反例中满足要求。','4':'VPN加密不等于专用链路，也未给其国际路径更优的正证。'},
 '补得CloudFront动态方法正证和当前费用结构，构造两种原文允许而选择不同的API行为；不再把未部署测速或未得实际账单当主要缺口。',
 {'status':'CONFIRMED_MISSING_DECISIVE_API_SEMANTICS','reason':'可缓存同响应与必须隔离的个性化响应都是原文允许场景，给定缓存策略在两者的可行性不同。'},
 proposal={'kind':'separate_practice_new_correctness_given','target':'stem, append',
  'text':'Every GET response contains customer-specific transaction data and must never be cached at an edge location, even briefly.',
  'preserves':'国际ERP API响应加速目标；只给清楚的缓存正确性约束，不猜原实际API属性','notYetBlindTested':True},
 proof='Q1004')

assert len(rows)==9
# A bounded visible-pool search proves a teaching gap, never a service capability absence.
tls_hits=[rid for rid,c in pool.items() if '1.3' in json.dumps(c['visibleBody'],ensure_ascii=False)]
assert not tls_hits
count=dict(collections.Counter(x['status'] for x in rows))
sourcefiles={e['sourcePath']:e['sourceFileSha256'] for e in registry.values()}
(E/'manifest.json').write_text(json.dumps(sourcefiles,ensure_ascii=False,indent=2)+'\n')
result={'schemaVersion':1,'reviewer':'actual_cards_review independent source-unknown02 group b',
 'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'inputManifestPath':str(R/'manifest.json'),'inputManifestSha256':sha((R/'manifest.json').read_bytes()),
 'inputFiles':M,'officialEvidenceManifestPath':str(E/'manifest.json'),
 'officialEvidenceManifestSha256':sha((E/'manifest.json').read_bytes()),
 'corePoolCount':351,'corePoolProvisionalNotFinalN':True,
 'questionCount':9,'counts':count,'results':rows,'evidenceRegistry':registry,
 'countermodels':{'path':str(proof_path),'sha256':sha(proof_path.read_bytes()),'reproducibleNotProductionMeasurements':True},
 'boundedTeachingGapSearch':{'ruleScope':'all351 four-field visible bodies','literalTerm':'1.3','matchingRuleIds':tls_hits,
  'serviceAbsenceNotInferred':True},
 'oldSourceCurrentFinalResultsUntouched':True,'originalQuestionsUntouched':True,
 'correctedVariantsAuthored':False,'cardsAuthored':False,'currentPointersChanged':False,
 'userCorrectionPolicyPreserved':True,'unknownQuestionsNotExempted':True,
 'modelCliApiCalls':0,'nativeUsage':'unknown','finalNStillUnknown':True}
out=R/'results.json';assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for row in rows:
 assert row['questionSha256']==sha(ca(by[row['qid']]['originalQuestion']))
 for a in row['necessaryCardAnchors']:
  c=pool[a['ruleId']];assert c['bodySha256']==a['bodySha256']==sha(ca(c['visibleBody']))
  assert c['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']]==a['quote']
for e in registry.values():
 p=pathlib.Path(e['sourcePath']);d=json.loads(p.read_text());assert sha(p.read_bytes())==e['sourceFileSha256']
 assert sha(d['text'].encode())==e['textSha256']
 assert d['text'][e['quoteStart']:e['quoteEnd']]==e['quote']
for p,h in M.items():assert sha(pathlib.Path(p).read_bytes())==h
(R/'readback.json').write_text(json.dumps({'status':'PASS','resultsPath':str(out),'resultsSha256':sha(out.read_bytes()),
 'questionCount':9,'allFrozenInputsMatch':True,'allQuestionHashesMatch':True,'allFourFieldHashesAndLiteralOffsetsMatch':True,
 'allOfficialSnapshotsAndLiteralOffsetsMatch':True,'allCountermodelAssertionsPass':True,'oldResultsAndCurrentPointersUntouched':True,
 'modelCliApiCalls':0,'nativeUsage':'unknown'},ensure_ascii=False,indent=2)+'\n')
(R/'summary.md').write_text(
 '# 九项UNKNOWN再核查\n\n'
 '结果：Q977 SUPPORTED（A）；Q571 INSUFFICIENT_CARDS（A事实上支持TLS1.3，当前卡未教支持版本）；Q659/Q764/Q801/Q841/Q1002/Q1004 SOURCE_ISSUE（有新官方正证或可复算反例）；Q851仍UNKNOWN。\n\n'
 '撤销的额外假设包括：Q571须只允许最低TLS1.3、Q801客户端加密还必须另写TLS才能保护在途数据、Q977的ACM证书必须直接安装到RDS。CloudFront动态请求并非自动不可行；增长负载也不自动等于不可预测尖峰。\n\n'
 'Q841的两个每日5%块更新模型给出相反成本排序；Q659的两种现行VPN规格给出相反在线期限结论。反例不是原生产数据，也不要求部署实测SLA。\n\n'
 '五项具体最小新练习修正仅为建议，未作者或盲测，不升级原题。Q764没有捏造访问者/引擎限制来制造唯一性；Q851未确认的默认产品事实继续保留，不套纠错豁免。原审查、原题、卡片和current均不改。模型CLI/API 0，native unknown；最终N仍未知。\n')
print(json.dumps({'path':str(out),'sha256':sha(out.read_bytes()),'counts':count,'officialEvidenceCount':len(registry),'readback':'PASS'},ensure_ascii=False))

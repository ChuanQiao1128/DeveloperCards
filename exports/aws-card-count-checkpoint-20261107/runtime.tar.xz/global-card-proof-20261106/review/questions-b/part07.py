from review_helper import *
save(7,[
(483,'INSUFFICIENT_CARDS',[3],[('GSC-133','Windows容器应选择当前支持该环境的平台'),('GSC-089','固定时间用适用调度器')],'C定时Fargate任务方向明确，A不能只因短时长忽略Windows；但B同样写Fargate资源，卡组没教AWS Batch/Fargate的Windows支持差异，无法完整解释为什么B不可替代。',['AWS Batch on Fargate与ECS on Fargate对Windows任务的支持边界'],[]),
(490,'INSUFFICIENT_CARDS',[],[('GSC-043','不代表分析副本持续实时等于在线表'),('CUR:NB04','point-in-time recovery')],'B的PITR与一次表导出不等于持续S3备份；C能消费后续变更但完整连续备份还需基线及可恢复变化记录。不能把PITR连续保护错误升级成S3持续导出。',['无RCU影响的完整持续S3备份/增量调度与基线策略'],[]),
(493,'SOURCE_ISSUE',[],[('CUR:CMP-M15','符合相应语言及转录方式的支持条件'),('GSC-106','把文字转换为英语'),('GSC-105','先核对语言和功能支持')],'预期任务链为4/5/6，但D/E都声称any language，而卡面及服务范围明确有语言支持条件；题目又要求未来新增语言，不能把有限支持改写成任意语言。',[],['D/E的any language是无条件能力陈述；若改为实际受支持语言，Transcribe→Translate→Comprehend链才成立。不默默改题后记SUPPORTED。']),
(500,'INSUFFICIENT_CARDS',[1,4],[('CUR:XB023','SMB路径可保留NTFS访问控制列表')],'A直接DataSync SMB到FSx可保留ACL，B/C/E经普通对象复制不保证Windows权限；第二个D涉及Snowcone设备订购和运行DataSync agent，当前卡没有证明其资格/能力，不能为Choose two强选。',['Snowcone当前订购资格及其DataSync agent作为SMB传输宿主的可用能力'],[]),
(501,'CONDITIONAL',[1],[('CUR:NC01','数据持续到达'),('CUR:XB004','Lambda消费者清理记录并写入DynamoDB'),('CUR:NS01','配置了实际目的地的Data Firehose交付流')],'A流摄取后Lambda实时分析最贴合，Glue不是实时入口，Firehose单独是交付而非分析。A仍须由处理代码或明确交付路径把结果写入S3，不能仅建流就声称湖已有数据。',[],['A的Lambda处理必须实际写入S3或接上完整S3交付路径；所给选项只写摄取和分析，未明说最后输出。']),
(502,'SUPPORTED',[3,5],[('GSC-001','同一个EFS文件系统，让实例共同挂载'),('CUR:CA13','适用内容可从缓存返回'),('CUR:CB03','跨AZ Auto Scaling组维持容量')],'C共享文件去除单实例卷，E多实例加边缘内容分发；B主机NFS仍单点，A把对象存储当原生共同文件挂载不等价，D加速器不如静态缓存直接卸载重复图像。',[],[]),
(504,'SUPPORTED',[3],[('GSC-075','TGW用中心路由连接多个网络')],'C中心网络账户TGW配路由管理多账户VPC；A点对点关系数量增长，D自管转接VPN更多维护，B互联网NAT不是私网互联。',[],[]),
(505,'SUPPORTED',[3],[('GSC-146','优先承载能容忍中断并恢复的任务')],'C可失败重跑批任务用Spot并随CPU扩量；A/B对每天6小时固定承诺可能闲置，D增规格不利用中断容忍优势。',[],[]),
(507,'CONDITIONAL',[2],[('GSC-045','异步复制有延迟'),('GSC-039','不要假设任何跨Region写入都会立刻在所有副本可见'),('GSC-056','有数据副本与应用已经恢复是两个阶段')],'B单writer加跨Region reader最接近原意，A多Region写与单主要求不一致。若globally consistent指所有Region严格强一致读取，则异步reader不能保证；低于1秒平均更新也不是无条件上限。',[],['把globally consistent限定为单一权威writer且接受副本异步延迟；如字面要求全球同步强一致，B/C均不成立，本题应另行澄清而不默默降低约束。']),
(508,'INSUFFICIENT_CARDS',[2,4],[('CUR:NS03','统一计划安排备份和恢复点生命周期'),('GCL-014','EC2实例资源备份'),('GSC-070','目标Region最近已可用恢复点')],'D可证明内置跨Region定时EC2备份；A/E灾后才复制拖RPO/RTO，C自建复制函数多维护。B EC2 AMI生命周期管理能力未在EBS专用DLM卡中教明，不能据名称强选第二项。',['Data Lifecycle Manager支持EC2-backed AMI定时创建及跨Region复制的范围'],[]),
(511,'INSUFFICIENT_CARDS',[2],[('CUR:XB027','只是选了Serverless名称，并不等于默认就会降到零'),('CUR:CC22','在引擎和功能兼容的前提下迁移到相应RDS')],'B单AZ托管PostgreSQL拟选；A/C都没写Serverless自动暂停，不能把A自行改成Serverless版本。但卡没有给开发单AZ RDS与Aurora常驻容量的经济取舍，无法证明最低费。',['所给非Serverless数据库选项在短时开发环境下的成本取舍'],[]),
(512,'SUPPORTED',[1],[('CUR:CC10','资源是否有标签等真实配置'),('CUR:CC10','Automation实际执行修改步骤'),('CUR:NS03','跨服务统一计划用AWS Backup')],'A配置评估找漏标签再程序补标，给支持资源纳入统一计划；D漏洞服务不负责标签合规，B仅未运行资源并不等于应备份全集。AWS Backup范围按受支持资源理解，不扩成所有AWS资源类型。',[],[]),
(513,'SUPPORTED',[1],[('CUR:CA16','存储直接返回页面文件'),('CUR:CA17','短时函数'),('GSC-029','由写入事件启动处理'),('CUR:NA05','不受单个实例和其块卷的生命周期约束')],'A静态前端加弹性函数缩图并S3对象保存；C单EC2处理单点，D后端仍单EC2，B StepFunctions编排本身不执行图片变换且RDS非图片对象库。',[],[]),
(515,'INSUFFICIENT_CARDS',[1,2,3],[('GSC-102','通过服务API提交SQL并取得结果'),('CUR:XB013','Redshift的数据仓库面向分析查询')],'A数据API可证；D缓存、E在线请求规模不是仓库用途。B加密范围和C指定时段运行的调度/暂停能力没有当前卡面依据，不能因Choose three只剩三项而推成支撑。',['Redshift适用的客户端/服务器端加密范围及现行支持','按指定时段运行/暂停分析仓库的成本机制'],[]),
(516,'SUPPORTED',[2],[('CUR:CA17','入口和计算由托管服务按请求承载'),('GSC-134','provisioned concurrency预先初始化相应执行环境')],'B托管API/函数并预热稳定延迟；D仅预留并发不初始化，A/C维护应用平台更多。',[],[]),
(518,'SUPPORTED',[1],[('GSC-050','存储自动扩展'),('GSC-050','扩大CPU和内存规格不能代替解决磁盘空间不足')],'A在线存储容量增长路径最少手动；B不等价扩磁盘，C IOPS不是空间，D恢复替库增停机步骤。',[],[]),
(520,'SUPPORTED',[2],[('GSC-038','难预测的负载考虑on-demand'),('GCL-023','频繁请求通常比较Standard')],'B独立选按需容量及请求频繁的Standard表类；D IA偏存储主导而本题中高读写，A预配难预计。',[],[]),
(522,'SUPPORTED',[2,3],[('GSC-138','HPA调整工作负载副本'),('GSC-138','节点伸缩补充承载资源')],'B/C分别Pod与节点容量，两个层次配合；A自定义Lambda调整多维护，D入口/E网格观测不自动创建所需工作副本/节点。',[],[]),
(523,'SUPPORTED',[1],[('GCL-007','多个步骤依次使用输入和前一步结果')],'A请求内流水线取多张DynamoDB表并组响应，避免把全部编排写在应用函数；D分析联合查询路径不同，边缘入口不自动合并数据源。未声称任何数据库读都零成本。',[],[]),
(525,'INSUFFICIENT_CARDS',[1],[('GSC-153','交互分析及适用API查询用Cost Explorer')],'A是唯一正确程序化费用分析方向；B CSV不是直接API，C/D预算投递不提供查询预测接口。但卡只有“预测”泛称，没有教所需未来12个月预测时间范围。',['Cost Explorer API历史及未来12个月预测的支持粒度/范围'],[])
])

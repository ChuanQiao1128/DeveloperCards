from review_helper import *
save(6,[
(408,'SUPPORTED',[2],[('CUR:XB041','UDP使用适用的NLB'),('CUR:NS02','多Region应用需要统一固定入口并健康选路'),('CUR:XB019','少维护宿主机可选Fargate')],'B跨Region GA/NLB加Fargate处理UDP；C/D ALB协议不符，A NLB到Lambda并非已教HTTP函数入口路径且DNS切换受缓存影响。',[],[]),
(413,'SUPPORTED',[2],[('GCL-001','订单确认或营销邮件'),('GCL-001','专门邮件服务承担相应发送能力')],'B SES减少自建邮件投递复杂度；C SNS通知不等同客户内容投递，A/D继续自管邮件处理机器。',[],[]),
(416,'SUPPORTED',[2,4],[('CUR:CA13','适用内容可从缓存返回'),('GSC-046','把适用的只读请求连接到副本端点')],'B边缘交付减少远端等待，D分担OLTP读；E经典standby不扩读，A仓库不是线上读优化，C不能在S3执行动态代码。',[],[]),
(422,'SUPPORTED',[4],[('GSC-079','持久工作队列保存任务'),('GSC-114','每实例积压量'),('GSC-137','底层容量伸缩提供实际CPU、内存等资源'),('GSC-136','内存配置也影响分配的CPU资源')],'D持久异步积压加任务和底层容量两层伸缩；B App Mesh不替容量伸缩，C声称AutoScaling直接调Lambda vCPU混淆资源与并发，A NLB不是Lambda调用入口。',[],[]),
(424,'INSUFFICIENT_CARDS',[2],[('GSC-146','是否能重做或续跑决定适用性')],'B是拟选稳定前端/可变后端，但题未说明后端能承受Spot中断，卡亦未教EC2 RI持续使用经济机制；A Fargate也需容器改造未给。',['EC2 RI与On-Demand的持续运行承诺成本规则'],['若选Spot后端，需确认后端能够重试/恢复，短时及数量变化本身不等于可中断。']),
(427,'SUPPORTED',[2],[('GCL-006','支持的应用平台组织部署和相关AWS资源管理'),('CUR:CB03','在多个AZ各设子网并分散实例')],'B托管受支持服务器端应用的负载均衡环境并滚动部署；A改函数执行模型不适合直接Tomcat，D把数据库也绑进各实例会留下数据库一致性/接管缺口。',[],[]),
(432,'INSUFFICIENT_CARDS',[2],[('GSC-109','自行在SageMaker训练部署模型'),('CUR:NA02','用QuickSight连接相应数据集')],'B建模与BI分工最贴切，D计算字段不是完整自训ML。但卡面没有把SageMaker推理结果接入QuickSight增强数据/图表的实际能力，不能仅凑两个产品名算整链成立。',['SageMaker模型预测与QuickSight增强数据的受支持集成'],[]),
(434,'SUPPORTED',[1],[('GSC-039','global tables管理跨Region复制'),('GSC-068','灾前准备越完整，灾后补建与扩容越少'),('GSC-126','主资源被判不健康时回答备用资源')],'A预建计算/负载均衡及global table，内置DNS健康failover少事后动作；C需临时创建计算，D自建函数切DNS多控制步骤。',[],[]),
(440,'INSUFFICIENT_CARDS',[1,3],[('GCL-019','SQL dump通常用客户端逻辑导入'),('GSC-048','快照导出面向数据分析')],'A/C拟选，C须理解为取回dump走客户端导入而非任意S3直接恢复；B/D/E混快照、数据导出和DMS源。但卡未明确RDS MySQL原生快照迁Aurora MySQL的跨产品支持，不能将“相应快照恢复”扩到任意目标。',['RDS MySQL原生快照到Aurora MySQL的迁移恢复兼容范围'],[]),
(441,'SUPPORTED',[3],[('CUR:CA13','适用内容可从缓存返回'),('CUR:CA16','存储直接返回页面文件')],'C将静态对象移S3并边缘缓存，降低Web计算需求；A/B只换购买方式不减少静态工作，D函数不是静态文件必要计算。',[],[]),
(444,'SUPPORTED',[2],[('GSC-053','删除保护直接阻止处于保护状态的实例被删除'),('CUR:CB01','跨AZ自动接管'),('CUR:CB03','跨AZ Auto Scaling组维持容量')],'B同时覆盖误删、DB故障和计算AZ故障；A单台计算仍单点，D全Spot增加可回收风险。',[],[]),
(447,'SUPPORTED',[1],[('GSC-128','多个经过适用健康筛选的资源地址'),('GSC-126','配置所需健康评估')],'A各Region健康检查结合活跃入口路由实现区域失效剔除；B CloudFront多个origin本身不是按任意healthcheck自动全局API路由，C/D跨错协议/资源层。',[],[]),
(452,'SUPPORTED',[2],[('CUR:CA17','处理逻辑可放在短时函数中'),('GSC-089','固定时间用适用调度器'),('GSC-150','没有流量不等于计算资源已释放')],'B每小时10秒短函数按调用付计算，免常驻机器；C只停容器不停止EC2计算，D每小时整机停启管理更多，A需额外容器化。',[],[]),
(454,'SOURCE_ISSUE',[],[],'C原本对应自动工作负载图，但其官方当前页明确方案已不可用；该坏卡已隔离，不能用它证明学习者会选C。其余选项未给等价跨账户自动资源关系发现。',[],['AWS官方Workload Discovery solution-overview明确This AWS Solution is no longer available；当前题目的最佳功能候选是已停用方案，保留原题并记录来源时效问题。']),
(458,'INSUFFICIENT_CARDS',[2,3],[('CUR:CA17','用API Gateway接收请求，调用Lambda执行处理逻辑'),('CUR:CC22','在引擎和功能兼容的前提下迁移到相应RDS')],'B/C符合函数计算与托管关系数据库方向；D模型不关系，E/EC2更多管理。但2GB计算存储为明确硬需求，现卡未教Lambda可配置临时存储范围及持久性。',['Lambda满足2GB计算临时存储的可配置范围与非持久边界'],[]),
(459,'INSUFFICIENT_CARDS',[1],[('GSC-154','激活相应的cost allocation tag'),('GSC-153','组织合并账单须有相应账户权限与交付范围')],'A拟选department为用户定义标签并组织汇总费用；B/D AWS定义与公司自加部门名不符。但卡未明确必须由管理账户激活组织成本标签，不能把“有相应权限”当确切账户职责。',['Organizations管理账户激活用户定义成本分配标签的控制范围'],[]),
(462,'SUPPORTED',[2],[('GSC-079','持久工作队列保存任务'),('GSC-114','待处理工作与处理容量联系起来')],'B始终先排队并伸缩消费写库，缓冲峰值；D等CPU高才排队且按日程扩不响应突发，A/C把数据库当SNS消费者不成所需处理链。',[],[]),
(463,'SUPPORTED',[3],[('CUR:CA17','处理逻辑可放在短时函数中'),('GSC-029','由写入事件启动处理'),('GSC-133','先匹配运行环境和资源，再检查时长')],'C短小30秒处理用函数随对象事件运行；Glue/EMR为这种逐对象小任务引入较重作业/集群，未要求新训练或大规模ETL。',[],[]),
(467,'SUPPORTED',[2],[('CUR:XA022','由管理账户在Billing preferences启用相应账户的折扣共享'),('GSC-155','已购承诺没充分用上')],'B共享未用承诺给组织内符合条件用量；A成员不能替管理账户控制组织共享，C迁工作负载多操作，D把Savings Plan当RI转售。原文虽省略通用提问尾句，目标由未充分利用与选项明确。',[],[]),
(473,'SUPPORTED',[1],[('CUR:CA13','适用内容可从缓存返回')],'A静态边缘缓存减少重复回源计算及长距传输；B ElastiCache不作为ALB静态目标，WAF规则不缓存，D加Region不自动最低费。保留原文state files写法，按前文static content判断。',[],[])
])
# Bind the current official discontinuation quote as source evidence, never as visible teaching.
p=V/'review/reuse-a/sources/e7fd40cd955e552704e9.json';d=rd(p);s=d['text'];quote='This AWS Solution is no longer available.';start=s.index(quote)
e={'qid':454,'purpose':'Original-question current source applicability; not learner-visible card knowledge','url':d['url'],'sourcePath':str(p),'sourceFileSha256':sha(p),'sourceTextSha256':hashlib.sha256(s.encode()).hexdigest(),'startChar':start,'endChar':start+len(quote),'quote':quote,'rawHtmlPath':str(p.with_suffix('.html')),'rawHtmlSha256':sha(p.with_suffix('.html'))}
op=V/'evidence/questions-b';op.mkdir(parents=True,exist_ok=True);(op/'q454-discontinuation.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')

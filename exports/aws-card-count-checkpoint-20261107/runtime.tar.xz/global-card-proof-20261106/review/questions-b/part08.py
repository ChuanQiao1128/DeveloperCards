from review_helper import *
save(8,[
(526,'SUPPORTED',[4],[('CUR:CB18','在适用故障切换中重新连接后端'),('CUR:CB18','隔开客户端连接与数据库连接的生命周期')],'D代理减少writer切换时客户端连接冲击，少改业务连接；A加reader不管理已有客户端重连，C不替writer服务，B另建簇增运维。',[],[]),
(527,'SUPPORTED',[4],[('GSC-056','执行适用的跨Region切换流程，使目标可写'),('GSC-126','主资源被判不健康时回答备用资源'),('CUR:CB03','同Region跨AZ不能替代Region级灾备')],'D第二Region计算与global数据复制加提升切流；A声称伸同一ASG到另一Region不符区域故障域，B不是原生global存储路径，C多自管DMS复制。',[],[]),
(528,'INSUFFICIENT_CARDS',[4],[('CUR:CMP-M19','Transfer Family保留客户端协议'),('GSC-029','S3对象创建事件'),('GSC-133','标准Lambda调用通常受900秒上限')],'D按到达触发3–8分钟处理、成功后删；A/B仍隔夜，C EBS与S3事件路径不合。但既有Transfer卡只限定SFTP，不能据它断言FTP客户端零改动可接TransferFTP。',['Transfer Family支持FTP及相应入口限制，不以SFTP兼容冒充FTP事实'],[]),
(530,'SUPPORTED',[3],[('CUR:XB041','UDP使用适用的NLB'),('CUR:NS02','多Region应用需要统一固定入口并健康选路')],'C统一加速入口到各NLB保留TCP/UDP；CloudFront/API缓存面向HTTP，ALB不处理UDP，不能只提高缓存时长修游戏传输。',[],[]),
(531,'INSUFFICIENT_CARDS',[1],[('CUR:XB012','function URL直接把HTTP请求交给函数')],'A单函数HTTP入口运维最少，B多ALB，C/D没有普通webhook公有订阅hostname。现卡仅AWS_IAM认证场景，第三方回调能否签名未给，也未教NONE认证的适用配置，不能忽略接入授权。',['Lambda function URL面向普通第三方webhook的认证接入选项'],[]),
(534,'CONDITIONAL',[3],[('CUR:CMP-M01','能等待恢复，才考虑符合取回时限的Glacier Flexible Retrieval'),('GSC-024','最短保留时间及取回要求')],'C首30天常用后转归档并90天删，符合备份阶段可等恢复；A仍Standard较贵，B/D90天又转又删无实际收益，D还单AZ。不是只看每GiB单价证明任何日志都最低。',[],['实际日志大小、生命周期可转移性和归档最短计费/转换开销下，30天转归档仍须总费用更低；卡未给本题对象分布，不承诺无条件最低。']),
(536,'SUPPORTED',[4],[('CUR:CB01','Multi-AZ DB cluster具有可读副本'),('GSC-046','把适用的只读请求连接到副本端点')],'D一个托管三AZ集群同时接管及分担读取，不额外建经典standby再加两reader；B经典standby不可读，A加大主库仍让分析争资源。',[],[]),
(537,'SOURCE_ISSUE',[],[('GSC-032','此比较不排除Memcached Serverless的托管跨AZ能力'),('CUR:NB08','跨实例保留状态还需共享存储方案'),('CUR:CB01','Multi-AZ DB cluster具有可读副本')],'A是node-based复制组惯常选择；但B没限定node-based，Memcached Serverless具跨AZ能力，不能用旧“Memcached无HA”排掉它。两者都可能存共享会话并缓存读。',[],['A/B的决定性差别缺部署模式限定；当前卡已明确不能把node-based Redis/Memcached差异泛化到Serverless，因此现题不能据此唯一选A。']),
(539,'SUPPORTED',[3],[('GSC-064','持续灾备评估Elastic Disaster Recovery'),('GSC-068','pilot light保留关键数据及最小基础'),('GSC-067','RPO限制可丢失的数据时间范围')],'C持续磁盘复制加小基础减少常驻成本，匹配秒级复制/小时恢复目标方向；D夜备不符30秒RPO，A企业版双活成本高，B常驻DB且不覆盖原VM完整应用。实际演练未执行不单独算知识缺口。',[],[]),
(540,'INSUFFICIENT_CARDS',[3],[('CUR:CC22','在引擎和功能兼容的前提下迁移'),('CUR:CB01','经典Multi-AZ DB instance的standby不服务读取')],'C表面满足HA与读卸载，但卡组未教Multi-AZ DB cluster是否支持Oracle；不能把通用RDScluster卡扩到所有引擎。B同AZ无所需AZ冗余，D混Aurora与经典instance部署。',['RDS Oracle与Multi-AZ DB cluster支持范围；当前C需官方事实核验，不能仅凭通用卡判可行'],[]),
(541,'INSUFFICIENT_CARDS',[1,3,5],[('CUR:CA16','脚本在浏览器运行'),('CUR:CA17','托管服务按请求承载'),('CUR:CA11','用户池负责客户登录'),('CUR:CA19','认证通过不代表拥有任意资源权限')],'A/C/E是低空闲成本前后端与客户登录链；F静态S3不能运行PHP，D身份池不是客户登录。但用户池验证身份不等于验证已付费，不能把注册成功当订阅授权。',['付费订阅资格与Cognito登录/API授权之间的实际校验机制'],[]),
(543,'SOURCE_ISSUE',[],[('CUR:XA022','把相关账户纳入同一Organizations合并计费组织'),('CUR:XA022','由管理账户在Billing preferences启用相应账户的折扣共享')],'A开共享成立；D新payer建组织邀请全部账户与E在现有计划账户建组织都能达到同组织折扣共享，题目未限制管理账户必须是谁。',[],['Choose two存在A+D与A+E两种可行组合；成员账户购买的Savings Plan亦可在组织共享，不能默默增设必须让购买账户当管理账户的条件。']),
(544,'INSUFFICIENT_CARDS',[1],[('GSC-127','适合逐步发布')],'A API原生canary小比例后提升方向正确；现卡只教Route53 weighted routing，没有教API Gateway canary stage和晋级机制，不能把另一个服务的路由功能无条件搬过来。',['API Gateway REST API原生canary deployment的比例与提升机制'],[]),
(545,'SUPPORTED',[2],[('GSC-126','正常时回答主资源'),('CUR:CA16','存储直接返回页面文件')],'B主动/备用DNS按ALB健康切S3静态页；A延迟不是故障主备，D多值不表达只在故障时返回备用，C活跃/活跃又说仅故障才选自相矛盾。',[],[]),
(546,'SUPPORTED',[4],[('GSC-013','向备份软件提供虚拟磁带库和磁带设备接口')],'D保留原磁带软件VTL流程而去实体磁带；A文件NFS与磁带接口不同，EFS是文件系统不提供虚拟磁带库。',[],[]),
(547,'SUPPORTED',[1],[('CUR:NS01','Firehose缓冲后写目的地')],'A托管近实时摄取交付S3最少维护；题目未要求自定义窗口分析，不需为此加Flink，Glue/DMS不是通用传感器直接摄取入口。',[],[]),
(551,'CONDITIONAL',[1],[('CUR:CMP-M01','6小时与12小时的容忍时间可能导向不同选择'),('GSC-024','最小计费对象大小、每次转换请求和适用的元数据开销')],'A一年级长期保留且容忍6小时恢复，Flexible Retrieval方向；D Deep Archive取回更慢，B过早IA生命周期不应凭低频套用，C把Intelligent-Tiering说成转换到独立IA类。',[],['50KB小对象须采用支持该对象大小的生命周期转层配置，并把请求/元数据开销纳入长期总费用；卡面未给具体最小转层默认值，不冒称默认规则已会转。']),
(552,'SUPPORTED',[2],[('CUR:CB02','不把承诺绑在单一EC2实例族')],'B一年ComputeSP允许每几月改族/型号；D EC2实例族计划不具同等族间灵活性，普通RI属性约束更大。',[],[]),
(554,'SUPPORTED',[3],[('GSC-111','选型要增加当前缺的资源')],'C应用和数据库都高内存，均按内存瓶颈选规格；A只数据库内存优化，D HPC或B磁盘规格没对准已测内存压力。',[],[]),
(557,'INSUFFICIENT_CARDS',[2],[('GSC-097','Spark等分布式框架，例如在Amazon EMR运行'),('GSC-101','Spectrum读取S3中的外部数据')],'B EMR并行处理方向可证，C Kinesis不是S3批量入仓连接，D治理不做数据丰富；但EMR读取Redshift丰富数据的实际接口未教，A Athena/Glue也可承担分布式处理，不能只见parallel关键词选B。',['EMR与Redshift集成读取/联接的支持路径及本题对A的必要竞争区别'],[])
])

from review_helper import *
save(9,[
(558,'INSUFFICIENT_CARDS',[3],[('CUR:CB16','选择VPC peering'),('GSC-075','多方连接会产生大量点对点关系')],'C两VPC直连最简，A中心TGW用于多方扩展，D专线不是直接VPC间连接；但卡未教peering与TGW连接/流量计费，不能从“无中转设备”自动推收费为零或最低。',['同Region双VPC peering与TGW在500GB/月下的服务计费取舍'],[]),
(559,'INSUFFICIENT_CARDS',[2,5],[('GSC-154','激活相应的cost allocation tag')],'B资源由团队添加的productline是用户定义标签，可用作费用维度；E管理账户激活为拟选，但当前卡没给组织标签激活具体账户职责，与Q459同一缺口。',['Organizations成本分配标签由管理账户激活的范围'],[]),
(561,'SUPPORTED',[1],[('GSC-036','DAX在内存中缓存DynamoDB读取结果')],'A原生兼容缓存最少自建读写同步；B/C独立cache-aside需应用管理新鲜度，D自写流消费者较多维护。普通缓存读场景不额外假定强一致必须命中。',[],[]),
(563,'INSUFFICIENT_CARDS',[2],[],'B拟选EKS Connector中央注册查看；当前相关卡只有ECS Anywhere控制本地ECS，不能把ECS管理外部实例当成EKS查看任意Kubernetes集群。',['EKS Connector中央注册并查看外部Kubernetes集群的用途；与Container Insights观测和EKS Anywhere的区别'],[]),
(565,'CONDITIONAL',[3],[('CUR:CC22','在引擎和功能兼容的前提下迁移'),('GSC-057','增加reader主要分担读工作')],'C保留MySQL兼容方向并通过Aurora reader自动伸缩；A只自动长存储，D换数据模型。Aurora Auto Scaling不是任意写入或writer计算自动变大。',[],['增加需求主要是可分给reader的读取且应用按副本端点读取；若主要writer计算或写负载，选项C的伸缩不能自动满足。']),
(566,'SUPPORTED',[2],[('GSC-001','EFS通过NFS提供同一份共享文件'),('GSC-020','Multi-Attach只在同一AZ')],'B跨AZLinux共享层级文件；C同AZ块共享且需协调写，A对象API不保留现有文件访问，D各自卷同步增加复杂度。',[],[]),
(567,'SUPPORTED',[1],[('CUR:CA17','用API Gateway接收请求，调用Lambda执行处理逻辑'),('CUR:XB013','低延迟键值/文档访问')],'A托管HTTP/函数/键值记录可独立增加组件，少常驻OS；C自管SQLServer，B/D自管计算且对象/文件不是该按租户计数记录的最直接访问模型。',[],[]),
(568,'SUPPORTED',[1],[('CUR:NA05','区域对象存储把文件作为独立对象保存'),('CUR:CA13','适用内容可从缓存返回')],'A大规模对象加全球内容缓存；B归档需恢复且ElastiCache不直接当文档CDN，C块卷绑定实例/AZ，D机房网关不符合全部AWS组件的必要方向。',[],[]),
(569,'CONDITIONAL',[1],[('GCL-024','匹配、调用及失败等指标')],'A按阶段看规则匹配与调用，B只终态失败，D API审计非投递计数；若是新事件总线模型，命名空间须按实际模型选择而非照搬。',[],['使用AWS/Events命名空间的Classic EventBridge规则；不把该命名空间泛化到采用AWS/EventsV2的新模型。']),
(570,'SUPPORTED',[2],[('GSC-113','已知日历和容量用scheduled scaling')],'B周五重复高峰按日历调到六台，其余维持两台；D泛动态策略等实际负载，C需手工，A仅提醒不改容量。',[],[]),
(572,'INSUFFICIENT_CARDS',[3],[('GSC-057','Serverless v2按负载调整适用实例的计算容量'),('CUR:CC22','在引擎和功能兼容的前提下迁移到相应RDS')],'C MySQL兼容托管且自动计算容量，A模型不兼容，D固定2GiB不会自动扩算力；但1ACU满足2GiB内存这个硬数值关系未教，不能只凭serverless名字忽略。',['Aurora Serverless v2每ACU内存与本题最低2GiB需求的匹配'],[]),
(573,'SUPPORTED',[4],[('GSC-135','发布适用版本时保存初始化状态快照'),('GSC-134','provisioned concurrency预先初始化相应执行环境')],'D初始化快照减少新环境启动而不常驻预热，适合非严格延迟成本目标；A持续预热更强但费用不同，B延长超时不减少冷启动，C不能保证消除初始化。运行时支持按既有FACT范围适用，不逐题重查。',[],[]),
(574,'INSUFFICIENT_CARDS',[1],[('CUR:XB027','使用支持自动暂停的Aurora Serverless版本'),('GSC-052','临时停止适合短期空闲')],'A最接近稀疏运行数据库；B常驻Aurora、C预留自管EC2、D自管容器都保留维护。现自动暂停卡专门限定PostgreSQL，不能直接证明MySQL版本0ACU/暂停可省闲置算力。',['Aurora Serverless v2 MySQL自动暂停/最低容量支持与稀疏运行费用'],[]),
(575,'SUPPORTED',[3],[('CUR:CB01','Multi-AZ DB cluster具有可读副本')],'C同时PostgreSQL托管HA及扩读；B经典MultiAZ standby不服务读，D跨Region异步reader不是同一托管HA接管，A改键值模型。',[],[]),
(576,'SUPPORTED',[4],[('CUR:CA13','API Gateway REST API也有内置CloudFront路径的edge-optimized入口')],'D全球HTTP边缘接入降低远端连接影响；private/interface为私网接入，Regional仍区域入口不自带同一路径。',[],[]),
(578,'SUPPORTED',[1],[('GSC-036','DynamoDB Accelerator（DAX）')],'A原生DynamoDB内存缓存提供适用亚毫秒命中；D独立Redis需自建缓存逻辑，Redshift/RDS换模型不是原表兼容缓存。',[],[]),
(579,'SUPPORTED',[1],[('GSC-150','实际停止、终止或缩减相应计算容量'),('GSC-052','临时停止适合短期空闲'),('GSC-089','固定时间用适用调度器')],'A现成停启日历符合工作日时段，周末短于长期自动重启风险；C按最低CPU自写函数不如已知日历直接，D长期承诺不释放夜间计算，B改备份不减实例运行。无需为题中已明确的调度动作背完整部署。',[],[]),
(580,'INSUFFICIENT_CARDS',[4],[('GSC-014','必须在实例停止或主机丢失后保留的数据应放持久存储'),('GSC-015','gp3把容量和性能配置分开')],'D本地块存储迁EBS且gp3独立性能有用，A/C网络文件系统改架构；但B与D的默认价格/性能比较未由当前卡说明，不能仅凭gp3较新证明最低费。',['gp3相对gp2在所需容量/性能下的成本与基线性能差异'],[]),
(581,'SUPPORTED',[2],[('GSC-116','剩余AZ的可用容量合计仍达到所需服务容量'),('GSC-146','关键基线使用符合可靠性要求的稳定容量')],'B两AZ各两台稳定容量，失一AZ仍两台；A失一AZ只一台，C单AZ全Spot，D一AZSpot可回收不等于稳定双台。状态复制仍独立于本题所问实例数。',[],[]),
(582,'SUPPORTED',[3],[('CUR:XB032','网络延迟用latency routing'),('CUR:XB032','非AWS目标也可按适用记录关联用于延迟判断的Region')],'C为机房目标关联邻近us-west-1以参与与eu-central-1入口的延迟选择；A国家定位不保证网络最快，D一半分流不看延迟。',[],[])
])

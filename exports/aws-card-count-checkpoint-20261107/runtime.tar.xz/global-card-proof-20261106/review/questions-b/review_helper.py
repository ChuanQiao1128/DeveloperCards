import json,pathlib,hashlib,collections,datetime
P=pathlib.Path(__file__).resolve().parent;V=P.parents[1]
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()
MP=P/"input/cases01.v3.manifest.json";M=rd(MP)
for f,h in M.items():assert sha(f)==h
CASES=rd(P/"input/cases01.v3.json");Q={x["qid"]:x for x in CASES}
KP=V/"deliverables/visible-knowledge-current.json";K=rd(KP);KS=sha(KP);C={c["ruleId"]:c for c in K}
assert len(CASES)==len(Q)==220 and len(K)==len(C)==355 and 'GCL-020' not in C
for q in CASES:
 for c in q['visibleCards']:
  assert c['ruleId'] in C and c['bodySha256']==C[c['ruleId']]['bodySha256'] and ch(c['visibleBody'])==c['bodySha256']
def show(a,b):
 cards={}
 seen={c["ruleId"] for q in CASES[:a] for c in q["visibleCards"]}
 for q in CASES[a:b]:
  print('Q'+str(q['qid']),q['question']['stem'].replace('\n',' '))
  for o in q['question']['options']: print(str(o['ordinal'])+':',o['text'].replace('\n',' '))
  print('CARDS',','.join(q['cardRuleIds']),'WITHHELD',q.get('withheldRuleIds',[]))
  cards.update({c['ruleId']:c for c in q['visibleCards']})
 print('VISIBLE CARD BODIES')
 for rid,c in cards.items():
  if rid not in seen:print(rid,' | '.join(c['visibleBody'].values()))
def save(part,decisions):
 results=[]
 for d in decisions:
  qid,status,opts,anchors,why,gaps,conditions=d
  q=Q[qid]; used=list(dict.fromkeys(a[0] for a in anchors)); aa=[]
  for rid,quote in anchors:
   c=C[rid];assert quote and any(quote in v for v in c['visibleBody'].values()),(qid,rid,quote)
   aa.append({'cardId':rid,'quote':quote,'bodySha256':c['bodySha256'],'additionalToInitialGroup':rid not in q['cardRuleIds']})
  assert status in ['SUPPORTED','CONDITIONAL','INSUFFICIENT_CARDS','SOURCE_ISSUE','UNKNOWN']
  results.append({'qid':qid,'status':status,'selectedOptionOrdinals':opts,'usedRuleIds':used,'necessaryAnchors':aa,'reasoningAndClosestCompetitor':why,'missingJudgments':gaps,'conditions':conditions,'sourceIssues':conditions if status=='SOURCE_ISSUE' else [],'questionSha256':ch(q['question']),'caseSha256':ch(q),'initialCardRuleIds':q['cardRuleIds'],'withheldRuleIds':q.get('withheldRuleIds',[]),'actualVisibleGroup':[{k:c[k] for k in ['ruleId','bodySha256']} for c in q['visibleCards']]})
 assert len(results)==len({r['qid'] for r in results})
 out={'schemaVersion':1,'reviewer':'questions-b independent current visible card application','inputManifestPath':str(MP),'inputManifestSha256':sha(MP),'inputHashes':M,'visibleKnowledgePath':str(KP),'visibleKnowledgeSha256':KS,'part':part,'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':dict(collections.Counter(r['status'] for r in results)),'results':results,'directCliApiCalls':0,'nativeUsage':'unknown','limits':['Design support from actual visible cards only; no learner accuracy or memory measurement.','No prior printed answer, private blueprint or prior support verdict is used to supply missing knowledge.','One shard of220, not whole1018 proof or final card-count proof.']}
 for f,h in M.items():assert sha(f)==h
 assert sha(KP)==KS
 op=P/('results-part'+str(part).zfill(2)+'.json');op.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(str(op),out['counts'])

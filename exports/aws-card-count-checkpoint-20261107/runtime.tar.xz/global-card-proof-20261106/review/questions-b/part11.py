from review_helper import *
save(11,[
(605,'SUPPORTED',[4],[('GSC-010','cached以S3为主存，只在本地保留缓存'),('GSC-012','不是给应用提供iSCSI块卷')],'D保留块卷访问且仅热点在本地，减少本地完整存储；C stored仍全主数据在机房，A文件协议不等价iSCSI，B EBS不能直接当机房iSCSI网关。',[],[]),
(606,'SUPPORTED',[2],[('CUR:CMP-M01','立即读取选Standard-IA'),('CUR:CMP-M01','One Zone-IA只有单AZ')],'B首30天Standard后多AZ即时IA，兼顾低频与随时取回；A Glacier有恢复等待，C单AZ降低所需耐久隔离。D冗余层级切换不优于已知阶段直接规则。',[],[]),
(607,'SUPPORTED',[3],[('GSC-041','正文放S3，数据库或消息保留元数据和对象引用'),('CUR:NA05','多AZ S3存储类别')],'C把大BLOB字节移对象存储仍留数据库查询元数据，降低数据库存储压力；A/B只买更大DB资源，D换键值模型且大项受载荷边界，非必要。',[],[]),
(611,'SUPPORTED',[1],[('CUR:XB004','流保留记录供消费者读取'),('CUR:XB004','Lambda通过事件源映射取得一批记录')],'A流持久缓冲与函数消费者拆开摄取/处理，不让EC2当前计算峰值直接拒单；B配额限制只是拒绝请求，D容器重打包仍同步处理容量瓶颈，C不如持久流明确重读。',[],[]),
(614,'SUPPORTED',[4],[('CUR:CMP-M10','在接收端只放行实际上一跳和目标服务端口'),('CUR:CMP-M10','ALB连Web目标时引用ALB安全组')],'D经内部ALB组织应用层后端：ALB入口只收WebSG、AppSG只收ALBSG，沿实际上一跳限权；NACL不按SG动态身份筛Web伸缩组，PrivateLink不是本分层必要入口。',[],[]),
(615,'SUPPORTED',[4],[('GSC-143','Container Insights等工作负载指标和日志采集')],'D集成容器指标日志汇总；A仅装通用Agent未表达完整容器洞察，AppMesh非独立日志指标控制台，CloudTrail是API审计。',[],[]),
(617,'SUPPORTED',[2,5],[('GSC-001','EFS通过NFS提供同一份共享文件'),('CUR:NC07','DataSync管理可重复的传输任务及相应控制')],'B NFS共享到多AWS资源，E托管同步复制现有运行数据；A Lustre并行专用接口不是NFS保留，C对象协议不同，D手动拷贝更难重复追赶不中断服务变化。',[],[]),
(618,'CONDITIONAL',[3],[('CUR:CA15','两个AZ之间同步复制数据并可自动故障切换'),('CUR:CA15','本身不保证发生Region灾难时也只有5分钟数据丢失'),('CUR:CMP-M16','Backup Vault Lock的compliance模式')],'C本地MultiAZ应对维护/AZ故障，异地日备加compliance五年防删除；B/D governance可有权绕过，A单AZ不提供相同本地接管。',[],['5分钟RPO针对本地计划维护/服务故障；若也涵盖整个Region灾难，日备异地副本不满足，本题四项均有缺口。']),
(620,'INSUFFICIENT_CARDS',[3],[('GSC-014','必须在实例停止或主机丢失后保留的数据应放持久存储'),('GSC-051','选择或调整能满足实际IOPS需求的存储配置')],'C持久SSD方向，A临时盘/B缓存不属持久主存；但现卡只教gp3独立性能和按瓶颈调IOPS，没有说明Provisioned IOPS SSD相对Throughput Optimized HDD的一致低延迟适用差异。',['Provisioned IOPS SSD与Throughput Optimized HDD的延迟/访问模式取舍'],[]),
(621,'SUPPORTED',[1],[('CUR:NEW04','为后续符合规则的新对象配置CRR')],'A原生跨Region复制新照片；B CORS是跨源访问不复制，C Lifecycle不搬跨Region，D自写复制函数多维护。',[],[]),
(622,'INSUFFICIENT_CARDS',[1,4],[('CUR:CA16','存储直接返回页面文件'),('CUR:CA13','适用内容可从缓存返回'),('GSC-038','难预测的负载考虑on-demand'),('CUR:XB013','低延迟键值/文档访问')],'A/D拟选按需在线表和静态边缘交付；C预配伸缩对快速变动需预测/等待，E自管静态Web增加容量维护。但DynamoDB快速演进item schema与关系库schema的差别未教，不能把键值用途等同已满足schema要求。',['DynamoDB灵活项目schema对快速演进数据模型的适用机制'],[]),
(625,'CONDITIONAL',[3],[('CUR:XB032','国家内容用geolocation'),('CUR:XB032','DNS选择入口不等于内容访问授权'),('CUR:CB12','依据请求IP的地理定位结果匹配国家规则')],'C按来源国家选相应内容入口，D距离不等于分发权区域。若“不得违反版权”要求阻止绕过入口访问，单靠DNS无权实施，需实际入口地域访问控制。',[],['C满足按国家引导正确内容；若要求强制拒绝所有越权来源，则须入口WAF/CloudFront地域规则，DNS选择本身不是访问控制。']),
(626,'SUPPORTED',[2],[('CUR:NC07','持续托管传输、校验或限速需求可用DataSync任务')],'B托管在线同步与完整性校验；FileGateway是持续文件/对象接口，TransferAcceleration加速不是自带全迁移验证流程，Snowball非在线工具替代。',[],[]),
(627,'SUPPORTED',[1],[('GSC-129','建立public hosted zone和对应记录'),('GSC-129','把域名的权威委派指向Route 53提供的名称服务器')],'A迁权威区域与记录到托管DNS，少维护服务器；B单机单点，C仍搬服务器，D desired1仍需管理OS且存在启动替换等待。',[],[]),
(628,'SUPPORTED',[3],[('CUR:XA045','未完成分块上传数量等指标'),('CUR:XA045','按组织、账户、Region和桶汇总')],'C现成组织存储状态指标；Config非该汇总指标，SCP限制权限不产生报告，MRAP路由不统计未完成上传。',[],[]),
(629,'SUPPORTED',[4],[('GCL-011','建立并行的新环境，验证后按受支持机制切换入口'),('GCL-011','有状态数据还须保持适用同步')],'D受支持RDS托管蓝绿让新版本先测且保留同步后切换，少自建复制；A原地升级难隔离验证，B手工恢复有数据追赶，C自管DMS切换更多维护。',[],[]),
(630,'SUPPORTED',[3],[('GSC-133','标准Lambda调用通常受900秒上限'),('CUR:XB019','少维护宿主机可选Fargate'),('GSC-089','固定时间用适用调度器')],'C每天两小时按时Fargate任务，不付全天主机也不依赖可回收Spot；B时长不符，A长期常驻承诺，D还要管理EC2容量。',[],[]),
(631,'INSUFFICIENT_CARDS',[2],[('CUR:NC11','以节点和边表示实体及关系'),('GSC-042','变更流描述项目数据的变化')],'B图数据库加原生变更流最贴合，QLDB账本不是图遍历模型。但DynamoDB Streams用途不能替代Neptune Streams具体可用能力，不能只按Streams同名字作全链证明。',['Neptune Streams记录图数据更改并供应用消费的原生能力'],[]),
(632,'SUPPORTED',[3],[('GSC-001','把文件放在同一个EFS文件系统，让实例共同挂载'),('GSC-020','Multi-Attach只在同一AZ')],'C跨AZ Linux共享读写文件不绑定单卷单机，适合持续增长共享文件；B/D块卷不能按所述跨AZ共同挂载，A归档等恢复不适合小时修改分析。',[],[]),
(633,'SUPPORTED',[3],[('CUR:CB01','经典Multi-AZ DB instance的standby不服务读取'),('GSC-046','把适用的只读请求连接到副本端点')],'C复制后实际把读请求送副本以分担主库；A standby不能读，B对象传输加速非DB功能，D交付流不充当SQL查询并发代理。',[],[])
])

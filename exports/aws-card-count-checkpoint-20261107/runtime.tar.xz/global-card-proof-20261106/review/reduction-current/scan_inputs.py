# -*- coding: utf-8 -*-
import json,pathlib,hashlib,collections,datetime
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106');O=V/'review/reduction-current'
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def wr(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
prior=rd(V/'review/reduction-a/results.json');deletions=[x for x in prior['results'] if x.get('decision')=='remove'];targets={x['ruleId'] for x in deletions};cs=rd(V/'deliverables/visible-knowledge-current.json');current={x['ruleId']:x for x in cs}
cat=rd(V/'inputs/card-catalogue.frozen-design.json')+rd(V/'inputs/supplemental-catalogue.approved.json');aliases={}
for x in cat:
 rid=x['ruleId'];aliases[rid]=rid;aliases[(rid[4:] if rid.startswith('CUR:') else rid)]=rid
 if x.get('displayId'):aliases[x['displayId']]=rid
for rid in current:
 if rid.startswith(('GSC-','GCL-')):aliases[rid.replace('-','')]=rid
canon=lambda x:aliases.get(x,x)
files=set()
for name in ['questions-a','questions-b','questions-c','gap-a','gap-b','source-a']:
 files.update((V/'review'/name).glob('results*.json'))
files.update((V/'review/current-impact01').rglob('results*.json'));files.add(V/'review/reuse-a/question-reuse371.json');files.add(V/'review/reuse-a/supplemental01.review.json')
# Existing reuse receipts bind older real proof files; include their full actual use rows too.
for r in rd(V/'review/reuse-a/question-reuse371.json')['results']:
 for e in r.get('proofs',[]):
  p=pathlib.Path(e['path'])
  if '/input/' not in str(p) and p.suffix=='.json' and p.exists():files.add(p)
rows=[];proof_inputs=[]
actualfields=['usedRuleIds','usedCardIds','completeDependencyIds']
def walk(x,path='$'):
 if isinstance(x,dict):
  q=x.get('qid',x.get('questionId'))
  if isinstance(q,int):
   used=set()
   for k in actualfields:
    if isinstance(x.get(k),list):used.update(canon(i) for i in x[k] if isinstance(i,str))
   anchors=x.get('necessaryAnchors',x.get('supportingAnchors',[]))
   for a in anchors:
    if isinstance(a,dict):
     rid=a.get('ruleId',a.get('cardId'))
     if isinstance(rid,str):used.add(canon(rid))
   for rid in used&targets:rows.append({'ruleId':rid,'qid':q,'sourcePath':str(p),'sourceSha256':digest,'recordJsonPath':path,'status':x.get('status',x.get('reuseVerdict',x.get('priorVerdict'))),'actualUseFields':{k:x[k] for k in actualfields if k in x},'anchorsForTarget':[a for a in anchors if canon(a.get('ruleId',a.get('cardId','')))==rid],'record':x})
  for k,y in x.items():walk(y,path+'.'+k)
 elif isinstance(x,list):
  for i,y in enumerate(x):walk(y,path+'['+str(i)+']')
for p in sorted(files):
 digest=sha(p);d=rd(p);proof_inputs.append({'path':str(p),'sha256':digest});walk(d)
uses={rid:sorted({r['qid'] for r in rows if r['ruleId']==rid}) for rid in sorted(targets)}
qraw=rd(V.parent/'domain1-final-card-catalog-20261105/questions.all.json');qids=set()
for d in deletions:qids.update(d['allAssociatedQuestionIds']);qids.update(uses[d['ruleId']])
wr(O/'frozen-current-visible.json',cs);wr(O/'proof-inputs.json',proof_inputs);wr(O/'actual-use-occurrences.json',rows);wr(O/'full-original-questions.json',{str(q):qraw[str(q)] for q in sorted(qids)})
old={c['ruleId']:c for c in rd(V/'review/reduction-a/frozen355.json')};diff=[]
for d in deletions:
 rid=d['ruleId'];alternatives=d.get('alternativeCardIds',[]);ids=[rid]+alternatives
 diff.append({'ruleId':rid,'priorAssociatedQids':d['allAssociatedQuestionIds'],'actualUseQids':uses[rid],'newActualUseQids':sorted(set(uses[rid])-set(d['allAssociatedQuestionIds'])),'currentBodies':[{'ruleId':i,'oldHash':old[i]['bodySha256'],'currentHash':current[i]['bodySha256'],'bodyChanged':old[i]['visibleBody']!=current[i]['visibleBody'],'visibleBody':current[i]['visibleBody'],'prerequisites':current[i]['prerequisiteRuleIds']} for i in ids]})
wr(O/'current-impact-input.json',diff)
print(json.dumps({'proofFileCount':len(files),'actualUseQids':uses,'originalQuestions':sorted(qids),'changedTargetOrSubstituteBodies':[(r['ruleId'],[x['ruleId'] for x in r['currentBodies'] if x['bodyChanged']]) for r in diff]},ensure_ascii=False,indent=2))

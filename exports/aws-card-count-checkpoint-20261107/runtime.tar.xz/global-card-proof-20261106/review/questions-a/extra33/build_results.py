import json,pathlib,hashlib,collections,re
R=pathlib.Path(__file__).resolve().parent;A=R.parent;V=A.parent.parent
I=A/'input/cases02.v2.json';M=A/'input/cases02.v2.manifest.json';C=json.load(open(I));B={x['qid']:x for x in C}
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def filehash(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
manifest=json.load(open(M))
for p,h in manifest.items():assert filehash(p)==h,p
poolpath=V/'deliverables/cards.current.json';pool=json.load(open(poolpath));pb={x['ruleId']:x for x in pool};assert len(pb)==356
records=json.load(open(R/'decisions.json'));out=[]
for qid,status,selection,used,reason,missing,conditions,competitor in records:
 x=B[qid];cm={z['ruleId']:z for z in x['visibleCards']};ids=used.split(',');anchors=[]
 for c in cm.values():
  assert c['bodySha256']==digest(c['visibleBody'])==pb[c['ruleId']]['bodySha256']
 for cid in ids:
  c=cm[cid];assert c['bodySha256']==digest(c['visibleBody'])==pb[cid]['bodySha256']
  for field,quote in c['visibleBody'].items():
   if quote:anchors.append({'cardId':cid,'ruleId':cid,'bodySha256':c['bodySha256'],'field':field,'quote':quote,'role':'Explicit condition, conclusion, mechanism or boundary of the actual visible card; no learned premise is added beyond these sentences.'})
 assert set(selection)<={o['ordinal'] for o in x['question']['options']}
 if status=='SUPPORTED':
  expected=3 if re.search(r'Choose\s+three',x['question']['stem'],re.I) else 2 if re.search(r'Choose\s+two',x['question']['stem'],re.I) else 1
  assert len(selection)==expected and not missing
 else:assert selection==[] and missing
 per=[{'cardId':z,'canRemoveWithinThisQuestion':False if status=='SUPPORTED' else None,'remainingCardIds':[t for t in ids if t!=z],'reason':'This selected rule supplies an explicit condition, action, mechanism or material contrast not fully replaced by the remaining visible selected group.' if status=='SUPPORTED' else 'Whole-question sufficiency remains open; do not infer global deletability from this partial proof.'} for z in ids]
 removable={990:{'CUR:NC07':'GSC-001 already teaches the actual NFS shared storage after migration. The original asks the deployed storage, not a migration transfer task.'},996:{'GSC-139':'The original already commits to EKS; XB019 supplies the host-maintenance distinction that selects Fargate.'},1001:{'GSC-112':'GSC-114 already directly teaches backlog-based consumer scaling; GSC-079 supplies persistent handoff.'},1000:{}}
 removed=removable.get(qid,{}) if status=='SUPPORTED' else {}
 for p in per:
  if p['cardId'] in removed:p['canRemoveWithinThisQuestion']=True;p['reason']=removed[p['cardId']]
 out.append({'qid':qid,'status':status,'selectedOptionOrdinals':selection,'usedRuleIds':ids,'necessaryAnchors':[a for a in anchors if a['cardId'] not in removed],'supportingAnchors':[a for a in anchors if a['cardId'] in removed],'derivation':reason,'missingJudgments':missing,'conditions':conditions,'sourceIssues':[{'status':'UNCONFIRMED_TYPE_AMBIGUITY','detail':'HTTP API product versus generic HTTP REST API changes resource-policy eligibility; not resolved from the frozen original.'}] if qid==1019 else [],'nearestCompetitor':competitor,'deletionCheck':{'status':'LOCAL_REMOVAL_PROVEN' if removed else 'NO_USED_CARD_PROVEN_REMOVABLE' if status=='SUPPORTED' else 'UNRESOLVED_SUFFICIENCY','perUsedCard':per,'omittedAllocatedRuleIds':[z for z in x['cardRuleIds'] if z not in ids],'globalCardDeletionProven':False},'bindings':{'caseSha256':digest(x),'questionSha256':digest(x['question']),'originalStemUtf8Sha256':hashlib.sha256(x['question']['stem'].encode()).hexdigest(),'originalOptionsCanonicalSha256':digest(x['question']['options']),'visibleCardBodies':{c['ruleId']:c['bodySha256'] for c in x['visibleCards']},'additionalVisibleBodyBindings':{}}})
assert len(out)==len({x['qid'] for x in out})==33 and set(B)=={x['qid'] for x in out}
inputsha=filehash(I)
parts=[]
for idx,items in enumerate([out[:20],out[20:]],1):
 p=R/f'results-part{idx:02d}.json';p.write_text(json.dumps({'inputFileSha256':inputsha,'inputManifestSha256':filehash(M),'globalActualPoolFileSha256':filehash(poolpath),'results':items},ensure_ascii=False,indent=2)+'\n');parts.append(p)
counts=collections.Counter(x['status'] for x in out)
for s in ['SUPPORTED','CONDITIONAL','INSUFFICIENT_CARDS','SOURCE_ISSUE','UNKNOWN']:counts.setdefault(s,0)
summary={'schemaVersion':1,'scope':{'slice':'questions-a extra33 cases02.v2','expectedQuestionCount':33,'reviewedQuestionCount':33,'exactCoverage':True,'first220ArtifactsModified':False,'globalVerificationComplete':False},'inputManifestPath':str(M),'inputManifestSha256':filehash(M),'inputBindings':manifest,'globalActualPool':{'path':str(poolpath),'fileSha256':filehash(poolpath),'observedBodyCount':356,'factTeachingOrQuestionSufficiencyVerifiedByCount':False,'frozenV2BodiesMatchCurrent':True,'additionalVisibleBodiesUsed':0},'counts':dict(counts),'pending_ids':[x['qid'] for x in out if x['status']!='SUPPORTED'],'current_artifacts':[str(x) for x in parts]+[str(R/'results.json')],'partBindings':{str(p):filehash(p) for p in parts},'findings':[{'qid':x['qid'],'status':x['status'],'missingJudgments':x['missingJudgments']} for x in out if x['status']!='SUPPORTED'],'attempts':{'nativeIndependentReviewPasses':1,'externalModelCliApiCalls':0,'nativeTokenUsage':'unknown','historicalBudgetOrClockReset':False,'newOfficialLookups':0},'deletionCheck':{'questionLocalRemovalProofs':sum(x['deletionCheck']['status']=='LOCAL_REMOVAL_PROVEN' for x in out),'globalDeletionProven':False},'next_action':'Parent reconciles this v2 slice with first220 and other shards, preserving all missing premises and type conditions. Recheck only actual changed dependencies; 356 actual bodies alone do not verify the final number.','results':out}
(R/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
readback={'status':'PASS_DETERMINISTIC_INTEGRITY_ONLY','questionCount':33,'counts':dict(counts),'parts':[20,13],'exactCoverage':True,'manifestHashesMatch':True,'allCardBodyHashesRecomputed':True,'allAnchorQuotesExact':True,'choiceCardinalityMatches':True,'first220NotOverwritten':True,'globalFinalNVerified':False,'resultsSha256':filehash(R/'results.json')}
(R/'final-readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(readback,ensure_ascii=False,indent=2))

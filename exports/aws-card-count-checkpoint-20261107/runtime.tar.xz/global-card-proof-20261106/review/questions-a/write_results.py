import json,pathlib,hashlib,sys,datetime
ROOT=pathlib.Path(__file__).resolve().parent
V=ROOT.parent.parent
INP=ROOT/'input/cases01.json'
CASES=json.load(open(INP)); BY={x['qid']:x for x in CASES}
SUPPATH=V/'evidence/questions-a/global-alternatives.visible.json'
SUP=json.load(open(SUPPATH)); SUPCARDS={x['ruleId']:x for x in SUP['cards']}
REMOVABLE=json.load(open(ROOT/'local-removal-checks.json'))
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(part,records):
 out=[]
 for r in records:
  qid,status,selected,used,reason,missing,conditions,competitor=r
  x=BY[qid]; cmap={c['ruleId']:c for c in x['visibleCards']}; extra={z:SUPCARDS[z] for z in used.split(',') if z and z not in cmap}; cmap.update(extra); anchors=[]
  for rule in used.split(',') if used else []:
   c=cmap[rule]; b=c['visibleBody']
   for field in ['answerZH','keyPointZH']:
    quote=b[field]
    anchors.append({'cardId':rule,'ruleId':rule,'bodySha256':c['bodySha256'],'field':field,'quote':quote,'role':'以下推导所用的选择或因果前提；仅按引句明示范围使用'})
  item={'qid':qid,'status':status,'selectedOptionOrdinals':selected,'usedRuleIds':used.split(',') if used else [],'necessaryAnchors':anchors,'derivation':reason,'missingJudgments':missing,'conditions':conditions,'sourceIssues':[],'nearestCompetitor':competitor,'deletionCheck':{'status':'NO_USED_CARD_PROVEN_REMOVABLE' if used else 'NO_CARD_USED','reason':'所用卡分别承担下述推导的必要前提；未将主题关联当作可删除证明。未用的分配卡不计为本题必要学习项。','omittedAllocatedRuleIds':[z for z in x['cardRuleIds'] if z not in used.split(',')]},'bindings':{'caseSha256':digest(x),'questionSha256':digest(x['question']),'visibleCardBodies':{c['ruleId']:c['bodySha256'] for c in x['visibleCards']}}}
  if status!='SUPPORTED': item['deletionCheck']['reason']='当前推理未闭合；不据此删除任何承载独立前提的卡。未用分配卡不是已证明可从全库删除。'
  removal=REMOVABLE.get(str(qid),{}) if status=='SUPPORTED' else {}
  item['supportingAnchors']=[a for a in item['necessaryAnchors'] if a['ruleId'] in removal]
  item['necessaryAnchors']=[a for a in item['necessaryAnchors'] if a['ruleId'] not in removal]
  item['bindings']['additionalVisibleBodyBindings']={z:c['bodySha256'] for z,c in extra.items()}
  if extra:
   item['bindings']['globalAlternativeSource']={'path':str(SUPPATH),'snapshotSha256':hashlib.sha256(SUPPATH.read_bytes()).hexdigest(),'sourceFileSha256':SUP['sourceFileSha256']}
  item['deletionCheck']['perUsedCard']=[{'cardId':z,'canRemoveWithinThisQuestion':(z in removal) if status=='SUPPORTED' else None,'remainingCardIds':[t for t in used.split(',') if t and t!=z],'reason':removal.get(z,'No remaining visible card combination was identified that replaces this explicit decisive premise.') if status=='SUPPORTED' else 'Whole-question sufficiency remains open; local partial matching does not establish removable teaching.'} for z in used.split(',') if z]
  if removal:
   item['deletionCheck']['status']='LOCAL_REMOVAL_PROVEN'
   item['deletionCheck']['reason']='Only this current question proof can omit the listed cards. This is not a global card deletion or merge proof.'
  out.append(item)
 payload={'schemaVersion':1,'scope':'questions-a frozen 220 cases; this part only','inputFileSha256':hashlib.sha256(INP.read_bytes()).hexdigest(),'reviewMethod':'Independent native semantic review of complete original and actual visible card text. No blueprint, private solution, printed key or external model channel used. RuleId is actual identifier exposed in frozen pool; cardId aliases it without inventing a new identity.','results':out}
 (ROOT/f'results-part{part:02d}.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':
 part=int(sys.argv[1]); records=json.load(open(sys.argv[2]));write(part,records)

import pathlib,sys,json,hashlib,collections,re
r=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(r));import write_results as w
for p in sorted(r.glob('decisions*.json')):w.write(int(p.stem[-2:]),json.load(open(p)))
parts=sorted(r.glob('results-part*.json'));rows=[x for p in parts for x in json.load(open(p))['results']];cases=w.BY
manifestpath=r/'input/cases01.manifest.json';manifest=json.load(open(manifestpath));checks=[]
for p,sha in manifest.items():assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==sha,p
checks.append('Every frozen manifest file hash matches, including original case bundle, rules and teaching standard.')
assert len(rows)==len(set(x['qid'] for x in rows))==220
assert set(x['qid'] for x in rows)==set(cases)
checks.append('Exact 220/220 qid coverage, no duplicate, omission or out-of-shard question.')
assert all(len(json.load(open(p))['results'])==22 for p in parts)
for row in rows:
 x=cases[row['qid']];cmap={c['ruleId']:c for c in x['visibleCards']};cmap.update({z:w.SUPCARDS[z] for z in row['bindings']['additionalVisibleBodyBindings']})
 assert row['bindings']['questionSha256']==w.digest(x['question'])
 assert row['bindings']['caseSha256']==w.digest(x)
 assert row['bindings']['visibleCardBodies']=={c['ruleId']:c['bodySha256'] for c in x['visibleCards']}
 for c in cmap.values():assert w.digest(c['visibleBody'])==c['bodySha256'],c['ruleId']
 for a in row['necessaryAnchors']+row['supportingAnchors']:
  assert a['quote'] and a['quote'] in cmap[a['cardId']]['visibleBody'][a['field']]
  assert a['bodySha256']==cmap[a['cardId']]['bodySha256']
 assert set(a['cardId'] for a in row['necessaryAnchors']+row['supportingAnchors'])==set(row['usedRuleIds'])
 assert set(row['selectedOptionOrdinals'])<=set(o['ordinal'] for o in x['question']['options'])
 if row['status']=='SUPPORTED':
  assert row['selectedOptionOrdinals'] and not row['missingJudgments']
  expected=3 if re.search(r'Choose\s+three',x['question']['stem'],re.I) else 2 if re.search(r'Choose\s+two',x['question']['stem'],re.I) else 1
  assert len(row['selectedOptionOrdinals'])==expected,(row['qid'],expected)
 else:assert row['selectedOptionOrdinals']==[] and row['missingJudgments']
 row['bindings']['originalStemUtf8Sha256']=hashlib.sha256(x['question']['stem'].encode()).hexdigest()
 row['bindings']['originalOptionsCanonicalSha256']=w.digest(x['question']['options'])
checks+=['Every case/question/card-body hash recomputed with canonical JSON; exact original stem and all-options hashes retained.','Every quoted anchor is an exact nonempty substring of its actual visible body; every used rule has a bound anchor.','All supported selected ordinals exist and match Choose-two/three cardinality including line-broken stems; all non-supported selections are empty with explicit remaining judgments.']
counts=collections.Counter(x['status'] for x in rows)
for status in ['SUPPORTED','CONDITIONAL','INSUFFICIENT_CARDS','SOURCE_ISSUE','UNKNOWN']:
 counts.setdefault(status,0)
summary={'schemaVersion':1,'scope':{'slice':'questions-a','expectedQuestionCount':220,'reviewedQuestionCount':220,'exactCoverage':True,'fullProjectQuestionCount':1018,'fullProjectVerificationComplete':False},'inputManifestPath':str(manifestpath),'inputManifestSha256':hashlib.sha256(manifestpath.read_bytes()).hexdigest(),'inputBindings':manifest,'partBindings':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in parts},'current_artifacts':[str(p) for p in parts]+[str(r/'results.json')],'counts':dict(counts),'pending_ids':[x['qid'] for x in rows if x['status']!='SUPPORTED'],'findings':[{'qid':x['qid'],'status':x['status'],'missingJudgments':x['missingJudgments']} for x in rows if x['status']!='SUPPORTED'],'attempts':{'independentReviewPasses':1,'externalModelCliApiCalls':0,'nativeTokenUsage':'unknown','historicalBudgetAndClockReset':False,'deterministicIntegrityAttempts':[{'status':'FAIL','reason':'Initial Choose two cardinality detector did not accept a line break in Q45. No semantic content was changed for that failure.'},{'status':'PASS','repair':'Whitespace-aware Choose two/three parser; full integrity readback rerun.'}]},'globalActualBodyAlternative':{'snapshotPath':str(w.SUPPATH),'snapshotSha256':hashlib.sha256(w.SUPPATH.read_bytes()).hexdigest(),'globalPoolFileSha256':w.SUP['sourceFileSha256'],'questionIds':[48,116,265]},'deletionCheck':{'questionLocalRemovalProofCount':sum(x['deletionCheck']['status']=='LOCAL_REMOVAL_PROVEN' for x in rows),'removableLocalReferenceCount':sum(y['canRemoveWithinThisQuestion'] is True for x in rows for y in x['deletionCheck']['perUsedCard']),'globalCardDeletionProven':False},'sourceIssuePolicy':{'confirmedSourceIssues':0,'newOfficialLookups':0,'note':'No source defect was confirmed only because deployment parameters were omitted or current cards lack needed knowledge. Suspected capacity/identity/topology issues remain explicit unresolved judgments; they do not shrink the denominator.'},'next_action':'Parent reconciles these exact-version proofs and all other shards, obtains missing actual teaching or resolves accepted source/scope exceptions, then rechecks only affected dependencies. Do not declare final N from 356 design entries, 266 observed bodies, or this 220-question slice.','results':rows}
(r/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
report={'status':'PASS_DETERMINISTIC_INTEGRITY_ONLY','checks':checks,'counts':dict(counts),'questionCount':220,'partCount':10,'sourceManifestSha256':summary['inputManifestSha256'],'resultsSha256':hashlib.sha256((r/'results.json').read_bytes()).hexdigest(),'semanticWholeQuestionClosure':False,'pendingCount':len(summary['pending_ids']),'globalFinalNVerified':False}
(r/'final-readback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))

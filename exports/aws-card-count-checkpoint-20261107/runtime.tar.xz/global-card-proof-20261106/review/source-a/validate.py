import json,pathlib,hashlib,urllib.parse,collections,datetime
V=pathlib.Path(__file__).resolve().parents[2]
p=V/'review/source-a/results.json';d=json.load(open(p));src=json.load(open(V/'inputs/source-held100.json'));expected={x['originalQuestion']['qid']:x['originalQuestion'] for x in src};errors=[];checks=0
for k,h in json.load(open(V/'review/source-a/input/manifest.json')).items():
 checks+=1
 if hashlib.sha256(pathlib.Path(k).read_bytes()).hexdigest()!=h:errors.append('frozen input changed '+k)
ids=[x['qid'] for x in d['records']]
checks+=3
if len(ids)!=100 or len(set(ids))!=100:errors.append('not100unique')
if set(ids)!=set(expected):errors.append('qid set mismatch')
if d['inputSha256']!=hashlib.sha256((V/'inputs/source-held100.json').read_bytes()).hexdigest():errors.append('inputsha')
verdicts={'RESOLVED_FROM_ORIGINAL','CONFIRMED_SOURCE_ISSUE','UNKNOWN_OFFICIAL_EVIDENCE'}
for r in d['records']:
 q=expected[r['qid']];checks+=3
 if r['sourceVerdict'] not in verdicts:errors.append((r['qid'],'verdict'))
 if r['originalQuestionSha256']!=hashlib.sha256(json.dumps(q,ensure_ascii=False,sort_keys=True).encode()).hexdigest():errors.append((r['qid'],'originalhash'))
 if not r['originalAnchors'] or not r['decisiveSourceQuestion'] or not r['correctionProposalReviewOnly']:errors.append((r['qid'],'requiredfields'))
 fields={'stem':q['stem'],**{f"option:{o['ordinal']}:{o['originalLabel']}":o['text'] for o in q['options']}}
 for a in r['originalAnchors']:
  checks+=1
  if fields[a['field']][a['start']:a['end']]!=a['quote']:errors.append((r['qid'],'anchor'))
 for e in r['officialEvidence']:
  checks+=4;p0=pathlib.Path(e['sourcePath']);z=json.load(open(p0));t=z.get('text',z.get('content',''))
  if hashlib.sha256(p0.read_bytes()).hexdigest()!=e['fileSha256']:errors.append((r['qid'],'evidencefilehash'))
  if hashlib.sha256(t.encode()).hexdigest()!=e['textSha256']:errors.append((r['qid'],'evidencetexthash'))
  if t[e['quoteStart']:e['quoteEnd']]!=e['quote']:errors.append((r['qid'],'evidencequote'))
  if urllib.parse.urlparse(e['url']).hostname not in ['docs.aws.amazon.com','aws.amazon.com']:errors.append((r['qid'],'nonawsurl'))
 if r['cardGroupSufficiency']!='NOT_ASSESSED' or r['originalSourceModified']:errors.append((r['qid'],'scope'))
checks+=1
if dict(collections.Counter(x['sourceVerdict'] for x in d['records']))!=d['counts']:errors.append('counts')
res={'status':'PASS' if not errors else 'FAIL','checks':checks,'uniqueQuestions':len(ids),'counts':d['counts'],'resultsSha256':hashlib.sha256((V/'review/source-a/results.json').read_bytes()).hexdigest(),'errors':errors,'scopeLimit':'Mechanical exactness only; does not independently re-perform the semantic review or mark card sufficiency.'}
(V/'review/source-a/validation.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps(res,ensure_ascii=False,indent=2))
print('RESOLVED',[x['qid'] for x in d['records'] if x['sourceVerdict']=='RESOLVED_FROM_ORIGINAL'])
print('UNKNOWN',[x['qid'] for x in d['records'] if x['sourceVerdict']=='UNKNOWN_OFFICIAL_EVIDENCE'])
assert not errors

import json,hashlib,pathlib,urllib.request,concurrent.futures,datetime
import re,html,ssl
V=pathlib.Path(__file__).resolve().parents[2];D=V/'evidence/source-a/downloads';D.mkdir(exist_ok=True)
urls={
'EFS_LIMIT':'https://docs.aws.amazon.com/efs/latest/ug/limits.html',
'CONFIG_ACM':'https://docs.aws.amazon.com/config/latest/developerguide/acm-certificate-expiration-check.html',
'RABBIT':'https://docs.aws.amazon.com/amazon-mq/latest/developer-guide/rabbitmq-basic-elements-broker.html',
'FIFO':'https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/FIFO-queues-exactly-once-processing.html',
'ASG_EVENTS':'https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-event-reference.html',
'KDA_END':'https://docs.aws.amazon.com/kinesisanalytics/latest/dev/what-is.html',
'RDS_STORAGE':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_Storage.html',
'FARGATE_SIZES':'https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task-cpu-memory-error.html',
'SNS_FIFO':'https://docs.aws.amazon.com/sns/latest/dg/fifo-message-grouping.html',
'EKS_KMS':'https://docs.aws.amazon.com/autoscaling/ec2/userguide/key-policy-requirements-EBS-encryption.html',
'AS2_IDP':'https://docs.aws.amazon.com/transfer/latest/userguide/create-as2-server.html',
'SHUTDOWN':'https://docs.aws.amazon.com/general/latest/gr/full_shutdown_services.html',
'TLS_HTTP':'https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-ciphers.html',
'ONTOOT':'https://docs.aws.amazon.com/fsx/latest/ONTAPGuide/volume-storage-capacity.html',
'KMS_DELETE':'https://docs.aws.amazon.com/kms/latest/developerguide/deleting-keys.html',
'XKS':'https://docs.aws.amazon.com/kms/latest/developerguide/keystore-external.html',
'TRANSFER_AD':'https://docs.aws.amazon.com/transfer/latest/userguide/directory-services-users.html',
'SCHEDULED_RI':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-scheduled-instances.html',
'MACIE_LIMIT':'https://docs.aws.amazon.com/macie/latest/user/quotas.html',
'DAX_CLIENT':'https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DAX.client.run-application.html',
}
def fetch(z):
 k,u=z
 try:
  raw=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=25,context=ssl.create_default_context(cafile="/etc/ssl/cert.pem")).read();markup=raw.decode('utf-8');markup=re.sub(r'<(script|style)[^>]*>.*?</\1>', '', markup, flags=re.S|re.I);markup=re.sub(r'<[^>]+>', '\n', markup);t=html.unescape(markup);t=re.sub(r'\n[ \t]*\n+', '\n', t).strip();r={'url':u,'text':t,'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rawSha256':hashlib.sha256(raw).hexdigest()};p=D/(k+'.json');p.write_text(json.dumps(r,ensure_ascii=False,indent=2));return k,str(p),len(t)
 except Exception as e:return k,'ERROR',str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: print(json.dumps(list(pool.map(fetch,urls.items())),indent=2))

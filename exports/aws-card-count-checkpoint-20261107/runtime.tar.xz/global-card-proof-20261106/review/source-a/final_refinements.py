import sys
from evidence_tools import add
for k,p in [('HTTP_FEATURES','Authorization options'),('ASG_MULTI','Availability Zones'),('S0030','CachingOptimized')]:
 try:add(k,p,span=1500)
 except ValueError:pass
from write_results import *
record(138,C,['redundant pair (active/standby) of RabbitMQ instances on Amazon MQ'], '已定位RabbitMQ专属官方页：跨AZ cluster是三个RabbitMQ节点；A/B把它写成active/standby两节点对，不能套用ActiveMQ部署。','将B队列改为Amazon MQ for RabbitMQ多AZ三节点cluster，其余应用ASG/RDS Multi-AZ保持准确。',['RABBIT_ARCH'])
record(145,C,['Configure the launch template to use a Spot Fleet'], '官方关系是Fleet中实例由launch template配置；D把模板/Fleet依赖方向写反，又与ASG叠用，原部署步骤不准确。','改为ASG使用launch template与受支持的Spot/mixed instances配置，不让模板嵌套使用Spot Fleet。',['SPOT_FLEET','S0308'])
record(388,C,['All configurations for the network ACLs, security groups, and route tables are still in their default states','cannot connect to the database'], '官方default SG允许来自同组资源的所有入站；若EC2和RDS均用同一默认组，题述无法连接与该默认网络假设冲突。若用不同SG，题面又缺明确关联信息，无法唯一诊断。','明确EC2/RDS使用不同安全组且数据库组无允许应用MySQL的规则，再选择D。',['DEFAULT_SG'])
record(457,C,['must\nuse Applicability Statement 2 (AS2) protocol','Create an AWS Lambda function for IdP authentication'], '已定位AS2建服官方页，明确AS2不能选择identity provider。C若指Transfer AS2内置用户自定义IdP则不受支持；若指独立应用登录则原题未给该分层链路。','明确IdP只鉴权应用登录、AS2以其受支持伙伴/证书机制传输，或重写为支持自定义用户IdP的文件协议。',['AS2_WORKFLOW'])
# Add newly located narrow facts; retain the originally uncertain scope rather than claim more.
by={r['qid']:r for r in DATA['records']}
ed=json.load(open(V/'evidence/source-a/evidence.json'))
by[46]['officialEvidence'].append(ed['MACIE_GENERAL'])
by[46]['decisiveSourceQuestion']+=' 官方还列non-binary text单文件20GB、Avro/Parquet8GB等格式上限，原>200GB文件不能无条件全量扫描。'
by[46]['remainingOfficialEvidenceOrClarification']=['仍须给出真实文件格式和是否拆分；官方格式上限不能替代本题缺失格式。']
for q in [540,581,1019]:
 k={540:'RDS_MULTI_SUPPORT',581:'ASG_MULTI',1019:'HTTP_FEATURES'}[q]
 by[q]['officialEvidence']=[x for x in by[q]['officialEvidence'] if x['evidenceId']!=k]+[ed[k]]
# Bind all source proof records to the latest checked excerpt, without touching source snapshots.
for r in DATA['records']:
 r['officialEvidence']=[ed[x['evidenceId']] for x in r['officialEvidence']]
 if r['qid']==1004:r['officialEvidence'].append(ed['S0030'])
save()

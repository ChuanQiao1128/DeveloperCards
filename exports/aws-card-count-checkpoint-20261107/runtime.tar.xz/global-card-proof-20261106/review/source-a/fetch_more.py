import json,hashlib,pathlib,urllib.request,concurrent.futures,datetime
import re,html,ssl
V=pathlib.Path(__file__).resolve().parents[2];D=V/'evidence/source-a/downloads';D.mkdir(exist_ok=True)
urls={
'RABBIT_ARCH':'https://docs.aws.amazon.com/amazon-mq/latest/developer-guide/rabbitmq-broker-architecture.html',
'AS2_SERVER':'https://docs.aws.amazon.com/transfer/latest/userguide/create-server-as2.html',
'MACIE_QUOTA':'https://docs.aws.amazon.com/macie/latest/user/discovery-quotas.html',
'SNOW_UPDATE':'https://aws.amazon.com/blogs/storage/aws-snow-device-updates/',
'APPSYNC':'https://docs.aws.amazon.com/appsync/latest/devguide/pipeline-resolvers.html',
'RDS_MULTI_SUPPORT':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Concepts.RDS_Fea_Regions_DB-eng.Feature.MultiAZDBClusters.html',
'ORG_CREATE':'https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_org_create.html',
'EKS_PRIVATE':'https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html',
'REDIS_HA':'https://docs.aws.amazon.com/AmazonElastiCache/latest/dg/AutoFailover.html',
'GUARDDUTY_RDS':'https://docs.aws.amazon.com/guardduty/latest/ug/rds-protection.html',
'LOCAL_ZONES':'https://docs.aws.amazon.com/local-zones/latest/ug/what-is-aws-local-zones.html',
'DX_RESTRICTIONS':'https://docs.aws.amazon.com/directconnect/latest/UserGuide/direct-connect-gateways-intro.html',
'S3_SSEC_BATCH':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/batch-ops-copy-object.html',
'S3_SSEC_DEFAULT':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/ServerSideEncryptionCustomerKeys.html',
'S3_ARCHIVE_RESTORE':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/restoring-objects-retrieval-options.html',
'S3_SSE_POLICY':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/UsingServerSideEncryption.html',
'KMS_EVENTS':'https://docs.aws.amazon.com/kms/latest/developerguide/logging-using-cloudtrail.html',
'HTTP_FEATURES':'https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-vs-rest.html',
}

def fetch(z):
 k,u=z
 try:
  raw=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=25,context=ssl.create_default_context(cafile="/etc/ssl/cert.pem")).read();markup=raw.decode('utf-8');markup=re.sub(r'<(script|style)[^>]*>.*?</\1>', '', markup, flags=re.S|re.I);markup=re.sub(r'<[^>]+>', '\n', markup);t=html.unescape(markup);t=re.sub(r'\n[ \t]*\n+', '\n', t).strip();r={'url':u,'text':t,'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rawSha256':hashlib.sha256(raw).hexdigest()};p=D/(k+'.json');p.write_text(json.dumps(r,ensure_ascii=False,indent=2));return k,str(p),len(t)
 except Exception as e:return k,'ERROR',str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: print(json.dumps(list(pool.map(fetch,urls.items())),indent=2))

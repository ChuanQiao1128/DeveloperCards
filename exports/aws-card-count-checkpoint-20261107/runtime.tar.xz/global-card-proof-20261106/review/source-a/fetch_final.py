import json,hashlib,pathlib,urllib.request,concurrent.futures,datetime
import re,html,ssl
V=pathlib.Path(__file__).resolve().parents[2];D=V/'evidence/source-a/downloads';D.mkdir(exist_ok=True)
urls={
'SPOT_FLEET':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/spot-fleet.html',
'SCHEDULED_API':'https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_PurchaseScheduledInstances.html',
'AS2_WORKFLOW':'https://docs.aws.amazon.com/transfer/latest/userguide/create-as2-transfer-server.html',
'TRANSFER_IDP':'https://docs.aws.amazon.com/transfer/latest/userguide/create-server.html',
'MACIE_GENERAL':'https://docs.aws.amazon.com/general/latest/gr/macie.html',
'DEFAULT_SG':'https://docs.aws.amazon.com/vpc/latest/userguide/default-security-group.html',
'ONTAP_ROOT':'https://docs.aws.amazon.com/fsx/latest/ONTAPGuide/creating-volumes.html',
'BUDGET_UPDATE':'https://docs.aws.amazon.com/cost-management/latest/userguide/budgets-best-practices.html',
'S3_LIFECYCLE':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/object-lifecycle-mgmt.html',
'ASG_MULTI':'https://docs.aws.amazon.com/autoscaling/ec2/userguide/auto-scaling-benefits.html',
'WAF_ALB':'https://docs.aws.amazon.com/waf/latest/developerguide/how-aws-waf-works-resources.html'
}

def fetch(z):
 k,u=z
 try:
  raw=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=25,context=ssl.create_default_context(cafile="/etc/ssl/cert.pem")).read();markup=raw.decode('utf-8');markup=re.sub(r'<(script|style)[^>]*>.*?</\1>', '', markup, flags=re.S|re.I);markup=re.sub(r'<[^>]+>', '\n', markup);t=html.unescape(markup);t=re.sub(r'\n[ \t]*\n+', '\n', t).strip();r={'url':u,'text':t,'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rawSha256':hashlib.sha256(raw).hexdigest()};p=D/(k+'.json');p.write_text(json.dumps(r,ensure_ascii=False,indent=2));return k,str(p),len(t)
 except Exception as e:return k,'ERROR',str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: print(json.dumps(list(pool.map(fetch,urls.items())),indent=2))

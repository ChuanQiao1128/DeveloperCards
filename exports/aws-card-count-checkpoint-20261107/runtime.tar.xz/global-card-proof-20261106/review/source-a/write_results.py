import json,pathlib,hashlib,datetime,collections
V=pathlib.Path(__file__).resolve().parents[2]
INPUT=V/'inputs/source-held100.json';xs=json.load(open(INPUT));BY={x['originalQuestion']['qid']:x for x in xs}
P=V/'review/source-a/results.json'
DATA=json.load(open(P)) if P.exists() else {'schemaVersion':1,'reviewScope':'100 original source-held questions; source integrity/ambiguity only, not card sufficiency','inputPath':str(INPUT),'inputSha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),'modelCliApiCalls':0,'records':[]}
def record(qid,verdict,anchors,issue,recommendation,eids=(),resolved=(),unknown=()):
 q=BY[qid]['originalQuestion'];ed=json.load(open(V/'evidence/source-a/evidence.json'));aa=[]
 for anchor in anchors:
  found=[]
  for field,body in [('stem',q['stem'])]+[(f"option:{o['ordinal']}:{o['originalLabel']}",o['text']) for o in q['options']]:
   if anchor in body:found.append({'field':field,'quote':anchor,'start':body.index(anchor),'end':body.index(anchor)+len(anchor)})
  assert found,(qid,anchor);aa.extend(found)
 r={'qid':qid,'sourceVerdict':verdict,'originalQuestionSha256':hashlib.sha256(json.dumps(q,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),'originalAnchors':aa,'decisiveSourceQuestion':issue,'officialEvidence':[ed[k] for k in eids],'resolvedPriorConcerns':list(resolved),'remainingOfficialEvidenceOrClarification':list(unknown),'correctionProposalReviewOnly':recommendation,'cardGroupSufficiency':'NOT_ASSESSED','originalSourceModified':False}
 DATA['records']=[x for x in DATA['records'] if x['qid']!=qid]+[r]
def save():
 DATA['records'].sort(key=lambda x:x['qid']);DATA['completedCount']=len(DATA['records']);DATA['expectedCount']=100;DATA['complete']=DATA['completedCount']==100;DATA['counts']=dict(collections.Counter(x['sourceVerdict'] for x in DATA['records']));DATA['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();P.write_text(json.dumps(DATA,ensure_ascii=False,indent=2)+'\n');print(DATA['completedCount'],DATA['counts'])
R='RESOLVED_FROM_ORIGINAL';C='CONFIRMED_SOURCE_ISSUE';U='UNKNOWN_OFFICIAL_EVIDENCE'

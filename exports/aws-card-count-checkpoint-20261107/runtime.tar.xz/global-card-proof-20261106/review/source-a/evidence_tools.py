import json,pathlib,hashlib,re,urllib.request,html
BASE=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028')
V=BASE/'runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106'
CAT=json.load(open(V.parent/'domain1-final-card-catalog-20261105/official-sources.catalog.json'))
SOURCES={x['sourceKey']:x for x in CAT}
def source(key):
 s=SOURCES.get(key)
 if s is None:
  p=V/'evidence/source-a/downloads'/(key+'.json');d=json.load(open(p));s={'url':d['url'],'sourcePath':str(p)}
 else:d=json.load(open(s['sourcePath']))
 return s,d.get('text',d.get('content',''))
def show(key,pattern,span=400):
 s,t=source(key);print('\n',key,s['url'])
 hits=list(re.finditer(pattern,t,re.I))
 for m in hits[:5]:print(repr(t[max(0,m.start()-120):m.end()+span]))
 if not hits: print('NO MATCH',t[:400])
def add(key,pattern,eid=None,span=350):
 s,t=source(key);m=re.search(pattern,t,re.I)
 if not m:raise ValueError((key,pattern))
 start=max(0,t.rfind('\n\n',0,m.start())+2);end=t.find('\n\n',m.end())
 if end<0:end=min(len(t),m.end()+span)
 if end-start>1800:start=max(0,m.start()-100);end=min(len(t),m.end()+span)
 q=t[start:end];p=pathlib.Path(s['sourcePath']);rec={'evidenceId':eid or key,'url':s['url'],'sourcePath':str(p),'fileSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':q,'quoteStart':start,'quoteEnd':end}
 out=V/'evidence/source-a/evidence.json';a=json.load(open(out)) if out.exists() else {};a[rec['evidenceId']]=rec;out.write_text(json.dumps(a,ensure_ascii=False,indent=2));return rec
if __name__=='__main__':
 import sys;show(*sys.argv[1:])

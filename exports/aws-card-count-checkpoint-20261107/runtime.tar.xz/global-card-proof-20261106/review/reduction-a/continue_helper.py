import json,pathlib,hashlib,collections,datetime
P=pathlib.Path(__file__).resolve().parent;V=P.parents[1]
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()
M=rd(P/"input-manifest.json");KP=P/"frozen355.json";assert sha(KP)==M[str(V/"deliverables/visible-knowledge-current.json")]
K=rd(KP);C={c['ruleId']:c for c in K};Q=rd(V.parent/"domain1-final-card-catalog-20261105/questions.all.json");A=rd(V/"inputs/question-allocation1018.json")
done={x['ruleId'] for x in rd(P/'batch01.review.json')['results']};T=[x for x in rd(P/'low-frequency-queue155.json')['queue'] if x['ruleId'] not in done];assert len(T)==139
parents=collections.defaultdict(list)
for c in K:
 for d in c['prerequisiteRuleIds']:parents[d].append(c['ruleId'])
def close(rid,g):
 seen=set();stack=list(g.get(rid,[]))
 while stack:
  x=stack.pop()
  if x not in seen:seen.add(x);stack+=list(g.get(x,[]))
 return sorted(seen)
PG={c['ruleId']:c['prerequisiteRuleIds'] for c in K}
def show(a,b):
 for e in T[a:b]:
  c=C[e['ruleId']];print('CARD',c['ruleId'],c['questionIds'],'PRE',c['prerequisiteRuleIds']);print(' | '.join(c['visibleBody'].values()));n=c['questionIds'][0];q=Q[str(n)];print('Q'+str(n),q['stem'].replace('\n',' '));print('\n'.join(str(o['ordinal'])+':'+o['text'].replace('\n',' ') for o in q['options']))
def save(batch,rows):
 out=[]
 for rid,decision,qid,reason,otherIds in rows:
  c=C[rid];assert decision in ['retain','remove','merge','unknown'];assert qid in c['questionIds'];alts=[]
  for i in otherIds:
   x=C[i];alts.append({'ruleId':i,'visibleBody':x['visibleBody'],'bodySha256':x['bodySha256']})
  out.append({'ruleId':rid,'decision':decision,'bodySha256':c['bodySha256'],'reason':reason,'witnessQuestionId':qid,'witnessQuestionSha256':ch(Q[str(qid)]),'fullWitnessStemAndAllOptionsRead':True,'allAssociatedQuestionIds':sorted(set(c['questionIds'])|{a['qid'] for a in A if rid in a.get('designRuleIdsIncludingPrerequisites',a['designRuleIds'])}),'allAssociatedQuestionsChecked':False,'prerequisiteClosure':close(rid,PG),'dependentCardClosure':close(rid,parents),'alternativeCardsConsidered':alts,'retainedNecessaryAnchor':{'field':'answerZH','quote':c['visibleBody']['answerZH'],'bodySha256':c['bodySha256']},'mutationApplied':False})
 assert len(out)==len({r['ruleId'] for r in out});assert all(r['decision'] not in ['remove','merge'] for r in out),'Removal/merge needs expanded all-question ablation evidence, do not bypass with this retain helper.'
 p=P/('batch'+str(batch).zfill(2)+'.review.json');d={'schemaVersion':1,'batch':batch,'reviewer':'reduction-a independent semantic necessity review','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen355Path':str(KP),'frozen355Sha256':sha(KP),'original356ManifestPath':str(P/'input-manifest.json'),'results':out,'counts':dict(collections.Counter(r['decision'] for r in out)),'scope':'Retain uses a complete original-question witness of a distinct necessary judgment. It does not claim all associated questions already supported. No removal is inferred from local omission.','directCliApiCalls':0,'nativeUsage':'unknown'};p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(str(p),d['counts'])

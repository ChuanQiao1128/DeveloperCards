from continue_helper import *
save(6,[
('GSC-040','retain',196,'Q196自动过期属性/后台TTL清理是特定DynamoDB保留机制；NB04PITR历史恢复和S3生命周期不能推导DDB逐item到期。旧池不额外补epoch新句。',['CUR:NB04','CUR:CMP-M01']),
('GSC-059','unknown',827,'唯一Q827说流量增长/存储性能，但没有I/O费用占比与总费用数据。该卡有独立计费知识，却尚未证明是本题必要条件，也未证其余卡可完整替代；暂缓核心包取舍，不因只有一题删义务。',['GSC-057','GSC-051']),
('GSC-062','retain',886,'Q886少改SQLServer应用需Babelfish T-SQL/协议兼容层，061结构转换和060记录复制不自动保留应用SQL协议。',['GSC-061','GSC-060']),
('GSC-063','retain',948,'Q948复制工作量变动且只配所需容量，需要DMS Serverless，060全量/CDC任务流程不说明复制资源自动伸缩，不能拿EC2ASG替代。',['GSC-060','GSC-112']),
('GSC-066','retain',786,'Q786采服务器利用率/配置为迁移评估要ADS/当前发现路径，064迁移复制工具和SCT数据库结构转换不提供实际资产需求发现。',['GSC-064','GSC-061']),
('GSC-071','unknown',68,'Q68核心是低成本DX主用/VPN备用，卡的预建测试主要是实施准备；NB01已有承载差别但未教完整成本取舍，未完成不依赖071的唯一选型证明，不能宣布可删。',['CUR:NB01','GSC-068']),
('GSC-074','retain',499,'Q499伙伴hosted小带宽与自购dedicated交付方式是必要边界；NB01只教专线非互联网，不说明hosted商品范围。旧卡数值缺口不以新repair07填补。',['CUR:NB01']),
('GSC-076','retain',439,'Q439同VPC追加CIDR避免重建互联，CB16互联路由或075中心连接不说明VPC本身可关联新CIDR，需保留这一扩展能力。',['CUR:CB16','GSC-075']),
('GSC-085','retain',363,'Q363每服务各一份又有序需要SNS FIFO端到端消息组，080扇出无顺序、NC04 SQS FIFO不提供上游SNS有序承诺。',['GSC-080','CUR:NC04']),
('GSC-087','retain',138,'Q138RabbitMQ active/standby选项与真实集群模型不符，086通用MQ协议兼容不能说明每个引擎HA部署；源问题需要此区别，不能默换成ActiveMQ。',['GSC-086','CUR:CB01']),
('GSC-003','retain',699,'Q699 Fargate使用EFS挂入容器是受支持平台集成，001泛NFS共享和XB019免主机管理不证明ECS任务定义接入方式。',['GSC-001','CUR:XB019']),
('GSC-008','retain',635,'Q635 ONTAP原生SnapMirror跨Region保持CIFS/NFS；056 Aurora副本提升原则不提供ONTAP原生复制能力，不能仅因复制流程相似删掉唯一可见SnapMirror上下文。',['GSC-056','GSC-009']),
('GCL-008','retain',64,'Q64保留混合Windows文件访问的FSx本地缓存不同于012 S3对象后端缓存；只选云端FSx会让所有机房访问都远程，当前资格边界不抵扣所需机制。',['GSC-012','CUR:CA15']),
('GCL-018','retain',384,'Q384既有POSIX路径内转EFS IA与S3转对象接口不同，001共享文件没教生命周期转层，CMPM01 S3类不能直接套到EFS。',['GSC-001','CUR:CMP-M01']),
('GCL-028','retain',698,'Q698 EKS Fargate可接EFS及静态PV/PVC边界是平台支持事实，003 ECS任务定义不能搬作Kubernetes，020单AZ块共享不满足跨容器容错。',['GSC-003','GSC-001','GSC-020']),
('GCL-031','retain',972,'Q972 Windows跨AZ共享块接口需ONTAP iSCSI，不等于CA15 SMB文件共享或020单AZEBS共享；协议与可用性支持是独立必要判断。',['CUR:CA15','GSC-020']),
('GSC-091','retain',402,'Q402隔日消费记录丢失要区分保留窗口与shard吞吐，093自动容量不会恢复已过期记录。默认时长缺口另记，不能删除retention机制本身。',['GSC-093']),
('GSC-093','retain',888,'Q888变化点击流on-demand管理shard容量，XB004流消费者处理和NC01Flink分析不提供容量模式的管理边界。',['CUR:XB004','CUR:NC01']),
('GSC-094','retain',362,'Q362 Kinesis同partition key进同shard有序是除SQS FIFO外第二种支持路径，NC04消息组原则不定义Kinesis分片路由。',['CUR:NC04'])
])
p=P/'batch06.review.json';d=rd(p);rid='GSC-072';c=C[rid];assoc=sorted(set(c['questionIds'])|{a['qid'] for a in A if rid in a.get('designRuleIdsIncludingPrerequisites',a['designRuleIds'])});assert assoc==[448,858] and close(rid,parents)==[]
def an(i,f,quote):assert quote in C[i]['visibleBody'][f];return {'cardId':i,'field':f,'quote':quote,'bodySha256':C[i]['bodySha256']}
a=[an('CUR:CB03','keyPointZH','把实例分散到独立AZ，才避免同一故障域一起失效'),an('GSC-119','keyPointZH','分散降低共同硬件故障影响')]
d['results'].append({'ruleId':rid,'decision':'remove','bodySha256':c['bodySha256'],'reason':'两原题把物理共同故障点直接写在题干/选项；既有独立故障域和硬件分散原则可以迁移，不需为DirectConnect再背一次相同可靠性规则。','allAssociatedQuestionIds':assoc,'allAssociatedQuestionsChecked':True,'prerequisiteClosure':close(rid,PG),'dependentCardClosure':close(rid,parents),'recursivePrerequisitesAndDependentsCheckedAgainst355':True,'alternativeCardIds':['CUR:CB03','GSC-119','CUR:CB16'],'questionChecks':[{'qid':448,'questionSha256':ch(Q['448']),'fullOriginalRead':True,'statusAfterRemoval':'SUPPORTED_no_new_gap','selectedOptionOrdinals':[3],'anchors':a+[an('CUR:CB16','keyPointZH','连接本身不引入这种设备的单点与带宽瓶颈')],'derivation':'题干明确Management所有VPN依赖同一机房设备，C增第二customer gateway才去掉该共同硬件点。A/D增加VPC间路径不改变机房单设备；B增加AWS侧网关也不移除明示单设备。无需假定新AWS服务行为，按题中实际路径与已教故障隔离推理。'},{'qid':858,'questionSha256':ch(Q['858']),'fullOriginalRead':True,'statusAfterRemoval':'SUPPORTED_no_new_gap','selectedOptionOrdinals':[3],'anchors':a,'derivation':'C同时把来源数据中心、DX地点和设备分散；A仍仅主数据中心，B同设备同地点，D仍同地点。题目已列出地点/设备关系，直接应用避免共同故障域原则，不把不同连接数当地点独立。'}],'mutationApplied':False})
d['counts']=dict(collections.Counter(x['decision'] for x in d['results']));d['scope']='20 candidates, including complete two-question shared failure-domain ablation forGSC072; frozen355 only.';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');assert len(d['results'])==20;print('EXPANDED',d['counts'])

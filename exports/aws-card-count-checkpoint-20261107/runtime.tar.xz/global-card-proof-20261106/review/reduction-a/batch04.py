from continue_helper import *
save(4,[
('CUR:XB025','retain',514,'Q514两个私有入口分别为EKS管理API和Kubernetes集群API；CMPM04通用interface endpoint不能推导注册节点到底连谁，删除会误选B。',['CUR:CMP-M04','CUR:CA18']),
('CUR:XB026','retain',517,'Q517原生SessionManager内容日志须单独S3偏好配置，CA03能会话登录不代表已归档，通用Agent指标卡不能替此原生功能。',['CUR:CA03','GSC-141']),
('CUR:XB033','retain',185,'Q185应用凭据必须taskRoleArn，CMPM06只明确EC2/Lambda身份交付，不包含ECS task与task execution role职责差别。',['CUR:CMP-M06']),
('CUR:XB036','retain',723,'Q723保留原数据库实例角色而纳管需DHMC独立SSM权限，CA03一般SSM实例角色不能满足不替换/不加第二角色的约束。',['CUR:CA03','CUR:CMP-M06']),
('CUR:XB039','unknown',783,'账本只追加与密码学验证未被普通数据/审计卡替代，但原题唯一QLDB选项已停用，未接受题源范围例外。不能因停用直接删义务，也不能把机制卡当当前托管解，等待核心包处置。',['CUR:CC23','CUR:CMP-M16']),
('CUR:XB040','retain',808,'Q808保留ECS且已有/新镜像扫CVE，需要ECR basic push/manual触发入口，CC02一般Inspector漏洞扫描不说明镜像仓库触发和不换编排器。',['CUR:CC02','GSC-139']),
('CUR:XB042','retain',903,'Q903共享桶每应用前缀策略的独立AccessPoint入口未被XB021桶策略允许/拒绝原则替代；不需复制数据的入口治理是独立动作。',['CUR:XB021']),
('CUR:XB043','retain',928,'Q928 NLB创建时无SG不能事后新增是服务生命周期约束，CMPM10来源规则不能说明需重建且关闭旧入口。',['CUR:CMP-M10','CUR:CB10']),
('CUR:XB045','retain',1006,'Q1006托管补丁前摘流/排空/恢复runbook与target类型是必要平台边界，CC01补丁执行或维护日历不执行该流量编排。原题声称原地改类型的缺口不抵扣。',['CUR:CC01','CUR:XB016']),
('CUR:XR102','retain',332,'Q332个人远程设备安全接入需ClientVPN，NB01专线/站点互联与CA15文件ACL都不提供个人端到VPC接入。',['CUR:NB01','CUR:CA15']),
('CUR:aws-rb2-20261105-boundary-aurora-iam-token-login','retain',854,'Q854用角色生成数据库登录token替静态密码，CMPM06临时AWS凭据不等于数据库已支持/启用IAM认证；CMPM08安全存密码也不消除密码。',['CUR:CMP-M06','CUR:CMP-M08']),
('CUR:aws-rb2-domain1-normal-batch06-20261105-roles-anywhere-workload-identity','retain',982,'Q982外部VM无人值守机器身份需RolesAnywhere证书信任锚换临时角色，企业人员SSO/SAML或EC2 profile不能直接套用。原选项IdentityCenter措辞疑点另留。',['CUR:XA026','CUR:CMP-M06']),
('CUR:aws-rb2-domain1-normal-batch08-20261105-s3-account-public-access-guardrail','retain',412,'Q412全账户现有未来桶预防公开并阻止关防护，需要account BPA加SCP；通用SCP不能凭空定义S3 BPA保护机制，Config事后补救不同。',['CUR:CMP-M05','CUR:CC10']),
('CUR:XB016','retain',377,'Q377终止前不能先销毁实例，要lifecycle hook等待上报；CB03自动补容量或userData启动脚本不构成终止前关口。',['CUR:CB03']),
('CUR:XB030','retain',599,'Q599现场供电网络/物理访问及故障容量由客户负责，XB029本地控制面位置不说明shared-responsibility和容量不会自动补足。',['CUR:XB029','GSC-116']),
('CUR:XA012','retain',211,'Q211跨Region按标签找到当前资源需要TagEditor查询，CC23事件历史或GSC154成本标签维度不能产生资源清单。',['CUR:CC23','GSC-154']),
('CUR:XA036','retain',748,'Q748CloudWatch源账户共享链接/监控账户配置是数据接入，CA08角色授权或SCP上限不会自动建立可观测性共享。',['CUR:CA08','CUR:CMP-M05']),
('CUR:XA046','retain',893,'Q893工作负载分账户但共用中央子网要RAM子网共享；TGW连各自VPC不是在中央VPC创建自己的资源，NC05账户治理也不建共享网络。',['GSC-075','CUR:NC05']),
('CUR:XB029','retain',805,'Q805数据/计算本地且要EKS，Outposts和local cluster现场边界不能由LocalZones/Wavelength或XB030机柜运维责任替代。',['GCL-027','CUR:XB030']),
('CUR:XB031','retain',457,'Q457 AS2特定协议入口与普通数据复制不同，CMPM19 SFTP入口不证明AS2能力及认证限制；原题Lambda IdP搭配缺口仍保留。',['CUR:CMP-M19','CUR:NC07'])
])

from continue_helper import *
# Preserve earlier ablation proposal as history; the full existing-proof scan found a real unresolved inventory premise.
pb=V/'review/gap-b/results-part02.json';pc=V/'review/gap-b/results-part03.json';oldrp=V/'review/reuse-a/question-reuse371.json';oldr=next(x for x in rd(oldrp)['results'] if x['qid']==873)
assert oldr['priorVerdict']=='CONDITIONAL' and any('Inventory' in x for x in oldr['preservedApplicabilityConditions'])
extra={'schemaVersion':1,'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'basis':'Actual used-rule scan of all existing question proof artifacts, including uses outside initial assignment.','proofInputs':[{'path':str(p),'sha256':sha(p)} for p in [pb,pc,oldrp]],'overrides':[{'ruleId':'CUR:XA044','decision':'unknown','priorDecision':'remove','priorDecisionPath':str(P/'batch03.review.json'),'priorDecisionSha256':sha(P/'batch03.review.json'),'bodySha256':C['CUR:XA044']['bodySha256'],'allAssociatedQuestionIds':[454,873],'allAssociatedQuestionsChecked':True,'reason':'GenericCC01 teaches executing/tracking patches andCC02 vulnerability matching; neither explicitly provides the requested OS/software metadata inventory. Prior validQ873 proof requiredInventory actually enabled. ChoosingB remains plausible, but that is not proof all inventory knowledge is supplied withoutXA044. Earlier deletion proposal is withdrawn rather than treating an uncovered business requirement as a weak distractor.','questionChecks':[{'qid':873,'questionSha256':ch(Q['873']),'fullOriginalRead':True,'statusAfterRemoval':'NOT_PROVEN; existingInventory/applicability condition preserved','conditions':oldr['preservedApplicabilityConditions'],'anchors':[]},{'qid':454,'questionSha256':ch(Q['454']),'fullOriginalRead':True,'statusAfterRemoval':'SOURCE_ISSUE_preserved','note':'gap-b usedInventory scope to reject map discovery; originalWorkloadDiscovery retirement remains in current-AWS correction disposition. No current-map replacement invented.','anchors':[]}],'prerequisiteClosure':close('CUR:XA044',PG),'dependentCardClosure':close('CUR:XA044',parents),'mutationApplied':False}], 'additionalQuestionChecks':[{'ruleId':'GSC-098','qid':515,'questionSha256':ch(Q['515']),'fullOriginalRead':True,'priorStatus':'UNKNOWN','statusAfterRemoval':'UNKNOWN_existing_unresolved_gap_preserved_no_new_gap','additionalAlternativeCardIds':['GSC-150','GSC-089','CUR:XB013'],'anchors':[{'cardId':'GSC-150','field':'answerZH','quote':C['GSC-150']['visibleBody']['answerZH'],'bodySha256':C['GSC-150']['bodySha256']},{'cardId':'GSC-089','field':'answerZH','quote':C['GSC-089']['visibleBody']['answerZH'],'bodySha256':C['GSC-089']['bodySha256']},{'cardId':'CUR:XB013','field':'keyPointZH','quote':C['CUR:XB013']['visibleBody']['keyPointZH'],'bodySha256':C['CUR:XB013']['bodySha256']}],'derivation':'Q515C analytics at specifiedhours can use the existing warehouse-purpose rule plus fixed-time scheduling and releasing idle compute. TheGSC098EMR wording adds no Redshift-specific evidence. Original client-side-encryption/secondary-replica selection ambiguity remainsUNKNOWN; no whole-question promotion or retired encryption capability added.'}],'directCliApiCalls':0,'nativeUsage':'unknown'}
(P/'actual-proof-use-addendum.json').write_text(json.dumps(extra,ensure_ascii=False,indent=2)+'\n')
# Gather every completed semantic row exactly once;NS04 is an explicit extra higher-frequency overlap check.
files=sorted(P.glob('batch[0-9][0-9].review.json'));assert len(files)==8
allrows=[];bindings=[]
for p in files:
 d=rd(p);bindings.append({'path':str(p),'sha256':sha(p)});allrows+=d['results']
assert len(allrows)==len({r['ruleId'] for r in allrows})==156
rows={r['ruleId']:r for r in allrows}
for x in rd(P/'scope-update-overrides.json')['overrides']:rows[x['ruleId']]=x
for x in extra['overrides']:rows[x['ruleId']]=x
r=rows['GSC-098'];r=dict(r);r['allAssociatedQuestionIds']=sorted(set(r['allAssociatedQuestionIds'])|{515});r['questionChecks']=list(r['questionChecks'])+extra['additionalQuestionChecks'];r['alternativeCardIds']=sorted(set(r['alternativeCardIds'])|set(extra['additionalQuestionChecks'][0]['additionalAlternativeCardIds']));r['additionalKnownProofUsePath']=str(P/'actual-proof-use-addendum.json');rows['GSC-098']=r
low={x['ruleId'] for x in rd(P/'low-frequency-queue155.json')['queue']};assert len(low)==155 and low <= set(rows)
lowrows=[rows[rid] for rid in [x['ruleId'] for x in rd(P/'low-frequency-queue155.json')['queue']]]
assert len(lowrows)==155
# Search actual prior/full proof uses, not merely blueprint links.
proofUses=collections.defaultdict(set);proofSourceBindings=[]
def walk(z):
 if isinstance(z,dict):
  qid=z.get('qid');ids=z.get('usedRuleIds',[])
  if isinstance(qid,int) and isinstance(ids,list):
   for rid in ids:
    if rid in C:proofUses[rid].add(qid)
  for x in z.values():walk(x)
 elif isinstance(z,list):
  for x in z:walk(x)
for area in ['questions-a','questions-b','questions-c','gap-a','gap-b']:
 for p in (V/'review'/area).glob('*.json'):
  try:d=rd(p)
  except (json.JSONDecodeError,UnicodeDecodeError):continue
  walk(d);proofSourceBindings.append({'path':str(p),'sha256':sha(p)})
for z in rd(oldrp)['results']:
 for cid in z.get('usedCardIds',[])+z.get('completeDependencyIds',[]):
  rid='CUR:'+cid
  if rid in C:proofUses[rid].add(z['qid'])
removed={r['ruleId'] for r in lowrows if r['decision']=='remove'};kept=set(C)-removed;checks=[];allq=set();anchorcount=0
for r in lowrows:
 rid=r['ruleId'];assert r['bodySha256']==C[rid]['bodySha256']==ch(C[rid]['visibleBody'])
 if r['decision']!='remove':continue
 assoc=set(C[rid]['questionIds'])|{a['qid'] for a in A if rid in a.get('designRuleIdsIncludingPrerequisites',a['designRuleIds'])}|proofUses[rid]
 assert set(r['allAssociatedQuestionIds'])==assoc,(rid,assoc,r['allAssociatedQuestionIds']);assert {q['qid'] for q in r['questionChecks']}==assoc
 altset=set(r.get('alternativeCardIds',[]));closure=set()
 for a in altset:assert a in kept;closure|=set(close(a,PG))
 assert closure<=kept and not (altset&removed) and not (closure&removed)
 dependent=set(close(rid,parents));assert not (dependent&kept),(rid,'kept descendant would need removed prerequisite')
 for q in r['questionChecks']:
  assert q['questionSha256']==ch(Q[str(q['qid'])]);assert q['fullOriginalRead'];allq.add(q['qid'])
  for a in q.get('anchors',[]):
   cid=a['cardId'];assert cid in kept and cid in altset;assert C[cid]['bodySha256']==a['bodySha256'];body=C[cid]['visibleBody'];assert a['quote'] and any(a['quote'] in s for s in body.values());anchorcount+=1
 checks.append({'ruleId':rid,'allAssociatedQuestionIds':sorted(assoc),'actualProofUseQuestionIds':sorted(proofUses[rid]),'alternativeCardIds':sorted(altset),'recursiveAlternativePrerequisiteIds':sorted(closure),'allAlternativesAndPrerequisitesStillKept':True,'survivingDependentCards':sorted(dependent&kept),'allOriginalQuestionChecksPresent':True,'scopeDisposition':r.get('removalType','duplicate_or_derivable_teaching')})
assert len(checks)==7
counts=dict(collections.Counter(r['decision'] for r in lowrows));unknown=[r['ruleId'] for r in lowrows if r['decision']=='unknown'];assert not low-set(rows)
for p,h in M.items():
 if p.endswith('SKILL.md') or p.endswith('/deliverables/visible-knowledge-current.json'):continue
 assert sha(p)==h
joint={'schemaVersion':1,'status':'PASS_joint_proposed_kept_set_check','basisFrozen355Path':str(KP),'basisFrozen355Sha256':sha(KP),'proposedRemovalRuleIds':sorted(removed),'proposedKeptRuleIds':sorted(kept),'checks':checks,'cyclicOrRemovedAlternativeDependencies':[],'keptCardsDependingOnRemovedCards':[],'ablationOriginalQuestionCount':len(allq),'literalReplacementAnchorCount':anchorcount,'currentPoolMutationApplied':False,'rootUpdatedPoolMustReconcileChangedBodiesBeforeApplication':True,'noFinalNClaim':True}
(P/'joint-removal-check.json').write_text(json.dumps(joint,ensure_ascii=False,indent=2)+'\n')
final={'schemaVersion':1,'status':'complete_all155_low_frequency_semantic_dispositions_not_final_core_count','reviewer':'reduction-a independent shared-core necessity reviewer','basisFrozen355Path':str(KP),'basisFrozen355Sha256':sha(KP),'initial356CataloguePath':str(V/'inputs/card-catalogue.frozen-design.json'),'initial356CatalogueSha256':M[str(V/'inputs/card-catalogue.frozen-design.json')],'counts':counts,'semanticReviewedLowFrequencyCount':155,'unreviewedLowFrequencyCount':0,'unknownDispositionRuleIds':unknown,'proposedRemovalRuleIds':sorted(removed),'results':lowrows,'additionalHigherFrequencyReview':rows['CUR:NS04'],'unreviewedHigherFrequencyCount':199,'batchBindings':bindings,'overrideBindings':[{'path':str(p),'sha256':sha(p)} for p in [P/'scope-update-overrides.json',P/'actual-proof-use-addendum.json']],'actualProofSourcesScanned':proofSourceBindings,'old371UseAuditPath':str(oldrp),'old371UseAuditSha256':sha(oldrp),'jointRemovalCheckPath':str(P/'joint-removal-check.json'),'jointRemovalCheckSha256':sha(P/'joint-removal-check.json'),'skillForwardCheckPath':str(P/'skill-forward-check.md'),'current_artifacts':[str(P/'results.json'),str(P/'joint-removal-check.json'),str(P/'skill-forward-check.md')],'pending_ids':unknown,'findings':['XA044 deletion proposal withdrawn after full existing-proof scan exposed unproven inventory requirement.','GSC098 additionalQ515 use retested; originalUNKNOWN remains, no hidden coverage upgrade.','Only confirmedQLDB retirement uses new user current-AWS correction scope; existing-eligible services remain.'],'attempts':'All original batches and first3 removal proposals preserved; targeted overlays record later evidence and user-scope changes.','next_action':'Root reconciles these old-pool proposals with current24 revisions and other reduction work; target7 unknown candidate obligations; no automatic deletion, no final card-count announcement.','directCliApiCalls':0,'nativeUsage':'unknown','finalN':'not_proven','currentBodyOrAllocationMutationApplied':False}
(P/'results.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
# Stable deterministic readback, independent from presentation counts.
f=rd(P/'results.json');assert len(f['results'])==len({r['ruleId'] for r in f['results']})==155;assert {r['ruleId'] for r in f['results']}==low;assert counts==dict(collections.Counter(r['decision'] for r in f['results']));assert removed=={r['ruleId'] for r in f['results'] if r['decision']=='remove'}
rb={'status':'PASS','resultsPath':str(P/'results.json'),'resultsSha256':sha(P/'results.json'),'exact155LowFrequencyIds':True,'counts':counts,'unknownIds':unknown,'initial3RemovalProposalsPreserved':True,'all7EffectiveRemovalsAllKnownOriginalAssociationsAndRecursiveDependenciesChecked':True,'jointAlternativesAndPrerequisitesRemainKept':True,'removedCardsHaveNoKeptDependents':True,'frozenOld355PoolUsed':True,'original356AndAllocationUnchanged':True,'allReplacementQuotesLiteral':True,'knownProofUsesOutsideBlueprintHandled':True,'root24RevisionConflictReconciliationStillRequired':True,'currentOrAllocationMutationApplied':False,'finalN':'not_proven','directCliApiCalls':0,'nativeUsage':'unknown'};(P/'final-readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
p=P/'skill-forward-check.md';s=p.read_text();s+='\n最终实际联合检查：全部155低频候选已有语义去向。7项有效删除提议的替代卡及递归先修均在同一个拟保留旧池集合，未发现循环替代或删除项被保留卡依赖。GSC098的Q515额外使用已回测，XA044原删除提议因Inventory义务回退unknown；原证据保留。详细集合与逐项结果在joint-removal-check.json，哈希回读在final-readback.json。未应用删除，未宣称最终N。\n';p.write_text(s)
print(json.dumps(rb,ensure_ascii=False));print('REMOVALS',sorted(removed))

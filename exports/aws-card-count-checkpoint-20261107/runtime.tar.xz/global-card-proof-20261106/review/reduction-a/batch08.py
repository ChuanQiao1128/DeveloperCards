from continue_helper import *
save(8,[
('GSC-145','unknown',910,'唯一Q910要求不超过2分钟的EC2监控，当前卡只教1秒自定义采样与显示刷新差别，未教EC2 detailed monitoring一分钟。141已有采集/显示层次原则，但尚不能完整替代本题所需能力，暂缓卡的必要性/重选而不宣称可删。',['GSC-141']),
('GSC-147','retain',47,'Q47短期指定AZ保证EC2容量，不是CB02ComputeSP价格折扣。容量预留与购买承诺的不同权益是必要边界，不能由弹性补实例或RI名称推导。',['CUR:CB02','GSC-112']),
('GSC-149','retain',383,'Q383socket/core授权须主机物理信息控制，DedicatedHost与Instance不等价；119放置分散或CB02折扣灵活性不说明许可证主机控制。',['GSC-119','CUR:CB02']),
('GSC-064','retain',539,'Q539持续VM灾备与1010整机迁移目的不同，065测试切换和068准备程度不教MGN/DRS工具生命周期定位。',['GSC-065','GSC-068']),
('GSC-090','retain',809,'Q809事件后HTTP用户名密码调用少维护需EventBridge API destination/connection，CC17筛选转换不包含该认证目标能力。',['CUR:CC17','GSC-089']),
('GCL-004','retain',257,'Q257把已在CloudWatch的指标持续导到S3要MetricStreams出口，141采集内存指标和NS01Firehose目的地不自动连CloudWatch指标源。状态事件/指标歧义保留。',['GSC-141','CUR:NS01']),
('GCL-005','retain',338,'Q338 Aurora global存储可以无DB计算secondary是必要成本能力，056副本提升及068pilot-light名称不证明复制存储与计算可分离。',['GSC-056','GSC-068']),
('GCL-007','retain',523,'Q523API请求内多DDB源组合要AppSync pipeline resolver，088长流程状态机或CA17函数入口不提供GraphQL数据解析流水线。',['GSC-088','CUR:CA17']),
('GCL-012','retain',194,'Q194自管DB自动接管必须数据复制加集群接管，CB03跨AZ实例数量或118EC2底层恢复都不让任意DB自动接管。',['CUR:CB03','GSC-118']),
('GCL-013','retain',247,'Q247读副本创建前非零自动备份及长事务准备是特定复制前提，CB01HA/扩读职责与047PITR历史窗口不教这些创建要求。',['CUR:CB01','GSC-047']),
('GCL-015','retain',103,'Q103避免重复处理旧XML输入需Glue bookmarks处理进度，095真正ETL格式转换或088工作流状态不能替代Glue输入处理水位。',['GSC-095','GSC-088']),
('GCL-016','retain',198,'Q198保留MongoDB接口同时少自管数据库，CC22关系RDS兼容与XB013DynamoDB模型不说明DocumentDB支持MongoDBAPI；零改代码仍须兼容条件。',['CUR:CC22','CUR:XB013']),
('GCL-019','retain',440,'Q440原生snapshot/SQLdump/S3物理备份是不同恢复输入，048导出可分析不等于恢复点只提供部分排除，不教逻辑SQL导入/物理格式条件。',['GSC-048','GSC-060']),
('GCL-023','retain',520,'Q520DynamoDB表类请求费/存储费与容量模式独立，038只决定on-demand/provisioned，不提供Standard与IA的成本差别。S3类不能跨服务照搬。',['GSC-038','CUR:CMP-M01']),
('GCL-024','retain',569,'Q569需要规则匹配和目标调用两阶段指标，CC23API审计与143容器指标不证明EventBridge具体阶段可观测；仅泛说看CloudWatch不足以替代。',['CUR:CC23','GSC-143']),
('GCL-025','unknown',664,'Q664仅给CPU变为平常10倍，没有绝对基线、持续时长或成本目标；A/B两种按请求伸缩规格都可能可行。独立credit知识未证在这题是决定性必要条件，也未证明别卡完整替代，待原题/核心包处置。',['GSC-111','GSC-112','GSC-113']),
('GCL-026','retain',603,'Q603千项并行Map模式要Distributed独立子执行与Inline限制区别，088只讲持久步骤/等待不说明Map的并发和历史规模能力。',['GSC-088','GSC-097']),
('GCL-027','retain',684,'Q684实际运行位置与CloudFront缓存不同，LocalZones和运营商Wavelength边缘也不同；CA13网络交付入口、XB029机房Outposts不替代两种可部署位置。法规/地点条件仍需回测。',['CUR:CA13','CUR:XB029']),
('GCL-032','retain',969,'Q969现有应用自动打包工具与容器运行平台职责独立，GCL002一般容器保留运行模型、XB019Fargate免主机管理不证明App2Container生成工件。既有客户仍提供，不按全停服务删掉。',['GCL-002','CUR:XB019'])
])
# Apply only the newly accepted current-AWS scope to the previously unknown isolated retired-ledger card.
scopep=V/'inputs/user-knowledge-scope-accepted.json';scope=rd(scopep);assert scope['policy']=='current_AWS' and scope['confirmedObsoleteOnlyMayUseCorrectionDisposition'];sourcep=V/'review/source-a/results.json';sr=next(x for x in rd(sourcep)['records'] if x['qid']==783);assert sr['sourceVerdict']=='CONFIRMED_SOURCE_ISSUE';e=sr['officialEvidence'][0];assert sha(e['sourcePath'])==e['fileSha256'];s=rd(e['sourcePath'])['text'];assert hashlib.sha256(s.encode()).hexdigest()==e['textSha256'];assert s[e['quoteStart']:e['quoteEnd']]==e['quote'];assert 'Amazon Quantum Ledger Database (Amazon QLDB)' in e['quote'] and 'July 31, 2025' in e['quote']
rid='CUR:XB039';c=C[rid];assoc=sorted(set(c['questionIds'])|{a['qid'] for a in A if rid in a.get('designRuleIdsIncludingPrerequisites',a['designRuleIds'])});assert assoc==[783] and close(rid,parents)==[]
x={'ruleId':rid,'decision':'remove','priorDecision':'unknown','priorDecisionPath':str(P/'batch04.review.json'),'priorDecisionFileSha256':sha(P/'batch04.review.json'),'bodySha256':c['bodySha256'],'removalType':'current_core_package_scope_disposition_not_duplicate_substitution','reason':'唯一关联Q783的QLDB已被AWS官方确认全面关闭；用户现已选择现行AWS范围。当前包不单独教授这个孤立账本机制卡，原题/关闭纠错和不可变可验证变更日志考点义务保留在历史纠错记录，不将其伪装成当前可新部署服务。','allAssociatedQuestionIds':assoc,'allAssociatedQuestionsChecked':True,'prerequisiteClosure':close(rid,PG),'dependentCardClosure':close(rid,parents),'recursivePrerequisitesAndDependentsCheckedAgainst355':True,'alternativeCardIds':[],'acceptedScopePath':str(scopep),'acceptedScopeSha256':sha(scopep),'officialSourceReviewPath':str(sourcep),'officialSourceReviewSha256':sha(sourcep),'officialRetirementEvidence':e,'questionChecks':[{'qid':783,'questionSha256':ch(Q['783']),'fullOriginalRead':True,'statusAfterRemoval':'ACCEPTED_CURRENT_AWS_HISTORICAL_CORRECTION_DISPOSITION','selectedOptionOrdinals':[],'originalPreserved':True,'correction':'OptionD namesQLDB; full shutdown2025-07-31, so it is not a current new-deployment recommendation.','knowledgeDisposition':'Immutable plus cryptographically verifiable change-history objective retained in the correction/knowledge-disposition queue; no unsupported contemporary AWS replacement or coverage claim.','anchors':[]}],'mutationApplied':False}
(P/'scope-update-overrides.json').write_text(json.dumps({'schemaVersion':1,'reason':'New user current-AWS decision after batch04; historical receipt not overwritten.','overrides':[x],'directCliApiCalls':0,'nativeUsage':'unknown'},ensure_ascii=False,indent=2)+'\n');print('SCOPE_OVERRIDE',rid,'remove_current_core_only')

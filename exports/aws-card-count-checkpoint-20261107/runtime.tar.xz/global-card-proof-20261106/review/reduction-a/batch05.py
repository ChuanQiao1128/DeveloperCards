from continue_helper import *
save(5,[
('CUR:XB034','retain',712,'Q712VPC向机房查私有DNS须outbound端点和域名转发规则，GSC129权威托管与NB01专线连通不产生该查询转发。',['GSC-129','CUR:NB01']),
('CUR:XB035','retain',717,'Q717现成Transfer上传完成managed workflow是独立受支持触发入口；GSC029只教S3事件，不能直接替代选项D的Transfer工作流能力。原公共/私网选项差异仍独立核验。',['GSC-029','CUR:CMP-M19']),
('CUR:XB037','retain',742,'Q742普通配置验证/渐进发布由AppConfig管理，不是CMPM08秘密轮换/共享读取代码；两种数据生命周期不能强塞成一项秘密任务。',['CUR:CMP-M08']),
('CUR:XB038','retain',775,'Q775HTTPS服务注册发现需要Lattice service network，CMPM04私网入口和TGW路由只连接网络，不注册服务DNS。',['CUR:CMP-M04','GSC-075']),
('CUR:XB044','retain',932,'Q932Pod IP来自自定义子网是CNI网络分配，CA18 service account IAM身份不分配地址，必须保留这一层次区别。',['CUR:CA18']),
('CUR:XR001','retain',295,'Q295按读取方返回脱敏视图而不预存三份，需要ObjectLambda返回路径转换，NA05持久对象或XA013CloudFront边缘函数不等同该S3接口；资格边界未获范围排除。',['CUR:NA05','CUR:XA013']),
('CUR:aws-rb2-domain1-normal-batch07-20261105-s3-bucket-key-request-cost','retain',1009,'Q1009减少KMS逐对象调用需S3BucketKey层级缓存；SC01用钥授权或SC02加密模式不提供该请求费用机制，且减少不等于零的题源边界必须保留。',['CUR:SC01']),
('GCL-022','retain',648,'Q648高可用Lustre persistent复制及scratch不复制是可靠性决定条件，005只保证SSD全量低延迟，不提供数据保护。',['GSC-005']),
('GSC-009','retain',719,'Q719ONTAP同时SMB/NFS且冷热数据auto tiering，008灾备/SnapMirror或EFS生命周期不教ONTAP性能层/容量层。',['GSC-008','GCL-018']),
('GSC-016','retain',919,'Q919单io1性能触顶后多卷条带要确认实例EBS总路径余量；015只教gp3卷性能解耦，051RDS存储瓶颈原则不解释聚合路径上限。',['GSC-015','GSC-051']),
('GSC-017','retain',20,'Q20快照新卷首次读块初始化与FSR按AZ启用是特定恢复性能机制，014持久盘或Backup自动周期不消除首次读延迟。',['GSC-014','CUR:NS03']),
('GSC-018','retain',841,'Q841七年归档与标准层增量大小比较，archive变完整恢复点是决定性计费机制，S3归档单价原则不能替代EBS增量共享差别。',['CUR:CMP-M01','CUR:NS03']),
('GSC-021','retain',1,'Q1跨洲直接上传既需TransferAcceleration路径也需multipart并行/独立重试；023不提供上传分块机制，022下载Range方向不同。',['GSC-023','GSC-022']),
('GSC-028','retain',88,'Q88所有者费用转给请求方需RequesterPays，不是降低总流量或授权。078少搬数据和CA08跨账户授权不改变付款人。',['GSC-078','CUR:CA08']),
('GSC-031','retain',49,'Q49按业务查询找到文件需要元数据索引，NA05对象存储/生命周期本身不提供任意标签搜索；D的RDS元数据有实际查询路径。',['CUR:NA05','CUR:CMP-M01']),
('GCL-029','retain',737,'Q737全球读写统一入口需MRAP且复制独立，NEW04跨Region复制不会自动提供单一就近请求入口，CA13下载CDN不承载同一对象API写入语义。',['CUR:NEW04','CUR:CA13']),
('GSC-034','retain',431,'Q431动态top10需按分数排序维护，032缓存/复制组只教低延迟及接管，不提供sorted set排名查询能力。',['GSC-032']),
('GSC-035','unknown',726,'原题要求经纬度位置快速更新读取，没有明确距离/附近检索，geo-index可能是多余教学；032/033可解释缓存，但当前组对写瓶颈及B竞争方案的完整支撑尚不足，未证明可删，也不把主题位置相同当必要。',['GSC-032','GSC-033','GSC-036'])
])
p=P/'batch05.review.json';d=rd(p)
def an(i,f,quote):assert quote in C[i]['visibleBody'][f];return {'cardId':i,'field':f,'quote':quote,'bodySha256':C[i]['bodySha256']}
for rid,qid,alts,anchors,reason,derivation,sel in [
('GSC-019',662,['CUR:NS03'],[an('CUR:NS03','answerZH','EBS专用快照生命周期可用Data Lifecycle Manager'),an('CUR:NS03','keyPointZH','两者都减少手工调度'),an('CUR:NS03','watchOutZH','新策略不代表历史无用快照已自动清完')],'Q662必要判断是清理已有无用快照并自动管理未来周期，卷原地缩小只是无关干扰项能力；不需为排除它单背一张否定配置卡。','D清理旧无用快照并用DLM控制后续快照，C仅一次性手删不处理持续增长；A/B围绕已有卷大小，不管理题中持续累积快照，也增加日志/脚本运维。保留原题成本范围，不声称EBS可原地缩小。',[4]),
('GCL-017',309,['CUR:XA045'],[an('CUR:XA045','answerZH','使用适用范围的S3 Storage Lens指标汇总'),an('CUR:XA045','keyPointZH','CloudTrail操作记录不能直接代替当前存储状态汇总'),an('CUR:XA045','watchOutZH','按指标所需级别配置汇总；访问活动分析与仅看容量或保护配置是不同指标用途')],'与XA045是同一S3聚合指标而非逐条日志分析规则；目标卡已明说访问活动与容量/保护指标不是一回事，无须重复一张活动指标卡。','A选择StorageLens的advanced activity指标，测是否访问不能用BucketSizeBytes容量；XA045明示按指标级别配置且区分活动与容量。D逐条API日志再查询需要额外维护，B泛控制台不是已教集中指标路径。没有把所有Lens指标都假设免费或默认开启。',[1])]:
 c=C[rid];assoc=sorted(set(c['questionIds'])|{a['qid'] for a in A if rid in a.get('designRuleIdsIncludingPrerequisites',a['designRuleIds'])});assert assoc==[qid] and close(rid,parents)==[]
 d['results'].append({'ruleId':rid,'decision':'remove','bodySha256':c['bodySha256'],'reason':reason,'allAssociatedQuestionIds':assoc,'allAssociatedQuestionsChecked':True,'prerequisiteClosure':close(rid,PG),'dependentCardClosure':close(rid,parents),'recursivePrerequisitesAndDependentsCheckedAgainst355':True,'alternativeCardIds':alts,'questionChecks':[{'qid':qid,'questionSha256':ch(Q[str(qid)]),'fullOriginalRead':True,'statusAfterRemoval':'SUPPORTED_no_new_gap','selectedOptionOrdinals':sel,'anchors':anchors,'derivation':derivation}],'mutationApplied':False})
d['counts']=dict(collections.Counter(x['decision'] for x in d['results']));d['scope']='20 candidates:17 retain/unknown witnesses and2 full sole-question ablations, with frozen355 alternatives; no current mutation.';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');assert len(d['results'])==20;print('EXPANDED',d['counts'])

from continue_helper import *
save(3,[
('CUR:XA037','retain',777,'Q777限定开发OU的AMI启动范围，需要OU launch permission；SCP上限和KMS用钥是另两层，不能替代AMI范围授权。',['CUR:CMP-M05','CUR:SC01']),
('CUR:XA038','retain',779,'Q779必须由IAM阻止写EFS，ClientWrite文件系统资源策略不同于本地readonly挂载或POSIX权限；CMPM06运行角色不说明EFS客户端动作。',['CUR:CMP-M06','CUR:NEW05']),
('CUR:XA039','retain',789,'Q789创建前阻止必须CF hook/proactive，而CC10事后Config评估和修复不能保证部署前拦截；真实阶段差别独立。',['CUR:CC10','CUR:NC05','CUR:XA031']),
('CUR:XA040','retain',791,'Q791开发者可看配置但不见明文，通用客户端加密/用钥权限还需Lambda encryption helpers的具体适用入口；删后仅知原则不足以选D的受支持配置。',['CUR:CMP-M20','CUR:CMP-M06','CUR:SC01']),
('CUR:XA041','retain',793,'Q793撤销待删除key要CancelKeyDeletion和等待期语义；CC17路由报警并不执行取消。原题DeleteKey名称疑点不使此恢复义务被别卡覆盖。',['CUR:CC17']),
('CUR:XA042','retain',803,'Q803按IP/地点/设备风险追加MFA要user pool adaptive authentication，CA11仅登录与换凭证分工，不含风险决策。',['CUR:CA11','CUR:NEW01']),
('CUR:XA047','retain',898,'Q898少开发汇原始安全数据到湖要Security Lake，NC06汇发现/控制结果不是原始日志规范化摄取。',['CUR:NC06']),
('CUR:XA048','retain',924,'Q924查IAM过度授权/unused access，CC02只教软件漏洞与行为威胁，不能推出Access Analyzer权限分析。',['CUR:CC02']),
('CUR:XA049','retain',931,'Q931订阅登记和实际SNS调用Lambda是两个目标/主体。CA08通用跨账户及CMPM06函数资源策略给出部分原则，但未完全证明SNS主题对外订阅授权能力和两个调用身份，未证可删。',['CUR:CA08','CUR:CMP-M06','GSC-080']),
('CUR:XA051','retain',966,'Q966作业权限隔离且不能取IMDSv2需要EMR runtime roles的隔离行为，普通实例profile/Pod身份不自动给同等作业边界。',['CUR:CA18','CUR:CMP-M06']),
('CUR:XA053','retain',1019,'Q1019的HTTP API资源策略支持范围是硬边界，CA19身份验证或CMPM04私网端点不教HTTP/REST功能差异；保留不代表替原题修正API类型。',['CUR:CA19','CUR:CMP-M04']),
('CUR:XA054','retain',371,'Q371实际创建加密节点卷的Auto Scaling service-linked role是独立用钥主体；EBS默认加密和Pod角色原则不说明这个执行者。原选项未明示该角色的缺口保留。',['CUR:CC09','CUR:CA18','CUR:SC01']),
('CUR:XA056','retain',382,'Q382 NLB能终止TLS及listener上部署证书的入口能力，不从ALB证书Region卡自动推到任意L4入口；保留明确NLB支持与透传差别。',['CUR:CB13','CUR:CMP-M11']),
('CUR:XB001','retain',15,'Q15实际流量检查和拦截需要Network Firewall路径，告警/镜像或中央策略管理不等于阻断；新服务能力和路由位置未被其他卡替代。',['CUR:CC02','CUR:XA007']),
('CUR:XB002','retain',19,'Q19第三方设备透明检查链需GWLB和endpoint；CMPM04 PrivateLink服务发布和TGW路由不说明GENEVE设备转发。',['CUR:CMP-M04','GSC-075']),
('CUR:XB003','retain',27,'Q27无AWS账号外部仪表板分享是专门入口及权限边界；QuickSight用户分享或IAM组权限不等于CloudWatch外部分享。',['CUR:NA02','CUR:CA09']),
('CUR:XB005','retain',60,'Q60 HTTP自动转HTTPS需要HTTP listener redirect，CB13证书终止TLS不主动改变客户端URL；独立动作不可由装证书代替。',['CUR:CB13']),
('CUR:XB008','retain',157,'Q157数据库内部操作审计与备份恢复点职责不同，NS03备份周期和CC23AWS API审计不提供PostgreSQL内部日志导出及独立保留。',['CUR:NS03','CUR:CC23']),
('CUR:XB014','retain',334,'Q334既有AD用户与SFTP保留需Transfer身份提供方/AD Connector，CMPM19只教SFTP及S3/EFS后端，不教接企业身份。',['CUR:CMP-M19','CUR:XA026'])
])
p=P/'batch03.review.json';d=rd(p);rid='CUR:XA044';c=C[rid];assoc=sorted(set(c['questionIds'])|{a['qid'] for a in A if rid in a.get('designRuleIdsIncludingPrerequisites',a['designRuleIds'])});assert assoc==[873] and close(rid,parents)==[]
def an(i,f,quote):assert quote in C[i]['visibleBody'][f];return {'cardId':i,'field':f,'quote':quote,'bodySha256':C[i]['bodySha256']}
r={'ruleId':rid,'decision':'remove','bodySha256':c['bodySha256'],'reason':'Q873真正选择的是受支持OS补丁自动执行与软件漏洞扫描组合；选项没有单独SSM Inventory服务。已教Patch Manager执行/跟踪与Inspector版本漏洞匹配足以选B，不需另记一张Inventory元数据服务卡。','allAssociatedQuestionIds':assoc,'allAssociatedQuestionsChecked':True,'prerequisiteClosure':close(rid,PG),'dependentCardClosure':close(rid,parents),'recursivePrerequisitesAndDependentsCheckedAgainst355':True,'alternativeCardIds':['CUR:CC01','CUR:CC02'],'questionChecks':[{'qid':873,'questionSha256':ch(Q['873']),'fullOriginalRead':True,'statusAfterRemoval':'SUPPORTED_no_new_gap','selectedOptionOrdinals':[2],'anchors':[an('CUR:CC01','answerZH','受支持的补丁用Systems Manager Patch Manager'),an('CUR:CC01','keyPointZH','Patch Manager按受支持的补丁目录执行与跟踪'),an('CUR:CC02','answerZH','已知软件漏洞用适用的Inspector'),an('CUR:CC02','keyPointZH','漏洞扫描匹配软件版本的已知弱点')],'derivation':'B用受管补丁执行/跟踪处理OS更新状态，用已安装软件版本漏洞匹配提供每实例漏洞审查；A SecurityHub汇聚不替代底层扫描，C/D Config不实际安装补丁，Shield/GuardDuty也不完成软件漏洞匹配。没有把完整软件资产目录部署手册作为排除干扰项所需。'}],'mutationApplied':False}
d['results'].append(r);d['counts']=dict(collections.Counter(x['decision'] for x in d['results']));d['scope']='19 retain witnesses plus1 removal: complete sole original Q873 and recursive dependencies checked with literal replacement quotes; unchanged frozen355 only.';p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print('EXPANDED',d['counts'])

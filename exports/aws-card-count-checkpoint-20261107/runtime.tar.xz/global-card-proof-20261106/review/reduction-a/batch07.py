from continue_helper import *
save(7,[
('GSC-096','retain',812,'Q812无代码/剖析/共享recipe需要DataBrew，095ETL作业和088工作流编排不提供可共享无代码清洗recipe；784可局部只用编排不等于全局可删。',['GSC-095','GSC-088']),
('GSC-097','retain',557,'Q557并行处理大数据的EMR/Spark分布式机制未由101Spectrum外部SQL或095单个ETL名称替代；Redshift接口未闭合不使并行框架判断消失。',['GSC-101','GSC-095']),
('GSC-102','retain',515,'Q515Redshift DataAPI是服务调用SQL的独立入口能力，XB013数据仓库用途不说明免传统连接的API；其他加密/时段选项缺口保留。',['CUR:XB013']),
('GSC-103','retain',804,'Q804SQL命令创建训练模型需要RedshiftML，普通分析仓库/BI图表或自建SageMaker平台不自动给SQL训练入口。',['GSC-101','GSC-109','CUR:NA02']),
('GSC-104','retain',968,'Q968原生搜索更新需OpenSearch索引，031业务属性找对象与CC03S3SQL不是全文/搜索引擎索引能力；摄取接口仍需另行回测。',['GSC-031','CUR:CC03']),
('GSC-106','retain',493,'Q493明确录音文本转英语，CMPM15转录与105情绪理解都不改变语言；Translate职责独立，不能为压张数把三种转换混进一张。',['CUR:CMP-M15','GSC-105']),
('GSC-107','retain',57,'Q57少开发图像内容审核要Rekognition预训练视觉能力，105Comprehend处理文本和108人工当前复核均不能替图像模型；它也是拟删108的替代主卡。',['GSC-105','GSC-108']),
('GSC-109','retain',687,'Q687无ML经验按历史时序预测，Forecast与自建SageMaker流程职责是必要取舍，103RedshiftSQL训练或105文本理解不覆盖；资格/预测接口缺口不自动放行。',['GSC-103','GSC-105']),
('GSC-110','retain',302,'Q302原始视频编码/码率要实际转码，不是CA13边缘缓存复制；视频转换义务真实，旧ElasticTranscoder选项时效不能抵扣为已覆盖或直接删目标。',['CUR:CA13','GSC-095']),
('GCL-003','retain',201,'Q201SMS必须有入站回复路径，不同于GCL001HTML邮件、SNS事件通知或持久流。题源Pinpoint/一年归档问题保留，不据此删除双向短信义务。',['GCL-001','CUR:XB011']),
('GSC-111','retain',219,'Q219有状态内存任务要按内存瓶颈选规格，112横向CPU伸缩或141采集内存指标不说明购买哪类资源；不能只把有监控当已选型。',['GSC-112','GSC-141']),
('GSC-117','retain',594,'Q594预备初始化实例需要warm pool，113日历提前加desired不等于已有初始化状态；Lambda预热/快照也不能直接套EC2。',['GSC-113','GSC-134','GSC-135']),
('GSC-120','retain',795,'Q795紧耦合HPC通信栈低延迟需EFA/Libfabric，121ENA普通网络能力与全球GA入口不同，不可仅用“增强网络”泛称替代OS bypass机制。',['GSC-121','CUR:NS02']),
('GSC-121','retain',746,'Q746增强网络而非多ENI数量提高适用网络能力，119cluster放置只改变节点位置，120EFA特殊HPC软件栈不能替代普通ENA选择。',['GSC-119','GSC-120']),
('GSC-123','retain',714,'Q714ALB按未完成请求忙闲分配需要least outstanding，XB041HTTP内容路由和112扩容CPU反馈不说明负载均衡算法。CloudWatch指标归因缺口仍不升级。',['CUR:XB041','GSC-112']),
('GSC-129','retain',627,'Q627托管权威DNS需hosted zone/委派，XB034Resolver向机房转发查询不会迁移权威记录；NS02流量入口不管理权威域名。',['CUR:XB034','CUR:NS02']),
('GSC-135','retain',573,'Q573非严格延迟/成本冷启动取舍要初始化快照SnapStart，134常驻预热不同机制，136资源/运行时费用不能推导快照复用。',['GSC-134','GSC-136']),
('GSC-140','retain',900,'Q900现场ECSexternal与云Fargate需ECSAnywhere，XB029现场EKS控制面不是ECS管理接口，XB019Fargate免主机管理不把计算留本地。',['CUR:XB029','CUR:XB019']),
('GSC-142','retain',695,'Q695跨微服务请求耗时关联需要分布式trace，143容器CPU日志和CC23AWSAPI审计都不把同一业务请求各调用拼起来。',['GSC-143','CUR:CC23']),
('GSC-144','retain',150,'Q150CPU且IO同时高才触发，组合alarm状态AND/OR是独立控制表达；141采集指标/145高分辨率不实现告警布尔组合。',['GSC-141','GSC-145'])
])

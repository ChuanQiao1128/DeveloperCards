import json,pathlib,hashlib,collections,datetime
P=pathlib.Path(__file__).resolve().parent;V=P.parents[1]
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
packet=rd(P/'batch01.input.json');C={c['ruleId']:c for c in packet['candidateCards']+packet['alternativeCards']};M=rd(P/'input-manifest.json')
for p,h in M.items():assert sha(p)==h
rows=[]
def anchor(rid,quote):
 c=C[rid];assert any(quote in v for v in c['visibleBody'].values());return {'cardId':rid,'quote':quote,'bodySha256':c['bodySha256']}
def add(rid,decision,reason,questions,alternatives=()):
 c=C[rid];deps=packet['all355RecursiveDependencyScan'][rid];associated=sorted(set(c['questionIds'])|set(deps['allocationQuestionIds']));assert sorted(x['qid'] for x in questions)==associated
 for q in questions:q['questionSha256']=ch(packet['questions'][str(q['qid'])]);q['fullOriginalRead']=True
 rows.append({'ruleId':rid,'decision':decision,'bodySha256':c['bodySha256'],'reason':reason,'allAssociatedQuestionIds':associated,'allAssociatedQuestionsChecked':True,'prerequisiteClosure':deps['prerequisiteClosure'],'dependentCardClosure':deps['dependentCardClosure'],'recursivePrerequisitesAndDependentsCheckedAgainst355':True,'questionChecks':questions,'alternativeCardIds':list(alternatives),'mutationApplied':False})
add('GSC-084','remove','该唯一关联题不是空ReceiveMessage优化题；可由已有消息处理租约和成功后删除规则完成判断，不必另记长轮询20秒。删除仅针对冻结关联范围，不断言长轮询机制本身没有价值。',[{'qid':98,'statusAfterRemoval':'SUPPORTED_no_new_gap','selectedOptionOrdinals':[3],'anchors':[anchor('GSC-081','检查visibility timeout是否覆盖实际处理时间'),anchor('GSC-081','超时后尚未删除的消息会重新可见'),anchor('GSC-079','消费者成功处理后再确认删除')],'derivation':'C延长正在处理消息的不可见期，避免尚未完成就被再取；D预删丢失败重试，B换FIFO不等于延长这次处理的租约，A等待接收请求也不改变已取走消息的处理租约。无需先背A的30秒为何超上限，便能按故障阶段排除它。'}],['GSC-081','GSC-079'])
add('GSC-108','remove','Q57的决定条件是图像内容审核及最少开发，人工复核是A/B共有步骤，不必为排除自行训练方案单独学习A2I资格及human review loop。',[{'qid':57,'statusAfterRemoval':'SUPPORTED_no_new_gap','selectedOptionOrdinals':[2],'anchors':[anchor('GSC-107','Amazon Rekognition对应的图像识别或内容审核能力'),anchor('GSC-107','受支持的预训练视觉分析，减少为常见识别任务自行训练模型的需要'),anchor('GSC-105','输入已经是文字')],'derivation':'B直接使用预训练图像审核，A是文本理解服务不是该输入任务，C/D自行训练/部署模型增加开发；A/B都已有低置信度交人复核，不要求新增A2I特定服务判断。保留该常识步骤，不添加未教的A2I配置。'}],['GSC-107','GSC-105'])
add('GSC-098','remove','EMR六小时批作业的闲置释放可以由现有通用计算计费规则迁移；关键节点数据职责另由GSC099承担，Q753没有EMR特定需要。',[{'qid':652,'statusAfterRemoval':'SUPPORTED_no_new_gap','selectedOptionOrdinals':[2],'anchors':[anchor('GSC-150','应按可停条件实际停止、终止或缩减相应计算容量'),anchor('GSC-150','费用取决于资源是否仍处于计费运行状态'),anchor('GSC-099','关键primary/core按可靠性要求使用稳定容量'),anchor('GSC-099','优先用于不存HDFS数据、可重新执行任务的task节点')],'derivation':'B用transient使工作结束后释放空闲EC2容量；作业运行期间稳定primary/core保护关键数据，task可重做用Spot。A长驻仍付18小时闲置费，C/D把关键core放Spot不符运行期数据可靠要求。无需向GSC150追加EMR清单。'},{'qid':753,'statusAfterRemoval':'SUPPORTED_no_new_gap','selectedOptionOrdinals':[1],'anchors':[anchor('CUR:CMP-M19','Linux共享文件接EFS'),anchor('CUR:CMP-M19','Transfer Family保留客户端协议'),anchor('GSC-001','把文件放在同一个EFS文件系统，让实例共同挂载'),anchor('GSC-113','已知日历和容量用scheduled scaling')],'derivation':'A托管SFTP并保留共享文件访问，夜间日历开可替换批计算，文件在共享EFS而非实例本地。B/C自管SFTP；D虽持久S3，但额外要求修改原文件应用拉取对象。GSC098的EMR与HDFS文字并不提供这里额外必要前提。'}],['GSC-150','GSC-099','CUR:CMP-M19','GSC-001','GSC-113'])
retain=[
('GSC-065','Q539局部可不使用，但Q1010明确包含初始复制、test acceptance及停源cutover；GSC064只区分迁移/灾备目的，GSC060仅DMS数据CDC，不能可靠替代该阶段和最终写入控制。',{539:'DRS目的选择本题可以不必用065；这只是局部省略。',1010:'保留测试不等于最终生产点、控制源写入再切换的机制；其他卡未替代此完整判断。'}),
('GSC-099','GSC146只教可恢复计算可用Spot，没有教EMR primary/core/task数据职责；不能把这个必要平台差别当作通用Spot口诀已覆盖。',{652:'保留task不存HDFS而primary/core承担控制/数据职责，否则不能解释B胜于C。'}),
('GSC-141','默认EC2没有内存指标是独立的采集前提，刷新频率/CPU瓶颈卡不提供这项事实。',{219:'C声称内置EC2内存指标；删除后无法解释C与agent方案D的差别。',276:'E内存自动伸缩另需采集，D现成CPU可用；卡112只讲策略不提供数据源。'}),
('GCL-010','托管Kubernetes节点/控制面与仅伸缩EC2主机有真实职责差别；GSC139只讲保留Kubernetes接口，不教节点生命周期维护优势。',{128:'A/B同Spot，B managed node group的运维优势必须有可见依据。'}),
('GCL-011','加权小比例路由不等于隔离新环境验证和数据同步；不能将蓝绿机制塞到DNS权重卡里减数。',{190:'并行Beanstalk环境验证后切入口是所问频繁测新功能的因果。',629:'RDS蓝绿需要保持数据同步后测试/切换，Aurora clone并不跟随写入，不能替代。'}),
('GCL-014','统一备份计划卡只说明调度和保护范围需确认，没有教EC2实例配置与仅卷快照恢复产物差别。',{312:'B/C唯一关键差别是选择EC2资源或仅卷，删除后失去配置恢复判断。',602:'EC2级备份恢复配置和附加卷支持C，不能把卷快照自动当完整实例。'}),
('GSC-053','HA与事后恢复不能推导主动阻止Delete API；保留这个安全动作判断。',{444:'误删后恢复不等于阻止删除，需删除保护。',727:'题目是DynamoDB，当前卡只写RDS的作用域缺口不因保留而闭合；既有接受/修订另行处理，不能删除必要预防义务。'}),
('GSC-022','上传multipart与下载Range GET的动作、接口方向不同；共同“并行”并不证明合并成一张无条件上传下载清单。',{690:'Choose two同时要求上传与下载吞吐，021不能替代下载多个Range GET。',759:'此题存储层/取回时限判断中可局部不使用022，但Q690仍有独立必要用途。'}),
('GCL-009','DataSync按实际NFS源location接入是本题重要协议边界；NC07托管同步一般用途没有教SFTP应用入口与底层NFS源的区别。',{102:'必须能解释合适location针对底层NFS；不得把SFTP名字当DataSync源协议。'}),
('GCL-021','网络mount target与文件访问access point承担不同机制，普通共享文件卡只说共同挂载不说明AZ入口。',{475:'明确每AZ mount target条件，不能只凭EFS名称不核网络入口。',487:'C多个mount target与D单target多个access point的差别，需要021。'}),
('GCL-030','VPC连通与Lambda文件系统配置是不同层次；GSC001泛Linux挂载不能自动替代Lambda受支持access point/本地路径配置。',{800:'当前原题还涉及跨账户集成限制，保留配置机制不等于整题充分；未找到能替代该文件配置义务的其余正文。'}),
('CUR:NS04','与XR003只有AppFlow共同服务名，S3客户管理KMS落盘要求和私有运行路径是独立条件；合并会增加一个普通卡的回忆任务。',{41:'托管SaaS→S3与上传事件通知，本题可复用基础flow用途。',460:'KMS客户管理key落盘与传输TLS不是XR003私网路径所教。',821:'本题可由XR003私网规则主担，NS04局部可省；不能据此删除460所需知识。'}),
('CUR:XR003','NS04的TLS/KMS不等于“不走公网”；private flow/PrivateLink及来源资格是独立路径条件，不硬合加密与私网两个任务。',{821:'C的私有AppFlow路径与D peering不是同义，NS04只证明安全加密flow不证明实际传输绕公网。'})]
for rid,reason,qs in retain:
 add(rid,'retain',reason,[{'qid':qid,'statusAfterRemoval':'not_proven_replaceable' if not (rid=='GSC-022' and qid==759) else 'locally_omittable_only','necessaryJudgment':text,'anchors':[]} for qid,text in qs.items()])
add('GSC-030','unknown','可能只是排除A/C弱干扰项的事件子类型细节，但必须先证明当前剩余卡组能独立解决Q139的实际复制/事件目标链。029泛创建事件不教Copy/CompleteMultipartUpload；现有缺口不能充当已被其他卡覆盖。',[{'qid':139,'statusAfterRemoval':'UNKNOWN_no_global_deletion','necessaryJudgment':'保留完整原题：复制或复制函数、S3直接目的地、EventBridge目标和ObjectCreated子类型是多个条件。未完成不依赖030的完整排他推导，不能宣布可删。','anchors':[]}])
proofs=[]
for f in [V/'review/questions-b/results.json',V/'review/questions-c/results-part01.json',V/'review/questions-c/results-part04.json']:
 assert f.exists();proofs.append({'path':str(f),'fileSha256':sha(f)})
counts=dict(collections.Counter(r['decision'] for r in rows));out={'schemaVersion':1,'reviewer':'reduction-a independent removal/merge review','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'complete_first_usable_batch_not_global_reduction_complete','inputManifestPath':str(P/'input-manifest.json'),'inputManifestSha256':sha(P/'input-manifest.json'),'inputPacketPath':str(P/'batch01.input.json'),'inputPacketSha256':sha(P/'batch01.input.json'),'counts':counts,'candidatesReviewed':len(rows),'uniqueOriginalQuestionsRead':len(packet['questions']),'allCandidateAssociatedQuestionsAndRecursiveDependenciesChecked':True,'results':rows,'priorSupportedEvidenceBindings':proofs,'noExactDuplicateBodyGroups':True,'notClaimingMathematicalMinimum':True,'current355BodyMutationApplied':False,'globalAllocationMutationApplied':False,'directCliApiCalls':0,'nativeUsage':'unknown','limits':['The3 remove dispositions are independently tested proposals against current frozen assignments, not an applied reduced package or final N.','155 low-frequency cards screened deterministically;16 of155 semantically reviewed,139 remain pending.','One additional3-question AppFlow card reviewed with its overlap partner.','Other200 higher-frequency cards have not received exhaustive semantic deletion review.','No whole1018 coverage or learner performance claim.']}
assert len(rows)==17
op=P/'batch01.review.json';op.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
queue=rd(P/'low-frequency-queue155.json');dec={x['ruleId']:x for x in rows}
for x in queue['queue']:
 if x['ruleId'] in dec:x['decision']=dec[x['ruleId']]['decision'];x['reason']=dec[x['ruleId']]['reason'];x['reviewPath']=str(op)
queue['pendingSemanticCount']=sum(x['ruleId'] not in dec for x in queue['queue']);(P/'low-frequency-dispositions.current.json').write_text(json.dumps(queue,ensure_ascii=False,indent=2)+'\n')
for p,h in M.items():assert sha(p)==h
for r in rows:
 if r['decision']=='remove':
  assert not r['dependentCardClosure'];assert r['allAssociatedQuestionsChecked'];assert all(x['statusAfterRemoval']=='SUPPORTED_no_new_gap' for x in r['questionChecks'])
  for q in r['questionChecks']:
   for a in q['anchors']:assert a['cardId']!=r['ruleId'] and any(a['quote'] in s for s in C[a['cardId']]['visibleBody'].values())
rb={'status':'PASS_integrity_readback','reviewPath':str(op),'fileSha256':sha(op),'counts':counts,'all17CandidateBodyBindings':True,'all25OriginalQuestionBindings':True,'allRemovalQuestionsAndRecursiveDependenciesChecked':True,'literalAlternativeAnchorQuotes':True,'frozenInputsUnchanged':True,'all355AndOriginal356Preserved':True,'pendingLowFrequencySemanticReview':queue['pendingSemanticCount'],'globalReducedCardCount':'not_proven','directCliApiCalls':0,'nativeUsage':'unknown'};(P/'batch01.readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rb,ensure_ascii=False))

from continue_helper import *
save(2,[
('CUR:CMP-M09','retain',3,'Q3按组织成员自动授权需要PrincipalOrgID；CA08跨账户角色和SCP账户上限不说明请求者组织条件。ResourceAccount又是资源所有者，不能硬合进角色卡。',['CUR:CA08','CUR:CMP-M05']),
('CUR:XA005','retain',82,'Q82的导入证书30天到期事件和DaysToExpiry是独立服务事件来源；NEW02已教不能自动续期，但CC17通用路由不能推导ACM会发布哪种事件。',['CUR:NEW02','CUR:CC17']),
('CUR:XA006','retain',96,'Q96必须区分用户SourceIp与实例IP，并解释目标Region的StringNotEquals。NEW05只给匹配Deny优先，不提供这些条件的对象语义。',['CUR:NEW05']),
('CUR:XA007','retain',119,'Q119跨账户多Region少维护要求Firewall Manager集中WAF分发；CB10只教在HTTP入口附webACL，不教组织范围治理。',['CUR:CB10']),
('CUR:XA008','retain',137,'Q137限定管理员收信且避免单人漏接，需要root分发邮箱与备用联系人职责；rootMFA或Organizations成员权限不能推导通知联系人。',['CUR:NEW01','CUR:CMP-M05']),
('CUR:XA011','retain',172,'Q172中间应用不可读的字段密文，TLS连接或签名访问不能替代；需要边缘公钥字段加密及下游私钥这一独立机制。',['CUR:CMP-M11','CUR:CC21']),
('CUR:XA014','retain',368,'Q368账户级IAM password policy作用范围不能由rootMFA或单用户身份策略推导；它不同于每用户配置。',['CUR:NEW01','CUR:CA09']),
('CUR:XA015','retain',387,'Q387工程师只管堆栈而服务代建资源需CloudFormation service role和PassRole；CA08跨账户AssumeRole或CMPM06运行时代码角色不等价。',['CUR:CA08','CUR:CMP-M06']),
('CUR:XA017','retain',429,'Q429关键是BoolIfExists缺失也匹配和Deny只覆盖列出动作；NEW05只教已匹配Deny优先，无法补缺失键算子语义。',['CUR:NEW05']),
('CUR:XA018','retain',442,'Q442选择性跨账户数据扩张要标签规则跟随新表；CC19行列过滤不说明LF-TBAC批量授权和LF-Tag区别。',['CUR:CC19']),
('CUR:XA020','retain',519,'Q519中央维护批准工具供客户自助启动，Service Catalog产品/portfolio是独立治理能力；XA031模板重复部署不等于授权产品目录。',['CUR:XA031']),
('CUR:XA021','retain',535,'Q535的etcd控制平面数据层与节点EBS/外部secret存储不同，需API envelope encryption。默认版本可能影响唯一选项，但不构成该层次义务已由其他卡替代。',['CUR:CMP-M08','CUR:CC09']),
('CUR:XA023','retain',560,'Q560组织OU关系漂移需要Control Tower account drift；NC05组织纳管和XA031 CloudFormation模板/堆栈漂移都不覆盖账户治理关系。',['CUR:NC05','CUR:XA031']),
('CUR:XA025','retain',586,'Q586一个账户不能同时属两组织是明确成员资格约束；SCP继承或合并账单规则不包含退出再邀请的顺序。',['CUR:CMP-M05','CUR:XA022']),
('CUR:XA026','retain',624,'Q624沿用企业AD身份要SAML federation映射角色，CA08只教已获信任身份AssumeRole，不教企业SAML与非SAML LDAP桥接。',['CUR:CA08']),
('CUR:XA027','retain',644,'Q644必须覆盖apex及一层国家子域；NEW02只教DNS验证/续期，不教通配符不覆盖apex。不能用证书名称泛化丢掉范围条件。',['CUR:NEW02','CUR:CB13']),
('CUR:XA029','retain',645,'Q645实际key必须留在外部多厂商管理器，CC05一般KMSkey权限或导入材料不能推导XKS代理密码操作和可用性责任。',['CUR:CC05']),
('CUR:XA030','retain',657,'Q657集中动态CIDR且最低费要customer-managed prefix list/RAM共享，CMPM10只说明按上一跳来源设规则，不提供共享地址对象或FMS成本差别。',['CUR:CMP-M10']),
('CUR:XA033','retain',716,'Q716公网broker与TLS认证是分层条件，公有子网不自动开启MSK public access。CMPM11通用TLS不能替代MSK入口开关；原选项完整性缺口仍保留。',['CUR:CMP-M11']),
('CUR:XA035','retain',745,'Q745要日常人员身份且保留必要root、root启MFA。NEW01只教额外MFA，CA09组权限不教避免root日常使用或不能直接以普通管理员取代root。',['CUR:NEW01','CUR:CA09'])
])

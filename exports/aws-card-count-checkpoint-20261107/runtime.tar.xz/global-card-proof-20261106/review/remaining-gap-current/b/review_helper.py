# -*- coding: utf-8 -*-
import pathlib,json,hashlib,collections,datetime
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106');O=V/'review/remaining-gap-current/b';MP=V/'review/remaining-gap-current/input/manifest2.json'
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ch(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
manifest=rd(MP)
for p,h in manifest.items():assert sha(p)==h,(p,h)
cases=rd(V/'review/remaining-gap-current/input/cases2.json');qb={x['qid']:x for x in cases};pool=rd(V/'review/remaining-gap-current/input/visible-pool.frozen.json');cards={x['ruleId']:x for x in pool}
for c in cards.values():assert ch(c['visibleBody'])==c['bodySha256']
for q in cases:
 for c in q['visibleCards']:assert c['visibleBody']==cards[c['ruleId']]['visibleBody'] and c['bodySha256']==cards[c['ruleId']]['bodySha256']
registry={}
def cite(p,needle,n,claim):
 p=pathlib.Path(p);d=rd(p);s=d['text'];st=s.index(needle);quote=s[st:st+n];e={'claim':claim,'url':d['url'],'sourcePath':str(p),'sourceFileSha256':sha(p),'sourceTextSha256':hashlib.sha256(s.encode()).hexdigest(),'quote':quote,'quoteStart':st,'quoteEnd':st+len(quote),'quoteSha256':hashlib.sha256(quote.encode()).hexdigest()};eid=ch(e);registry[eid]=e;return eid
shutdown=V/'evidence/source-a/downloads/SHUTDOWN.json'
SDEF=cite(shutdown,'Full shutdown represents the final stage',480,'Full shutdown means entirely removed and unavailable in any capacity, not only closed to new customers.')
SNOW=cite(shutdown,'AWS Snowball Edge',160,'Snowball Edge and Snowmobile full shutdown dates.')
def anchors(rid,fields=('answerZH','keyPointZH')):
 c=cards[rid];return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'quoteStart':0,'quoteEnd':len(c['visibleBody'][f]),'additionalToInitialGroup':rid not in {x['ruleId'] for x in current_case['visibleCards']}} for f in fields if c['visibleBody'].get(f)]
def make(qid,status,choice,ids,reason,missing=None,conditions=None,implementation=None,queries=None,sourceEvidenceIds=None,sourceIssues=None,findings=None):
 global current_case
 current_case=qb[qid];aa=[]
 for i in ids:
  if isinstance(i,tuple):aa+=anchors(i[0],i[1])
  else:aa+=anchors(i)
 searched=[]
 for terms in queries or []:
  hits=[rid for rid,c in cards.items() if any(t.lower() in json.dumps(c['visibleBody'],ensure_ascii=False).lower() for t in terms)];searched.append({'terms':terms,'matchedRuleIds':hits,'scope':'entire frozen visible pool; matching bodies read where relevant, not private targets'})
 pre=[];todo=list({a['ruleId'] for a in aa});seen=set()
 while todo:
  rid=todo.pop()
  if rid in seen:continue
  seen.add(rid)
  for p in cards[rid].get('prerequisiteRuleIds',[]):
   assert p in cards,(qid,rid,p);pre.append({'from':rid,'ruleId':p,'bodySha256':cards[p]['bodySha256']});todo.append(p)
 return {'qid':qid,'status':status,'selectedOptionOrdinals':choice if status=='SUPPORTED' else [],'candidateOptionOrdinals':choice,'questionSha256':ch(current_case['question']),'originalStemUtf8Sha256':hashlib.sha256(current_case['question']['stem'].encode()).hexdigest(),'originalOptionsCanonicalSha256':ch(current_case['question']['options']),'fullStemAndAllOptionsRead':True,'usedRuleIds':sorted({a['ruleId'] for a in aa}),'necessaryAnchors':aa,'reasoningAndClosestCompetitor':reason,'minimumNecessaryMissingJudgments':missing or [],'conditions':conditions or [],'implementationChecksNotNewCards':implementation or [],'wholePoolTargetedSearch':searched,'officialEvidenceIds':sourceEvidenceIds or [],'sourceIssues':sourceIssues or [],'findings':findings or [],'recursiveUsedPrerequisiteBindings':pre,'initialGroupRuleIds':[c['ruleId'] for c in current_case['visibleCards']],'noPrivateGoalOrPrintedAnswerUsed':True,'notLearnerOutcomeMeasured':True}
def write(part,rows):
 used={e for r in rows for e in r['officialEvidenceIds']}
 for r in rows:
  for a in r['necessaryAnchors']:assert cards[a['ruleId']]['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']]==a['quote']
 for p,h in manifest.items():assert sha(p)==h
 policy=V/'inputs/user-source-correction-policy-accepted.json'
 j={'schemaVersion':1,'reviewer':'remaining-gap-current/b independent actual-visible-card reviewer','part':part,'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(MP),'inputManifestSha256':sha(MP),'inputHashes':manifest,'newSourceCorrectionPolicyPath':str(policy),'newSourceCorrectionPolicySha256':sha(policy),'newSourceCorrectionPolicy':rd(policy),'scope':'original questions only; corrected practice variants not authored or accepted here','counts':dict(collections.Counter(r['status'] for r in rows)),'results':rows,'officialEvidenceRegistry':{x:registry[x] for x in sorted(used)},'currentMutationApplied':False,'cardAcceptanceOrFinalNVerified':False,'directCliApiCalls':0,'nativeUsage':'unknown'};p=O/f'results-part{part:02}.json';p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');print(part,len(rows),j['counts'],sha(p))

# Q949 source transcription review

Confirmed: option C is already truncated in the original PDF, ending “to establish.” on page1868. The next visible line is option D. The complete page render and independent pypdf/pdfplumber extraction agree; there is no clipped margin, wrapped continuation or next-page tail.

The normalized question preserved this source defect. Original PDF SHA256:098c3747706ef9d7bd73c3a920818d51711afb07ee3d7e9c9b89f44354590e6c.

Preserve original sources. A separate minimum corrected exercise may replace only the incomplete C distractor, preserving the stem, A/B/D and private-SaaS learning goal. Do not guess an omitted phrase: a plausible one-way-connection completion may make both C and D true. The replacement needs its own official-fact check and independent current-card review. No exercise was authored or accepted here, and no original-question status was promoted. Printed answers and community discussion were not used for this source-only finding.

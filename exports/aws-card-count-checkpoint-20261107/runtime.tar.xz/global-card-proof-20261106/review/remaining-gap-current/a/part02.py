# -*- coding: utf-8 -*-
from write_review import write
write(2,[
(323,'SUPPORTED',[2],['CUR:CA17','CUR:XB013'],'托管HTTPS API→Lambda处理→DynamoDB在线记录，B避免单EC2入口/计算单点；Route53只解析不提供函数HTTP调用，gatewayendpoint不能延伸机房VPN直接访问S3路径。结果可按数据库访问路径提供给分析团队，不必为每个报表另背菜单。',[],[],[]),
(350,'UNKNOWN',[1,2,3],['CUR:CB01','GSC-046','GSC-047'],'A的MultiAZ解决HA，C只读端点卸载报表方向。原SQLServer未给readreplica适用版本/edition，卡也未明其范围；且报表只每年数次，B快照恢复出的副本若接受该时点数据亦可隔离事务，原题没给新鲜度/成本限制唯一排除。暂不把A+C当完整唯一证明。',[],['确认SQLServer replica支持范围及报表是否须跟随当前数据；静态恢复点不等于持续副本。'],[]),
(355,'INSUFFICIENT_CARDS',[4],['VC-002','GSC-133','CUR:XB019','GSC-097'],'VC002已教Batch按资源调度/容器封依赖，故不再报Batch目的基础缺口。64vCPU/512GiB的硬尺度仍须核Fargate单任务资源范围，现卡只泛称匹配资源，不能凭15分钟就选Lambda或Fargate；D候选。',['Fargate实际单任务CPU/内存边界，解释此64vCPU/512GiB为何需EC2等匹配资源。'],[],['按真实程序选择EC2容量并核15分钟目标；未部署实测不另造SLA卡。']),
(366,'SOURCE_ISSUE',[],['CUR:CA11','CUR:CA19','CUR:CMP-M06'],'只准付费订阅者应在真实认证后做授权。DAPIkeys/usageplans只识别计量限流不作认证，A缓存/限流不识别付款，WAF规则没有给可靠订阅身份来源，C共享函数角色的DDB权限不能直接区分Cognito每用户订阅。给定项没有完整付费准入方案，不用改APIkey教学来迎合。',[],[],[]),
(372,'SUPPORTED',[2],['GSC-041','CUR:NA05','CUR:XB013'],'高分辨率正文存多AZS3，DynamoDB以地理code存引用，高并发按键更新/读，B；整张大图塞DDB受载荷限制，RDSOracle装图或仅索引都比简单键访问多关系平台管理，DAX不解决巨大图像载荷/写流量。',[],[],[]),
(390,'UNKNOWN',[2,4],['CUR:NB08','CUR:XB013','GSC-032'],'B的DynamoDB外置会话可持久保存；DRedis外置可跨Web主机退出保留，但现卡只教replication/failover，不证明durably的持久性与丢失边界。sticky/Cognito登录/SSM不替订单会话数据存储。需核题所指durability与Redis配置范围，不能用HA字样代替。',[],['若durably要求故障后已确认会话不丢，必须有真实Redis持久性依据，不能只凭跨AZ内存副本。'],[]),
(398,'CONDITIONAL',[3],['GSC-077','CUR:CMP-M11','CUR:NB01'],'600TB/100Mbps理想约556天远超两周，A/B不能突破链路；多设备离线C成本/时限方向。D临时10Gbps新专线多固定建设，原文不给现成线路。当前Snowball订购资格需确认，不能当任意新客户可买。',[],['具当前SnowballEdge客户订购资格；否则C不可直接采用。'],['按当前设备容量/交付导入留两周窗口并落实加密；不是未实下单就新增运输SLA卡。']),
(402,'INSUFFICIENT_CARDS',[1],['GSC-091'],'retention决定旧记录是否可重读，非shard或S3versioning；A方向。隔日消费为何超过default，仍需默认24小时范围，现卡只写有限窗口没给默认界线，新增两机制不修此点。',['Kinesis默认保留24小时与可延长窗口的实际边界，放回retention判断。'],[],[]),
(404,'SUPPORTED',[4],['GSC-029','GSC-079','VC-001','GSC-134'],'S3事件送SQS持久缓冲，Lambda事件源映射受管取消息/成功删除，D承受突发并可限并发；单纯延长timeout、复制桶或加函数不构成可靠积压与确认机制。',[],[],['按负载配置Lambda并发/visibility/批处理重试；不用未知所有根因阻止该最佳架构改进。']),
(418,'CONDITIONAL',[2],['CUR:CA08','CUR:CA09'],'B信任development account是正确目标角色侧授权；管理员全权/关BPA不符合最小权限，新用户另发凭据多管理。CA08同时要求调用身份获准AssumeRole，原只说dev组有S3权限，不保证已有该调用权限。',[],['dev调用用户/组还须允许AssumeRole到该受限生产角色；仅B的trust一侧不自动完成跨账户授权。'],[]),
(424,'CONDITIONAL',[2],['GSC-147','GSC-155','GSC-146'],'稳定前台匹配预留承诺；Spot适用于后端可恢复额外容量时B省费。短时/数量变化不等于能中断，A按需Fargate在不可中断时仍是候选，不能从动态一词补容错前提。',[],['后端任务能容忍Spot回收并重做/续跑，才可选B。'],[]),
(431,'INSUFFICIENT_CARDS',[2],['GSC-034','GSC-032','CUR:NB08'],'Redis sortedset维护前十排名已有教学，B比普通缓存/CF/报表SQL更直接。但题还要停止后恢复分数，当前全池只有外置Web会话/复制接管，没有Redis备份/恢复与数据保留机制；不能由计算排名推出来。',['Redis支持何种适用备份/恢复与停止后恢复分数的能力和边界；先用既有规则澄清，不强拼完整缓存配置表。'],[],[]),
(440,'INSUFFICIENT_CARDS',[1,3],['GCL-019','GSC-048'],'C的SQLdump可取回后用客户端逻辑导入，不应误说S3放文件即原生物理restore；DMS不直接导任意native快照/dump。A仍需实际RDSMySQL快照迁AuroraMySQL兼容支持，泛称相应快照恢复不能证明跨产品范围。',['RDS for MySQL原生兼容快照可迁为Aurora MySQL的范围。'],[],[]),
(443,'UNKNOWN',[1,3],['GSC-023','CUR:CA13','CUR:CA16'],'S3TA优化全球大文件上传，CloudFront边缘承接HTTP/下载，EC2ASG可跑动态服务。原文未说应用是否纯静态或有服务器逻辑，A的“host application onS3”是否合适未明；C也没给实际S3上传路径/费用模型，不能从全球二字断言唯一最优。',[],['明确应用运行模型和上传目的地/大小路径；不把S3TA当动态Web计算或下载缓存。'],[]),
(451,'CONDITIONAL',[2,3,6],['CUR:CC22','CUR:CMP-M11','CUR:XB019'],'客户配RDS实例/维护窗口、专线仍须自己落实传输加密，B/F；RDS底层平台与物理安全不是客户。C宿主机补丁/IDS在ECS EC2承载下由客户管，Fargate收回底层OS权限，未指定launchtype不能泛化C。',[],['ECS采用EC2承载时C成立；不套到Fargate宿主机。'],[]),
(458,'INSUFFICIENT_CARDS',[2,3],['CUR:CA17','CUR:CC22','GSC-133'],'托管API函数+关系RDS比EC2/EKS少平台维护，B/C方向；但硬要求1GBmemory/2GB计算存储需Lambda实际资源支持，当前卡未给可配置/tmp范围，不能只因为短函数合适就忽略2GB临时盘。',['Lambda可配置临时/tmp满足2GB，并与持久数据分开的实际范围。'],[],[]),
(485,'INSUFFICIENT_CARDS',[1,3,4],['CUR:CMP-M01','GSC-024'],'冷档可等恢复时有归档经济方向，但必须最多5分钟参与判断。当前卡没教Glacier Expedited的通常取回窗口/容量与例外，不能仅看Expedited名词判A保证硬上限；C/D即时层成本与可用性也须比较。',['Glacier Flexible Expedited实际取回窗口、容量条件与非任意对象硬SLA边界；结合即时IA成本判断，不写绝对“归档总能5分钟”。'],['原题未给多AZ耐久要求、对象大小/取回量，A与IA的绝对最低成本还不能无条件定。'],[]),
(486,'INSUFFICIENT_CARDS',[1],['CUR:CA16','CUR:XB019','CUR:CC22','GCL-010','GSC-139'],'S3静态+托管Fargate+RDS可定A/C；关键差是ECS与EKS两种Fargate编排。现卡教保Kubernetes接口时EKS必要，却没说明无该要求时ECS/EKS管理/控制面费用差异；不能只凭名称证明A降低成本。',['无Kubernetes接口要求时ECS与EKS Fargate编排的实际运维/控制面成本取舍，先补现有容器平台判断。'],[],[]),
(489,'INSUFFICIENT_CARDS',[3],['GSC-079','GSC-083','VC-001'],'失败通知应留DLQ而非放在发布之前队列，C方向；但现卡只教SQS工作队列DLQ，未教SNS订阅DLQ实际只支持SQS目标、及14天保留窗口。不能把所有死信目标Kinesis/DDB当同样受支持。',['SNS订阅失败DLQ→SQS的实际目标范围与SQS最长14天保留。'],[],[]),
])

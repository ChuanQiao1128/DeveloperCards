# -*- coding: utf-8 -*-
from write_review import write
write(1,[
(19,'CONDITIONAL',[4],['CUR:XB002'],'GWLB+应用侧endpoint及路由透明送检，D方向，ALB/NLB不是同一IP透明检查平台，TGW只转路由不自动把流量交设备。原文仅说设备接受IP，卡明确这不证明GENEVE兼容。',[],['既有设备须支持GWLB的GENEVE，不能从普通IP接口推出。'],['配置应用入口到GWLBendpoint的实际路由。']),
(64,'CONDITIONAL',[4],['CUR:CA15','GCL-008','GSC-012'],'云端FSx保存Windows共享，本地FSxFileGateway缓存供机房低延迟读取，D保持双端文件访问。A机房每次远程取，B/C的S3Gateway后端对象与FSx Windows语义不同。现卡明确FSxFileGateway既有资格，原题未给。',[],['具FSxFileGateway现行使用资格及环境支持；不是全面退役豁免。'],[]),
(78,'INSUFFICIENT_CARDS',[2],['CUR:NS03','CUR:NB04','GSC-047'],'7年历史需长期恢复点，PITR短窗口不等于多年历史，B托管计划比自写Lambda少运维。当前卡只泛称AWSBackup跨受支持服务，未给DynamoDB长期计划/保留支持；不能由原选项或审核者记忆补事实。',['AWS Backup对DynamoDB的周期备份与多年保留范围；补在统一备份工具判断，不自动新卡。'],[],[]),
(104,'SUPPORTED',[1,3],['CUR:CMP-M22','CUR:CA13','CUR:CC02'],'ShieldAdvanced检测缓解DDoS，CloudFront边缘承接HTTP静动态内容，A/C。GuardDuty发现不自动封源；上千随机IP不适持续改有限NACL，Spot不保关键前台稳定。',[],[],['按实际公网入口登记Shield保护并配置源站；此架构选择不等于已实测绝对零停机。']),
(127,'UNKNOWN',[1,4],['GSC-014','CUR:NA05','CUR:CMP-M01','GSC-015'],'S3长期媒体/Glacier冷档方向可定；A/D差EBS与instanceStore。现卡只在可重建临时本机工作集下推荐instanceStore，原题未明10TB是否可丢/可重建，也未给IO模式或规格来证明全局最大性能。不能新增“instanceStore永远最快”规则。',[],['明确10TB工作数据持久性/可重建性与IO模式，A/D性能不能无条件比较。'],[]),
(133,'INSUFFICIENT_CARDS',[1],['GSC-049','GSC-045','CUR:CC22'],'普通RDS不给底层OS，Custom虽保部分控制，但当前官方不支持创建cross-Region RDSCustomOracle replica。A自管Oracle跨Region复制为可行候选；现卡没教该Custom复制限制，不能凭Custom名字给C PASS。',['RDS Custom for Oracle不支持创建跨Region受管replica的实际范围；据此选择EC2自管DR，不把2027停止日误当当前已退役。'],[],['自管原生Oracle复制与引擎版本/授权另按实际配置。']),
(139,'INSUFFICIENT_CARDS',[2,4],['CUR:CC17','GSC-029','GSC-030','CUR:NEW04'],'S3直接通知不把SageMakerPipelines作为原生目标，需EventBridge路由目标，B/D方向；大文件Copy/完成分块不能只盯Put已有教学。全池仍未教EventBridge→Pipelines支持范围，也未明确复制对象是否产生所用ObjectCreated事件，因此B的代码Copy与D托管replication尚不能闭合最少运维选择。',['S3真实创建/replica事件范围与EventBridge可启动SageMakerPipelines的目标能力；先核官方机制，不增加同义事件卡。'],['复制后的事件与显式CopyObject不能仅凭“新增”视为同一路径。'],[]),
(141,'UNKNOWN',[1,2],['CUR:CA13','CUR:XB032','GSC-132'],'A边缘缓存与连接优化，B把动态业务源放两Region；当前卡说明动态仍回源、DNS按网络延迟选择。未给动态比例/用户分布/源站计算与复制，无法证明任一方案对所有用户绝对最低；C绕开动态边缘，D按国家不是网络延迟。',[],['待实际动态/缓存需求和区域延迟比较；不新增“所有全球网站永远单RegionCF”口诀。'],[]),
(148,'INSUFFICIENT_CARDS',[4],['GSC-079','GSC-083','VC-001','GSC-080'],'失败持久保留后再处理比仅增加重试次数可靠，D方向；VC001已教SQS→Lambda处理，不再报轮询缺口。但当前卡未教SNS→Lambda异步接收成功后函数失败与SNS投递失败的区别，也没教Lambda on-failure目的地SQS，不能把queueDLQ规则直接套异步函数。',['Lambda异步失败目的地到SQS，以及SNS投递重试与函数处理失败的边界；复用失败保留规则。'],[],['目的地消息须正确解析重放，并保持幂等，单独存在队列不等于错误已修复。']),
(168,'SUPPORTED',[4],['CUR:CMP-M05'],'组织SCP在root/OU继承设置成员账户操作上限，D可统一维护；ACL/SG不管AWSAPI权限，cross-accountrole只约束使用该角色者。',[],[],['受限账户为成员账户；管理账户不受SCP约束，按卡保留边界。']),
(177,'SOURCE_ISSUE',[],['GSC-036'],'DAX是匹配DynamoDB重读的缓存方向B，但原文禁止重新配置应用；官方要求DAX客户端/cluster endpoint的最小配置改变。其他缓存同样需接入，globaltables不是不改客户端的透明读缓存，不能把minimalchanges说成zerochanges。',[],[],[]),
(201,'UNKNOWN',[1,2],['GCL-003','GSC-091','CUR:NS01'],'必须双向SMS+实际一年持久归档；当前卡双向能力为EndUserMessaging，Pinpointjourney官方已停。AConnect当前SMS路径及一年存储仍未由卡/官方完整闭合，不能因为B过时就整个题自动豁免，也不能把Kinesis保留名字当一年归档。',[],['原Bjourney过时另记；A真实接收及长期归档路径待查。'],[]),
(228,'SUPPORTED',[3],['GSC-079','VC-001','GSC-134','CUR:CB18'],'SQS持久缓冲写峰，事件源映射取消息/成功删除，限制Lambda并发可把数据库写入连接压力控制在适用范围，C。SNS并行直调无同等工作积压，RDSstandby不能一起写，单加内存不解决突发连接/不丢队列。',[],[],['按现卡设置处理并发、批大小和visibility，成功提交再确认/幂等；Proxy可按需复用但不冒称C已自动建Proxy。']),
(235,'CONDITIONAL',[3],['GSC-060','GSC-061'],'异构迁移先schema转换再全量+CDC所有表，C比DataSync或仅最大表正确；但单向CDC不解决两边同表并写。逐应用迁移若仍统一写原库可用，若新旧应用分别写两库需另有冲突/同步策略，不能暗自假设。',[],['明确阶段内唯一写方向或经证实的双向冲突策略；不把“选全部表”当自动双向同步。'],[]),
(240,'INSUFFICIENT_CARDS',[4],['GSC-078','CUR:NB01'],'计算移近50MB结果，仅500KB页面出站可推B/D；专线不走公网不等于本身单价更低。现卡没教DX与Internet适用DTO单价比较，D候选仍缺决定性经济事实。',['既有DX场景比较相应Region/接入地点DTO单价与Internet；不能泛化所有量级/免费档永远DX便宜。'],[],[]),
(284,'CONDITIONAL',[2],['GSC-153','GSC-154'],'CostExplorer现成报表B比自建查询/原始账单最少操作；但按用户列账单须已有用户/部门归属标签或等价数据，当前卡已教激活/历史范围，不需要添同义新卡。',[],['实际可用归属维度须存在；IAM用户不是所有资源费用天然归属列。'],[]),
(295,'CONDITIONAL',[2],['CUR:XR001','CUR:NA05'],'读取路径按应用即时脱敏，用ObjectLambda不存三套大副本，B；DynamoDB/代理或预生成多份更多开发/存储。当前卡限定既有使用资格，原题未说明，不能无条件推荐给新客户。',[],['具ObjectLambda现行使用资格；该资格限制不是全面退役。'],[]),
(300,'CONDITIONAL',[3],['GSC-147','GSC-155','GSC-054','GSC-050','CUR:CC22'],'24x7稳定用量用计算/DB预留承诺可由现卡迁移，Aurora存储增长方向C；但原legacydatabase未给引擎，不能从泛称数据库推出MySQL/PostgreSQL兼容。Spot/对象模型不保既有关系应用。',[],['原库引擎/功能须在Aurora兼容范围，否则C不能直接成立。'],[]),
(302,'CONDITIONAL',[1,5],['CUR:CA13','GSC-110'],'先转码再边缘分发可由卡推导。ElasticTranscoder已过停止支持日，历史A+C不能当前推荐；现行给定选项A+E可转码分发，但教学卡已教MediaConvert而非维护EC2转码集群，保留历史服务纠错与当前组合差异，不冒升原历史答案。',[],['保留官方确认旧C过时及独立现行替代提案；现代低运维练习应另用MediaConvert选项并独立回测。'],[]),
(321,'UNKNOWN',[4],['CUR:CMP-M11','CUR:CMP-M03','CUR:CMP-M20'],'D的server-side-encryption header与静态加密有关；C只强制传输TLS，ACL是访问权限。原问题没说静态/传输或指定加密方式；当前默认S3加密与是否须显式header尚未在卡面完整教明，不能把今天未发header一概说成对象未加密，也不能无证仅按旧题年代表免。',[],['核对当前S3默认静态加密及原题所需“显式请求头”是否真实需求；此处不确认原题错误或擅自改题。'],[]),
])

# -*- coding: utf-8 -*-
import pathlib,json,hashlib,datetime,collections,shutil,sys,re
from write_review import D,V,I,Q,C,sha
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat();E=D/'evidence';E.mkdir(exist_ok=True)
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def ex(key,p,start,end):
 p=pathlib.Path(p);d=json.loads(p.read_text());t=d['text'];s=t.index(start);e=t.index(end,s)+len(end);target=E/(key+'.snapshot.json')
 if p!=target:shutil.copyfile(p,target)
 return dict(url=d.get('finalUrl') or d['url'],quote=t[s:e],quoteStart=s,quoteEnd=e,snapshotPath=str(target),snapshotSha256=sha(target.read_bytes()),textSha256=sha(t.encode()))
# Reuse only exact, previously semantically selected official paragraphs, then verify every binding below.
prior=json.loads((V/'review/gap-b/official-evidence.json').read_text())['evidence']
keys=['retention','aurora-mysql-snapshot','lambda-storage','dlm-copy','backup-copy','forecast','function-none','eks-connector','hibernate','nlb','ddb-schema','neptune','dx-rate','transcoder-end','pinpoint-end','redshift-cse','ecs-no-fee']
EV={k:prior[k] for k in keys}
EV['custom-no-cross-region']=ex('custom-no-cross-region',E/'custom-limit.json',"You can't create cross-Region RDS Custom for Oracle replicas.","You can't create cross-Region RDS Custom for Oracle replicas.")
EV['dax-client-change']=ex('dax-client-change',E/'dax-client-modify.json','To modify your program, replace the DynamoDB client with a DAX client.','To modify your program, replace the DynamoDB client with a DAX client.')
EV['dax-endpoint-change']=ex('dax-endpoint',V/'evidence/gap-a/fetch-dax-client.json','Run the programs again, but this time, specify the cluster endpoint','command line parameter.')
EV['s3-default-current']=ex('s3-default-current',E/'s3-default.json','Amazon S3 now applies server-side encryption','have default encryption configured.')
EV['ecs-eks-cost']=ex('eks-control-plane',E/'eks-pricing.json','Kubernetes Version Support Tier\nPricing','Standard Kubernetes version support + $0.50 per cluster per hour)')
EV['redis-backup']=ex('redis-backup',E/'cache-backup.json','Amazon ElastiCache caches running Valkey, Redis OSS, or Serverless Memcached','durable storage.')
EV['sqs-retention']=ex('sqs-retention',E/'sqs-quotas.json','Message retention\nBy default, a message is retained','The maximum is 1,209,600 seconds (14 days).')
EV['lambda-async-destination']=ex('lambda-async-destination',V/'evidence/gap-a/fetch-lambda-dest.json','Lambda can send records of asynchronous invocations','events that fail all processing attempts.')
EV['sns-dlq']=ex('sns-dlq',V/'evidence/gap-a/fetch-sns-dlq.json','A dead-letter queue is an Amazon SQS queue','further analysis or reprocessing.')
EV['api-key-not-auth']=ex('api-key-not-auth',V/'evidence/gap-a/fetch-api-keys.json',"Don't use API keys for authentication or authorization",'role, a Lambda authorizer, or an Amazon Cognito user pool.')
EV['eventbridge-pipeline']=ex('eventbridge-pipeline',V/'evidence/gap-a/fetch-eventbridge-targets.json','SageMaker AI Pipeline','SageMaker AI Pipeline')
EV['ddb-backup']=ex('ddb-backup',V/'evidence/gap-a/fetch-backup-dynamo.json','AWS Backup supports additional, advanced features','features enabled by default.')
EV['backup-long-snapshot']=ex('backup-long-snapshot',V/'evidence/gap-a/fetch-backup-continuous.json','Alternatively, snapshot backups can be taken','Snapshot backups can be stored for up to a maximum of 100 years.')
EV['fargate-table']=ex('fargate-table',V/'review/gap-b/evidence/fargate-cpu.json','CPU value\nMemory value','60 GB, 120 GB, 244 GB\nLinux')
sys.path.insert(0,str(V/'review/gap-b'));from source_tools import pool
p=[x['path'] for x in pool() if x['url'].endswith('glacier-storage-classes.html')][0]
EV['expedited-window']=ex('expedited-window',p,'Expedited retrieval – Typically restores the object in 1–5 minutes.','we recommend that you purchase provisioned retrieval capacity.')
p=V/'evidence/gap-a/fetch-s3-noncurrent.json';t=json.loads(p.read_text())['text'];st=t.index('NoncurrentVersionExpiration action');en=t.index('Delayed removal',st);sub=t[st:en]
# Keep the complete expiration (not transition) paragraph; the snapshot includes its filter/age conditions.
EV['noncurrent-count']=ex('noncurrent-count',p,sub[:100],sub[-120:])
rows=[x for p in sorted(D.glob('results-part*.json')) for x in json.loads(p.read_text())['results']];R={x['qid']:x for x in rows}
assert len(rows)==58 and len(R)==58
# Each request is a minimum missing judgment, never a new-card count or authorization.
requests=[]
def req(rid,qs,ids,text,ev,terms,kind='clarify_existing'):
 requests.append(dict(requestId=rid,qids=qs,targetRuleIds=ids,status='PROPOSED_NOT_AUTHORED',kind=kind,minimumClarification=text,evidenceKeys=ev,poolSearchTerms=terms,newCardRequired=None,scope='优先复用/精炼现有卡；只有独立必要能力仍不可迁移时才由主流程决定，不能按请求数累计卡数。'))
req('RGA-01',[78],['CUR:NS03'],'AWSBackup对DynamoDB周期备份/多年保留的真实范围。',['ddb-backup','backup-long-snapshot'],['AWS Backup','DynamoDB','备份'])
req('RGA-02',[133],['GSC-049'],'RDSCustomOracle不能创建受管跨Regionreplica，需据受支持DR方式选择Custom或EC2。',['custom-no-cross-region'],['Custom','Oracle','replica','跨Region'])
req('RGA-03',[139],['CUR:CC17','GSC-030'],'EventBridge可启动SageMakerPipelines及S3实际创建事件范围；replica事件与CopyObject需先核清，不能把未证复制事件边界直接写入卡。',['eventbridge-pipeline'],['Pipelines','EventBridge','复制','ObjectCreated'])
req('RGA-04',[148],['GSC-083'],'Lambda异步失败目的地可SQS，区分SNS投递与异步函数处理失败。',['lambda-async-destination','sns-dlq'],['Lambda','失败','死信'])
req('RGA-05',[240],['GSC-078','CUR:NB01'],'DX与Internet按实际Region/地点/档位比较DTO，专线隔离本身不证明永远低价。',['dx-rate'],['Direct Connect','费用','传输'])
req('RGA-06',[355],['CUR:XB019'],'Fargate单任务CPU/内存实际资源边界；新Batch机制已教，不重复新增。',['fargate-table'],['Fargate','资源','CPU'])
req('RGA-07',[402],['GSC-091'],'Kinesis默认24小时保留与可延长窗口。',['retention'],['Kinesis','retention','24'])
req('RGA-08',[431],['GSC-034','GSC-032'],'Redis可通过快照备份/恢复保存分数；这不证明任意停止/失败无数据丢失。',['redis-backup'],['Redis','恢复','备份','持久'])
req('RGA-09',[440],['GCL-019'],'兼容版本的RDSMySQL原生快照可迁为AuroraMySQL。',['aurora-mysql-snapshot'],['Aurora','快照','MySQL'])
req('RGA-10',[458],['GSC-133'],'Lambda可配置/tmp足2GB的实际临时存储范围。',['lambda-storage'],['Lambda','临时','存储'])
req('RGA-11',[485],['CUR:CMP-M01'],'GlacierExpedited通常1–5分钟及供给容量条件，不当任意对象硬5分钟保证。',['expedited-window'],['Expedited','Glacier','分钟'])
req('RGA-12',[486],['CUR:XB019','GCL-010'],'无Kubernetes要求时ECS/EKS Fargate编排的控制面费用与维护取舍。',['ecs-no-fee','ecs-eks-cost'],['ECS','EKS','费用','控制面'])
req('RGA-13',[489],['GSC-083'],'SNS订阅死信目标SQS及最长14天保留，区分放在发布前的队列。',['sns-dlq','sqs-retention'],['SNS','死信','14'])
req('RGA-14',[498],['GSC-026'],'Lifecycle按新非当前版本数保留、当前版计数及年龄/异步执行条件。',['noncurrent-count'],['版本','数量','NewerNoncurrentVersions'])
req('RGA-15',[508],['CUR:NS03','GCL-014'],'DLM管理AMI并跨区copy，AWSBackup实例备份原生copy规则范围。',['dlm-copy','backup-copy'],['AMI','跨Region','AWS Backup'])
req('RGA-16',[525],['GSC-153'],'CostExplorer月粒度预测12个月，日粒度不同窗口。',['forecast'],['Cost Explorer','预测','12'])
req('RGA-17',[531],['CUR:XB012'],'functionURL NONE与AWS_IAM认证及第三方webhook自定义验证的区别。',['function-none'],['function URL','NONE','AWS_IAM'])
req('RGA-18',[563],[],'EKSConnector注册外部Kubernetes供EKS控制台查看的独立用途/边界。',['eks-connector'],['Connector','Kubernetes','查看'],'deferred_independent_task')
req('RGA-19',[594],['GSC-117'],'Hibernation将RAM存EBS并恢复内存/进程，区别普通Stopped预热池。',['hibernate'],['hibernation','RAM','内存'])
req('RGA-20',[600],['CUR:XB041'],'NLB产品面向百万级请求/秒低延迟，不等于任意配置无限吞吐。',['nlb'],['NLB','百万','请求'])
req('RGA-21',[622],['GSC-038'],'DynamoDB除主键外每项属性可不同的schema演进机制。',['ddb-schema'],['DynamoDB','schema','属性'])
req('RGA-22',[631],['GSC-042','CUR:NC11'],'NeptuneStreams原生图变更日志供应用读取。',['neptune'],['Neptune','Streams','更改'])
for x in rows:
 x['minimumClarificationRequestIds']=[r['requestId'] for r in requests if x['qid'] in r['qids']]
 x['officialEvidenceKeys']=list(dict.fromkeys(k for r in requests if x['qid'] in r['qids'] for k in r['evidenceKeys']))
 x['prerequisiteBindings']=[dict(ruleId=k,bodySha256=C[k]['bodySha256'],prerequisites=[dict(ruleId=p,bodySha256=C[p]['bodySha256']) for p in C[k].get('prerequisiteRuleIds',[])]) for k in x['usedRuleIds']]
for q,keys in {177:['dax-client-change','dax-endpoint-change'],366:['api-key-not-auth'],201:['pinpoint-end'],302:['transcoder-end'],321:['s3-default-current'],515:['redshift-cse']}.items():R[q]['officialEvidenceKeys']+=keys
# Full-pool retrieval audit. Matches are navigation evidence, not semantic proof of support.
queries=[]
for r in requests:
 matches=[]
 for k,c in C.items():
  hit=[f for f,t in c['visibleBody'].items() if any(term.lower() in t.lower() for term in r['poolSearchTerms'])]
  if hit:matches.append(dict(ruleId=k,bodySha256=c['bodySha256'],matchedFields=hit))
 queries.append(dict(requestId=r['requestId'],poolCount=357,terms=r['poolSearchTerms'],matchingCards=matches,semanticDisposition='已检查匹配正文与相关现有规则后保留最小缺口，字符串命中不等于该能力已教。'))
policy=V/'inputs/user-source-correction-policy-accepted.json';shutil.copyfile(policy,D/policy.name)
# Minimal proposals are separately identified new exercises, not asserted original intent/printed answers.
variants=[]
x=json.loads(json.dumps(Q[177]['question']));x['stem']=x['stem'].replace('without reconfiguring the application','with only minimal client configuration changes')
variants.append(dict(variantId='RGA-Q177-CORR-PROPOSED01',originalQid=177,originalQuestionSha256=R[177]['questionSha256'],isNewExercise=True,status='PROPOSED_PENDING_INDEPENDENT_CURRENT_CARD_REVIEW',change='仅将禁止应用重新配置改成允许最小客户端配置；保留其余原场景/所有选项。',question=x,evidenceKeys=['dax-client-change','dax-endpoint-change'],originalStatusRemains='SOURCE_ISSUE',notClaimedOriginalIntentOrPrintedAnswer=True))
x=json.loads(json.dumps(Q[366]['question']));x['options'][3]['text']="D. Configure a Lambda authorizer to validate the Cognito token and the user's current subscription before authorizing premium API requests."
variants.append(dict(variantId='RGA-Q366-CORR-PROPOSED01',originalQid=366,originalQuestionSha256=R[366]['questionSha256'],isNewExercise=True,status='PROPOSED_PENDING_INDEPENDENT_CURRENT_CARD_REVIEW',change='只替换原D的APIkey授权动作，保留订阅准入目标、原题干及其他选项；这是新练习，不冒称原印刷答案。',question=x,evidenceKeys=['api-key-not-auth'],originalStatusRemains='SOURCE_ISSUE',notClaimedOriginalIntentOrPrintedAnswer=True))
findings=[]
for q,keys,kind in [(177,['dax-client-change','dax-endpoint-change'],'literal_no_reconfiguration_conflict'),(366,['api-key-not-auth'],'usage_plan_is_not_subscription_authorization')]:
 findings.append(dict(qid=q,status=R[q]['status'],kind=kind,originalQuestion=Q[q]['question'],questionSha256=R[q]['questionSha256'],evidenceKeys=keys,conclusion=R[q]['reasoningAndClosestCompetitor'],originalPreserved=True,originalNeverUpgradedByVariant=True,correctedVariantId=next(v['variantId'] for v in variants if v['originalQid']==q)))
for q,keys,note in [(201,['pinpoint-end'],'仅原Bjourney官方确认过时，A仍待核；不豁免整个UNKNOWN。'),(302,['transcoder-end'],'原C服务已停止；保留历史和现行替代去向，原题未升级。'),(321,['s3-default-current'],'当前S3新上传自动静态加密正证已找到，但原题加密语义/是否强制显式头未明，保留UNKNOWN，不自动确认整题过时。'),(515,['redshift-cse'],'只证明COPY/UNLOAD旧CSE停止，不证明应用侧加密值全部不可能。')]:findings.append(dict(qid=q,status=R[q]['status'],originalQuestion=Q[q]['question'],questionSha256=R[q]['questionSha256'],evidenceKeys=keys,conclusion=note,originalPreserved=True,scopeExemptionApplied=False))
manifest=json.loads((I/'manifest1.json').read_text());finalmanifest=dict(originalManifestPath=str(I/'manifest1.json'),originalManifestSha256=sha((I/'manifest1.json').read_bytes()),originalFrozenInputs=manifest,additionalUserPolicyPath=str(D/policy.name),additionalUserPolicySha256=sha((D/policy.name).read_bytes()),finalizedAtUtc=NOW)
dump(D/'manifest-final.json',finalmanifest)
counts=dict(collections.Counter(x['status'] for x in rows));pending=[x['qid'] for x in rows if x['status']!='SUPPORTED']
dump(D/'official-evidence.json',dict(schemaVersion=1,evidence=EV,scope='只为具体缺口/题源判断选相应AWS官方段落；机械哈希不替语义。'))
dump(D/'revision-requests.json',dict(schemaVersion=1,requests=requests,count=len(requests),newCardCountClaim=None,noCardEdits=True))
dump(D/'pool-search-audit.json',dict(schemaVersion=1,poolCount=357,queries=queries))
dump(D/'source-findings.json',dict(schemaVersion=1,findings=findings,sourceDenominatorPreserved=1018,policyPath=str(D/policy.name),unknownNotExempted=True))
dump(D/'corrected-exercise-proposals.json',dict(schemaVersion=1,policyPath=str(D/policy.name),variants=variants,independentlyPassedVariants=0,originalsNeverUpgraded=True))
dump(D/'results.json',dict(schemaVersion=2,reviewer='actual_gap_review',manifestFinalPath=str(D/'manifest-final.json'),manifestFinalSha256=sha((D/'manifest-final.json').read_bytes()),reviewedAtUtc=NOW,questionCount=58,visiblePoolCount=357,counts=counts,results=rows,current_artifacts=dict(results=str(D/'results.json'),requests=str(D/'revision-requests.json'),sources=str(D/'source-findings.json'),proposedCorrectedExercises=str(D/'corrected-exercise-proposals.json')),pending_ids=pending,next_action='由主流程先精炼现有规则的22项澄清，再对受影响原题回测；2个纠错提案另编冻结练习包独立审核，UNKNOWN继续查证。',minimumClarificationRequestCount=len(requests),deferredIndependentTaskCount=1,newCardCountClaim=None,externalModelCliApiCalls=0,nativeUsage='unknown',originalSourceDenominator=1018,formalInventoryUnchanged=True,fullLibraryNUnknown=True))
checks={}
checks['58_exact_unique_input_qids']=len(R)==58 and len(rows)==58 and set(R)==set(Q)
checks['all_frozen_inputs_unchanged']=all(sha(pathlib.Path(p).read_bytes())==h for p,h in manifest.items())
checks['all357_body_hashes_match']=all(sha(json.dumps(c['visibleBody'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==c['bodySha256'] for c in C.values())
checks['all_original_question_hashes_match']=all(x['questionSha256']==sha(json.dumps(Q[x['qid']]['question'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()) for x in rows)
checks['all_premise_field_quotes_and_hashes_match']=all(a['bodySha256']==C[a['ruleId']]['bodySha256'] and a['quote']==C[a['ruleId']]['visibleBody'][a['field']] for x in rows for a in x['necessaryAnchors'])
checks['all_prerequisites_current']=all(a['bodySha256']==C[a['ruleId']]['bodySha256'] for x in rows for b in x['prerequisiteBindings'] for a in b['prerequisites'])
checks['all_official_quotes_exact']=all((lambda p,d,e:sha(p.read_bytes())==e['snapshotSha256'] and sha(d['text'].encode())==e['textSha256'] and d['text'][e['quoteStart']:e['quoteEnd']]==e['quote'])(pathlib.Path(e['snapshotPath']),json.loads(pathlib.Path(e['snapshotPath']).read_text()),e) for e in EV.values())
checks['all_reference_keys_defined']=all(k in EV for x in rows for k in x['officialEvidenceKeys'])
checks['new2_mechanisms_exist']=all(k in C for k in ['VC-001','VC-002'])
checks['quarantined_GCL020_not_used']=all('GCL-020' not in x['usedRuleIds'] for x in rows)
checks['original_source_issues_not_upgraded_by_variants']=all(R[x['originalQid']]['status']=='SOURCE_ISSUE' and x['status']=='PROPOSED_PENDING_INDEPENDENT_CURRENT_CARD_REVIEW' for x in variants)
checks['all_three_parts_preserved']=len(list(D.glob('results-part*.json')))==3
checks['additional_policy_unchanged']=sha(policy.read_bytes())==finalmanifest['additionalUserPolicySha256']
checks['conditions_separate_from_implementation']=all(not x['conditions'] for x in rows if x['status']=='SUPPORTED')
assert all(checks.values()),checks
files=['results.json','revision-requests.json','official-evidence.json','pool-search-audit.json','source-findings.json','corrected-exercise-proposals.json','manifest-final.json']
dump(D/'final-readback.json',dict(schemaVersion=1,status='PASS_MECHANICAL_ONLY',readbackAtUtc=NOW,counts=counts,checks=checks,pendingCount=len(pending),semanticLimit='条件/未知/卡片缺口/题源问题仍未PASS；纠错练习未独立回测，绝不抵扣原题。',outputSha256={str(D/n):sha((D/n).read_bytes()) for n in files},externalModelCliApiCalls=0,nativeUsage='unknown',noBudgetReset=True))
print(counts,'requests',len(requests),'evidence',len(EV),'all checks',all(checks.values()))

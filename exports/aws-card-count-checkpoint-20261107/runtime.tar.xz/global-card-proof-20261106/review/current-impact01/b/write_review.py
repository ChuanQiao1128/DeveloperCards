import pathlib,json,hashlib,datetime,collections
D=pathlib.Path(__file__).resolve().parent;V=D.parents[2];I=D.parent/'input'
def sha(b):return hashlib.sha256(b).hexdigest()
Q={x['qid']:x for x in json.loads((I/'cases-current-2.json').read_text())};C={x['ruleId']:x for x in json.loads((I/'visible-pool.frozen.json').read_text())}
def write(part,specs):
 rows=[]
 for q,status,opts,ids,reason,missing,conditions in specs:
  initial=[x['ruleId'] for x in Q[q]['visibleCards']]
  rows.append(dict(qid=q,status=status,selectedOptionOrdinals=opts if status=='SUPPORTED' else [],candidateOptionOrdinals=opts if status!='SUPPORTED' else [],usedRuleIds=ids,reasoningAndClosestCompetitor=reason,missingJudgments=missing,conditions=conditions,sourceIssues=[reason] if status=='SOURCE_ISSUE' else [],necessaryAnchors=[dict(ruleId=k,bodySha256=C[k]['bodySha256'],field=f,quote=C[k]['visibleBody'][f],additionalToInitialGroup=k not in initial) for k in ids for f in ('answerZH','keyPointZH','watchOutZH') if C[k]['visibleBody'].get(f)],questionSha256=sha(json.dumps(Q[q]['question'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),initialCardGroupRuleIds=initial))
 p=D/f'results-part{part:02}.json';p.write_text(json.dumps(dict(schemaVersion=1,reviewer='actual_gap_review',frozenManifestPath=str(I/'manifest-current-2.json'),frozenManifestSha256=sha((I/'manifest-current-2.json').read_bytes()),policyPath=str(D/'user-knowledge-scope-accepted.json'),counts=dict(collections.Counter(x['status'] for x in rows)),reviewedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=rows),ensure_ascii=False,indent=2)+'\n');print(p,len(rows))

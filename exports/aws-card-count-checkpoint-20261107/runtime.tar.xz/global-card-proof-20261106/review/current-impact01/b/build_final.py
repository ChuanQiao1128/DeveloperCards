# -*- coding: utf-8 -*-
import pathlib,json,hashlib,datetime,collections,shutil
from write_review import D,V,I,Q,C,sha
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat();E=D/'evidence';E.mkdir(exist_ok=True)
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def quote(key,src,start,end):
 p=pathlib.Path(src);d=json.loads(p.read_text());t=d['text'];s=t.index(start);e=t.index(end,s)+len(end);target=E/(key+'.snapshot.json')
 if p!=target:shutil.copyfile(p,target)
 u=d.get('finalUrl') or d['url'];assert u.startswith(('https://docs.aws.amazon.com/','https://aws.amazon.com/'))
 return dict(url=u,quote=t[s:e],quoteStart=s,quoteEnd=e,snapshotPath=str(target),snapshotSha256=sha(target.read_bytes()),textSha256=sha(t.encode()),selection='已读取所引具体语义段落，不以URL、标题或哈希存在代替支持。')
EV={}
EV['HTTP_API_RESOURCE_POLICY_UNSUPPORTED']=quote('http-rest-comparison',E/'http-rest-compare.json','Authorization options\nREST API\nHTTP API','Resource policies\nYes\nNo')
EV['HTTP_API_PRIVATE_ENDPOINT_UNSUPPORTED']=quote('http-rest-endpoints',E/'http-rest-compare.json','Endpoint types\nREST API\nHTTP API','Private\nYes\nNo')
EV['A2C_EXISTING_CUSTOMER_SCOPE']=quote('a2c-eligibility',V/'evidence/gap-a/fetch-a2c-support.json','AWS .NET Modernization Tools Porting Assistant','accelerate enterprise modernization of .NET.')
EV['A2C_LINUX_ASPNET_SUPPORTED']=quote('a2c-linux',V/'evidence/gap-a/fetch-a2c-support.json','For ASP.NET applications running on Linux,','Process mode is not supported for ASP.NET applications\nrunning on .NET Core.')
EV['BACKUP_RDS_PITR_SCOPE']=quote('backup-rds-pitr',V/'evidence/gap-a/fetch-backup-continuous.json','RDS\nAWS Backup supports continuous backups','continuous backups or point-in-time recovery for Amazon RDS Multi-AZ clusters.')
EV['BACKUP_PITR_AND_SNAPSHOT_DURATION']=quote('backup-retention',V/'evidence/gap-a/fetch-backup-continuous.json','With continuous backups, you can restore','Snapshots can be copied\nfor full or incremental backups.')
EV['API_GATEWAY_TO_SQS']=quote('api-sqs',V/'evidence/gap-a/fetch-api-sqs.json','This pattern creates a REST API endpoint','avoids direct access to the SQS queue.')
EV['AURORA_IO_COST_CONDITION']=quote('aurora-io-cost',E/'aurora-storage.json','Aurora I/O-Optimized – Improved price performance','Aurora database spending.')
rows=[]
for p in sorted(D.glob('results-part*.json')):rows+=json.loads(p.read_text())['results']
assert len(rows)==126;R={x['qid']:x for x in rows};assert len(R)==126
# Add front statements where a visible premise/term is taught there; preserve all six original batches.
for q,x in R.items():
 for k in x['usedRuleIds']:
  x['necessaryAnchors'].insert(0,dict(ruleId=k,bodySha256=C[k]['bodySha256'],field='frontZH',quote=C[k]['visibleBody']['frontZH'],additionalToInitialGroup=k not in x['initialCardGroupRuleIds']))
 x['implementationChecks']=x['conditions'] if x['status']=='SUPPORTED' else []
 if x['status']=='SUPPORTED':x['conditions']=[]
 x['officialEvidenceKeys']=[]
 x['requiredPrerequisiteBindings']=[dict(ruleId=k,bodySha256=C[k]['bodySha256'],prerequisiteRuleIds=C[k].get('prerequisiteRuleIds',[]),prerequisites=[dict(ruleId=a,bodySha256=C[a]['bodySha256']) for a in C[k].get('prerequisiteRuleIds',[])]) for k in x['usedRuleIds']]
for q,ks in {827:['AURORA_IO_COST_CONDITION'],969:['A2C_EXISTING_CUSTOMER_SCOPE','A2C_LINUX_ASPNET_SUPPORTED'],978:['BACKUP_RDS_PITR_SCOPE','BACKUP_PITR_AND_SNAPSHOT_DURATION'],1005:['API_GATEWAY_TO_SQS'],1019:['HTTP_API_RESOURCE_POLICY_UNSUPPORTED','HTTP_API_PRIVATE_ENDPOINT_UNSUPPORTED']}.items():R[q]['officialEvidenceKeys']=ks
# No silent exception: qualification restrictions are conditions, not confirmed service retirement.
findings=[dict(qid=1019,status='SOURCE_ISSUE',kind='explicit_HTTP_API_product_capability_conflict',questionSha256=R[1019]['questionSha256'],originalQuestion=Q[1019]['question'],evidenceKeys=['HTTP_API_RESOURCE_POLICY_UNSUPPORTED','HTTP_API_PRIVATE_ENDPOINT_UNSUPPORTED'],conclusion='REST API支持API resource policy；HTTP API不支持。A为后端private integration不按客户端IP限流，C托管API不能直接部署入私有子网，D不能给API Gateway附加所述安全组。按明确产品HTTP API原文无有效选项。',terminologyCaveat='若原HTTP仅为协议泛称且实际REST API，B才可成立；本次不静默替换产品类型。',officiallyConfirmedObsolete=False,correctionProposal='核实原题产品用词；如原意REST API，明确更正HTTP为REST并保留纠错谱系后再测。',currentAwsScopeExceptionApplied=False,originalDenominatorPreserved=True),dict(qid=949,status='UNKNOWN',kind='incomplete_original_option',questionSha256=R[949]['questionSha256'],originalQuestion=Q[949]['question'],evidenceKeys=[],conclusion='第三选项结束于“without enabling the third-party SaaS provider to establish.”；不能恢复未见字词后排除或接受C，D有PrivateLink方向支持但唯一性未闭合。',officiallyConfirmedObsolete=False,currentAwsScopeExceptionApplied=False,correctionProposal='回读原始PDF所示完整第三选项；不得改写冻结原题后冒称原文已充分支撑。',originalDenominatorPreserved=True),dict(qid=827,status='UNKNOWN',kind='cost_condition_not_implied_by_high_traffic',questionSha256=R[827]['questionSha256'],originalQuestion=Q[827]['question'],evidenceKeys=['AURORA_IO_COST_CONDITION'],conclusion='官方按I/O占总支出比例比较Standard与I/O-Optimized，原题只说large traffic/存储性能，未给该关键经济量。保留A/D条件，不增错误绝对规则。',officiallyConfirmedObsolete=False,currentAwsScopeExceptionApplied=False,originalDenominatorPreserved=True)]
requests=[dict(requestId='CIB-R01',qids=[978],status='PROPOSED_NOT_AUTHORED',kind='clarify_existing',targetRuleIds=['CUR:NS03','GSC-047'],minimumClarification='AWS Backup对RDS DB instance的连续PITR支持与周期快照保留分工：14天连续恢复窗口、90天历史恢复点使用有效的独立规则；Multi-AZ DB cluster例外保留。',evidenceKeys=['BACKUP_RDS_PITR_SCOPE','BACKUP_PITR_AND_SNAPSHOT_DURATION'],newCardRequired=False,note='先复用/精炼现有规则；本复核不新增卡。'),dict(requestId='CIB-R02',qids=[1005],status='PROPOSED_NOT_AUTHORED',kind='clarify_existing',targetRuleIds=['CUR:CA17'],minimumClarification='API Gateway的AWS服务集成可把请求发送SQS；托管入口与队列并不是只能经计算主机转发。',evidenceKeys=['API_GATEWAY_TO_SQS'],newCardRequired=False,note='可与已登记API Gateway→Kinesis/Firehose机制澄清共用，非一个服务组合一张卡。')]
R[978]['minimumClarificationRequestIds']=['CIB-R01'];R[1005]['minimumClarificationRequestIds']=['CIB-R02']
for x in rows:x.setdefault('minimumClarificationRequestIds',[])
counts=dict(collections.Counter(x['status'] for x in rows));pending=[x['qid'] for x in rows if x['status']!='SUPPORTED']
manifest=json.loads((I/'manifest-current-2.json').read_text());policy=D/'user-knowledge-scope-accepted.json';binding=json.loads((D/'input-binding.json').read_text())
old={x['ruleId']:x for x in json.loads((V/'review/gap-b/input/visible-cards355.json').read_text())};changed=[k for k in C if C[k]['bodySha256']!=old[k]['bodySha256']]
result=dict(schemaVersion=2,reviewer='actual_gap_review',frozenManifestPath=str(I/'manifest-current-2.json'),frozenManifestSha256=sha((I/'manifest-current-2.json').read_bytes()),inputBindingPath=str(D/'input-binding.json'),inputBindingSha256=sha((D/'input-binding.json').read_bytes()),scopePolicyPath=str(policy),scopePolicySha256=sha(policy.read_bytes()),scopePolicy='current_AWS',reviewedAtUtc=NOW,questionCount=126,visiblePoolCount=355,changedBodiesFromPrior355Count=len(changed),changedRuleIds=changed,counts=counts,results=rows,current_artifacts=dict(results=str(D/'results.json'),sources=str(D/'official-evidence.json'),sourceFindings=str(D/'source-findings.json'),requests=str(D/'revision-requests.json')),pending_ids=pending,next_action='只处理2项真实卡面澄清及列明的条件/未知/题源问题；沿冻结正文与依赖重测，不重做已有效判断。',formalInventoryUnchanged=True,originalSourceDenominator=1018,exclusionsAdded=0,confirmedObsoleteCorrectionExceptionsApplied=0,externalModelCliApiCalls=0,nativeUsage='unknown',notFinalCardCount=True,studyOutcomeNotMeasured=True,conclusion='指定126题当前正文独立复测完成；101题设计支撑充分不代表学习者正确率，全库N与全1018覆盖仍须由主流程验收。')
dump(D/'official-evidence.json',dict(schemaVersion=1,evidence=EV))
dump(D/'source-findings.json',dict(schemaVersion=1,findings=findings,sourceDenominatorPreserved=1018,scopePolicy='current_AWS',confirmedObsoleteExceptionCount=0))
dump(D/'revision-requests.json',dict(schemaVersion=1,requests=requests,newCardCountClaim=None,noNewCardAuthorization=True))
dump(D/'results.json',result)
checks={}
checks['126_unique_exact_input_qids']=len(rows)==126 and len(R)==126 and set(R)==set(Q)
checks['frozen_manifest_inputs_unchanged']=all(sha(pathlib.Path(p).read_bytes())==h for p,h in manifest.items())
checks['all355_body_hashes_match']=all(sha(json.dumps(c['visibleBody'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==c['bodySha256'] for c in C.values())
checks['all_questions_hash_match']=all(x['questionSha256']==sha(json.dumps(Q[x['qid']]['question'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()) for x in rows)
checks['all_used_card_anchors_exact']=all(a['bodySha256']==C[a['ruleId']]['bodySha256'] and a['quote']==C[a['ruleId']]['visibleBody'][a['field']] for x in rows for a in x['necessaryAnchors'])
checks['all_prerequisite_bindings_current']=all(a['bodySha256']==C[a['ruleId']]['bodySha256'] for x in rows for b in x['requiredPrerequisiteBindings'] for a in b['prerequisites'])
checks['all_official_quotes_exact']=all((lambda p,d,e:sha(p.read_bytes())==e['snapshotSha256'] and sha(d['text'].encode())==e['textSha256'] and d['text'][e['quoteStart']:e['quoteEnd']]==e['quote'])(pathlib.Path(e['snapshotPath']),json.loads(pathlib.Path(e['snapshotPath']).read_text()),e) for e in EV.values())
checks['all_request_and_evidence_ids_defined']=all(k in {r['requestId'] for r in requests} for x in rows for k in x['minimumClarificationRequestIds']) and all(k in EV for x in rows for k in x['officialEvidenceKeys'])
checks['gap_b76_not_repeated']=not(set(R)&{q['qid'] for q in json.loads((V/'review/gap-b/input/cases76.json').read_text())})
checks['24_revisions_frozen']=len(changed)==24
checks['supported_choices_nonempty']=all(bool(x['selectedOptionOrdinals']) for x in rows if x['status']=='SUPPORTED')
checks['nonpass_not_selected_as_supported']=all(not x['selectedOptionOrdinals'] for x in rows if x['status']!='SUPPORTED')
checks['all_six_first_pass_batches_preserved']=len(list(D.glob('results-part*.json')))==6
checks['policy_matches_start']=sha(policy.read_bytes())==binding['policySha256']
checks['no_quarantined_GCL020_used']=all('GCL-020' not in x['usedRuleIds'] for x in rows)
assert all(checks.values()),checks
dump(D/'final-readback.json',dict(schemaVersion=1,status='PASS_MECHANICAL_ONLY',readbackAtUtc=NOW,checks=checks,counts=counts,pendingQuestionCount=len(pending),newCardCountClaim=None,questionCount=126,actualVisiblePoolCount=355,modelCliApiCalls=0,nativeUsage='unknown',semanticScope='该机械PASS只核计数、完整输入、逐题/正文/引用绑定；不升级18条件、4未知、2缺卡或1源问题为语义充分。',outputSha256={str(p):sha(p.read_bytes()) for p in [D/'results.json',D/'official-evidence.json',D/'source-findings.json',D/'revision-requests.json']}))
print(counts,'pending',len(pending),'evidence',len(EV),'all checks',all(checks.values()))

# Current-impact01/a: 126-question retest

Completed 126/126: 107 SUPPORTED, 11 INSUFFICIENT_CARDS, 6 CONDITIONAL, 2 SOURCE_ISSUE. UNKNOWN: 0.

Frozen current pool: 355 actual visible Chinese cards. GCL-020 and all pending supplemental cards excluded. Old question results were not read or mechanically rebound. Original question denominator and all options are preserved.

Current AWS is the accepted knowledge scope. This does not automatically exempt unresolved sources or services still available to qualified existing customers. Card sufficiency, original-source issues, deployment measurements and learner outcomes remain separate.

The two source issues are Q193 (both Redis and current Memcached Serverless can provide HA caching when node-based deployment is not required) and Q426 (both DataSync+data events and secure accelerated client transfer+data events can meet the stated requirement without a least-operations constraint). Literal official evidence is stored under evidence/. Neither is silently removed from coverage.

Q391 used only current visible GCL-012 AMI-rebuild and CUR:XA037 AMI-launch sentences plus RDS PITR to derive stateless recovery. No unapplied VC candidate was used.

| Question | Status | Selected ordinal(s) | Minimal gap / condition |
|---|---|---|---|
| Q4 | SUPPORTED | 1 |  |
| Q5 | SUPPORTED | 3 |  |
| Q13 | SUPPORTED | 1 |  |
| Q14 | SUPPORTED | 3 |  |
| Q18 | INSUFFICIENT_CARDS | unproved | Lambda以SQS事件源映射触发、成功确认消息的实际消费机制。 |
| Q19 | CONDITIONAL | 4 | 第三方设备必须支持/配置GWLB所需GENEVE；若只有普通IP接口则此兼容性尚未成立。 |
| Q22 | SUPPORTED | 2 |  |
| Q29 | SUPPORTED | 1 |  |
| Q40 | SUPPORTED | 1 |  |
| Q41 | SUPPORTED | 2 |  |
| Q50 | SUPPORTED | 4 |  |
| Q54 | SUPPORTED | 3 |  |
| Q59 | SUPPORTED | 4 |  |
| Q63 | SUPPORTED | 1 |  |
| Q64 | CONDITIONAL | 4 | 须符合FSx File Gateway现行既有使用资格；原题没有证明资格。 |
| Q65 | SUPPORTED | 3 |  |
| Q69 | SUPPORTED | 2 |  |
| Q76 | SUPPORTED | 2 |  |
| Q78 | INSUFFICIENT_CARDS | unproved | DynamoDB PITR实际保留窗口及AWS Backup长期保留该表的适配。 |
| Q90 | SUPPORTED | 2 |  |
| Q91 | SUPPORTED | 1 |  |
| Q92 | SUPPORTED | 1,3 |  |
| Q93 | SUPPORTED | 2 |  |
| Q94 | INSUFFICIENT_CARDS | unproved | Lambda SQS事件源映射/受管消费。 |
| Q95 | SUPPORTED | 4 |  |
| Q97 | SUPPORTED | 4 |  |
| Q99 | SUPPORTED | 4 |  |
| Q101 | SUPPORTED | 1 |  |
| Q102 | SUPPORTED | 2,5 |  |
| Q110 | SUPPORTED | 3,4 |  |
| Q111 | SUPPORTED | 4 |  |
| Q115 | SUPPORTED | 3 |  |
| Q120 | SUPPORTED | 2 |  |
| Q125 | SUPPORTED | 1,5 |  |
| Q129 | SUPPORTED | 1,5 |  |
| Q136 | SUPPORTED | 1,3 |  |
| Q139 | INSUFFICIENT_CARDS | unproved | S3复制目标的EventBridge对象创建事件行为；SageMaker Pipelines事件目标接入。 |
| Q142 | SUPPORTED | 3 |  |
| Q144 | SUPPORTED | 2 |  |
| Q159 | SUPPORTED | 3,5 |  |
| Q161 | SUPPORTED | 2 |  |
| Q162 | SUPPORTED | 1 |  |
| Q168 | CONDITIONAL | 4 | 限制目标必须是成员账户，且组织根的广泛挂载范围可接受；若all包含管理账户，SCP不能满足该部分。 |
| Q176 | SUPPORTED | 1 |  |
| Q177 | INSUFFICIENT_CARDS | unproved | DAX接入客户端/端点是否需要应用调整，及原题“without reconfiguring”能否成立。 |
| Q180 | SUPPORTED | 2,3 |  |
| Q182 | SUPPORTED | 2 |  |
| Q183 | SUPPORTED | 1 |  |
| Q186 | SUPPORTED | 2 |  |
| Q187 | SUPPORTED | 1,4 |  |
| Q188 | SUPPORTED | 1 |  |
| Q191 | SUPPORTED | 1 |  |
| Q192 | SUPPORTED | 2,5 |  |
| Q193 | SOURCE_ISSUE | unproved | 如把Memcached限定为node-based而要求复制/接管，则B；原题应补此限制或允许两种当前方案。用户现行AWS口径不等于自动豁免该源问题。 |
| Q196 | SUPPORTED | 4 |  |
| Q197 | SUPPORTED | 2,5 |  |
| Q200 | SUPPORTED | 4 |  |
| Q205 | SUPPORTED | 3 |  |
| Q212 | SUPPORTED | 1 |  |
| Q223 | SUPPORTED | 1,4 |  |
| Q228 | INSUFFICIENT_CARDS | unproved | Lambda SQS事件源映射及受管消费机制。 |
| Q229 | SUPPORTED | 1 |  |
| Q230 | SUPPORTED | 3 |  |
| Q231 | SUPPORTED | 2 |  |
| Q232 | SUPPORTED | 3 |  |
| Q235 | CONDITIONAL | 3 | 迁移期间写入集中于明确源库，或另有已验证双向复制/冲突协调；如果应用切换后立即各写两库同表，仅C所列单向任务不足。 |
| Q236 | SUPPORTED | 4 |  |
| Q237 | SUPPORTED | 1 |  |
| Q249 | SUPPORTED | 4 |  |
| Q252 | SUPPORTED | 1 |  |
| Q258 | SUPPORTED | 4 |  |
| Q259 | SUPPORTED | 1 |  |
| Q260 | SUPPORTED | 4 |  |
| Q262 | SUPPORTED | 1 |  |
| Q266 | SUPPORTED | 1 |  |
| Q268 | SUPPORTED | 1 |  |
| Q269 | SUPPORTED | 3 |  |
| Q270 | SUPPORTED | 1 |  |
| Q277 | SUPPORTED | 4 |  |
| Q281 | SUPPORTED | 1 |  |
| Q287 | SUPPORTED | 2 |  |
| Q288 | SUPPORTED | 3 |  |
| Q293 | SUPPORTED | 4 |  |
| Q294 | SUPPORTED | 2 |  |
| Q295 | CONDITIONAL | 2 | 须已获Object Lambda使用资格；原题未证明资格。未经确认不能当官方退役题自动豁免。 |
| Q298 | SUPPORTED | 3 |  |
| Q301 | SUPPORTED | 3 |  |
| Q304 | SUPPORTED | 1 |  |
| Q305 | SUPPORTED | 3 |  |
| Q307 | SUPPORTED | 4 |  |
| Q314 | SUPPORTED | 2 |  |
| Q316 | INSUFFICIENT_CARDS | unproved | Lambda SQS事件源映射/受管拉取和函数消费触发。 |
| Q322 | SUPPORTED | 3 |  |
| Q326 | SUPPORTED | 1,2 |  |
| Q332 | SUPPORTED | 2 |  |
| Q334 | SUPPORTED | 1 |  |
| Q337 | INSUFFICIENT_CARDS | unproved | Aurora Replica复制/存储机制如何降低该场景lag，及原stored procedures兼容/是否真需替换。 |
| Q350 | INSUFFICIENT_CARDS | unproved | RDS SQLServer read replica具体支持范围，以及报告是否要求持续更新而非时点副本。 |
| Q352 | SUPPORTED | 2 |  |
| Q357 | SUPPORTED | 1,4 |  |
| Q365 | SUPPORTED | 3 |  |
| Q366 | INSUFFICIENT_CARDS | unproved | 订阅资格怎样关联当前Cognito调用身份并由入口/业务授权强制检查；C/D在现有调用路径下的实际权限约束。 |
| Q367 | SUPPORTED | 1 |  |
| Q374 | SUPPORTED | 4 |  |
| Q381 | SUPPORTED | 2 |  |
| Q384 | SUPPORTED | 3 |  |
| Q386 | SUPPORTED | 2 |  |
| Q389 | SUPPORTED | 1 |  |
| Q391 | SUPPORTED | 3 |  |
| Q399 | SUPPORTED | 2 |  |
| Q401 | SUPPORTED | 1 |  |
| Q404 | INSUFFICIENT_CARDS | unproved | Lambda SQS事件源映射/受管消费。 |
| Q407 | SUPPORTED | 4 |  |
| Q408 | SUPPORTED | 2 |  |
| Q409 | SUPPORTED | 3 |  |
| Q411 | SUPPORTED | 3 |  |
| Q415 | SUPPORTED | 1 |  |
| Q418 | CONDITIONAL | 2 | 开发用户/组必须另有仅指向该生产角色的sts:AssumeRole权限；若仅有题面S3权限，B本身还未形成完整双边授权。 |
| Q419 | SUPPORTED | 1,3 |  |
| Q421 | SUPPORTED | 2 |  |
| Q426 | SOURCE_ISSUE | unproved | 若要求托管迁移/自动增量校验的最小运维，则A更合适；当前原题未给这个优化目标。现行AWS口径不自动豁免此多解问题。 |
| Q430 | SUPPORTED | 2,3 |  |
| Q439 | SUPPORTED | 1 |  |
| Q444 | SUPPORTED | 2 |  |
| Q445 | SUPPORTED | 1 |  |
| Q450 | SUPPORTED | 3,5,6 |  |

Per-question unused mappings do not prove global deletion. No full-library closure, measured learner improvement or final N is claimed. Model CLI/API calls: 0; native usage unknown. No current pointer, inventory, budget, study record or publication was changed by this reviewer.

# 独立回测 B：150题

当前冻结358卡池；本批115题SUPPORTED、16题CONDITIONAL、14题INSUFFICIENT_CARDS、5题SOURCE_ISSUE。358为候选实际卡池数，不是最终N。

已逐题读完整题干及全部选项，必要卡句、正文哈希、引用偏移和递归先修绑定在results.json及parts。readback.json通过150题全集/完整题哈希/可见卡358正文哈希/当前事实教学凭证绑定/全部锚点切片/先修闭包检查。

未使用被省略7卡或隔离GCL-020；未读旧预期答案或作者分析；未改正文、原题、学习记录或生产指针。模型CLI/API调用0，native用量unknown；未声明最终N。

## 未充分项

- Q59 CONDITIONAL：若将题意限定为优先托管的连续点击流摄取，D充分；原文只问能传输和处理，尚无足够条件把B唯一排除，未用未查到文档宣称源题错误。
- Q107 CONDITIONAL：B自身未列持久层；按常规将实际存储和读写代码留给后端实现时可选B。卡组可教一个可行实现，但原题对存储介质/检索模式不明确，不能据选项B两项名称声称已展示完整持久存取设计。
- Q134 INSUFFICIENT_CARDS：缺SSE-S3/CRR加密路径的可见必要判断，既有数据必须用有效补复制或规则后重传纳入，不能把现有对象默认为live自动覆盖。
- Q139 INSUFFICIENT_CARDS：缺复制写入目标桶与EventBridge ObjectCreated触发的可见规则。未以没有查到文档确认源题错误；不把任一复制对象都算成Put。
- Q146 CONDITIONAL：B需基线维持所需服务，额外Spot被回收后仍能安全恢复且不影响约定可用性。题目只说无状态，没有明确容量冗余/中断恢复条件，卡不能把无状态自动等同无可用性影响。
- Q157 CONDITIONAL：D/E充分用于备份保留5年及审计无限期；原文若要求生产库每条业务数据5年后也必须删除，备份到期不会完成该删除，须另有数据生命周期动作。不将备份保留误作自动删除在线业务行。
- Q215 CONDITIONAL：必须确认现行Snowball可用资格、足量设备与运输导入窗口；卡明确不能用不可订购设备或忽略交付时间证明一个月可行。原文未给资格，故不能无条件支持。
- Q258 CONDITIONAL：D为通用受管大文件ETL路径；但1GB本身不证明Lambda无法在900秒内完成，A同属无服务器转换，题干没有处理复杂度/运行时数据，当前卡不能以文件大小单独排除A。
- Q267 INSUFFICIENT_CARDS：缺当前分析服务与Firehose的实际连接及加密判断，不能只把两个服务名称放一起认为分析已接通；未用旧Kinesis SQL产品记忆补缺或直接宣布源题错误。
- Q290 CONDITIONAL：须应用的部分容量可中断并恢复且基线足够维持服务；题干只有ASG，没有声明Spot耐受。不能把自动伸缩或Web应用自动等同Spot回收无影响。
- Q355 INSUFFICIENT_CARDS：缺64vCPU/512GiB作业与Fargate/Batch EC2资源支持边界的可见判断；不是要求实测相同15分钟，而是硬资源条件必须参与。
- Q373 CONDITIONAL：要宣称D最便宜，仍须对象平均大小及读取/转换计费比较；trillions对象令逐对象监控、最低计费及转换费用具有实质影响。仅给总对象数量未给大小，现卡不能保证A/D成本排名。
- Q390 CONDITIONAL：若durably指脱离Web实例生命周期，共享Redis与DynamoDB对应B/D；若要求每条已确认会话写入在缓存故障后零损失，Redis副本/快照不能自动证明该保证，卡也明确快照后写入可能丢失。
- Q424 CONDITIONAL：题干未明确后端可中断/重试；短时、数量变化本身不足以保证Spot适用，B在任务可恢复条件下成立。
- Q457 SOURCE_ISSUE：官方创建AS2服务器说明不能选择身份提供方，basic authentication不受支持；详见本批official-evidence.json，不能把C静默改为SFTP。
- Q473 CONDITIONAL：A原文写state files而非static files。按题干静态内容语境理解为静态文件缓存可选A；若确指业务状态文件，必须另核缓存安全性，不静默修改原文。
- Q500 SOURCE_ISSUE：官方已停止Snowcone新旧客户订购，证据见official-evidence.json；保留原题与ACL要求，不把已持有旧设备或现代替代设备改进原选项。
- Q528 INSUFFICIENT_CARDS：缺Transfer Family FTP入口能力的实际可见句；协议是原题硬条件，不是可省部署参数。
- Q540 INSUFFICIENT_CARDS：缺Oracle引擎与可读Multi-AZ cluster/副本支持边界及A的实际数据库拓扑。官方支持矩阵已另定位MySQL/PostgreSQL范围，但不足仅凭未列Oracle就在本次证明所有选项无解，故保留缺卡状态。
- Q572 INSUFFICIENT_CARDS：缺ACU与内存的实际可见换算，不能凭审查者记忆断言C的最低1ACU已满足2GiB硬条件。
- Q574 CONDITIONAL：成本论证若依赖空闲降至零，须MySQL目标版本支持并启用自动暂停、无保持连接等阻碍。XB027实际只讲PostgreSQL自动暂停，不能把其条件静默移植为全部MySQL v2默认行为。
- Q580 INSUFFICIENT_CARDS：缺gp2/gp3在本题常见负载下为何gp3更经济的可见判断，不能只因名称新就选择MOST cost-effective。
- Q590 SOURCE_ISSUE：这是两个完整条件下可行的具体方案，不是因为缺部署参数就判错；题目未给能唯一排除按月独立报告库的优化目标，不能强选唯一A。
- Q620 INSUFFICIENT_CARDS：缺决定C优于D的EBS SSD/HDD工作负载判断；不能拿Lustre SSD延迟直接替代另一存储产品的性能证据。
- Q649 INSUFFICIENT_CARDS：缺RDS PostgreSQL gp3的15,000 IOPS支持条件/容量边界及成本区别；不能用EC2卷规则填平受管RDS硬容量约束。
- Q693 CONDITIONAL：DMS迁移须原嵌入式NoSQL引擎及数据结构处于其支持范围；卡GSC-060明确是适用DMS任务，题干未标源引擎，不能把任意嵌入式NoSQL自动等同受支持源。
- Q734 INSUFFICIENT_CARDS：缺Direct Connect gateway可达/不传递范围的实际卡面判断；不能靠产品名称断言D实现原文所有网络间连通。
- Q781 SOURCE_ISSUE：官方明确cost budget设spending limits、usage budget设usage limits，本题无严格合格选项；见official-evidence.json。不能静默将A的usage改成cost。
- Q800 INSUFFICIENT_CARDS：缺Lambda跨账户EFS集成是否受支持及其实际支持路径，故不能仅以B最少网络改动判充分；也未教C是否在给定文件访问方式下可等价代理。
- Q804 INSUFFICIENT_CARDS：缺Redshift MPP/Serverless能力可见句；不能只从选项包含Serverless字样或自己产品记忆填上该硬判断。
- Q891 INSUFFICIENT_CARDS：缺MRAP利用AWS网络加速与故障路由的可见必要判断；不能把Global Accelerator卡的能力自动贴给另一S3服务。
- Q930 CONDITIONAL：A需现有提取程序已符合Lambda执行环境、时长和接入方式，并可在不改原程序/门户代码下触发。原文绝不改代码而未给程序接口，不能默认任意现有程序均可直接搬入函数。
- Q940 CONDITIONAL：原文只说long-running，未明示三年稳定利用；若未来使用期限不足三年，更多承诺可导致闲置总成本，不能把更低单价无条件等同更低总成本。
- Q954 CONDITIONAL：D原文写scale number of the services，需按服务任务副本伸缩理解；ECS Service Auto Scaling增加的是任务desired count而非自动创建更多服务定义。若按字面创建服务数，卡不支持该动作。
- Q995 SOURCE_ISSUE：原题只问满足可扩展且经济，并非明确最少运维/只能托管；B/C两个按题干约束可部署的例子已给，不能凭偏好Fargate将C判错或强唯一。

题源问题Q457/Q500/Q781附官方正向快照；Q590/Q995列两个按原题实际约束可行的具体实现。题源纠错须由主任务另行处理，本报告不改写原题。

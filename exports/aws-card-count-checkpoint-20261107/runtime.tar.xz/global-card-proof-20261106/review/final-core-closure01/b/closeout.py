import json,hashlib,collections,datetime,shutil
from pathlib import Path
O=Path(__file__).parent;I=O.parent/'input';P={x['ruleId']:x for x in json.loads((I/'visible-pool.frozen.json').read_text())};C={x['qid']:x for p in (I/'b').glob('cases*.json') for x in json.loads(p.read_text())}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda d:hashlib.sha256(json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
prior=O/'pre-readback';prior.mkdir(exist_ok=True)
for p in sorted((O/'parts').glob('part*.json')):
 if not (prior/p.name).exists():shutil.copyfile(p,prior/p.name)
extra={
48:{'CUR:NB04':['answerZH','keyPointZH','watchOutZH']},
84:{'VC-007':['frontZH','answerZH','keyPointZH']},
146:{'VC-007':['frontZH','answerZH','keyPointZH']},
167:{'VC-007':['frontZH','answerZH','keyPointZH']},
124:{'GSC-133':['watchOutZH']},
215:{'GSC-077':['watchOutZH']},
279:{'CUR:NS03':['watchOutZH']},
299:{'GSC-005':['watchOutZH'],'GSC-009':['watchOutZH']},
348:{'GCL-023':['watchOutZH']},
355:{'VC-002':['watchOutZH'],'GSC-133':['watchOutZH']},
369:{'GSC-133':['watchOutZH']},
390:{'CUR:NB04':['watchOutZH']},
397:{'GSC-133':['watchOutZH']},
457:{'CUR:XB031':['watchOutZH']},
574:{'CUR:XB027':['frontZH']},
651:{'VC-006':['watchOutZH']},
772:{'GSC-139':['frontZH','answerZH','keyPointZH']},
794:{'GSC-133':['watchOutZH']},
800:{'GCL-030':['watchOutZH']},
865:{'GSC-133':['watchOutZH']},
930:{'GSC-133':['watchOutZH']},
940:{'VC-007':['frontZH']},
952:{'CUR:XA004':['watchOutZH']},
989:{'VC-010':['watchOutZH']},
995:{'GSC-133':['watchOutZH']}
}
changes=[];allrows=[]
for path in sorted((O/'parts').glob('part*.json')):
 rows=json.loads(path.read_text())
 for r in rows:
  q=r['qid']
  if q==952:
   r['usedRuleIds']=[x for x in r['usedRuleIds'] if x!='CUR:SC01'];r['necessaryAnchors']=[x for x in r['necessaryAnchors'] if x['ruleId']!='CUR:SC01'];changes.append({'qid':q,'action':'Removed ordinary KMS permission configuration from necessary rule dependencies; no verdict change.'})
  for rid,fields in extra.get(q,{}).items():
   if rid not in r['usedRuleIds']:r['usedRuleIds'].append(rid)
   for f in fields:
    text=P[rid]['visibleBody'][f]
    if text and not any(a['ruleId']==rid and a['field']==f for a in r['necessaryAnchors']):r['necessaryAnchors'].append(dict(ruleId=rid,bodySha256=P[rid]['bodySha256'],field=f,quote=text,start=0,end=len(text)))
   changes.append({'qid':q,'ruleId':rid,'action':'Bound additional already-read visible scope/boundary or necessary supporting card.','fields':fields})
  used=set(r['usedRuleIds']);closure=set()
  def add(rid):
   if rid in closure:return
   closure.add(rid)
   for dep in P[rid]['prerequisiteRuleIds']:add(dep)
  for rid in used:add(rid)
  r['actualVisibleGroup']=[dict(ruleId=rid,bodySha256=P[rid]['bodySha256'],prerequisiteRuleIds=P[rid]['prerequisiteRuleIds'],role='used' if rid in used else 'recursive_prerequisite') for rid in sorted(closure)]
  r['sourceCasePath']=str(I/'b'/('cases'+path.stem[-2:]+'.json'))
  r['selectionInterpretation']='full_supported_choice_or_required_combination' if r['status']=='SUPPORTED' else ('conditional_candidate_not_unconditional_coverage' if r['status']=='CONDITIONAL' else ('feasible_alternatives_or_remaining_valid_option_not_a_unique_complete_answer' if r['status']=='SOURCE_ISSUE' else 'no_proven_complete_selection'))
  if q in [590,995]:
   r['sourceIssueEvidenceKind']='two concrete feasible alternatives under the original stated optimization goal'
   r['sourceIssueAlternativeExamples']=([{'optionOrdinal':1,'implementation':'RDS read replica receives ongoing asynchronous changes; monthly report connects to replica endpoint while ordinary requests remain on writer.','cardRules':['GSC-046']},{'optionOrdinal':2,'implementation':'At the monthly reporting boundary restore a current native backup to a separate DB instance; run the month-end snapshot report there while writer continues ordinary requests. No freshness or least-maintenance requirement was stated.','cardRules':['CUR:NB04']}] if q==590 else [{'optionOrdinal':2,'implementation':'ECS/Fargate matching resource requirements streams source video from S3 for a 20-minute container processing task; task replicas scale with demand; metadata is stored in Aurora.','cardRules':['CUR:XB019','GSC-137','GSC-025']},{'optionOrdinal':3,'implementation':'SQS retains each S3 Standard video work reference; EC2 ASG consumers process for 20 minutes, confirm successful work, and scale by backlog per instance.','cardRules':['GSC-079','GSC-114','CUR:NA05']}])
  elif r['status']=='SOURCE_ISSUE':r['sourceIssueEvidenceKind']='positive AWS official snapshot evidence'
  allrows.append(r)
 path.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(O/'anchor-closeout-changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((I/'b/manifest.json').read_text());failures=[]
for p,h in manifest.items():
 if sha(p)!=h:failures.append('frozen manifest mismatch '+p)
for rid,p in P.items():
 if canon(p['visibleBody'])!=p['bodySha256']:failures.append('body canonical mismatch '+rid)
 if any(x not in P for x in p['prerequisiteRuleIds']):failures.append('pool has excluded/missing prerequisite '+rid)
index=json.loads((I/'card-review-index.frozen.json').read_text());ix={x['ruleId']:x for x in index['cards']}
for rid in P:
 if ix[rid]['status']!='PASS' or ix[rid]['currentBodySha256']!=P[rid]['bodySha256']:failures.append('current FACT/teaching binding mismatch '+rid)
if len(allrows)!=150 or len({r['qid'] for r in allrows})!=150 or set(C)!={r['qid'] for r in allrows}:failures.append('qid coverage')
for r in allrows:
 q=C[r['qid']]
 if canon(q['question'])!=q['questionCanonicalSha256'] or r['questionCanonicalSha256']!=q['questionCanonicalSha256']:failures.append('question hash '+str(r['qid']))
 if not r['fullStemAndAllOptionsRead']:failures.append('full read marker '+str(r['qid']))
 if any(n<1 or n>len(q['question']['options']) for n in r['selectedOptionOrdinals']):failures.append('option ordinal '+str(r['qid']))
 for a in r['necessaryAnchors']:
  p=P[a['ruleId']]
  if a['bodySha256']!=p['bodySha256'] or p['visibleBody'][a['field']][a['start']:a['end']]!=a['quote']:failures.append('anchor '+str(r['qid']))
  if a['ruleId'] not in r['usedRuleIds']:failures.append('unused anchor '+str(r['qid']))
 closure=set()
 def add(rid):
  if rid in closure:return
  closure.add(rid)
  for dep in P[rid]['prerequisiteRuleIds']:add(dep)
 for rid in r['usedRuleIds']:add(rid)
 if closure!={x['ruleId'] for x in r['actualVisibleGroup']}:failures.append('closure '+str(r['qid']))
 for x in r['actualVisibleGroup']:
  if x['bodySha256']!=P[x['ruleId']]['bodySha256'] or x['prerequisiteRuleIds']!=P[x['ruleId']]['prerequisiteRuleIds']:failures.append('closure binding '+str(r['qid']))
 if r['status']!='SUPPORTED' and not r['concreteGapOrCondition']:failures.append('missing limitation '+str(r['qid']))
 if r['status']=='SOURCE_ISSUE' and not(r.get('officialEvidence') or len(r.get('sourceIssueAlternativeExamples',[]))>=2):failures.append('source issue without positive proof '+str(r['qid']))
 for e in r.get('officialEvidence',[]):
  d=json.loads(Path(e['snapshotPath']).read_text());t=d['text']
  if sha(e['snapshotPath'])!=e['snapshotSha256'] or hashlib.sha256(t.encode()).hexdigest()!=e['textSha256'] or t[e['start']:e['end']]!=e['quote']:failures.append('official evidence '+str(r['qid']))
assert not failures,failures
allrows.sort(key=lambda x:x['qid'])
counts=dict(collections.Counter(x['status'] for x in allrows));out={'scope':'independent final-core-closure01 reviewer B; 150 affected originals only','frozenVisiblePoolCount':len(P),'finalCardCount':None,'notFinalN':True,'counts':counts,'results':allrows,'usage':{'modelCliApiCalls':0,'native':'unknown'},'originalsAndCurrentInventoryUnchanged':True}
(O/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
readback={'status':'PASS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewScope':'150 complete original questions, current actual visible Chinese cards and recursive prerequisite bodies','questions':150,'counts':counts,'checks':{'frozenManifestFiles':len(manifest),'frozenVisibleBodiesCanonicalHashes':len(P),'currentFactTeachingPassBindings':len(P),'questionCanonicalHashes':150,'fullStemAndAllOptionsReadMarkers':150,'uniqueAndExactQidSet':True,'necessaryAnchorExactSlices':sum(len(x['necessaryAnchors']) for x in allrows),'recursivePrerequisiteClosures':150,'excludedOrQuarantinedCardsUsed':False,'positiveSourceIssueEvidence':True,'noFinalNClaim':True},'failures':[],'semanticReadbackBoundary':'This deterministic readback checks complete current evidence binding and accounting; it does not upgrade any CONDITIONAL/INSUFFICIENT_CARDS/SOURCE_ISSUE or measure learner performance.','files':{str(p):sha(p) for p in sorted((O/'parts').glob('part*.json'))},'resultsSha256':sha(O/'results.json'),'usage':{'modelCliApiCalls':0,'native':'unknown'}}
(O/'readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n')
lines=['# 独立回测 B：150题','',f'当前冻结358卡池；本批115题SUPPORTED、16题CONDITIONAL、14题INSUFFICIENT_CARDS、5题SOURCE_ISSUE。358为候选实际卡池数，不是最终N。','','已逐题读完整题干及全部选项，必要卡句、正文哈希、引用偏移和递归先修绑定在results.json及parts。readback.json通过150题全集/完整题哈希/可见卡358正文哈希/当前事实教学凭证绑定/全部锚点切片/先修闭包检查。','','未使用被省略7卡或隔离GCL-020；未读旧预期答案或作者分析；未改正文、原题、学习记录或生产指针。模型CLI/API调用0，native用量unknown；未声明最终N。','','## 未充分项','']
for r in allrows:
 if r['status']!='SUPPORTED':lines.append(f"- Q{r['qid']} {r['status']}：{r['concreteGapOrCondition']}")
lines+=['','题源问题Q457/Q500/Q781附官方正向快照；Q590/Q995列两个按原题实际约束可行的具体实现。题源纠错须由主任务另行处理，本报告不改写原题。','']
(O/'readback.md').write_text('\n'.join(lines))
print(json.dumps({'status':'PASS','counts':counts,'anchors':readback['checks']['necessaryAnchorExactSlices'],'results':str(O/'results.json'),'readback':str(O/'readback.json')},ensure_ascii=False))

import json,hashlib,sys
from pathlib import Path
OUT=Path(__file__).parent
INP=OUT.parent/'input'
POOL={c['ruleId']:c for c in json.loads((INP/'visible-pool.frozen.json').read_text())}
def make(s,c):
 qid,status,selected,ids,reason,*rest=s
 anchors=[]
 for rid in ids:
  card=POOL[rid]
  for field in ('answerZH','keyPointZH'):
   quote=card['visibleBody'][field]
   if quote: anchors.append(dict(ruleId=rid,bodySha256=card['bodySha256'],field=field,quote=quote,start=0,end=len(quote)))
 allids=set()
 def add(rid):
  if rid in allids:return
  allids.add(rid)
  for p in POOL[rid].get('prerequisiteRuleIds',[]):add(p)
 for rid in ids:add(rid)
 return dict(qid=qid,status=status,questionCanonicalSha256=c['questionCanonicalSha256'],fullStemAndAllOptionsRead=True,selectedOptionOrdinals=selected,usedRuleIds=ids,necessaryAnchors=anchors,actualVisibleGroup=[dict(ruleId=rid,bodySha256=POOL[rid]['bodySha256'],prerequisiteRuleIds=POOL[rid].get('prerequisiteRuleIds',[]),role='used' if rid in ids else 'recursive_prerequisite') for rid in sorted(allids)],reasoningAndClosestCompetitor=reason,concreteGapOrCondition=rest[0] if rest else None,reviewBasis='Current frozen visible Chinese card bodies only; original complete stem and every option inspected; retrieval IDs were not treated as proof.',usage={'modelCliApiCalls':0,'native':'unknown'})
n=sys.argv[1]
cases=json.loads((INP/'b'/f'cases{n}.json').read_text())
spec=json.loads((OUT/f'spec{n}.json').read_text())
assert {c['qid'] for c in cases}=={s[0] for s in spec}
by={c['qid']:c for c in cases}
results=[make(s,by[s[0]]) for s in spec]
(OUT/'parts'/f'part{n}.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(n,len(results),{s:sum(r['status']==s for r in results) for s in sorted({r['status'] for r in results})})

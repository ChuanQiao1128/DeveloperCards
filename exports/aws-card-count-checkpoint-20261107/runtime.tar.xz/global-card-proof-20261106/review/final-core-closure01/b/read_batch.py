import json,sys
from pathlib import Path
I=Path(__file__).parent.parent/'input'
n=int(sys.argv[1]); seen=set()
for j in range(1,n):
 for c in json.loads((I/'b'/f'cases{j:02d}.json').read_text()):seen.update(x['ruleId'] for x in c['visibleCards'])
a=json.loads((I/'b'/f'cases{n:02d}.json').read_text()); new={}
for c in a:
 print('\nQ'+str(c['qid'])+' '+c['question']['stem'])
 for o in c['question']['options']:print(o['ordinal'],o['text'])
 print('cards:',','.join(x['ruleId'] for x in c['visibleCards']))
 for x in c['visibleCards']:
  if x['ruleId'] not in seen:new[x['ruleId']]=x
print('\nNEW VISIBLE CARD BODIES')
for rid,x in new.items():print(rid,json.dumps(x['visibleBody'],ensure_ascii=False))

import json,hashlib,collections,re
from pathlib import Path
from datetime import datetime,timezone
import review_helper as h
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canonical=lambda d:hashlib.sha256(json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
errors=[]
manifest=json.loads((h.INPUT/'c/manifest.json').read_text())
for p,s in manifest.items():
 if sha(p)!=s:errors.append('input manifest mismatch '+p)
rows=[r for p in sorted((h.BASE/'parts').glob('part[0-9][0-9].json')) for r in json.loads(p.read_text())]
qids=[r['qid'] for r in rows]
if len(qids)!=len(set(qids)):errors.append('duplicate question')
if set(qids)!=set(h.QUESTIONS):errors.append('question set mismatch')
for c in h.POOL:
 if canonical(c['visibleBody'])!=c['bodySha256']:errors.append('pool body hash '+c['ruleId'])
for r in rows:
 qid=r['qid'];case=h.QUESTIONS[qid];q=case['question'];prefix='Q'+str(qid)+' '
 if canonical(q)!=case['questionCanonicalSha256'] or r['questionCanonicalSha256']!=case['questionCanonicalSha256']:errors.append(prefix+'question hash')
 if r['fullStemAndAllOptionsRead'] is not True:errors.append(prefix+'read flag')
 if r['status'] not in ['SUPPORTED','CONDITIONAL','INSUFFICIENT_CARDS','SOURCE_ISSUE','UNKNOWN']:errors.append(prefix+'status')
 ordinals={o['ordinal'] for o in q['options']}
 if not set(r['selectedOptionOrdinals'])<=ordinals:errors.append(prefix+'option bounds')
 if r['status']=='SUPPORTED':
  expected=3 if re.search(r'Choose three',q['stem'],re.I) else 2 if re.search(r'Choose two',q['stem'],re.I) else 1
  if len(r['selectedOptionOrdinals'])!=expected:errors.append(prefix+'selected option count')
 if not r['reasoningAndClosestCompetitor']:errors.append(prefix+'reasoning absent')
 anchors=r['necessaryAnchors'];used=set(r['usedRuleIds']);anchored={a['ruleId'] for a in anchors}
 if not used<=anchored:errors.append(prefix+'used rule without anchor '+str(used-anchored))
 for a in anchors:
  c=h.CARDS[a['ruleId']];t=c['visibleBody'][a['field']]
  if a['ruleId'] not in used or a['bodySha256']!=c['bodySha256'] or t[a['start']:a['end']]!=a['quote']:errors.append(prefix+'anchor mismatch')
 closure=set()
 def walk(i):
  if i in closure:return
  closure.add(i)
  for p in h.CARDS[i]['prerequisiteRuleIds']:walk(p)
 for i in used:walk(i)
 actual={c['ruleId']:c for c in r['actualVisibleGroup']}
 if set(actual)!=closure:errors.append(prefix+'prerequisite closure set')
 for i,c in actual.items():
  frozen=h.CARDS[i]
  if c['bodySha256']!=frozen['bodySha256'] or c['prerequisiteRuleIds']!=frozen['prerequisiteRuleIds']:errors.append(prefix+'closure hash/dependency')
  if c['role']!=('used' if i in used else 'recursive-prerequisite'):errors.append(prefix+'closure role')
 if 'GCL-020' in closure:errors.append(prefix+'quarantined card')
 if r['status']=='SOURCE_ISSUE' and not r.get('officialEvidence') and len(r.get('sourceIssueCounterexamples',[]))<2:errors.append(prefix+'source issue no positive proof')
 for a in r.get('officialEvidence',[]):
  p=Path(a['snapshotPath']);d=json.loads(p.read_text());t=d['text']
  if sha(p)!=a['snapshotSha256'] or hashlib.sha256(t.encode()).hexdigest()!=a['textSha256'] or t[a['start']:a['end']]!=a['quote']:errors.append(prefix+'official evidence mismatch')
rows.sort(key=lambda r:r['qid'])
out=h.BASE/'results.json';out.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
counts=dict(collections.Counter(r['status'] for r in rows))
summary={s:[r['qid'] for r in rows if r['status']==s] for s in counts}
(h.BASE/'status-summary.json').write_text(json.dumps({'counts':counts,'qidsByStatus':summary},ensure_ascii=False,indent=2)+'\n')
report={'status':'PASS' if not errors else 'FAIL','scope':'150 original-question independent visible-current-core-card closure C; not final N or full-bank coverage','completedUtc':datetime.now(timezone.utc).isoformat(),'inputManifestPath':str(h.INPUT/'c/manifest.json'),'inputManifestSha256':sha(h.INPUT/'c/manifest.json'),'inputManifestEntriesVerified':len(manifest),'frozenVisiblePoolUniqueCards':len(h.POOL),'reviewedQuestions':len(rows),'expectedQuestions':len(h.QUESTIONS),'fullStemAndAllOptionsReadCount':sum(r['fullStemAndAllOptionsRead'] is True for r in rows),'statusCounts':counts,'necessaryAnchors':sum(len(r['necessaryAnchors']) for r in rows),'actualUsedUniqueRuleIds':len({i for r in rows for i in r['usedRuleIds']}),'recursiveVisibleUniqueRuleIds':len({c['ruleId'] for r in rows for c in r['actualVisibleGroup']}),'checks':['all frozen input hashes unchanged','full canonical original stem/options hashes recomputed','all frozen visible body hashes recomputed','150 exact qid set; no duplicates','selected options in range and SUPPORTED choose-count matched','used rules each have exact necessary visible anchor','quote offsets verified in named field','recursive prerequisites exact closure and hashes matched','only frozen 358 pool used; GCL-020 absent','SOURCE_ISSUE has positive official snapshot or two concrete viable counterexamples','official snapshot/quote hashes and offsets verified'],'errors':errors,'resultsPath':str(out),'resultsSha256':sha(out),'partFiles':[{'path':str(p),'sha256':sha(p),'questions':len(json.loads(p.read_text()))} for p in sorted((h.BASE/'parts').glob('part[0-9][0-9].json'))],'usage':{'modelCliCalls':0,'modelApiCalls':0,'nativeTokens':'unknown'},'boundaries':['No authoring or current-card/source-question changes','No old expected answers or author analyses read','No formal inventory, study records, publication or automation changes','Statuses are design sufficiency judgments, not learner performance','358 frozen candidate bodies are not final N']}
(h.BASE/'readback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'questions':len(rows),'counts':counts,'errors':errors,'resultsSha256':sha(out)},ensure_ascii=False))
if errors:raise SystemExit(1)

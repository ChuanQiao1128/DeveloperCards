import json,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
BASE=Path(__file__).parent
INPUT=BASE.parent/'input'
POOL=json.loads((INPUT/'visible-pool.frozen.json').read_text())
CARDS={x['ruleId']:x for x in POOL}
CASES=[q for p in sorted((INPUT/'c').glob('cases*.json')) for q in json.loads(p.read_text())]
QUESTIONS={x['qid']:x for x in CASES}
def render(part,start=0,end=20):
 qs=json.loads((INPUT/'c'/f'cases{part:02}.json').read_text())[start:end]
 ids=[]
 for c in qs:
  q=c['question']; print('\nQ'+str(c['qid'])+' '+q['stem'])
  for x in q['options']: print(str(x['ordinal'])+': '+x['text'])
  print('RETRIEVAL',','.join(c['initialRuleIdsForRetrievalOnly']))
  for id in c['initialRuleIdsForRetrievalOnly']:
   if id not in ids: ids.append(id)
 print('\nVISIBLE RETRIEVAL CARDS')
 for id in ids:
  if id not in CARDS: print(id,'NOT IN POOL');continue
  c=CARDS[id]; print(id,'prereq',c['prerequisiteRuleIds'])
  for f,t in c['visibleBody'].items():
   if t:print(f+': '+t)
def add(part,decisions):
 path=BASE/'parts'/f'part{part:02}.json'
 prior=json.loads(path.read_text()) if path.exists() else []
 for d in decisions:
  qid=d['qid']; case=QUESTIONS[qid]; ids=d.pop('rules')
  anchors=[]
  for selector in d.pop('anchors'):
   id,field=selector.split('|');c=CARDS[id];quote=c['visibleBody'][field]
   assert quote
   anchors.append({'ruleId':id,'bodySha256':c['bodySha256'],'field':field,'quote':quote,'start':0,'end':len(quote)})
  closure={}
  def walk(id):
   if id in closure:return
   c=CARDS[id];closure[id]={'ruleId':id,'bodySha256':c['bodySha256'],'prerequisiteRuleIds':c['prerequisiteRuleIds'],'role':'used' if id in ids else 'recursive-prerequisite'}
   for p in c['prerequisiteRuleIds']:walk(p)
  for id in ids:walk(id)
  row={'qid':qid,'questionCanonicalSha256':case['questionCanonicalSha256'],'fullStemAndAllOptionsRead':True,**d,'usedRuleIds':ids,'necessaryAnchors':anchors,'actualVisibleGroup':list(closure.values())}
  assert not any(x['qid']==qid for x in prior)
  prior.append(row)
 path.write_text(json.dumps(prior,ensure_ascii=False,indent=2)+'\n')
 print('saved',path,len(prior))
if __name__=='__main__':render(*map(int,sys.argv[1:]))
def official(path,quote):
 p=Path(path);d=json.loads(p.read_text());t=d['text'];i=t.index(quote)
 return {'url':d['url'],'snapshotPath':str(p),'snapshotSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':quote,'start':i,'end':i+len(quote)}

import json,pathlib,hashlib,datetime,sys,shutil,re,subprocess
V=pathlib.Path(__file__).resolve().parents[3]
BASE=V/'review/final-core-closure01';OUT=BASE/'a';I=BASE/'input'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def canon(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def write(p,x):pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
POOL={x['ruleId']:x for x in read(I/'visible-pool.frozen.json')};CAT=read(I/'official-snapshot-catalogue.json')
CASES={c['qid']:c for f in sorted((I/'a').glob('cases*.json')) for c in read(f)}
def evidence(ref,term):
 if isinstance(ref,int):
  src=pathlib.Path(CAT[ref]['snapshotPath']);dst=OUT/'official-evidence'/('catalogue-%03d.snapshot.json'%ref)
  if not dst.exists():shutil.copyfile(src,dst)
 else:dst=OUT/'official-evidence'/(ref+'.snapshot.json')
 x=read(dst);t=x['text'];m=re.search(re.escape(term).replace(r'\ ',r'\s+'),t,re.I)
 if not m:raise ValueError(('missing official quote',ref,term))
 st=max(0,m.start()-120);en=min(len(t),m.end()+380)
 return {'url':x.get('url',x.get('requestedUrl')),'snapshotPath':str(dst),'snapshotSha256':sha(dst),'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':t[st:en],'start':st,'end':en}
def anch(spec):
 rid,*rest=spec.split('|',2);field=rest[0] if rest else 'keyPointZH';t=POOL[rid]['visibleBody'][field];q=rest[1] if len(rest)>1 else t
 assert q in t,(rid,field,q)
 st=t.index(q);return {'ruleId':rid,'bodySha256':POOL[rid]['bodySha256'],'field':field,'quote':q,'start':st,'end':st+len(q)}
def closure(rids):
 seen={}
 def walk(r):
  if r in seen:return
  x=POOL[r];seen[r]={'ruleId':r,'bodySha256':x['bodySha256'],'prerequisiteRuleIds':x['prerequisiteRuleIds'],'usage':'direct' if r in rids else 'recursive_prerequisite'}
  for a in x['prerequisiteRuleIds']:walk(a)
 for r in rids:walk(r)
 return list(seen.values())
def result(qid,d,v=None):
 c=CASES[qid];q=c['question'] if v is None else v['correctedQuestion'];h=c['questionCanonicalSha256'] if v is None else v['correctedQuestionCanonicalSha256']
 assert canon(q)==h,(qid,canon(q),h)
 aa=[anch(s) for s in d['anchors']];rids=list(dict.fromkeys(a['ruleId'] for a in aa))
 out={'qid':qid,'status':d['status'],'questionCanonicalSha256':h,'fullStemAndAllOptionsRead':True,'selectedOptionOrdinals':d.get('selected',[]),'usedRuleIds':rids,'necessaryAnchors':aa,'actualVisibleGroup':closure(rids),'reasoningAndClosestCompetitor':d['reason'],'gapsOrConditions':d.get('gaps',[]),'officialEvidence':[evidence(*a) for a in d.get('evidence',[])],'poolWideAlternativeSearch':d.get('search','Checked the frozen 358-card pool; only the cited rules supply the necessary premises. No excluded card was used.')}
 if 'combinations' in d:out['validOptionCombinations']=d['combinations']
 if v:
  out.update(variantId=v['variantId'],originalQid=qid,originalQuestionCanonicalSha256=v['originalQuestionCanonicalSha256'],correctedQuestionCanonicalSha256=h,minimalityReview=d.get('minimality','Only the identified defective condition/option is changed; the original business task and unaffected options are retained.'),originalStatusNotUpgraded=True)
 return out
if __name__=='__main__':
 num=sys.argv[1];ds=read(OUT/('decisions'+num+'.json'));rs=[];vs=[]
 for c in read(I/'a'/('cases'+num+'.json')):
  d=ds[str(c['qid'])];rs.append(result(c['qid'],d))
  for v in c.get('correctedPracticeVariants',[]):vs.append(result(c['qid'],d['variants'][v['variantId']],v))
 part={'part':num,'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':rs,'correctedPracticeResults':vs,'directModelCliApiCalls':0,'nativeUsage':'unknown'};write(OUT/'parts'/('part'+num+'.json'),part)
 print('saved',num,len(rs),len(vs))

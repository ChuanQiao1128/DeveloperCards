exec((__import__('pathlib').Path(__file__).parent/'review_local.py').read_text().split("if __name__")[0])
from collections import Counter
manifest=read(I/'a/manifest.json');inputs=[{'path':p,'expectedSha256':h,'actualSha256':sha(p),'matches':sha(p)==h} for p,h in manifest.items()]
parts=[read(p) for p in sorted((OUT/'parts').glob('part*.json'))];rs=[r for p in parts for r in p['results']];vs=[r for p in parts for r in p['correctedPracticeResults']]
idx=read(I/'card-review-index.frozen.json');cards={c['ruleId']:c for c in idx['cards']};selection=read(I/'selection.frozen.json')
assert len(rs)==83 and len(vs)==48 and len(set(r['qid'] for r in rs))==83 and len(set(r['variantId'] for r in vs))==48
source={r['qid']:r for r in rs}
nonminimal={'Q321-CV03':'Changes the original encryption outcome into an explicit request-header compliance objective, a distinct task.','Q324-CV02':'Adds no-backup-software restriction in addition to necessary capacity correction.','Q764-CV06':'Invents direct-public-web/no-proxy and an unspecified Aurora-incompatible feature.','Q949-CV05':'Replaces a truncated original option with a new S3 distractor without recovering the original wording.'}
for r in rs:
 if r['qid'] in (454,783):
  r['currentAwsScopeDisposition']={'eligibleForUserAcceptedConfirmedRetirementException':True,'policyPath':str(V/'inputs/user-knowledge-scope-accepted.json'),'originalPreserved':True,'countedAsOriginalSupported':False,'archiveTopic':'Workload Discovery automatic workload diagrams' if r['qid']==454 else 'QLDB immutable cryptographically verifiable journal','currentTopicDisposition':'Officially retired service choice archived; replacement discovery tooling is an unverified future teaching target.' if r['qid']==454 else 'Original ledger requirement archived with retired QLDB; no replacement-ledger teaching or coverage is invented.'}
for r in vs:
 orig=source[r['qid']];confirmed=orig['status']=='SOURCE_ISSUE';r['originalDefectIndependentlyConfirmed']=confirmed
 r['standalonePracticeCardGroupStatus']=r['status']
 r['minimalityVerdict']='FAIL' if r['variantId'] in nonminimal else ('NOT_ESTABLISHED_FOR_ORIGINAL' if not confirmed else ('FAIL' if r['status']=='SOURCE_ISSUE' else 'PASS'))
 r['correctionDisposition']='NOT_ACCEPTABLE_AS_MINIMAL_CORRECTION' if r['variantId'] in nonminimal else ('ORIGINAL_NOT_CONFIRMED_ERRONEOUS_KEEP_SEPARATE_PRACTICE' if not confirmed else ('UNRESOLVED' if r['status']!='SUPPORTED' else 'CARD_GROUP_SUPPORTED_MINIMAL_CORRECTION'))
 if r['variantId'] in nonminimal:r['minimalityFailureReason']=nonminimal[r['variantId']]
 r['closureEligibleUnderAcceptedCorrectionPolicy']=confirmed and r['status']=='SUPPORTED' and r['minimalityVerdict']=='PASS'
# Bind reused immutable card fact checks, without reading older answers or author rationales.
allr=rs+vs;errors=[];anchors=0;hashes=0;official=0;used=set()
for r in allr:
 r['currentFactReviewBindings']=[{'ruleId':rid,'currentBodySha256':POOL[rid]['bodySha256'],'indexPath':str(I/'card-review-index.frozen.json'),'indexSha256':sha(I/'card-review-index.frozen.json'),'status':cards[rid]['status'],'proofs':cards[rid]['proofs']} for rid in r['usedRuleIds']]
 for a in r['necessaryAnchors']:
  anchors+=1;t=POOL[a['ruleId']]['visibleBody'][a['field']]
  if t[a['start']:a['end']]!=a['quote']:errors.append(('anchor',r['qid'],a))
  if a['bodySha256']!=POOL[a['ruleId']]['bodySha256']:errors.append(('body-binding',r['qid']))
 for g in r['actualVisibleGroup']:
  used.add(g['ruleId']);hashes+=1
  if g['bodySha256']!=POOL[g['ruleId']]['bodySha256']:errors.append(('dependency-hash',r['qid']))
  if cards[g['ruleId']]['currentBodySha256']!=g['bodySha256'] or cards[g['ruleId']]['status']!='PASS':errors.append(('fact-status',r['qid'],g['ruleId']))
  if g['ruleId'] not in selection['selectedRuleIds']:errors.append(('excluded',g['ruleId']))
 for e in r['officialEvidence']:
  official+=1;t=read(e['snapshotPath'])['text']
  if sha(e['snapshotPath'])!=e['snapshotSha256'] or t[e['start']:e['end']]!=e['quote']:errors.append(('official',r['qid']))
for rid,x in POOL.items():
 if canon(x['visibleBody'])!=x['bodySha256']:errors.append(('actual-visible-body-hash',rid))
 for dep in x['prerequisiteRuleIds']:
  if dep not in POOL:errors.append(('missing-pool-prerequisite',rid,dep))
if not all(a['matches'] for a in inputs):errors.append('input-manifest')
if set(source)!=set(CASES):errors.append('qid-coverage')
originalCounts=dict(Counter(r['status'] for r in rs));variantCounts=dict(Counter(r['status'] for r in vs));eligible=sum(r['closureEligibleUnderAcceptedCorrectionPolicy'] for r in vs)
metadata={'reviewer':'isolated reviewer A','reviewScope':'83 original full questions and 48 separate corrected practices, frozen candidate pool only','frozenPoolCount':len(POOL),'frozenPoolIsFinalN':False,'nativeUsage':'unknown','directModelCliApiCalls':0,'sourceDenominator':1018,'userExcludedOriginalQid':868,'productionPointersModified':False,'originalQuestionsModified':False,'originalAnswersOrAuthorVariantRationalesRead':False,'learningOutcomeMeasured':False,'originalStatusCounts':originalCounts,'correctedPracticeCardGroupStatusCounts':variantCounts,'correctionPolicyEligiblePracticeCount':eligible,'notMinimalVariantIds':list(nonminimal),'allInputManifestHashesMatch':all(a['matches'] for a in inputs),'retirementScopeExceptions':[454,783],'finalNDeclared':False,'note':'SUPPORTED is card-group design sufficiency only. A separately SUPPORTED practice is not accepted as original closure unless independent original defect confirmation and minimality also pass.'}
write(OUT/'results.json',{'metadata':metadata,'results':rs,'correctedPracticeResults':vs})
readback={'status':'PASS' if not errors else 'FAIL','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalCount':len(rs),'variantCount':len(vs),'questionIdsMatchFrozenInput':set(source)==set(CASES),'originalCanonicalHashesVerified':len(rs),'correctedCanonicalHashesVerified':len(vs),'necessaryAnchorChecks':anchors,'actualVisibleGroupHashChecks':hashes,'officialQuoteChecks':official,'actualPoolBodyHashesVerified':len(POOL),'partFiles':[{'path':str(p),'sha256':sha(p)} for p in sorted((OUT/'parts').glob('part*.json'))],'uniqueUsedRules':len(used),'allUsedRulesInFrozenSelectedPool':all(r in selection['selectedRuleIds'] for r in used),'excludedCardsUsed':[],'inputManifestChecks':inputs,'errors':errors,'resultsPath':str(OUT/'results.json'),'resultsSha256':sha(OUT/'results.json'),'metadata':metadata}
write(OUT/'readback.json',readback)
write(OUT/'metadata.json',metadata)
write(OUT/'official-evidence/metadata.json',{'sources':[{'path':str(p),'sha256':sha(p),'url':read(p).get('url'),'textSha256':hashlib.sha256(read(p)['text'].encode()).hexdigest()} for p in sorted((OUT/'official-evidence').glob('*.snapshot.json')) if read(p).get('text')],'scope':'AWS positive evidence only; fresh official HTML parsed locally or immutable existing official snapshot copied. No external model calls.'})
print(json.dumps(metadata,ensure_ascii=False,indent=2));print('readback',readback['status'],'anchors',anchors,'official',official,'errors',errors)

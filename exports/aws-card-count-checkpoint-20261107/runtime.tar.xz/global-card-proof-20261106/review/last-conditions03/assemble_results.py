import pathlib,json,hashlib,datetime,collections
P=pathlib.Path(__file__).parent;V=P.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
read=lambda p:json.loads(p.read_text())
manifest=read(P/'input/manifest.json')
for fn,h in manifest.items():assert sha(pathlib.Path(fn))==h,fn
cards={x['ruleId']:x for x in read(P/'input/visible-pool.frozen.json')};qs={x['qid']:x['question'] for x in read(P/'input/questions.json')}
assert len(cards)==362 and set(qs)=={267,355,734}
for c in cards.values():assert canon(c['visibleBody'])==c['bodySha256']
evidence={}
def ev(k,rel,quotes):
 p=V/rel;o=read(p);t=o['text'];assert hashlib.sha256(t.encode()).hexdigest()==o['textSha256']
 anchors=[]
 for q in quotes:
  assert q in t,(k,q);s=t.index(q);anchors.append({'quote':q,'start':s,'end':s+len(q)})
 evidence[k]={'sourceFile':str(p),'sourceFileSha256':sha(p),'url':o['url'],'finalUrl':o.get('finalUrl',o['url']),'httpStatus':o.get('httpStatus',200),'textSha256':o['textSha256'],'quotes':anchors,'reusedSnapshot':not str(p).startswith(str(P))}
E='review/last-conditions03/evidence/'
S='review/reuse-a/sources/'
ev('FLINK_SOURCES',S+'2c931334266adca900db.json',['The KinesisStreamsSource provides streaming data to your application from an Amazon Kinesis data stream.','The KafkaSource source provides streaming data to your application from an Amazon MSK topic.'])
ev('FLINK_FIREHOSE_SINK',S+'8f8249ba26d5003dbe50.json',['The FlinkKinesisFirehoseProducer is a reliable, scalable Apache Flink sink for storing application output using the Firehose service.'])
ev('FLINK_MANAGED_INFRASTRUCTURE',E+'flink-overview.snapshot.json',['Managed Service for Apache Flink provides the underlying infrastructure for your Apache Flink applications.','It handles core capabilities like provisioning compute resources, AZ failover resilience, parallel computation, automatic scaling, and application backups'])
ev('FIREHOSE_PARQUET',E+'firehose-format.snapshot.json',['Amazon Data Firehose can convert the format of your input data from JSON to\nApache Parquet\nor\nApache ORC\nbefore storing the data in Amazon S3.'])
ev('FIREHOSE_ENCRYPTION',E+'firehose-encryption.snapshot.json',['Amazon Data Firehose encrypts all data in transit using TLS protocol.','Amazon Data Firehose encrypts data using\nAWS Key Management Service'])
ev('S3_NEW_UPLOAD_ENCRYPTION',S+'e1e1c91f80b421c7dc9f.json',['all new object uploads to Amazon S3 are automatically encrypted at no additional cost and with no impact on performance.'])
ev('FARGATE_ECS_CPU_MEMORY',E+'fargate-resource-matrix.snapshot.json',['16384 (16 vCPU)','Between 32 GB and 120 GB in 8 GB increments','32768 (32 vCPU)','60 GB, 120 GB, 244 GB'])
ev('BATCH_FARGATE_CPU_MEMORY',S+'c67bb3a0de18e135e911.json',['value = 16 MEMORY = 32768, 40960, 49152, 57344, 65536, 73728, 81920, 90112, 98304, 106496, 114688, or 122880','value = 32 MEMORY = 61440, 122880, or 249856'])
ev('BATCH_MANAGED_EC2',E+'batch-managed-ec2.snapshot.json',['You can use a managed compute environment to have AWS Batch manage the capacity and instance\n   types of the compute resources within the environment.','AWS Batch doesn\'t automatically upgrade the AMIs in a compute environment after it\'s created.'])
ev('EC2_HIGH_RESOURCE_TYPES',E+'r6i-types.snapshot.json',['r6i.16xlarge\n64\n512','r6i.24xlarge\n96\n768'])
ev('LAMBDA_SINGLE_FUNCTION_MEMORY','review/remaining-source10/evidence/lambda-limits.json',['Function memory allocation\n128 MB to 10,240 MB, in 1-MB increments.'])
ev('DXGW_CROSS_REGION_VGW','review/remaining-source10/evidence/dxgw-vgw.json',['You can associate a virtual private gateway with a Direct Connect gateway to enable connectivity between your Direct Connect connection and VPCs across different accounts and Regions.','Each VPC requires a virtual private gateway that you associate with the Direct Connect gateway.','Direct communication between the virtual interfaces that are attached to a single Direct Connect gateway.'])
ev('DXGW_GLOBAL_SCOPE_AND_EXCEPTION','review/remaining-source10/evidence/dxgw.json',['A Direct Connect gateway is a globally available resource. You can connect to any Region globally using a Direct Connect gateway.','A Direct Connect gateway does not allow gateway associations that are on the same Direct Connect gateway to send traffic to each other','An exception to this rule, implemented in November 2021, is when a supernet is advertised across two or more VPCs','associated to the same Direct Connect gateway and on the same virtual interface. In this case, VPCs can communicate with each other via the Direct Connect endpoint.'])
(P/'evidence-registry.json').write_text(json.dumps({'evidence':evidence,'technicalUnknownsClaimed':False},ensure_ascii=False,indent=2)+'\n')

def make(qid,status,selected,ids,reason,competition,opts,eids,**extra):
 used=[]
 def visit(r):
  if r in used:return
  used.append(r)
  for d in cards[r].get('prerequisiteRuleIds',[]):visit(d)
 for r in ids:visit(r)
 anchors=[]
 for r in used:
  c=cards[r]
  for f,q in c['visibleBody'].items():
   if q:anchors.append({'ruleId':r,'bodySha256':c['bodySha256'],'field':f,'quote':q,'start':0,'end':len(q),'role':'necessary_visible_premise'})
 out={'qid':qid,'status':status,'questionCanonicalSha256':canon(qs[qid]),'fullStemAndAllOptionsReviewed':True,'originalQuestionPreserved':True,'selectedOptionOrdinals':selected,'selectedOrdinalsMeaning':'accepted selection for SUPPORTED; concrete scenario alternatives for SOURCE_ISSUE','choiceReasoning':reason,'keyCompetitionReasoning':competition,'optionDispositions':[{'ordinal':i+1,'originalLabel':chr(65+i),'originalTextSha256':hashlib.sha256(qs[qid]['options'][i]['text'].encode()).hexdigest(),'reason':text} for i,text in enumerate(opts)],'directlyUsedRuleIds':ids,'actualUsedRuleIdsIncludingRecursivePrerequisites':used,'cardBindings':[{'ruleId':r,'bodySha256':cards[r]['bodySha256'],'prerequisiteRuleIds':cards[r].get('prerequisiteRuleIds',[])} for r in used],'necessaryPremiseAnchors':anchors,'officialEvidenceIds':eids,'privateOfficialFactsDoNotReplaceVisibleTeaching':True,'learnerPerformanceMeasured':False}
 out.update(extra);return out
R=[]
R.append(make(267,'SUPPORTED',[4],['CUR:NC01','CUR:NS01','VC-011'],
'选择D的托管分析＋托管交付职责组合。当前CUR:NC01明确用支持的Kinesis Data Streams或Kafka/MSK源进入托管Flink，分析后由Firehose sink输出；CUR:NS01明确Firehose近实时交付S3及JSON→Parquet转换；VC-011明确新S3对象静态加密。配置应用逻辑、兼容输入、JSON输出/表schema、Firehose格式转换及加密即可满足。不能因为选项未枚举正常源/输出配置，要求再补原题或实测才能选择。',
'A中的Kinesis Data Streams本身不是S3交付器；即便用Flink S3 sink完成存储，也须维护其输出格式，并多了Lambda转送环节。C虽有合适Firehose交付，却用EMR集群而非托管流处理；B两者皆更繁。D减少自管分析集群和额外转送代码。没有把Firehose接成Flink输入，也没有宣称建完两服务就自动分析。',[
'A并非因任何未列细节而绝对不可能；其KDS保存流记录、Lambda转送及自行完成S3/Parquet输出，比托管分析＋内建交付多管理义务。','B既要自管EMR分析集群又有Lambda转送，没有最低运维优势。','C的托管交付可用，但EMR分析集群仍比Flink托管流处理承担更多集群管理。','D采用托管Flink分析与Firehose Parquet/S3输出，当前可见卡已教正确职责和方向。'],
['FLINK_SOURCES','FLINK_FIREHOSE_SINK','FLINK_MANAGED_INFRASTRUCTURE','FIREHOSE_PARQUET','FIREHOSE_ENCRYPTION','S3_NEW_UPLOAD_ENCRYPTION'],
remainingConditions=[],sourceIssueConfirmed=False,
ordinaryNonBlockingImplementation=[{'item':'兼容源连接器','resolution':'按CUR:NC01选KDS/Kafka等支持源，属于实现该托管分析应用的正常输入配置；不假定Firehose有可拉取队列接口。'},{'item':'输出格式/加密','resolution':'应用输出可转换JSON；Firehose配置schema、Parquet/S3目标及所需加密。题面没有指定必须在交给AWS前用客户算法变密文。'},{'item':'容量与延迟配置','resolution':'100万用户未给记录速率，按工作量配置支持的伸缩/缓冲；未规定硬秒级延迟，不要求生产压测作为单选前置条件。'}],
learnerDerivation={'givens':['移动应用数据持续产生','近实时分析及加密','集中S3/Parquet后续处理','最少运维'],'visibleCausalChain':['CUR:NC01：托管流处理分析，并在源/输出之间区分职责，Firehose是sink','CUR:NS01：托管缓冲交付S3，支持JSON转Parquet并由AWS管理交付服务器','VC-011：普通静态加密由S3托管密钥保护新上传对象'],'newPrivateInterfaceFactRequiredForSelection':False},
compatibilityNote='原选项Kinesis Data Analytics按现行托管Flink的流分析角色验收；未依赖停止新建/退役的旧SQL应用或旧Firehose输入接口。'))
constructCommon={'originalHost':{'vCPU':64,'memoryGiB':512},'jobSchedule':'hourly','originalAverageMinutes':15,'cpuIntensive':True,'application':'Linux legacy job, monolithic shared-memory processing; no cross-task rewrite assumed','whatStaysIdentical':'旧主机规格、运行频率、CPU密集、15分钟平均耗时与云上15分钟目标均保持；改变的只有原文没有给出的实际单作业资源需求。'}
R.append(make(355,'SOURCE_ISSUE',[2,4],['VC-002','CUR:XB019','GSC-133'],
'旧服务器有64vCPU/512GiB不等于批作业用满这些资源。现有VC-002恰好明确这条边界。Fargate现行单任务上限32vCPU/244GiB，而Batch EC2可选择更大实例。构造两种都能在给定旧主机平均15分钟完成的CPU密集作业：实际16vCPU/64GiB时B能承担且免主机维护；实际必须单任务64vCPU/512GiB时B不支持，D能选足规格EC2。由实际资源需求改变可行性/最少运维选择，不依赖要求用户先做生产SLA测试。',
'A的functional scaling不自动把遗留单作业拆成并行函数；在两种具体单体共享内存情境，单函数最大内存也不足。B与D是真正最近竞争。C不能把EC2 Auto Scaling直接用于Lightsail实例来取得所需批任务调度/容量；不会因旧主机给了大数字就自动选D。',[
'A不保证把一个不可拆的遗留共享内存任务变为多函数；不能仅看平均15分钟等于Lambda通常时限就判适配。','B在实际16vCPU/64GiB例可行，且免维护主机；实际64vCPU/512GiB例不支持单任务。','C所述Lightsail+AWS Auto Scaling不是该遗留高资源批任务的现成托管排队/容量组合。','D在高资源例以Batch托管调度并选择足规格EC2；但低实际需求例中并不比Fargate更少主机运维。'],
['FARGATE_ECS_CPU_MEMORY','BATCH_FARGATE_CPU_MEMORY','BATCH_MANAGED_EC2','EC2_HIGH_RESOURCE_TYPES','LAMBDA_SINGLE_FUNCTION_MEMORY'],
remainingConditions=[{'kind':'decisive_input_missing','description':'实际单作业CPU/内存需求（是否必须在一个执行单位内满足），不是AWS能力不明或普通测试尚未做。','blocksOriginalSupport':True}],
sourceConfirmation={'subtype':'decisive_input_missing','common':constructCommon,'construct1':{'actualSingleJobVCPU':16,'actualSingleJobMemoryGiB':64,'knownWorkloadProfile':'CPU计算实际只使用旧64核主机中的16核及64GiB，已有15分钟完成记录；剩余主机资源未被该作业使用。','targetResourceFeasibility':'ECS Fargate支持16vCPU与64GiB组合（Linux）；正常选择等效或更强支持规格满足该工作量，无须维护EC2主机。','preferredOrdinal':2,'whyThisDoesNotInventANewPerformanceObligation':'构造的是与原文相容的实际资源取值；不把尚未做基准测试当拒绝任何迁移的理由。'},'construct2':{'actualSingleJobVCPU':64,'actualSingleJobMemoryGiB':512,'knownWorkloadProfile':'同一旧主机规格下，另一个CPU密集作业确实需要64核和512GiB共享工作集，且不能拆成多个执行单位；平均15分钟。','targetResourceFeasibility':'Fargate最大32vCPU/244GiB，不能承载；Batch选择足规格EC2，例如r6i.24xlarge96vCPU/768GiB留宿主机余量，可分配所需64vCPU/512GiB。','preferredOrdinal':4},'whyNotContrived':'服务器经常承载未用满和用满资源的不同遗留作业；这正是当前VC-002已教的主机配置与作业需求区别。两例不变更原CPU密集或时限。','minimalClarificationRecommendation':'练习版只需明确“该单作业实际必须在一个执行单位中使用64vCPU/512GiB”（若要D），或提供真实较小单任务配置。原题中的旧服务器规格原样保留，不能偷偷替换成作业最低需求。','correctedVariantAuthored':False,'originalRemainsUnchanged':True},
cardGapInsteadOfSourceIssue=False,cardSufficiency='可见卡足以解释两种选择为什么不同；缺的是原场景的决定性取值，不需要新增背数值卡。'))
R.append(make(734,'SUPPORTED',[4],['GSC-073','GSC-075','CUR:CB16','CUR:XB019'],
'按原文“connectivity between two Regions and the data centers”的通常混合连接语义，复用既有专线，让两个机房接入跨两个Region的VPC集合。D的全局DX gateway关联各VPC的VGW，private VIF接入DX gateway，可共享专线提供跨账户/Region机房—VPC连接；GSC-073当前正文已明确这条路径及非自动转接边界。两个Region的非重叠VPC CIDR满足该关联前提。把第二条既有专线的适用VIF、VGW关联及路由配置纳入该架构属于正常实施，不另开等待条件。',
'A的inter-Region peering仅连接VPC，不提供把既有专线经一个VPC传给其他VPC的传递连接。B把private VIF直接连远端多个VPC，缺全局DX gateway/VGW共享结构。C自管EC2全网格VPN能增加连接但运维随连接和设备增长，比复用专线+全局网关重。未把D说成任意VPC/VIF自动互转，也不额外要求原文未逐对声明的DC↔DC或全部VPC两两直达。',[
'A只建VPC peering不能承担跨VPC转接现有DX到机房的共享接入需求。','B仅private VIF直连跨Region多个VPC不构成正确的可扩展共享结构；D才提供DX gateway和VGW关联。','C自管EC2 VPN全网格增加设备、隧道和路由维护；已有DX可复用时不满足最低运维取舍。','D可将既有DX经private VIF连接全局DX gateway，关联各Region VGW，为机房访问跨Region VPC提供共享路径。'],
['DXGW_CROSS_REGION_VGW','DXGW_GLOBAL_SCOPE_AND_EXCEPTION'],
remainingConditions=[],sourceIssueConfirmed=False,
originalTrafficScope={'exactOriginalClause':'The company requires connectivity between two Regions\nand the data centers.','acceptedNormalArchitectureReading':'两个既有机房使用专线访问位于两个Region的VPC集合，包括原来本地Region以外的VPC；采用题目要求的可扩展共享接入。','flowsActuallyProven':['原公司机房经DX/private VIF/DXGW到us-east-1及eu-west-2的关联VGW/VPC','所收购机房的既有DX以适用private VIF接入同一共享体系，到两个Region的关联VGW/VPC'],'notSilentlyAddedAsARequirement':['Direct Connect private VIF之间的直接机房↔机房转接','全部VPC两两直接转接','任意网络对任意网络的无条件互通'],'whyNotSourceUnderdetermination':'没有用户或题面给出全互通逐对矩阵。凭额外加入DC↔DC或全部VPC直达要求，无法构造一个只使用原明示要求却推翻D的独立反例。普通VIF/路由/关联省略不视为缺决定性输入。'},
technicalBoundaryReview={'default':'普通VGW/DXGW并不是TGW式关联之间任意传递路由，private VIF之间直接通信也不支持。','documentedException':'AWS当前概览明确：同DX gateway、同VIF、on-premises广告覆盖多个VPC的supernet时，可发生VPC间通信；2021-11起的例外保留，不能说所有VPC间通信绝不可能。','exceptionUsedToFillAnUntaughtNecessaryPremise':False,'why':'本题接受的机房—跨Region VPC共享接入本身不依赖这一例外。例外只用于保留正确平台边界，不用来声称原文要求的任意两两互通都已教会。'},
ordinaryNonBlockingImplementation=['适用private VIF','两条既有连接的关联配置','各VGW与DX gateway的跨账户/Region关联及前缀','BGP和请求/返回路由、安全组'],
learnerDerivation={'visibleCausalChain':['GSC-073：private VIF经DX gateway关联不同Region VGW/VPC；不自动提供任意转接','GSC-075：peering不提供传递路由，逐对扩展会增加拓扑关系','CUR:CB16：peering是直接VPC连接，路由仍要配置','CUR:XB019：自管EC2保留宿主机管理责任，不能因有AWS编排就认为VPN设备免维护'],'newPrivateExceptionRequiredForChoice':False}))
output={'reviewId':'last-conditions03','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'independent_native','scope':'only3 full original questions267/355/734 against362 frozen actual visible cards; no full-library replay','inputManifestSha256':sha(P/'input/manifest.json'),'candidatePoolCount':362,'candidatePoolIsFinalN':False,'originalQuestionCount':3,'statusCounts':dict(collections.Counter(x['status'] for x in R)),'results':R,'evidenceRegistryPath':str(P/'evidence-registry.json'),'evidenceRegistrySha256':sha(P/'evidence-registry.json'),'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','newCardsAuthored':0,'correctedVariantsAuthored':0,'originalQuestionEdits':0,'currentInventoryEdits':0,'productionPointersEdited':False,'priorClocksBudgetsCountersHistoryReset':False,'subagentsSpawned':0,'measuredLearnerOutcome':False}
(P/'results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n');print(output['statusCounts']);print(sha(P/'results.json'))

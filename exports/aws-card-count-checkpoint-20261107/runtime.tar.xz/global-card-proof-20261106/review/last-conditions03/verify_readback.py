import pathlib,json,hashlib,datetime,collections
P=pathlib.Path(__file__).parent;V=P.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
read=lambda p:json.loads(p.read_text())
checks=[]
def check(name,ok):
 assert ok,name
 checks.append({'check':name,'status':'PASS'})
m=read(P/'input/manifest.json')
for fn,h in m.items():check('frozen file '+pathlib.Path(fn).name,sha(pathlib.Path(fn))==h)
r=read(P/'results.json');e=read(P/'evidence-registry.json')['evidence'];c={x['ruleId']:x for x in read(P/'input/visible-pool.frozen.json')};q={x['qid']:x['question'] for x in read(P/'input/questions.json')}
check('exact3 original questions',set(q)=={267,355,734} and {x['qid'] for x in r['results']}==set(q) and len(r['results'])==3)
check('362 visible unique cards',len(c)==362)
check('status counts',r['statusCounts']=={'SUPPORTED':2,'SOURCE_ISSUE':1} and r['statusCounts']==dict(collections.Counter(x['status'] for x in r['results'])))
check('evidence registry binding',sha(P/'evidence-registry.json')==r['evidenceRegistrySha256'])
used={}
for item in r['results']:
 check('original canonical Q'+str(item['qid']),canon(q[item['qid']])==item['questionCanonicalSha256'])
 check('four options Q'+str(item['qid']),len(item['optionDispositions'])==len(q[item['qid']]['options'])==4)
 for d in item['optionDispositions']:
  check('option text Q'+str(item['qid'])+d['originalLabel'],hashlib.sha256(q[item['qid']]['options'][d['ordinal']-1]['text'].encode()).hexdigest()==d['originalTextSha256'])
 for b in item['cardBindings']:
  card=c[b['ruleId']];used[b['ruleId']]=b['bodySha256'];check('card binding Q'+str(item['qid'])+'/'+b['ruleId'],canon(card['visibleBody'])==card['bodySha256']==b['bodySha256'] and card.get('prerequisiteRuleIds',[])==b['prerequisiteRuleIds'])
 for a in item['necessaryPremiseAnchors']:
  card=c[a['ruleId']];check('exact visible sentence Q'+str(item['qid'])+'/'+a['ruleId']+'/'+a['field'],card['bodySha256']==a['bodySha256'] and card['visibleBody'][a['field']][a['start']:a['end']]==a['quote'])
 for eid in item['officialEvidenceIds']:check('registered evidence Q'+str(item['qid'])+'/'+eid,eid in e)
for eid,item in e.items():
 p=pathlib.Path(item['sourceFile']);o=read(p);check('evidence file hash '+eid,sha(p)==item['sourceFileSha256'])
 check('evidence text hash '+eid,hashlib.sha256(o['text'].encode()).hexdigest()==item['textSha256'])
 check('official URL '+eid,item['url'].startswith(('https://docs.aws.amazon.com/','https://aws.amazon.com/')))
 for a in item['quotes']:check('official quote '+eid+':'+str(a['start']),o['text'][a['start']:a['end']]==a['quote'])
corePath=V/'deliverables/core-visible-knowledge.provisional.json';core=read(corePath);cm={x['ruleId']:x for x in core}
for rid,h in used.items():check('current core used body '+rid,cm[rid]['bodySha256']==h)
check('current provisional362',len(core)==len(cm)==362)
q267=next(x for x in r['results'] if x['qid']==267);q355=next(x for x in r['results'] if x['qid']==355);q734=next(x for x in r['results'] if x['qid']==734)
check('267 source and sink direction retained','Firehose是sink' in q267['learnerDerivation']['visibleCausalChain'][0] and 'CUR:NC01' in q267['directlyUsedRuleIds'])
check('355 genuine two concrete resource cases',q355['sourceConfirmation']['construct1']['actualSingleJobVCPU']==16 and q355['sourceConfirmation']['construct2']['actualSingleJobVCPU']==64 and q355['sourceConfirmation']['construct1']['preferredOrdinal']!=q355['sourceConfirmation']['construct2']['preferredOrdinal'])
check('734 exact original traffic clause',q734['originalTrafficScope']['exactOriginalClause'] in q[734]['stem'])
check('734 no private exception used as hidden teaching',q734['technicalBoundaryReview']['exceptionUsedToFillAnUntaughtNecessaryPremise'] is False and len(q734['originalTrafficScope']['notSilentlyAddedAsARequirement'])==3)
check('no authoring/mutation/reset',r['newContentModelCallsCLIAPI']==r['newCardsAuthored']==r['correctedVariantsAuthored']==r['originalQuestionEdits']==r['currentInventoryEdits']==r['subagentsSpawned']==0 and not r['productionPointersEdited'] and not r['priorClocksBudgetsCountersHistoryReset'])
o={'reviewId':'last-conditions03','status':'PASS','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checkCount':len(checks),'checks':checks,'inputManifestSha256':sha(P/'input/manifest.json'),'resultsSha256':sha(P/'results.json'),'reportSha256':sha(P/'results.md'),'evidenceRegistrySha256':sha(P/'evidence-registry.json'),'originalQuestionCount':3,'statusCounts':r['statusCounts'],'officialSnapshotCount':len(e),'necessaryCurrentCardCount':len(used),'currentCorePath':str(corePath),'currentCoreSha256':sha(corePath),'currentCoreCount':len(core),'currentCoreIsFinalN':False,'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','originalQuestionEdits':0,'inventoryEdits':0,'priorClocksBudgetsHistoryReset':False,'fullLibraryReplayed':False,'correctedVariantAccepted':False,'learnerPerformanceMeasured':False}
(P/'readback.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');print('PASS',len(checks),'checks',len(used),'necessarycards');print('results',o['resultsSha256']);print('readback',sha(P/'readback.json'))

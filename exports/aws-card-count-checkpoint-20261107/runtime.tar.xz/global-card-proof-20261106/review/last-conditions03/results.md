本次仅独立回测原题267、355、734及当前362张可见核心卡：**267、734卡组充分；355确认缺少决定性作业资源输入**。没有继续以普通配置或“尚未做生产测试”为由挂CONDITIONAL。

| 原题 | 状态 | 裁定 |
| --- | --- | --- |
| 267 | SUPPORTED D | 当前卡已教支持的输入→托管Flink分析→Firehose sink→Parquet/S3交付，并由S3静态加密保护新对象。D提供最少运维的职责组合。 |
| 355 | SOURCE_ISSUE / decisive_input_missing | 旧主机64vCPU/512GiB不等于作业实际需求；实际16vCPU/64GiB与单作业64vCPU/512GiB会改变B/D选择。 |
| 734 | SUPPORTED D | 采用原文通常的机房与跨Region VPC共享接入语义，DX gateway经private VIF与各Region VGW关联，比自管EC2 VPN全网格维护少；不推导成任意网络两两转接。 |

267的正确方向是支持的Kinesis Data Streams或Kafka/MSK源进入托管Flink，分析结果从Firehose sink输出，由Firehose内建转换Parquet并交付S3。**Firehose不是Flink输入队列**。选项没有列全源连接器、schema、输出及加密配置，属于方案落地应做的正常设置，当前CUR:NC01、CUR:NS01、VC-011已教其职责；不能据此无限要求改题或实测。D仍需应用处理代码，不等于只创建两个服务便自动分析。A不是因未列配置便绝对不可行，但多了Lambda转送，并没有交付流内建转换的运维优势；B/C还需管理EMR分析集群。[Flink源](https://docs.aws.amazon.com/managed-flink/latest/java/how-sources.html)、[Flink Firehose sink](https://docs.aws.amazon.com/managed-flink/latest/java/how-sinks.html)、[Firehose格式转换](https://docs.aws.amazon.com/firehose/latest/dev/record-format-conversion.html)均有精确快照。

355用两个符合原文的普通场景确认欠定：两者都在64vCPU/512GiB旧主机上每小时执行、CPU密集、平均15分钟，且均为不可跨任务重写的共享内存作业。一个实际只使用16vCPU/64GiB，其余主机容量闲置，可选Fargate支持规格以免维护主机；另一个实际必须单任务64vCPU/512GiB，超Fargate当前32vCPU/244GiB范围，应选Batch与足规格EC2，例如96vCPU/768GiB实例为作业和宿主机留余量。改变的是原文未给的实际作业资源需求，而非增加生产压测义务。[ECS Fargate资源矩阵](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task-cpu-memory-error.html)、[Batch资源定义](https://docs.aws.amazon.com/batch/latest/APIReference/API_ResourceRequirement.html)、[EC2实例规格](https://aws.amazon.com/ec2/instance-types/r6i/)提供当前正证。最小练习字段是“该单作业实际必须在一个执行单位内使用64vCPU/512GiB”；不能把旧主机规格偷偷改成这个需求。本次未编写练习版，也未验收练习题卡组。

734保留原句“connectivity between two Regions and the data centers”。按通常混合连接语义，证明两既有机房经各自专线访问位于两个Region的关联VPC集合，包含远端Region访问。用户没有提供额外的逐对流量矩阵；不自行增加机房到机房或全部VPC两两直达条件，也不因此把D宣称成TGW式任意传递。当前GSC-073已明确跨Region DX gateway/VGW机制；GSC-075和CB16说明peering不承担所需传递接入。普通VIF、关联、BGP及回程路由不是新题面输入。[DX gateway跨Region VGW关联](https://docs.aws.amazon.com/directconnect/latest/UserGuide/virtualgateways.html)是正式依据。

DX gateway边界仍完整保留：默认不提供关联之间的任意转接，也不支持直接private VIF间通信。官方概览还明确保留2021年11月起的supernet、同DX gateway/同VIF例外，特定条件下VPC能互通，因此不能笼统说任何VPC间通信绝不可能。该例外只用于核准平台边界，**没有拿它填补当前卡面未教的必要前提或声称所有网络已经全互通**。[官方概览及例外](https://docs.aws.amazon.com/directconnect/latest/UserGuide/direct-connect-gateways-intro.html)。

全部必要可见句、正文hash、最近竞争和四选项判断在`results.json`。13份官方快照及精确偏移在`evidence-registry.json`；来源优先复用，新增仅必要的当前平台文档。`readback.json`回读冻结原文、362卡与实际当前必要卡、证据和状态计数。无新卡作者、无CLI/API模型调用，native用量unknown；原题、库存、生产指针、时钟、预算及历史未修改，不声称全库或最终N完成。

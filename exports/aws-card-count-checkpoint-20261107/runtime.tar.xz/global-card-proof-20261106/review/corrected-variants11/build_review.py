# -*- coding: utf-8 -*-
import collections, datetime, hashlib, json, re
from pathlib import Path

V=Path.cwd(); R=V/'review/corrected-variants11'; P=R/'input'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
objsha=lambda x:hashlib.sha256(canon(x).encode()).hexdigest()
manifest=json.loads((P/'manifest.json').read_text())
assert all(sha(p)==h for p,h in manifest.items())
cases=json.loads((P/'cases.json').read_text())
frozen={c['ruleId']:c for c in json.loads((P/'core-visible.frozen.json').read_text())}
assert len(frozen)==362 and all(objsha(c['visibleBody'])==c['bodySha256'] for c in frozen.values())
cards=frozen.copy(); incremental=[]
# Explicit accepted current changes only. The failed supplemental16 GSC-047 is excluded.
proofpath=V/'review/reuse-a/supplemental15.review.json'
receiptpath=V/'review/reuse-a/supplemental15.readback.json'
proof=json.loads(proofpath.read_text()); receipt=json.loads(receiptpath.read_text())
assert receipt['reviewSha256']==sha(proofpath) and receipt['status'].startswith('PASS')
live={c['ruleId']:c for c in json.loads((V/'deliverables/cards.current.json').read_text())}
for rid,affected in [('GSC-095',[501]),('GSC-016',[919])]:
    current=next(c for c in proof['results'] if c['ruleId']==rid)
    assert current['status']=='PASS' and objsha(current['visibleBody'])==current['bodySha256']
    assert current['visibleBody']==live[rid]['visibleBody']
    if current['bodySha256']!=cards[rid]['bodySha256']:
        incremental.append({'ruleId':rid,'affectedOriginalQids':affected,'frozenBodySha256':cards[rid]['bodySha256'],
          'currentBodySha256':current['bodySha256'],'visibleBody':current['visibleBody'],
          'proofPath':str(proofpath.resolve()),'proofSha256':sha(proofpath),
          'readbackPath':str(receiptpath.resolve()),'readbackSha256':sha(receiptpath),
          'acceptance':'PASS per exact card; frozen input is untouched'})
        cards[rid]={**cards[rid],'visibleBody':current['visibleBody'],'bodySha256':current['bodySha256'],
                    'prerequisiteRuleIds':current['prerequisiteRuleIds']}

# Parent adopted supplemental17 during this review. Only Q764 uses these two changed cards.
p17=V/'review/reuse-a/supplemental17.review.json'; r17=V/'review/reuse-a/supplemental17.readback.json'
j17=json.loads(p17.read_text()); receipt17=json.loads(r17.read_text())
assert receipt17['reviewSha256']==sha(p17) and receipt17['status'].startswith('PASS')
for rid in ['CUR:NB04','GSC-047']:
    current=next(c for c in j17['results'] if c['ruleId']==rid)
    assert current['status']=='PASS' and objsha(current['visibleBody'])==current['bodySha256']
    assert current['visibleBody']==live[rid]['visibleBody']
    incremental.append({'ruleId':rid,'affectedOriginalQids':[764],'frozenBodySha256':cards[rid]['bodySha256'],
      'currentBodySha256':current['bodySha256'],'visibleBody':current['visibleBody'],
      'proofPath':str(p17.resolve()),'proofSha256':sha(p17),'readbackPath':str(r17.resolve()),'readbackSha256':sha(r17),
      'acceptance':'Exact current card PASS; targeted Q764 review only.',
      'targetedImpactReason':'RDS/Aurora supported PITR and snapshot-plus-log mechanism remain taught. Added Redshift replica / manual-snapshot clauses are not necessary to Q764 and are not imported as extra answer obligations.'})
    cards[rid]={**cards[rid],'visibleBody':current['visibleBody'],'bodySha256':current['bodySha256'],
                'prerequisiteRuleIds':current['prerequisiteRuleIds']}

sources={}
def source(key,path,phrase):
    p=Path(path); j=json.loads(p.read_text()); t=j['text']
    match=re.search(r'\s+'.join(re.escape(s) for s in phrase.split()),t); assert match,(key,phrase)
    a,b=match.span()
    sources[key]={'url':j['url'],'snapshotPath':str(p.resolve()),'snapshotSha256':sha(p),
      'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':t[a:b],'quoteStart':a,'quoteEnd':b}
def import_source(key,item):
    path=item.get('snapshotPath',item.get('sourcePath'))
    expected=item.get('snapshotSha256',item.get('sourceFileSha256')); assert sha(path)==expected
    phrase=item.get('quote') or item['quotes'][0]['quote']; source(key,path,phrase)
past=json.loads((V/'review/remaining-source10/results.json').read_text())
for k in ['RDS_NO_ORACLE_CLUSTER','RDS_CLUSTER_NOT_AURORA','ORACLE_RR_LICENSE','DMS_ORACLE_TARGET',
          'FIFO_WINDOW','LAMBDA_SQS_AT_LEAST_ONCE','IO1_RATIO','S3_OVERHEAD','COST_TAGS','CE_GROUPS']:
    import_source(k,past['officialSources'][k])
cv10=json.loads((V/'review/corrected-variants10-current01/results.json').read_text())
for k in ['DATA_PIPELINE_EMR','AURORA_ENGINES','FLINK_SOURCE','FLINK_SINK','GLUE_KDS_OUTPUT']:
    import_source(k,cv10['officialEvidenceRegistry'][k])
s12=json.loads((V/'review/reuse-a/supplemental12.review.json').read_text())
for k,oldkey in [('INTERNET_FREE_ALLOWANCE','0443928cf85c762c5a0ccd49065e068e093fb6a5e697d4d3db2b7f99a1134db2'),
                 ('DX_PRICE_EXAMPLE','3ace764b726974ad2f7bc866e06c0cfb777bb382afdee73fbd1f8f580a872908')]:
    import_source(k,s12['evidenceRegistry'][oldkey])
source('CF_S3_WRITE_METHODS',R/'evidence/cloudfront-s3-methods.json',
 'CloudFront accepts the following requests from viewers and forwards them to your Amazon S3 origin: DELETE GET HEAD OPTIONS PATCH POST PUT')
source('CF_CACHES_READ_RESPONSES',R/'evidence/cloudfront-s3-methods.json',
 "CloudFront always caches responses to GET and HEAD requests. You can also configure CloudFront to cache responses to OPTIONS requests. CloudFront doesn't cache responses to requests that use the other methods.")
source('GLUE_SERVERLESS',V/'review/reuse-a/sources/3d0f63987febb279fd22.json',
 "It's also serverless, which means there's no infrastructure to manage.")
cat=json.loads((V/'review/final-core-closure01/input/official-snapshot-catalogue.json').read_text())
source('ARCHIVE_RETRIEVAL',cat[256]['snapshotPath'],
 'While objects stored in the S3 Glacier Instant Retrieval storage class are immediately available using GET , to access data stored in the S3 Glacier Flexible Retrieval or S3 Glacier Deep Archive storage classes you first need to retrieve data using the RestoreObject REST API.')

def close(ids):
    seen=set(ids); queue=list(ids)
    while queue:
        for d in cards[queue.pop()].get('prerequisiteRuleIds',[]):
            assert d in cards
            if d not in seen: seen.add(d); queue.append(d)
    return sorted(seen)
def anchors(ids,qid=None):
    narrow={
      (764,'CUR:NB04'):[('answerZH','RDS/Aurora或DynamoDB使用各自支持的备份/时间点恢复'),('keyPointZH','Aurora自动持续备份支持窗口内PITR')],
      (764,'GSC-047'):[('answerZH','近期用支持窗口内的PITR'),('keyPointZH','自动备份结合快照与事务日志，PITR窗口最多35天')],
      (764,'GSC-057'):[('frontZH','Aurora是兼容MySQL/PostgreSQL的关系库')]
    }
    out=[]
    for rid in ids:
        parts=narrow.get((qid,rid),[(f,t)for f,t in cards[rid]['visibleBody'].items()if t])
        for field,text in parts:
            start=cards[rid]['visibleBody'][field].index(text)
            out.append({'ruleId':rid,'bodySha256':cards[rid]['bodySha256'],'field':field,'quote':text,
                        'startChar':start,'endChar':start+len(text),'role':'actual necessary visible learning premise'})
    return out
def contains(haystack,needle):
    if isinstance(haystack,dict):
        if canon(haystack)==canon(needle):return True
        return any(contains(x,needle)for x in haystack.values())
    if isinstance(haystack,list):return any(contains(x,needle)for x in haystack)
    return False

judgments={
59:{
 'selected':[2,3,4],
 'ids':['CUR:NS01','CUR:XB004','CUR:XB013','GSC-093','CUR:CB03','CUR:CA13','CUR:NB03','GSC-029','GSC-133'],
 'official':['DATA_PIPELINE_EMR','CF_S3_WRITE_METHODS','CF_CACHES_READ_RESPONSES'],
 'defect':'原文没有最少运维、实时性或唯一框架目标，EC2处理后S3/Redshift与KDS/Firehose/S3/Redshift至少两条均可满足30TB/日，单选不唯一；Data Pipeline也须区分实际资格。',
 'minimal':'保留300多个网站、每日30TB和传输/分析目标，只改为全部技术可行并明确新客户无Data Pipeline资格。没有把原题暗改为最少运维。',
 'reason':'B由EC2执行代码并以ASG维持/扩展容量，结果入S3/Redshift；D由KDS保存流记录、Firehose交付S3、Redshift分析。C也有S3持久存储及对象创建Lambda处理：NB03已教CloudFront可转发上传至S3，CA13教缓存/回源，029教S3事件触发；可用受支持写接口完成这一路径，缓存自身不是采集或处理。总日量不要求一次Lambda读取30TB，可按对象分配工作并配置适用容量。此ALL题不按额外缓存层的必要性或运维高低排C。',
 'options':[
  '排除：本变体已明确公司是无Data Pipeline资格的新客户；不用把该服务写成对旧客户全面退役。',
  '可行：可伸缩EC2处理后存入S3，并用Redshift分析；没有给排除自管处理的优化目标。',
  '可行：CloudFront使用受支持写方法及S3源授权，数据落S3后由事件Lambda处理；可缓存相应GET内容。PUT/POST响应不被缓存，缓存也不替代数据写入。',
  '可行：KDS→Firehose→S3→Redshift的传输和分析链完整，可按日量配置适用容量。'],
 'notes':['旧Q059-CV10只证明至少B/D，并未封闭ALL。此次对C使用实际可见NB03与029正向推导，不复用“CloudFront不是摄取服务所以C不行”的简略排除。',
          '若另把C限定成“只有缓存，不许配置任何S3写接口”，它就不能摄取；当前题面没有这种限制，且明写Store the data in S3。普通受支持写配置不需要另造知识卡。']},
501:{
 'selected':[1],
 'ids':['CUR:XB004','CUR:CA17','CUR:NC01','CUR:NS01','CUR:NA05','CUR:CMP-M06','GSC-095','GSC-133'],
 'official':['FLINK_SOURCE','FLINK_SINK','GLUE_KDS_OUTPUT','GLUE_SERVERLESS'],
 'defect':'原题缺生产者既有输入/重放要求；HTTP请求→API Gateway/Lambda与KDS消费者→Lambda都能托管处理后写S3，不能仅凭每分钟到达就唯一选其一。',
 'minimal':'保留原实时分析后写S3及MOST operational efficiency，只补真实可区分入口的已有KDS接口必须保留、短逐记录分析；未靠禁用无关工具强迫单选。',
 'reason':'已有KDS使A直接复用XB004的流消费者与Lambda处理机制，再按NA05/M06写S3。短逐记录任务不用为分析另接两种持续ETL/流计算服务。B即使能由Glue读取KDS、产出受支持流再交Flink，也比单个函数多一段转换/输出/输入配置；无需学习完整Glue输出连接器才知道它不能比直接处理更少运维。',
 'options':[
  '最优：沿现有KDS流，以Lambda直接处理短逐记录函数，结果由函数写S3；不把流本身当作处理代码。',
  '不是最少运维：Glue streaming可消费流，故不以“不叫KDS”否定；接到另一个Flink处理器还需额外作业与输出/输入配置，而本题只要短逐记录函数。',
  '不是直接满足路径：Firehose交付与Flink输入职责不同，不能把Firehose自动当Flink源；再绕存储/桥接还会增加环节。',
  '不优：以API Gateway作为新摄取入口会改变已固定的生产接口；给已有KDS消费者另加闲置HTTP层也没有减少运维。']},
764:{
 'selected':[1,2,3,4],
 'ids':['CUR:CB04','CUR:CC22','CUR:NB04','GSC-047','GSC-057','CUR:CMP-M10'],
 'official':['AURORA_ENGINES'],
 'defect':'A/C保持EC2和RDS MySQL且均可PITR，私有Web可以由受支持入口接入；原题未给访客范围或旧拓扑，不能以Web一词强迫实例在公共子网。Aurora的兼容/迁移影响也未给。',
 'minimal':'保留三层、MySQL、最少架构改动、PITR和最低运维目标；允许先列技术候选并指出无法唯一排序所缺的事实，补回旧CV09遗漏的运维目标。',
 'reason':'RDS与Aurora在各自支持的引擎/版本/备份条件下能提供PITR。A可经公网ALB或已有私网入口到私有Web，C可让Web使用公共入口；B/D的Aurora为MySQL兼容候选。D放在公共子网不是单凭名称就自动失去三层连接或PITR，原题没有把所有后端必须私有列为硬条件；正常安全组应只放行实际上一跳。要比较最少改造及最低运维，仍需原Web入口、实际MySQL版本/功能兼容及现有部署运维方式。',
 'options':[
  '技术候选：私有Web可以放在适用ALB后或由办公室私网访问；RDS MySQL提供适用PITR。',
  '技术候选：公共Web和私有应用/DB可连通，Aurora MySQL需实际兼容；不能仅从兼容产品名保证零改造。',
  '技术候选：公共Web、私有应用和RDS MySQL可按正常路由/安全组实现三层，备份支持PITR。',
  '技术候选：原文未禁止公共子网，也未给必须公开数据库的条件；可用正常访问控制限制流量。Aurora兼容及PITR按实际支持范围。'],
 'responseExtras':['缺少的最少改造输入：原Web是否只供内网、已有公网入口/负载均衡拓扑、实际MySQL版本及应用用到的引擎功能。',
                   '缺少的最低运维排序输入：当前部署和数据库维护方式、可接受的迁移兼容改造以及哪些托管动作确实可替代现有运维。',
                   '不是宣称四项对任意未知应用都已部署成功；题目现已要求辨认可行候选并指出缺失排序输入，答案任务本身可完成。']},
240:{
 'selected':[4],
 'ids':['GSC-078','CUR:NB01'],
 'official':['INTERNET_FREE_ALLOWANCE','DX_PRICE_EXAMPLE'],
 'defect':'原文未给共享Internet免费额度用量及实际计费档；额度未用的1000次查询使A/B均可零Internet DTO，而付费档下A传50MB不再最低。实际最低结论可变。',
 'minimal':'只补题目此前缺少的付费档、免费额度已耗尽、适用Internet/DX单价并保留现有专线。保留50MB结果、500KB页面、不缓存及只比出站费的目标。',
 'reason':'GSC078教费用=传输量×路径价率，计算靠近大数据可只把较小页面送出。按题给十进制单位，每个查询对应一页：A=0.05GB×0.09=$0.0045；B=0.0005GB×0.09=$0.000045；C=0.05GB×0.02=$0.001；D=0.0005GB×0.02=$0.00001。单位选二进制也不改变相对大小。价率由练习直接给定，无需学习私有价表。',
 'options':['50MB原始结果经Internet，四项中出站费最高。','只传500KB页面，比A少100倍字节，但每GB高于DX。','DX单价低，但仍外传50MB查询结果。','最低：同Region完成大结果可视化，只把500KB页面经已有DX送出。'],
 'calculation':{'units':'decimal MB/GB, one query result mapped to one visualized page','A':0.05*.09,'B':.0005*.09,'C':.05*.02,'D':.0005*.02,'ratesComeFromVisibleVariant':True}},
284:{
 'selected':[2],
 'ids':['GSC-154','GSC-153','GSC-152'],
 'official':['COST_TAGS','CE_GROUPS'],
 'defect':'by user原本可能指资源Owner、成员账户或IAM调用者，且没有资源归属数据；费用工具不会自动重建共享资源的全服务用户归属。已激活正确Owner标签与没有归属记录会改变报表能否成立。',
 'minimal':'只把user限定为Owner并给已正确标记、激活和可用的历史账单数据；保留部门预算报告及高效率目标，没有把IAM身份冒称天然计费维度。',
 'reason':'154直接教激活的成本分配标签可进入Cost Explorer分组，且Owner不是IAM调用者；153说明它提供现成费用视图，而CUR/Athena适用于自定义明细查询。B在已具备归属数据时直接分组并下载；A不是不可能，但额外查询数据准备/自定义SQL不比现成视图高效。',
 'options':['若有CUR等数据可自定义查询，但不是此已有Owner维度报表的最省步骤。','最有效：Cost Explorer按激活且有数据的Owner标签分组并下载。','账单下载不自动生成资源Owner汇总维度。','Budgets/SES阈值通知不是按Owner列明细的预算分析报告。']},
540:{
 'selected':[3],
 'ids':['CUR:CB01','GSC-046','GSC-060','CUR:CC22','GSC-057','GSC-061'],
 'official':['RDS_NO_ORACLE_CLUSTER','RDS_CLUSTER_NOT_AURORA','ORACLE_RR_LICENSE','DMS_ORACLE_TARGET'],
 'defect':'Oracle不支持题C写的RDS Multi-AZ DB cluster形态，D也混用Aurora与经典Multi-AZ DB instance。Oracle原生只读副本又有EE/版本/Active Data Guard资格，原文未给；不能拿这些错误或未知组合强行恢复唯一答案。',
 'minimal':'只把C改为受支持的Oracle Multi-AZ DB instance主备加单独受支持的可读副本，并把必要版本/EE/ADG许可明确纳入该方案；保留高可用、报表卸载、性能和最少运维目标。',
 'reason':'C把两种职责分开：CB01的经典Multi-AZ standby用于可用性，046的独立read replica端点用于实际读卸载，不能把standby当报表读端。题目C已经限定支持的Oracle版本、edition和ADG许可，不要求学习者从私有证据补出未给的资格。A额外维护DMS跨Region复制/切换链，B同AZ故障域不足，D还涉及从Oracle换到Aurora的兼容转换及错误部署术语。',
 'options':['DMS到受支持目标并非不可能，但多Region复制及HA/报告路由需要更多组件管理；不比C原生角色分工直接。','同AZ的主库和读副本可分担读，但共用AZ故障域，且没有C的自动跨AZ主备保护。','最优：受支持Oracle Multi-AZ主备提供可用性，独立已满足许可/版本的read replica承接报表。','Aurora与经典RDS Multi-AZ实例模型混用；即使按宽泛Aurora集群理解，也要从Oracle转换兼容，不比C保留原引擎更少运维。']},
752:{
 'selected':[1,3,4],'sets':[[1,3],[1,4]],
 'ids':['CUR:CA17','GSC-082','GSC-081','CUR:NC04','VC-001','VC-009','GSC-139','CUR:XB019'],
 'official':['FIFO_WINDOW','LAMBDA_SQS_AT_LEAST_ONCE'],
 'defect':'FIFO发送去重有窗口，Lambda事件处理仍至少一次；已扣款后确认/删除前失败可以再次处理。因此只选Lambda+FIFO并不能保证无条件端到端应用消息恰好一次或业务只执行一次。',
 'minimal':'把不成立的绝对投递保证改为持久业务幂等，并明确普通重试与失败处理；保留最少基础设施目标，未加入原题没有的顺序要求，允许全部有效托管消息配对。',
 'reason':'A的按请求Lambda免常驻主机/集群，是题问的最少基础设施计算。VC001教SQS事件源映射，VC009教SNS到Lambda及两阶段失败处理；二者都能配A。082教稳定业务ID及可靠结果记录，重试返回原结果，并避免检查/执行的并发竞态。FIFO窗口和delivery层不代替该业务幂等。',
 'options':['选为计算层：Lambda处理业务，无须维持常驻EC2轮询或Kubernetes集群。','可以运行应用，但须维护实例计算/OS，未达最少基础设施目标。','可与A配对：SNS托管投递给Lambda，配好普通重试/失败保留，业务仍用稳定ID幂等。','可与A配对：FIFO队列接Lambda受管轮询，重复/失败仍由业务幂等保护；未强称FIFO使扣款自然一次。','EKS即使托管控制面/主机，也保留容器编排与工作负载管理；本题没有保留Kubernetes要求，不是最少基础设施计算。'],
 'responseExtras':['有效配对A+C与A+D；不是把A/C/D当原题Choose two的答案。',
                   '幂等自评：稳定业务ID、可靠保存完成状态/结果、重复返回已有结果、检查和执行防并发竞态；不要求完整支付审计/部署清单。']},
919:{
 'selected':[1],'ids':['GSC-016'], 'official':['IO1_RATIO'],
 'defect':'1TB即使按1TiB=1024GiB，io1在50IOPS/GiB限制下也只支持51200IOPS；64000至少需1280GiB。原初始配置不成立，而且单实例EBS路径余量不能凭存储实例类别猜测。',
 'minimal':'只把容量修为最低可支持64000IOPS的1280GiB，并明确实例支持且有聚合余量、瓶颈在单卷。保留Oracle/Linux/64000IOPS及提高存储性能目标。',
 'reason':'增量PASS的016明确在受支持实例上io1单卷最高64000IOPS；已达单卷上限、实例路径尚有余量时，多卷条带化可提高聚合I/O。容量数是题面条件，不把50:1计算隐藏成学习者必须新背的知识。',
 'options':['可改善：增加受支持io1卷并条带化，把I/O分到多卷，利用给定的实例聚合余量。','不能：当前卡明确io1单卷上限64000，不能提高到以上。','不能突破既有64000单卷IOPS上限；扩容量不等于此瓶颈已消失。','实例路径已经有余量，改实例类别而保持这个单卷不变，不能移除单卷瓶颈。']},
953:{
 'selected':[1,3],'ids':['CUR:CMP-M01','GSC-024','VC-006'],
 'official':['S3_OVERHEAD','ARCHIVE_RETRIEVAL'],
 'defect':'A/C的生成图像部分相同；原图Deep Archive与One Zone-IA的元数据、请求、最低计费和取回费可随对象大小反转总价。每年两次训练不是完整成本输入。原按1000张计价单位的反例可等比扩展到2000用户各10张=20000原图，仍在同一价格段，排序不变。',
 'minimal':'保留高级用户随时下载、普通用户每6小时可下载、每年两次训练及最低总成本目标；先列访问可行方案，再指出缺少成本输入，没有把下载频率改成可等6小时恢复。',
 'reason':'A/C的生成图像都在适用即时层，可满足高级用户随时下载；上传原图只在计划训练时读取，可为Deep Archive安排提前恢复，或直接用One Zone-IA。B/D把全部生成图像放Flexible Retrieval，连高级用户也要先恢复，不满足随时下载。024和CMP-M01已教不能只看GiB单价，须比较对象大小/开销、保存期及取回费用；不需学习者取得私有官方价表才能指出这些缺失输入。',
 'options':['访问可行：原图为计划训练可提前恢复；生成图像使用Standard/IA即时访问。','不满足高级用户随时下载：所有生成图像都变成需恢复的Flexible Retrieval。','访问可行：原图One Zone-IA即时读，题目未要求原图跨AZ；生成图像与A相同。','同B：高级用户生成图像也需先恢复，不能用普通用户6小时频率为其改写等待预算。'],
 'responseExtras':['还需原图及生成图像的对象大小/数量、实际留存期、每次真实取回字节和次数、归档恢复档位、适用价格/计费档以及有无多AZ等硬约束，才能排序A/C。',
                   '识别欠缺成本输入是一项已被当前卡教出的判断，不把私有10KiB/100MiB反例和价率当学习者已见事实。']}
}

rows=[]
for c in cases:
    qid=c['originalQid']; j=judgments[qid]; original=c['originalQuestion']; variant=c['correctedQuestion']
    assert objsha(original)==c['originalQuestionCanonicalSha256']
    assert objsha(variant)==c['correctedQuestionCanonicalSha256']
    sf=c['sourceFinding']; assert sha(sf['independentResultPath'])==sf['independentResultSha256']
    srcfile=json.loads(Path(sf['independentResultPath']).read_text()); actualfinding=sf['finding']; ignored=[]
    if not contains(srcfile,actualfinding):
        # Four frozen case records include a mechanical author-side anchor convenience field.
        # Bind the actual independent source row; never adopt these extra anchors as teaching.
        actualfinding={k:v for k,v in actualfinding.items() if k!='necessaryAnchors'}
        ignored=['necessaryAnchors']
    assert contains(srcfile,actualfinding)
    originalhash=sf['finding'].get('questionSha256',sf['finding'].get('questionCanonicalSha256'))
    assert originalhash==objsha(original)
    assert len(j['options'])==len(variant['options'])
    direct=j['ids']; allids=close(direct)
    # Required premises come from the actual visible card text and explicit exercise inputs.
    row={'variantId':c['variantId'],'originalQid':qid,'originalDefectIndependentlyConfirmed':True,
      'originalDefectConfirmation':{'path':sf['independentResultPath'],'fileSha256':sf['independentResultSha256'],
        'sourceFindingCanonicalSha256':objsha(actualfinding),'frozenEmbeddedFindingSha256':objsha(sf['finding']),
        'ignoredAuthorSideEnrichment':ignored,'independentReason':j['defect'],
        'officialEvidenceIds':j['official'],'notMerelyCopiedStatus':True},
      'minimalityVerdict':'PASS','minimalityReason':j['minimal'],
      'status':'SUPPORTED','standalonePracticeCardGroupStatus':'SUPPORTED',
      'closureEligibleUnderAcceptedCorrectionPolicy':True,
      'selectedOptionOrdinals':j['selected'],'selectedOptionSets':j.get('sets',[j['selected']]),
      'originalQuestionCanonicalSha256':objsha(original),'correctedQuestionCanonicalSha256':objsha(variant),
      'originalStemUtf8Sha256':hashlib.sha256(original['stem'].encode()).hexdigest(),
      'originalOptionsCanonicalSha256':objsha(original['options']),
      'variantStemUtf8Sha256':hashlib.sha256(variant['stem'].encode()).hexdigest(),
      'variantOptionsCanonicalSha256':objsha(variant['options']),
      'completeOriginalAndEveryOptionRead':True,'completeVariantAndEveryOptionRead':True,
      'originalOptionsUnchanged':original['options']==variant['options'],
      'actualDeltas':c['deltas'],'supersedesVariantId':c.get('supersedesVariantId'),
      'directlyUsedRuleIds':direct,'actualUsedRuleIdsIncludingRecursivePrerequisites':allids,
      'cardBindings':[{'ruleId':rid,'bodySha256':cards[rid]['bodySha256'],'prerequisiteRuleIds':cards[rid]['prerequisiteRuleIds']}for rid in allids],
      'necessaryAnchors':anchors(direct,qid),
      'recursiveUsedPrerequisiteBindings':[{'ruleId':rid,'bodySha256':cards[rid]['bodySha256'],'prerequisiteRuleIds':cards[rid]['prerequisiteRuleIds']}for rid in allids if rid not in direct],
      'recursivePrerequisiteAnchors':anchors([rid for rid in allids if rid not in direct]),
      'visibleCardReasoning':j['reason'],
      'optionJudgments':[{'ordinal':opt['ordinal'],'originalLabel':opt['originalLabel'],
                         'selected':opt['ordinal']in j['selected'],'judgment':text}
                        for opt,text in zip(variant['options'],j['options'])],
      'necessaryResponseExtras':j.get('responseExtras',[]),'reviewNotes':j.get('notes',[]),
      'explicitIncrementalRuleIds':[d['ruleId']for d in incremental if qid in d['affectedOriginalQids']],
      'minimumRemainingJudgments':[],'findings':[],
      'officialEvidenceIds':j['official'],'officialFactsNotSubstitutedForVisibleLearning':True,
      'ordinaryImplementationScope':'支持的路由、权限、作业拆分/容量及重试可正常配置；不要求部署并实测生产SLA，不为弱干扰项扩写服务手册。',
      'originalStatusAfterThisReview':'SOURCE_ISSUE','doesNotUpgradeOriginal':True,
      'exerciseInputsNotRecoveredOriginalFacts':True,'learnerEffectMeasured':False}
    if 'calculation'in j:row['visibleInputCalculation']=j['calculation']
    rows.append(row)

out={'schemaVersion':1,'reviewId':'corrected-variants11-independent-current','reviewer':'/root/domain_primary_audit',
 'completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'inputManifestPath':str((P/'manifest.json').resolve()),'inputManifestSha256':sha(P/'manifest.json'),
 'inputHashes':manifest,'frozenVisiblePoolCount':362,'candidatePoolNotFinalN':True,
 'explicitCurrentIncrementalDependencies':incremental,
 'excludedFailedCandidate':{'ruleId':'GSC-047','failedReviewPath':str((V/'review/reuse-a/supplemental16.review.json').resolve()),
   'failedCandidateBodySha256':'9fbd7fa8f2c0097fc653c2670cfb5faf44c15b9b8f398c0cb19805552b4da95a',
   'usedBodySha256':cards['GSC-047']['bodySha256'],'reason':'Failed supplemental16 candidate never adopted; current PASS supplemental17 repair explicitly bound for Q764 PITR only.'},
 'officialEvidenceRegistry':sources,'results':rows,
 'counts':{'variants':9,'originalDefectConfirmed':9,'minimalityPASS':9,'standaloneSUPPORTED':9,'closureEligible':9},
 'allOriginalStatusesRemainUnchanged':True,'variantsEdited':0,'newCardsAuthored':0,
 'currentProductionInventoryEdits':0,'mainRunEdits':0,'externalModelCliApiCalls':0,'nativeUsage':'unknown',
 'clockBudgetHistoryReset':False,'learnerEffectMeasured':False}
q953source=next(r for r in past['results'] if r['qid']==953)['sourceIssue']['calculationArtifact']
assert sha(q953source['path'])==q953source['sha256']
out['originalSourceCalculationBindings']=[{'originalQid':953,**q953source,
  'scope':'Official-price counterexample only; not a learner-visible card or a rate supplied to this practice.',
  'originalPopulationCompatibleScaling':'Multiply each 1000-object witness by 20: 2000 users with 10 originals each. The largest cohort is under 2 TiB, so the selected flat price tiers and opposite ordering remain unchanged.'}]
(R/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':out['counts'],'incrementalRuleIds':[d['ruleId']for d in incremental],
                  'selected':{r['variantId']:r['selectedOptionSets'] for r in rows}},ensure_ascii=False,indent=2))

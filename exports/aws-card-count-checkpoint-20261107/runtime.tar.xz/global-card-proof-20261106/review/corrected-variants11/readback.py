# -*- coding: utf-8 -*-
import collections,datetime,hashlib,json
from pathlib import Path
V=Path.cwd();R=V/'review/corrected-variants11';P=R/'input'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
objsha=lambda x:hashlib.sha256(canon(x).encode()).hexdigest()
o=json.loads((R/'results.json').read_text());rr=o['results']
cases={c['variantId']:c for c in json.loads((P/'cases.json').read_text())}
frozen={c['ruleId']:c for c in json.loads((P/'core-visible.frozen.json').read_text())};cards=frozen.copy()
incremental_checks=[]
for d in o['explicitCurrentIncrementalDependencies']:
 p=json.loads(Path(d['proofPath']).read_text());receipt=json.loads(Path(d['readbackPath']).read_text())
 c=next(c for c in p['results']if c['ruleId']==d['ruleId'])
 incremental_checks.append(sha(d['proofPath'])==d['proofSha256']and sha(d['readbackPath'])==d['readbackSha256']
  and receipt['reviewSha256']==d['proofSha256']and receipt['status'].startswith('PASS')and c['status']=='PASS'
  and c['bodySha256']==d['currentBodySha256']==objsha(d['visibleBody'])and c['visibleBody']==d['visibleBody']
  and frozen[d['ruleId']]['bodySha256']==d['frozenBodySha256'])
 cards[d['ruleId']]={**cards[d['ruleId']],'bodySha256':d['currentBodySha256'],'visibleBody':d['visibleBody'],
                    'prerequisiteRuleIds':c['prerequisiteRuleIds']}
live={c['ruleId']:c for c in json.loads((V/'deliverables/cards.current.json').read_text())}
def close(ids):
 seen=set(ids);queue=list(ids)
 while queue:
  for d in cards[queue.pop()]['prerequisiteRuleIds']:
   if d not in seen:seen.add(d);queue.append(d)
 return sorted(seen)
def contains(x,needle):
 if isinstance(x,dict):return canon(x)==canon(needle)or any(contains(v,needle)for v in x.values())
 if isinstance(x,list):return any(contains(v,needle)for v in x)
 return False
def check_source(r):
 c=cases[r['variantId']];b=r['originalDefectConfirmation'];s=c['sourceFinding'];row=s['finding']
 for k in b['ignoredAuthorSideEnrichment']:row={k1:v for k1,v in row.items()if k1!=k}
 return sha(b['path'])==b['fileSha256']==s['independentResultSha256']and objsha(row)==b['sourceFindingCanonicalSha256']and contains(json.loads(Path(b['path']).read_text()),row)
refs=o['officialEvidenceRegistry']
checks={
 'frozenInputManifestUnchanged':all(sha(p)==h for p,h in o['inputHashes'].items()),
 'manifestFileBindingExact':sha(o['inputManifestPath'])==o['inputManifestSha256'],
 'exactNineVariantIds':set(cases)=={r['variantId']for r in rr}and len(rr)==9,
 'originalQidMatchesEachVariant':all(r['originalQid']==cases[r['variantId']]['originalQid']for r in rr),
 'fullOriginalAndVariantHashesExact':all(r['originalQuestionCanonicalSha256']==objsha(cases[r['variantId']]['originalQuestion'])and r['correctedQuestionCanonicalSha256']==objsha(cases[r['variantId']]['correctedQuestion'])for r in rr),
 'completeSeparateStemAndOptionsHashesExact':all(r['originalStemUtf8Sha256']==hashlib.sha256(cases[r['variantId']]['originalQuestion']['stem'].encode()).hexdigest()and r['variantStemUtf8Sha256']==hashlib.sha256(cases[r['variantId']]['correctedQuestion']['stem'].encode()).hexdigest()and r['originalOptionsCanonicalSha256']==objsha(cases[r['variantId']]['originalQuestion']['options'])and r['variantOptionsCanonicalSha256']==objsha(cases[r['variantId']]['correctedQuestion']['options'])for r in rr),
 'allOriginalAndVariantOptionsRead':all(r['completeOriginalAndEveryOptionRead']and r['completeVariantAndEveryOptionRead']for r in rr),
 'everyVariantOptionHasJudgmentIncludingWeakCandidates':all([(x['ordinal'],x['originalLabel'])for x in r['optionJudgments']]==[(x['ordinal'],x['originalLabel'])for x in cases[r['variantId']]['correctedQuestion']['options']]and all(x['judgment']for x in r['optionJudgments'])for r in rr),
 'onlyQ540OptionCChanged':all([a['ordinal']for a,b in zip(c['originalQuestion']['options'],c['correctedQuestion']['options'])if a!=b]==([3]if c['originalQid']==540 else[])for c in cases.values()),
 'originalDefectSourcesActuallyBound':all(check_source(r)for r in rr),
 'independentOriginalReasonAndMinimalityRecorded':all(r['originalDefectIndependentlyConfirmed']and r['originalDefectConfirmation']['independentReason']and r['minimalityVerdict']=='PASS'and r['minimalityReason']for r in rr),
 'all362FrozenBodyHashesExact':len(frozen)==362 and all(objsha(c['visibleBody'])==c['bodySha256']for c in frozen.values()),
 'onlyNecessaryAcceptedCurrentChangesExplicitlyImported':{d['ruleId']for d in o['explicitCurrentIncrementalDependencies']}=={'GSC-016','GSC-095','GSC-047','CUR:NB04'}and all(incremental_checks),
 'allRequiredBodiesMatchActualVisibleCurrent':all(cards[k]['visibleBody']==live[k]['visibleBody']for r in rr for k in r['actualUsedRuleIdsIncludingRecursivePrerequisites']),
 'allCardBodyBindingsExact':all(p['bodySha256']==cards[p['ruleId']]['bodySha256']for r in rr for p in r['cardBindings']),
 'allNecessaryAnchorsAreVisibleAtOffsets':all(cards[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']and a['bodySha256']==cards[a['ruleId']]['bodySha256']for r in rr for a in r['necessaryAnchors']+r['recursivePrerequisiteAnchors']),
 'allRecursiveDependenciesClosed':all(r['actualUsedRuleIdsIncludingRecursivePrerequisites']==close(r['directlyUsedRuleIds'])and {p['ruleId']for p in r['recursiveUsedPrerequisiteBindings']}==set(close(r['directlyUsedRuleIds']))-set(r['directlyUsedRuleIds'])for r in rr),
 'failedGSC047CandidateNotAdopted':o['excludedFailedCandidate']['failedCandidateBodySha256']!=cards['GSC-047']['bodySha256']==o['excludedFailedCandidate']['usedBodySha256'],
 'allOfficialSnapshotAndTextHashesExact':all(sha(s['snapshotPath'])==s['snapshotSha256']and hashlib.sha256(json.loads(Path(s['snapshotPath']).read_text())['text'].encode()).hexdigest()==s['textSha256']for s in refs.values()),
 'allOfficialQuotesExactAtOffsets':all(json.loads(Path(s['snapshotPath']).read_text())['text'][s['quoteStart']:s['quoteEnd']]==s['quote']for s in refs.values()),
 'allSourceEvidenceIdsResolve':all(all(k in refs for k in r['officialEvidenceIds'])for r in rr),
 'sourceCostCounterexampleFileUnchanged':all(sha(s['path'])==s['sha256']for s in o['originalSourceCalculationBindings']),
 'q240PricesComeFromVisiblePractice':next(r for r in rr if r['originalQid']==240)['visibleInputCalculation']['ratesComeFromVisibleVariant']and next(r for r in rr if r['originalQid']==240)['selectedOptionOrdinals']==[4],
 'q59AllCandidatesHandledWithoutCachingPOSTClaim':next(r for r in rr if r['originalQid']==59)['selectedOptionOrdinals']==[2,3,4]and 'CF_CACHES_READ_RESPONSES'in next(r for r in rr if r['originalQid']==59)['officialEvidenceIds'],
 'q752PairsAreExplicit':next(r for r in rr if r['originalQid']==752)['selectedOptionSets']==[[1,3],[1,4]],
 'allClosureDecisionsRequireThreeGates':all(r['closureEligibleUnderAcceptedCorrectionPolicy']==bool(r['originalDefectIndependentlyConfirmed']and r['minimalityVerdict']=='PASS'and r['standalonePracticeCardGroupStatus']=='SUPPORTED')for r in rr),
 'originalsNeverPromoted':all(r['originalStatusAfterThisReview']=='SOURCE_ISSUE'and r['doesNotUpgradeOriginal']for r in rr),
 'noPrivateEvidenceUsedAsLearning':all(r['officialFactsNotSubstitutedForVisibleLearning']and r['exerciseInputsNotRecoveredOriginalFacts']for r in rr),
 'countsMatchActualRows':o['counts']=={'variants':len(rr),'originalDefectConfirmed':sum(r['originalDefectIndependentlyConfirmed']for r in rr),'minimalityPASS':sum(r['minimalityVerdict']=='PASS'for r in rr),'standaloneSUPPORTED':sum(r['standalonePracticeCardGroupStatus']=='SUPPORTED'for r in rr),'closureEligible':sum(r['closureEligibleUnderAcceptedCorrectionPolicy']for r in rr)},
}
assert all(checks.values()),{k:v for k,v in checks.items()if not v}
out={'schemaVersion':1,'status':'PASS','readBackAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewer':'/root/domain_primary_audit','resultsPath':str((R/'results.json').resolve()),'resultsSha256':sha(R/'results.json'),
 'checks':checks,'counts':o['counts'],'originalPromotions':0,'finalNVerified':False,
 'originalsVariantsInventoryAndMainRunEditedByReviewer':False,'directCliApiCalls':0,'nativeUsage':'unknown',
 'semanticReviewIsSeparateFromDeterministicReadback':True,
 'notableFindings':['Q59 ALL includes B/C/D using taught CloudFront upload/S3 Lambda mechanisms, without caching POST responses.',
  'GSC095/GSC016 use supplemental15; Q764 alone explicitly binds supplemental17 GSC047/NB04 after concurrent parent adoption. Failed supplemental16 GSC047 is not adopted.',
  'Q240 rates are supplied on the visible practice; Q953 private price witnesses only confirm original defect.',
  'All nine are separately accepted practices; no original is marked SUPPORTED.']}
(R/'readback.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks),'counts':o['counts'],'originalPromotions':0},ensure_ascii=False,indent=2))

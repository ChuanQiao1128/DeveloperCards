import json,pathlib,hashlib,datetime,re,collections
V=pathlib.Path(__file__).resolve().parents[3];P=V/'review/corrected-variants09/input';O=V/'review/corrected-variants09';W=O/'work'
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def th(s):return hashlib.sha256(s.encode()).hexdigest()
def ch(x):return th(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
F=['frontZH','answerZH','keyPointZH','watchOutZH']
manifest=rd(P/'manifest.json');assert all(sha(p)==h for p,h in manifest.items())
cases=rd(P/'cases.json');base={x['ruleId']:x for x in rd(P/'core-visible.frozen.json')};assert len(base)==359 and len(cases)==6
canonical_path=V.parent/'domain1-final-card-catalog-20261105/questions.all.json';raw=rd(canonical_path)
for c in cases:
    assert c['originalQuestion']==raw[str(c['originalQid'])]
    assert ch(c['originalQuestion'])==c['originalQuestionCanonicalSha256'] and ch(c['correctedQuestion'])==c['correctedQuestionCanonicalSha256']
index_path=V/'validation/current-card-review-index.json';ix=rd(index_path);start_index_hash=sha(index_path);index={x['ruleId']:x for x in ix['cards']}
(W/'card-review-index.at-start.json').write_text(json.dumps(ix,ensure_ascii=False,indent=2)+'\n')
frozen_hashes={r:c['bodySha256'] for r,c in base.items()};incremental_context=[]
needed={'GSC-127','GSC-128','GSC-126','GSC-116','GSC-097','CUR:CC03','CUR:XB010','GSC-102','GSC-095','VC-011','CUR:CMP-M11','CUR:CMP-M20','GSC-010','GSC-011','GSC-013','CUR:CC22','CUR:NB04','CUR:CB04','GSC-047','GSC-057','CUR:CMP-M04','GSC-075','CUR:CB16','CUR:NB01'}
for rid in needed:
    i=index[rid]
    if i['currentBodySha256']==base[rid]['bodySha256']:continue
    found=None
    for p in i['proofs']:
        assert sha(p['path'])==p['sha256'];d=rd(p['path'])
        for r in d.get('results',d.get('cards',[])):
            if r.get('ruleId')==rid and r.get('bodySha256')==i['currentBodySha256'] and r.get('visibleBody'):
                found=(r,p)
    assert found and i['status']=='PASS',rid
    r,p=found;assert ch(r['visibleBody'])==i['currentBodySha256']
    nc=dict(base[rid]);nc.update(visibleBody=r['visibleBody'],bodySha256=r['bodySha256'],prerequisiteRuleIds=r.get('prerequisiteRuleIds',nc.get('prerequisiteRuleIds',[])))
    incremental_context.append({'ruleId':rid,'frozenBodySha256':base[rid]['bodySha256'],'currentBodySha256':nc['bodySha256'],'visibleBody':nc['visibleBody'],'proofPath':p['path'],'proofSha256':p['sha256'],'scope':'explicit approved-current incremental dependency; original frozen files unchanged'})
    base[rid]=nc
legacy_path=V/'inputs/existing176.json';legacy={c['ruleId']:c for c in rd(legacy_path)};proofs={}
def bind(rid):
    if rid in proofs:return proofs[rid]
    c=base[rid];i=index[rid];assert i['status']=='PASS' and i['currentBodySha256']==c['bodySha256'],rid
    out=[]
    for p in i['proofs']:
        assert sha(p['path'])==p['sha256'];d=rd(p['path']);rs=d.get('results',d.get('cards',[]));rs=list(rs.values()) if isinstance(rs,dict) else rs
        r=[r for r in rs if r.get('ruleId')==rid][-1];rh=r['bodySha256'];contract='canonical four visible fields including empty values'
        if rh!=c['bodySha256']:
            b={f:legacy[rid]['body'].get(f,'') for f in F};assert b==c['visibleBody'] and ch({k:v for k,v in b.items() if v})==rh
            contract='legacy omitted-empty body; exact four fields reconstructed and matched to frozen/current body'
        elif r.get('visibleBody'):assert r['visibleBody']==c['visibleBody']
        z={'ruleId':rid,'path':p['path'],'sha256':p['sha256'],'receiptBodySha256':rh,'currentBodySha256':c['bodySha256'],'bodyBindingContract':contract}
        if r.get('proofs'):
            for pp in r['proofs']:assert sha(pp['path'])==pp['sha256']
            z['parentGateReceipts']=r['proofs']
        out.append(z)
    proofs[rid]=out;return out
reg={}
def cite(p,needle,n,claim):
    p=pathlib.Path(p);p=p if p.is_absolute() else V/p;d=rd(p);s=d['text'];st=s.index(needle);q=s[st:st+n]
    z={'claim':claim,'url':d['url'],'sourcePath':str(p),'sourceFileSha256':sha(p),'sourceTextSha256':th(s),'quote':q,'startChar':st,'endChar':st+len(q),'quoteSha256':th(q)}
    eid=ch(z);reg[eid]=z;return eid
cat_path=V.parent/'domain1-final-card-catalog-20261105/official-sources.catalog.json';cat={e['url']:e for e in rd(cat_path)}
def C(url,needle,n,claim):return cite(cat[url]['sourcePath'],needle,n,claim)
E={}
E['weighted']=C('https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-weighted.html','Amazon Route 53 sends traffic to a resource',700,'Weighted Route53 supports relative traffic shares; equal positive weights are valid alternatives, with health checks supported below.')
E['multivalue']=cite('review/final-core-closure01/a/official-evidence/catalogue-026.snapshot.json','To route traffic roughly at random',575,'Multivalue DNS explicitly supports roughly random resource routing and healthy records.')
E['emr-glue-redshift']=cite('review/final-core-closure01/a/official-evidence/catalogue-068.snapshot.json','This integration provides you with a Spark connector',760,'Spark Redshift integration is included in EMR and Glue; verifies multiple original feasible paths, not an extra learner-visible card.')
E['lf-workflow']=cite('review/final-core-closure01/a/official-evidence/lakeformation-workflows.snapshot.json','A workflow encapsulates',640,'Lake Formation workflows generate actual Glue ETL jobs/crawlers/triggers.')
E['lf-redshift']=cite('review/final-core-closure01/a/official-evidence/lakeformation-redshift-glue-query.snapshot.json','After you grant permissions',425,'Redshift federated catalogs can be queried with Athena/EMR/Glue ETL.')
E['s3-default']=cite('review/reuse-a/sources/611c6926784e5bc640e8.json','Amazon S3 buckets have bucket encryption enabled by default',500,'All new S3 uploads have automatic SSE-S3 unless another supported choice is made.')
E['volume-quota']=cite('review/final-core-closure01/a/official-evidence/stored-quotas.snapshot.json','Maximum size of a volume',450,'Volume Gateway single cached32TiB/stored16TiB; large cached snapshots also have EBS restore restrictions.')
E['tape-restore']=C('https://docs.aws.amazon.com/storagegateway/latest/tgw/backup-tsm.html','Restoring your archived data is a two-step process.',660,'Backup software restores data from retrieved virtual tapes; a virtual tape is not an EBS snapshot.')
E['alb-private']=C('https://docs.aws.amazon.com/elasticloadbalancing/latest/userguide/how-elastic-load-balancing-works.html','Both internet-facing and internal load balancers route requests',910,'Public/internal load balancers route to private-IP targets; public web entry need not force public EC2 backends.')
E['rds-pitr']=C('https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_WorkingWithAutomatedBackups.html','you can recover your DB instance to any point in time',260,'RDS supports PITR inside its retention period.')
E['aurora-pitr']=cite('review/reuse-a/sources/55af09714c7bd99cd230.json','You can quickly restore a new copy of a DB cluster',525,'Aurora supports PITR with continuous incremental backups.')
E['privatelink-direction']=cite(W/'sources/privatelink-third-party.json','However, it is limited to only TCP traffic and unidirectional communication.',355,'PrivateLink provider cannot initiate communication back into the consumer; provider support is required.')
E['privatelink-path']=cite(W/'sources/privatelink-third-party.json',"Network traffic that uses PrivateLink doesn't travel over the public internet",395,'PrivateLink avoids public Internet and permits private VPCs.')

def A(rid,fields=('frontZH','answerZH','keyPointZH','watchOutZH')):
    c=base[rid];bind(rid)
    return [{'ruleId':rid,'bodySha256':c['bodySha256'],'field':f,'quote':c['visibleBody'][f],'startChar':0,'endChar':len(c['visibleBody'][f])} for f in fields if c['visibleBody'].get(f)]
def row(c,status,opts,ids,reason,gaps=(),minimal='PASS',minreason='',originalreason='',evidence=(),conditions=(),advice=None):
    aa=sum([A(r) for r in ids],[]);seen=set();todo=list(ids);pr=[]
    while todo:
        r=todo.pop()
        if r in seen:continue
        seen.add(r);bind(r)
        for dep in base[r].get('prerequisiteRuleIds',[]):
            pr.append({'from':r,'ruleId':dep,'bodySha256':base[dep]['bodySha256'],'visibleBody':base[dep]['visibleBody']});todo.append(dep)
    minimal_ok=minimal.startswith('PASS');supported=status=='SUPPORTED'
    return {'variantId':c['variantId'],'originalQid':c['originalQid'],'originalQuestionCanonicalSha256':ch(c['originalQuestion']),'correctedQuestionCanonicalSha256':ch(c['correctedQuestion']),
        'originalStemUtf8Sha256':th(c['originalQuestion']['stem']),'originalOptionsCanonicalSha256':ch(c['originalQuestion']['options']),'correctedStemUtf8Sha256':th(c['correctedQuestion']['stem']),'correctedOptionsCanonicalSha256':ch(c['correctedQuestion']['options']),
        'completeOriginalAndCorrectedStemAndEveryOptionRead':True,'originalMatchesCanonicalQuestionFile':True,'originalDefectIndependentlyConfirmed':True,'originalDefectStatus':'SOURCE_ISSUE','originalDefectReason':originalreason,
        'minimalityVerdict':minimal,'minimalityReview':minreason,'standalonePracticeCardGroupStatus':status,'selectedOptionOrdinals':opts if supported else [],'candidateOptionOrdinals':opts,
        'usedRuleIds':ids,'necessaryAnchors':aa,'recursiveUsedPrerequisiteBindings':pr,'reasoningAndClosestCompetitor':reason,'minimumRemainingJudgments':list(gaps),'conditions':list(conditions),'officialEvidenceIds':[E[k] for k in evidence],
        'correctionDisposition':'ACCEPTABLE_MINIMAL_PRACTICE' if minimal_ok and supported else 'UNRESOLVED_CARD_SUPPORT' if minimal_ok else 'NOT_ACCEPTABLE_AS_MINIMAL_CORRECTION',
        'closureEligibleUnderAcceptedCorrectionPolicy':minimal_ok and supported,'originalStatusNotUpgraded':True,'noPrivateGoalOrPrintedAnswerUsed':True,'officialFactEvidenceNotSubstitutedForMissingCardPremise':True,'minimumRepairAdvice':advice}
by={c['originalQid']:c for c in cases};rows=[]
rows.append(row(by[224],'INSUFFICIENT_CARDS',[2,3,4,5],['GSC-127','GSC-128','GSC-126','GSC-116'],
 '给定每个剩余AZ容量足够后，GSC116支持D/E两个替代布局；GSC126主备不对应所有实例参与。GSC127教权重比例，GSC128教多个健康地址和客户端选择，但当前两张都未明确随机/概率分流这个原题保留的必要属性，尤其多个地址不自动推出客户端随机选择。官方已证B/C可 roughly random，但不能把源摘录补进学习者卡面。',
 gaps=['Route53 weighted按权重概率选择和/或multivalue roughly random回答的必要可见说明，保留DNS并非逐HTTP请求严格随机的边界。'],
 minreason='只把不唯一的路由/布局改为全部有效，并补HA所必需的剩余容量前提；原随机与跨AZ目标保留，选项未改。',
 originalreason='官方weighted/多值都可分流，D/E均跨两个AZ且在剩余容量足够时可HA；例如每台足够承担正常量时两布局都可行。原Choose two无法唯一决定路由和布局。',
 evidence=['weighted','multivalue'],advice='可定向澄清已有GSC127/128中的同一DNS分流机制；不需要新开一套路由卡。'))
rows.append(row(by[557],'INSUFFICIENT_CARDS',[1,2,4],['GSC-097','CUR:CC03','CUR:XB010','GSC-102','GSC-095'],
 '可见卡已教EMR的多节点分布式处理、Athena读S3、Glue ETL读/转/写、JDBC/蓝图摄取关系数据和Redshift SQL API。它们使并行EMR+Redshift取数方向B可解释，但尚未明确Athena/Glue本身如何满足题中并行处理，不能仅因官方Spark连接器已验证就把所有A/B/D判为卡组充分。C的数据流并不自动把既有S3和Redshift关联完成富化。',
 gaps=['Athena/适用Glue ETL的并行处理能力，及其与Redshift数据富化路径的必要可见因果；不要求背连接器部署清单。'],
 minreason='只把单选改为全部技术有效方案，保留S3半结构化数据、并行处理和Redshift富化目标；无附加工具偏好。',
 originalreason='官方EMR/Glue Spark集成可读写Redshift，Lake Formation工作流可创建Glue ETL，Redshift联邦catalog支持Glue/EMR/Athena查询；多个现行方案满足同一目标，原单选不唯一。',
 evidence=['emr-glue-redshift','lf-workflow','lf-redshift'],advice='补已有处理规则的真实执行/数据接口必要句后再回测，不用来源摘录充作已学卡。'))
rows.append(row(by[321],'SUPPORTED',[5],['VC-011','CUR:CMP-M11','CUR:CMP-M20'],
 'VC011直接说明当前新上传自动SSE-S3，普通静态加密无需额外配置，E。CMPM11区分传输TLS与落盘加密，CMPM20区分SSE-C与客户端加密；ACL头也不建立所问的最小加密配置。新题只问普通新对象静态加密，不把特定客户KMS要求偷偷带入。',
 minreason='澄清当前普通新对象加密的最小额外动作并增加无额外配置选项，原A–D保留；不声称找到旧题唯一D。',
 originalreason='AWS现行自动SSE-S3已覆盖成功新上传，原四种策略均不再是必须的静态加密动作，旧题缺少当前正确的零额外动作选项且无唯一必要措施。',evidence=['s3-default']))
rows.append(row(by[324],'SUPPORTED',[2,4],['GSC-010','GSC-011','GSC-013'],
 'D的stored把全部主数据留本地，并由兼容快照创建EBS/挂EC2完成DR。B保留原本地存储日常路径，备份软件经Tape Gateway虚拟磁带保存历史，灾难后由兼容备份软件取回/恢复文件到EBS；不能把磁带直接当EBS快照。A/C的缓存仍写10TB，而数据改为10TiB，二者不相等且缓存小于数据量，不能保证所有读取都无云端回源延迟。B/D都能形成可行恢复路径；原文没给既有备份软件/迁移改造成本，不能唯一比较最少变化。',
 minreason='把超单卷配额的hundreds TB改为明确合规10TiB，并改问所有可行方案及据已给事实评估least-change；保留原选项与本地访问/DR目标。',
 originalreason='原题单stored volume为数百TB，官方上限16TiB；cached单卷32TiB也装不下。不能静默把数百TB拆卷后宣布旧D已充分。',evidence=['volume-quota','tape-restore'],
 conditions=['B须由兼容备份软件恢复，不是直接从S3挂载虚拟磁带或把磁带转换为EBS快照。','10TB缓存与10TiB数据严格区分；不按作者可能意图将二者改为相等。','least-change仍取决于已存在软件和迁移步骤，变体明确要求只评价给定事实可区分的部分。']))
rows.append(row(by[764],'SUPPORTED',[1,2,3,4],['CUR:CC22','CUR:NB04','CUR:CB04','GSC-047','GSC-057'],
 'CC22以实际引擎/功能兼容为前提减少数据库维护，NB04/047支持RDS及Aurora的PITR，CB04说明公网ALB可连接私有Web目标，因此A的私有Web不是不可访问。B/C的公共Web、D公共子网内受控应用/数据库也不因子网名就失去PITR或三层能力；四项均是正常连通且兼容时的技术候选。原事实不足以唯一比较兼容改造和入口变化。',
 minimal='FAIL_original_optimization_goal_omitted',
 minreason='新问法保留least-change讨论，却从原末句删除LEAST operational overhead，并未要求评价/保留该优化目标。选择所有技术可行项可以作为新练习，但不能在省略原优化目标后称已完成最小纠错。',
 originalreason='已用官方ALB私有目标及两类数据库PITR正证确认欠定：内部用户已有私网入口与直接互联网用户入口两种场景均符合原文，却分别改变A与公共Web方案的额外入口改造；Aurora/RDS的兼容性也未给。此处未知是原场景取值，不是技术能力未知。',
 evidence=['alb-private','rds-pitr','aurora-pitr'],advice='仅在纠错版最后一句补回least operational overhead评价/所缺事实，保留全部可行候选问法；无需改选项或强加某种入口偏好。'))
rows.append(row(by[949],'INSUFFICIENT_CARDS',[2,3,4],['CUR:CMP-M04','GSC-075','CUR:CB16','CUR:NB01'],
 'GSC075教TGW中心路由，练习已给供应商支持attachment，故B私网可行；CMPM04教endpoint service/消费interface endpoint，可支撑D。NB01区分公共互联网VPN与专用私网，排A的普通Internet VPN。C还断言提供方不能通过这些endpoint反向新建连接，官方已确认，但当前CMPM04正文只说明发布/消费入口和SG，未明确这项新连接方向边界，不能把原选项给出的断言当成学习卡。',
 gaps=['PrivateLink只由消费者发起、提供方不能沿该endpoint反向发起新连接的可见机制句；不是要求学习全部网络参数。'],
 minreason='C明确作为新练习补全同一PrivateLink方向表述，不冒称恢复被截断的原文；供应商同时支持TGW和PrivateLink为明确练习设定，改选全部避免工具偏好。',
 originalreason='原C在without enabling the third-party SaaS provider to establish.处确实缺连接对象，原文截断已与规范源逐字核对；原作者缺失的具体词仍UNKNOWN。官方PrivateLink私网/方向事实与TGW可行路径证明新练习设定可核查，不把补句倒写为原作者原话。',
 evidence=['privatelink-direction','privatelink-path'],advice='可在已有CMPM04的同一发布/消费角色机制中补清新连接方向，定向审该句和此变体即可；原截断文本仍保留。'))

used={a['ruleId'] for r in rows for a in r['necessaryAnchors']}|{a['ruleId'] for r in rows for a in r['recursiveUsedPrerequisiteBindings']}
live=rd(index_path);liveidx={x['ruleId']:x for x in live['cards']};used_drift=[r for r in used if liveidx[r]['currentBodySha256']!=base[r]['bodySha256'] or liveidx[r]['status']!='PASS']
assert not used_drift,used_drift
frozen_drift=[{'ruleId':r,'frozenBodySha256':h,'currentBodySha256':liveidx.get(r,{}).get('currentBodySha256')} for r,h in frozen_hashes.items() if liveidx.get(r,{}).get('currentBodySha256')!=h]
out={'schemaVersion':1,'reviewer':'independent corrected-variants09 reviewer, not author','reviewedAtUtc':now(),'inputManifestPath':str(P/'manifest.json'),'inputManifestSha256':sha(P/'manifest.json'),'inputHashes':manifest,
 'canonicalOriginalQuestionFilePath':str(canonical_path),'canonicalOriginalQuestionFileSha256':sha(canonical_path),'officialCataloguePath':str(cat_path),'officialCatalogueSha256':sha(cat_path),
 'frozenPoolCount':359,'currentReviewIndexPath':str(index_path),'currentReviewIndexAtStartSha256':start_index_hash,'reviewIndexSnapshotPath':str(W/'card-review-index.at-start.json'),'reviewIndexSnapshotSha256':sha(W/'card-review-index.at-start.json'),
 'currentDependencyDriftCheck':{'indexAtReadbackSha256':sha(index_path),'changedFrozenPoolBodies':frozen_drift,'explicitApprovedCurrentIncrementalContext':incremental_context,'usedOrRecursiveDependenciesAffectedAfterIncrementalBinding':used_drift,'verdict':'PASS_exact_current_used_bodies_with_explicit_incremental_GSC095_binding'},
 'counts':{'variants':6,'originalDefectsIndependentlyConfirmed':6,'minimalityPASS':5,'minimalityFAIL':1,'practiceCardGroupStatuses':dict(collections.Counter(r['standalonePracticeCardGroupStatus'] for r in rows)),'correctionClosureEligible':sum(r['closureEligibleUnderAcceptedCorrectionPolicy'] for r in rows)},
 'results':rows,'usedExistingCardProofBindings':proofs,'legacyBodyBindingSourcePath':str(legacy_path),'legacyBodyBindingSourceSha256':sha(legacy_path),'evidenceRegistry':reg,
 'limits':['Original source issues and corrected-practice sufficiency remain separate.','Six complete original/corrected stems and all options were read; all original text matches canonical source.','Unrelated later card version changes do not invalidate exact unchanged necessary dependencies.','No production/current/source mutation, no bilingual acceptance or learner-effect measurement.'],
 'priorSourceFindingOpinionsNotAdoptedAsAuthority':True,'currentCardsEditedByReviewer':False,'originalQuestionsEditedByReviewer':False,'originalStatusesUpgraded':False,'newCardCountOrFinalNApproved':False,'directCliApiCalls':0,'nativeUsage':'unknown','externalOfficialReadOnlyFetches':3,'webSearchCalls':1}
rp=O/'results.json';rp.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
z=rd(rp)
for r in z['results']:
    c=next(c for c in cases if c['variantId']==r['variantId']);assert ch(c['originalQuestion'])==r['originalQuestionCanonicalSha256'] and ch(c['correctedQuestion'])==r['correctedQuestionCanonicalSha256']
    for a in r['necessaryAnchors']:assert base[a['ruleId']]['bodySha256']==a['bodySha256'] and base[a['ruleId']]['visibleBody'][a['field']][a['startChar']:a['endChar']]==a['quote']
    for d in r['recursiveUsedPrerequisiteBindings']:assert base[d['ruleId']]['bodySha256']==d['bodySha256'] and base[d['ruleId']]['visibleBody']==d['visibleBody']
for eid,e in z['evidenceRegistry'].items():
    s=rd(e['sourcePath'])['text'];assert sha(e['sourcePath'])==e['sourceFileSha256'] and th(s)==e['sourceTextSha256'] and s[e['startChar']:e['endChar']]==e['quote'] and th(e['quote'])==e['quoteSha256'] and ch(e)==eid
assert all(sha(p)==h for p,h in manifest.items())
rb={'status':'PASS_serialized_review_bindings_unresolved_variants_remain','resultsPath':str(rp),'resultsSha256':sha(rp),'inputManifestSha256':sha(P/'manifest.json'),'readBackAtUtc':now(),'counts':z['counts'],
 'checks':{'sixCanonicalOriginalsAndSixCorrectedAllOptions':True,'allQuestionCanonicalAndUtf8Hashes':True,'allExactCardQuotesHashesAndRecursiveDependencies':True,'allNamedValidPriorReceipts':True,'allOfficialFileTextQuoteOffsetsAndHashes':True,'allFrozenInputsUnchanged':True,'currentUsedDependenciesRemainUnchangedAndPASS':True,'noVariantUpgradesOriginal':True,'noCurrentProductionOrSourceMutation':True},
 'unresolved':{'cardGroup':['Q224-CV09','Q557-CV09','Q949-CV09'],'minimality':['Q764-CV09']},'directCliApiCalls':0,'nativeUsage':'unknown','learnerEffectMeasured':False,'finalNVerified':False}
(O/'readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'results':str(rp),'sha256':sha(rp),'counts':z['counts']},ensure_ascii=False))

import pathlib,json,hashlib,shutil
V=pathlib.Path(__file__).resolve().parents[2]
O=pathlib.Path(__file__).resolve().parent/'input';O.mkdir(exist_ok=True)
def rd(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def freeze(p):
 p=pathlib.Path(p);q=O/(sha(p)+p.suffix)
 if not q.exists():shutil.copyfile(p,q)
 assert sha(q)==sha(p)
 return dict(originalPath=str(p),frozenPath=str(q),sha256=sha(q))
indexpath=V/'validation/current-corrected-variant-index.json';index=rd(indexpath)
rows=[r for r in index['rows'] if r['currentEffectiveStatus']=='NEEDS_CURRENT_DEPENDENCY_RECHECK']
assert {r['originalQid'] for r in rows}=={82,193,234,235,302,324,483,514,537,565,583,593,776,810}
files={}
for p in [indexpath,V/'deliverables/core-visible-knowledge.provisional.json',V/'validation/current-card-review-index.json',V/'rules.md',V/'inputs/teaching-standard.md']:
 files[str(p)]=freeze(p)
cases=[]
for r in rows:
 assert sha(r['variantPath'])==r['variantFileSha256'] and sha(r['independentProofPath'])==r['independentProofSha256']
 for p in [r['variantPath'],r['independentProofPath']]:
  if p not in files:files[p]=freeze(p)
 var=next(v for v in rd(r['variantPath']) if v['variantId']==r['variantId'])
 proof=rd(r['independentProofPath']);candidates=[]
 for k in ['results','correctedPracticeResults','correctedVariantImpactReview']:
  candidates.extend(x for x in proof.get(k,[]) if x.get('variantId')==r['variantId'])
 assert len(candidates)==1,(r['variantId'],len(candidates))
 cases.append(dict(indexRow=r,variant=var,priorIndependentRow=candidates[0]))
(O/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
manifest=dict(frozenFiles=files,casesPath=str(O/'cases.json'),casesSha256=sha(O/'cases.json'))
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(caseCount=len(cases),frozenFileCount=len(files),manifestPath=str(O/'manifest.json'))))

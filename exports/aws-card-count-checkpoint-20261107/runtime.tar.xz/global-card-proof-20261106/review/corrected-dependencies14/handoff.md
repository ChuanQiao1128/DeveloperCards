# corrected-dependencies14 保存点

用户要求“保存进度，提交到main”；父任务已要求本审查停止扩展。本文件只记录本子任务，未修改 root 总账或 Git。

## 当前状态

14项已冻结并完成变体全文、全部选项和受影响当前卡正文的初步语义回读；最终逐项结果组装、凭证链校验和回读尚未完成。**本目录还没有 `results.json` 或 `readback.json`，以下均不是新正式 PASS，不能升级纠错索引。**

原题号：82、193、234、235、302、324、483、514、537、565、583、593、776、810。

## 已保存的冻结输入

- `input/manifest.json`：SHA-256 `2d3ba2c0dd991176048165d7880c87091a646dc97a0a9627fa218b0aa570a79f`。
- `input/cases.json`：SHA-256 `e60dd43f64e087735e577fc88876c9106c17c3f9b8b340cc924fb800ee5c104f`；每项包含索引行、完整原题/变体和旧独立审查行。
- 15个文件已复制为内容哈希命名的本地快照，原路径、快照路径、SHA均在 manifest。包含纠错索引、当前363卡正文、当前卡审查索引、7份变体源文件、3份旧独立审查全文、rules和教学标准。
- 当前363卡快照：`input/5856229df57cda822c378105c4aceae8b4e2069c782370d0a32cbd967d9dc073.json`。
- `prepare_input.py` 是已执行的确定性冻结脚本。续作应直接用现有冻结包，不重跑它来悄悄换绑当前源。
- 已校验索引登记的变体文件和旧 proof 文件 SHA。逐项原/变体 canonical hash、当前所有必要卡/递归先修的最终证明绑定，以及未变原始缺陷的证据链回读仍待组装时校验；不得把“已冻结”写成这些检查全部通过。

## 初步语义发现

**Q483-CV04 暂不宜直接升级。** 旧缺口是 ECS/Fargate 与 Batch/Fargate 的 Windows 支持未教。当前 GSC-133 写：

> Windows容器不适合标准Lambda，可在支持该Windows版本的ECS/Fargate或Batch Windows环境运行。

这明确补足 ECS/Fargate 的 Windows 路径，故C有新增可见支撑；但“Batch Windows环境”本身也可能指 EC2 计算环境。VC-002 仍说“符合Fargate作业范围时可用Batch+Fargate”，并要求核实操作系统，未明确 Windows 属于该范围。不能仅将“Batch支持Windows”与“Batch支持Fargate”两句相交，就当作已教 **Batch/Fargate支持Windows**。B的这一必要能力应在最终审查中特别判清。当前不写新的作者稿，不据官方私有摘录补教学。旧最小性 PASS 可按原/变体 hash 不变复用，但原 INSUFFICIENT 不能只因正文 hash 更新而升级。

**Q776-CV07 原缺口初步看来已真实补足。** 当前 GSC-032 提醒明确：

> Memcached Serverless也提供跨AZ冗余及快照；本卡比较只限node-based，不能把其差异套到所有部署模式。

此句补的是旧 proof 明确缺失的 Memcached Serverless 快照能力。典型亚毫秒缓存机制仍在 keyPoint；NB04保留 Redis/Valkey 快照恢复，同时新增的 Redshift 例子不替代缓存能力。可继续定向验证 C/D，但尚未形成最终新凭证。

其余12项的正文变化初步未见破坏原支撑：

| 变体 | 本轮受影响内容与初步判断 |
| --- | --- |
| Q082-CV03 | XA005现在明确30天ACM事件/Config阈值，B/D提醒路径保留；新增递归先修须绑定CC17、NEW02。 |
| Q193-CV03 | GSC032明确区分node-based Redis与Memcached Serverless HA，B/D缓存路径保留。 |
| Q234-CV03 | CC08新增Redshift没有删除RDS/Aurora落盘与TLS区别，C的逐段保护仍可复用。**旧最小性是 NOT_ESTABLISHED_FOR_ORIGINAL，不能改成PASS。** |
| Q235-CV10 | GSC060保留DMS全量+CDC及单向写入边界；变体已明确Oracle唯一写源，C路径保留。 |
| Q302-CV08 | GSC110保留MediaConvert实际转码与缓存分工，A/C保留。**旧最小性同为 NOT_ESTABLISHED_FOR_ORIGINAL，不能闭合原题纠错。** |
| Q324-CV09 | GSC010仍教stored全量本地；新增传输费提醒不改变10TiB数据大于10TB缓存的判断。B/D恢复路径及GSC011/013未变部分可按hash复用。 |
| Q514-CV10 | CMP-M04仍要求端点连实际服务，新增PrivateLink方向不改变EKS私有控制平面与节点权限/出站判断；A/D旧支撑可按hash复用。 |
| Q537-CV07 | GSC032新增Memcached Serverless跨AZ/快照不削弱A/B；MySQL兼容、三AZWeb及外置会话的未变卡链须绑定。 |
| Q565-CV10 | GSC060保留DMS迁移；reader负载条件已在变体给出，GSC057的Aurora Auto Scaling作用未变，C路径保留。 |
| Q583-CV08 | 变体已明确既有Snowball资格、容量和总交付时间，不另造资格/物流门槛；077离线搬运与CMP-M01长期Deep Archive作用保留，C路径保留。 |
| Q593-CV05 | 变体明确单Region节点/AZ故障且接受异步最新写丢失；032复制/接管机制保留，NB04新增Redshift例子不改变它，A/C保留。 |
| Q810-CV04 | CMP-M04发布NLB/消费endpoint与后端目标维护保留；CB16重叠CIDR不能peering的边界保留，C路径保留。 |

## 恢复后下一动作

1. 从本冻结包接续，先核对各项原题/变体 canonical hash 与旧 proof；未变最小性和原始缺陷只做哈希绑定复用，不重复研究。
2. 仅对上表真正变化的知识和依赖落明确结论。尤其完成483的B平台交集核查、776的可见快照句闭合；无需重审其余题库。
3. 输出 `results.json` 与 `readback.json`，每项统一含 `variantId`、`originalQid`、原/变体canonical hash、`necessaryAnchors`、`cardBindings`、`recursiveUsedPrerequisiteBindings`、`status`、`minimalityVerdict`、`closureEligibleUnderAcceptedCorrectionPolicy`。234/302即使独立练习充分，原最小性未成立也必须维持closure false。
4. 不改卡、练习、正式库存、原题、最终N或生产指针。待父任务/用户恢复授权后再执行。

本子任务新增模型 CLI/API 调用0，外部抓取0，native用量unknown；没有重置历史预算、时钟或失败谱系。

# -*- coding: utf-8 -*-
import collections,datetime,hashlib,json
from pathlib import Path
R=Path.cwd()/'review/remaining-source10';P=R/'input';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
o=json.loads((R/'results.json').read_text());qs={q['qid']:q['question']for q in json.loads((P/'questions.json').read_text())};pool={c['ruleId']:c for c in json.loads((P/'visible-pool.frozen.json').read_text())};m=json.loads((P/'manifest.json').read_text());rr=o['results'];refs=o['officialSources'];prices=o['officialPriceSources']
checks={
 'frozenInputManifestUnchanged':all(sha(p)==h for p,h in m.items()),
 'all16QuestionIdsExact':set(qs)=={r['qid']for r in rr} and len(rr)==16,
 'questionIdsUnique':len({r['qid']for r in rr})==16,
 'fullQuestionHashesExact':all(r['questionSha256']==hashlib.sha256(canon(qs[r['qid']]).encode()).hexdigest()for r in rr),
 'allOriginalOptionsCovered':all([x['ordinal']for x in r['options']]==[x['ordinal']for x in qs[r['qid']]['options']]for r in rr),
 'allVisibleCardBodyBindingsExact':all(p['ruleId']in pool and p['bodySha256']==pool[p['ruleId']]['bodySha256']for r in rr for p in r['necessaryCardEvidence']),
 'allCardQuotesActuallyVisible':all(q['quote']==pool[p['ruleId']]['visibleBody'][q['field']]for r in rr for p in r['necessaryCardEvidence']for q in p['visibleQuotes']),
 'allOfficialSourceSnapshotsUnchanged':all(sha(s['snapshotPath'])==s['snapshotSha256']for s in refs.values()),
 'allOfficialQuotesExactAtOffset':all(json.loads(Path(s['snapshotPath']).read_text())['text'][s['quoteStart']:s['quoteEnd']]==s['quote']for s in refs.values()),
 'officialPriceSnapshotsUnchanged':all(sha(s['snapshotPath'])==s['snapshotSha256']for s in prices.values()),
 'everyQuestionHasOfficialRefsAndCardEvidence':all(r['officialEvidenceRefs'] and r['necessaryCardEvidence']for r in rr),
 'allOfficialRefsResolve':all(x in refs or x in prices for r in rr for x in r['officialEvidenceRefs']),
 'allSourceIssuesAreConfirmedWithSpecificSubtypes':all(r['sourceIssue']['confirmed'] and r['sourceIssue']['subtype']for r in rr if r['status']=='SOURCE_ISSUE'),
 'allDecisiveInputMissingHaveTwoPositiveCases':all(len(r['sourceIssue']['counterfactualScenarios'])>=2 and r['officialEvidenceRefs']for r in rr if r['status']=='SOURCE_ISSUE' and r['sourceIssue']['subtype']=='decisive_input_missing'),
 'sourceRuleActuallyBound':o['sourceAmbiguityRuleBinding']['actuallyRead'] and o['sourceAmbiguityRuleBinding']['sha256']==m[o['sourceAmbiguityRuleBinding']['path']],
 'everyInsufficientHasKnownSpecificCardGap':all(r['knownVisibleCardGaps']for r in rr if r['status']=='INSUFFICIENT_CARDS'),
 'noUnresolvedStatusUpgraded':all(r['wholeQuestionSupportFromVisibleCards']=='SUPPORTED' for r in rr if r['status']=='SUPPORTED') and all(r['wholeQuestionSupportFromVisibleCards']!='SUPPORTED'for r in rr if r['status']!='SUPPORTED'),
 'q953CostOrderingReverses': [z['lowerCostOriginalOption']for z in json.loads((R/'evidence/q953-counterfactual-costs.json').read_text())['cases']]==['C','A'],
 'countsMatchRows':o['counts']==dict(collections.Counter(r['status']for r in rr)),
 'noOriginalModified':all(not r['originalQuestionModified']for r in rr),
}
assert all(checks.values()),checks
notes=['# 16题当前正文与原题源独立核查','', '本次仅核冻结的16题与359张候选卡。判题、卡片充分性、原题错误及纠错练习分别记录。CLI/API模型调用0；native用量unknown。','', '| 题号 | 状态 | 候选选项（非SUPPORTED不等于接受答案） | 结论 |', '|---|---|---|---|']
for r in rr:notes.append('| Q'+str(r['qid'])+' | '+r['status']+' | '+','.join(str(x)for x in r['selectedOptionOrdinals'])+' | '+r['summary']+' |')
notes+=['','关键边界：Q800跨账户EFS有官方正证，当前卡仍缺明确的正向教学；Q919原始1TB/64,000 io1配置不成立；Q300/Q953分别附成本反例；Q49未确认源错，保留精确的元数据查询/成本条件待核。','', '完整题干和全部选项哈希、真实卡句/正文哈希、逐选项解释、官方原句/快照、题源反例与最小纠错字段见results.json。']
(R/'readback.md').write_text('\n'.join(notes)+'\n')
b={'schema':'independent-source10-mechanical-readback-v1','status':'PASS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/domain_primary_audit','resultsFile':{'path':str(R/'results.json'),'sha256':sha(R/'results.json')},'checks':checks,'counts':o['counts'],'explicitNonSupportedQids':[r['qid']for r in rr if r['status']!='SUPPORTED'],'sourceIssueQids':[r['qid']for r in rr if r['status']=='SOURCE_ISSUE'],'knownCardGapQids':[r['qid']for r in rr if r['knownVisibleCardGaps']],'conditionalQids':[r['qid']for r in rr if r['status']=='CONDITIONAL'],'notFinalN':True,'productionAndMainRunModified':False,'externalModelCliApiCalls':0,'nativeUsage':'unknown'}
(R/'readback.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':b['status'],'checks':len(checks),'counts':o['counts'],'sourceIssueQids':b['sourceIssueQids'],'knownCardGapQids':b['knownCardGapQids'],'conditionalQids':b['conditionalQids']},ensure_ascii=False,indent=2))

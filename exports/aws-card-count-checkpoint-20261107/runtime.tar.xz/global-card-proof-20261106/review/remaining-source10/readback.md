# 16题当前正文与原题源独立核查

本次仅核冻结的16题与359张候选卡。判题、卡片充分性、原题错误及纠错练习分别记录。CLI/API模型调用0；native用量unknown。

| 题号 | 状态 | 候选选项（非SUPPORTED不等于接受答案） | 结论 |
|---|---|---|---|
| Q49 | CONDITIONAL | 4 | D是当前卡组能解释的标准方案：S3保留可即时读取的新文件，RDS索引定位对象，旧文件转Deep Archive。尚不能把它升级成对所有原文允许数据量/元数据检索实现都最便宜的唯一答案。 |
| Q139 | SUPPORTED | 4 | D用托管复制完成持续搬运，再由分析桶Object Created事件经EventBridge分别启动Lambda和SageMaker Pipelines；比维护Lambda复制程序更少运维。 |
| Q240 | INSUFFICIENT_CARDS | 4 | 架构候选D：把50MB结果留在Region，仅把约500KB页面经现有专线送回办公室。卡组能推导减少约100倍外传字节，但缺少该题需要的专线与互联网DTO费率比较。 |
| Q257 | INSUFFICIENT_CARDS |  | 不能从现有卡唯一选择。A确实能导出已启用的ASG CloudWatch状态指标；若题目要求逐次伸缩事件载荷，则事件与指标不是同一数据，C的定时Lambda还需明确实际读取何种状态API。 |
| Q284 | SOURCE_ISSUE |  | “按用户列出所有AWS账单项”未提供用户归属数据或适用服务范围，不能从报告工具名称自动生成该归属。 |
| Q300 | SOURCE_ISSUE |  | 24×7能支持比较承诺折扣，但不能决定把折扣放在哪一层最省，也不能由存储增长推出Aurora对任意遗留引擎都可用或最便宜。B与D的节省取决于两层实际规模及报价。 |
| Q435 | INSUFFICIENT_CARDS |  | 既有合格Snowball客户仍可评估Storage Optimized 210TB加SCT/DMS持续变更的A路径；关闭新客户不等于A全面退役。当前卡只教一般离线运输与CDC，没有教这条离线数据库初载接续机制，也不足以判定两周/总成本对D的比较。 |
| Q511 | SOURCE_ISSUE |  | A未说明Serverless或预置，也未排除按需；C只是把Aurora PostgreSQL再写为On-Demand。两项在同一按需Aurora配置下重叠，不能把A偷偷读成Aurora Serverless而宣称唯一答案。 |
| Q540 | SOURCE_ISSUE |  | C的Oracle Multi-AZ DB cluster和D的Aurora Multi-AZ instance术语不能直接当作有效产品组合；B原生Oracle读副本能卸载报表，但其EE和Active Data Guard授权资格决定能否采用。A的DMS复制不能因省略常规建库步骤就一概判为不可能。 |
| Q728 | INSUFFICIENT_CARDS | 2 | B最符合把主数据迁云并只保留热点本地的容量目标。当前卡能排除stored仍保留全部主数据；但尚未教出题面“at no additional cost”与正常出站传输费的边界，不能把缓存未命中取回说成所有费用均为零。 |
| Q734 | INSUFFICIENT_CARDS | 4 | D是把既有专线共享给跨Region多个VGW/VPC的常规候选。当前卡没有讲Direct Connect gateway的跨Region关联及允许/不允许的中转流，不能由TGW或peering知识替它完成整题证明。 |
| Q752 | SOURCE_ISSUE |  | A+D是少基础设施管理的意向组合，但FIFO发送去重窗口与Lambda/SQS至少一次处理，不能无条件保证应用消息恰好投递/产生一次业务效果。 |
| Q800 | INSUFFICIENT_CARDS | 2 | B的同Region、匹配AZ的跨账户peered-VPC EFS访问有AWS官方正证，不能以“跨账户一概不支持”排除。当前卡GCL-030只泛称须确认支持，没有教会这一决定性正向路径。 |
| Q806 | SOURCE_ISSUE |  | B和D都能提供某种NFS路径，但File Gateway不是完整POSIX文件系统；原文只说NFS，未说明当前程序必要文件操作和冷热工作集，不能仅凭NFS名词确认唯一最低成本。 |
| Q919 | SOURCE_ISSUE |  | 原始“1TB io1、64,000 IOPS”已违反50 IOPS/GiB上限；即使把容量修正到至少1,280GiB，A仍要以实例EBS路径有余量为前提。 |
| Q953 | SOURCE_ISSUE |  | A与C对所有生成图像的存储完全相同；唯一区别是上传原图Deep Archive还是One Zone-IA。官方每对象请求/元数据及最低计费可使10KiB和100MiB两种原图在同一每年两次训练下反转成本排序，原题没有图像大小/留存/取回档位。 |

关键边界：Q800跨账户EFS有官方正证，当前卡仍缺明确的正向教学；Q919原始1TB/64,000 io1配置不成立；Q300/Q953分别附成本反例；Q49未确认源错，保留精确的元数据查询/成本条件待核。

完整题干和全部选项哈希、真实卡句/正文哈希、逐选项解释、官方原句/快照、题源反例与最小纠错字段见results.json。

# -*- coding: utf-8 -*-
import collections,datetime,hashlib,json,math,re
from pathlib import Path
V=Path.cwd();R=V/'review/remaining-source10';P=R/'input';E=R/'evidence'
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((P/'manifest.json').read_text());assert all(sha(p)==h for p,h in manifest.items())
questions=json.loads((P/'questions.json').read_text());pool=json.loads((P/'visible-pool.frozen.json').read_text());cards={c['ruleId']:c for c in pool}
for c in pool:assert hashlib.sha256(canon(c['visibleBody']).encode()).hexdigest()==c['bodySha256']
cat=json.loads((V/'review/final-core-closure01/input/official-snapshot-catalogue.json').read_text())
# Reference local official documents only. Short quotations are actual substrings; no generated paraphrase is passed off as a quote.
sources={}
def src(key,name,quote):
 p=E/(name+'.json');j=json.loads(p.read_text());t=j['text'];m=re.search(r'\s+'.join(re.escape(x) for x in quote.split()),t);assert m,(key,quote);quote=m.group(0)
 sources[key]={'url':j['url'],'snapshotPath':str(p.resolve()),'snapshotSha256':sha(p),'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':quote,'quoteStart':t.index(quote),'quoteEnd':t.index(quote)+len(quote)}
 return key
def old(key,index,quote):
 z=cat[index];p=Path(z['snapshotPath']);assert sha(p)==z['snapshotSha256'];j=json.loads(p.read_text());t=j['text'];m=re.search(r'\s+'.join(re.escape(x) for x in quote.split()),t);assert m,(key,quote);quote=m.group(0)
 sources[key]={'url':z['url'],'snapshotPath':str(p),'snapshotSha256':sha(p),'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':quote,'quoteStart':t.index(quote),'quoteEnd':t.index(quote)+len(quote)}
 return key
src('CW_STREAMS','cw-streams','You can use metric streams to continually stream CloudWatch metrics to a destination of your choice, with near-real-time delivery and low latency.')
src('ASG_GROUP_METRICS','asg-metrics','GroupInServiceInstances The number of instances that are running as part of the Auto Scaling group.')
src('ASG_EVENTS','asg-events','Amazon EventBridge, formerly called CloudWatch Events, helps you set up event-driven rules that monitor resources and initiate target actions that use other AWS services.')
src('CE_GROUPS','ce-groups','With Cost Explorer, you can filter how you view your AWS costs by one or more of the following values:')
src('COST_TAGS','cost-user-tags','After you\nhave created and applied the user-defined tags, you can activate by using the Billing and Cost Management\nconsole for cost allocation tracking.')
src('COST_USER_ATTRIBUTES','cost-user-attributes','AWS supports cost allocation based on user attributes for Amazon Q Business, Amazon Q Developer, and Amazon QuickSight.')
src('COST_IAM_PRINCIPAL','cost-iam-principal','AWS supports cost allocation for Amazon Bedrock based on IAM principal identity and tags')
src('EC2_RI','ec2-ri-pricing','Provide a significant discount compared to running instances On-Demand.')
old('RDS_RI',267,'Reserved DB instances provide you with a significant discount compared to on-demand DB instance pricing.')
src('RDS_NO_ORACLE_CLUSTER','rds-cluster-engines',"Multi-AZ DB clusters aren't available with the following engines: RDS for Db2 RDS for MariaDB RDS for Oracle RDS for SQL Server")
src('RDS_CLUSTER_NOT_AURORA','rds-cluster',"Multi-AZ DB clusters aren't the same as Aurora DB clusters.")
src('ORACLE_RR_LICENSE','rds-rr-oracle','To use this feature, you need an Active Data Guard license and an Oracle Database Enterprise Edition license for both the replica and primary DB instances.')
src('DMS_ORACLE_TARGET','dms-oracle-target','You can migrate data to Oracle database targets using AWS DMS, either from another Oracle database or from one of the other supported databases.')
src('DXGW_ACROSS_REGIONS','dxgw-vgw','You can associate a virtual private gateway with a Direct Connect gateway to enable connectivity between your Direct Connect connection and VPCs across different accounts and Regions.')
src('DXGW_NONTRANSIT','dxgw-vgw','Direct communication between the virtual interfaces that are attached to a single Direct Connect gateway.')
src('DXGW_SUPERNET_EXCEPTION','dxgw','An exception to this rule, implemented in November 2021, is when a supernet is advertised across two or more VPCs')
src('VOLUME_CACHED','vg-cached','Cached volumes minimize the need to scale your on-premises storage infrastructure, while still providing your applications with low-latency access to their frequently accessed data.')
src('VOLUME_STORED','vg-cached','By using stored volumes, you can store your primary data locally, while asynchronously backing up that data to AWS.')
src('GATEWAY_DTO','vg-pricing','Data Transfer OUT from the AWS Storage Gateway service to your on-premises gateway appliance')
src('EFS_LINKS','efs-faq','They also support full file system access semantics, such as strong consistency and file locking.')
src('FG_NO_LINKS','filegateway-faq','Symbolic links and hard links are not supported. Attempting to create a link will result in an error.')
src('EFS_ONPREM','efs-faq','You can mount your Amazon EFS file systems on your on-premises servers')
src('EFS_LIFECYCLE','efs-lifecycle','Use lifecycle management to automatically transition data between storage classes according to the lifecycle configuration for the file system.')
src('LAMBDA_EFS_CROSS_ACCOUNT','lambda-efs-launch','You can connect to EFS in the same AZ via cross account VPC but there can be data transfer costs for that.')
src('LAMBDA_EFS_PEERING','lambda-efs-detail',"This only applies if your function's VPC is peered to another VPC with a file system.")
src('LAMBDA_CROSS_ACCOUNT_VPC','lambda-crossvpc','Configure your Lambda function to use a Amazon VPC peering connection to access these resources.')
src('IO1_RATIO','ebs-io1','The maximum ratio of provisioned IOPS to requested volume size (in GiB) is 50:1.')
src('SNOW_ELIGIBILITY','snow-availability','This change will not impact customers currently using AWS Snowball Edge to meet their edge compute and data migration needs.')
src('SNOW_GPU_RETIRED','snow-updates','After this date, both new and existing customers can no longer order the previous generation, discontinued Snowball device models.')
src('SNOW_SCT_AGENT','dms-sct-integration','When working with AWS Snowball Edge Edge, the AWS SCT agent replicates data to the AWS Snowball Edge device.')
src('SNOW_DB_ONGOING','dms-snow-large','The tasks start loading the ongoing transactions once existing data is migrated.')
src('SNOW_SHIPPING','snow-how','When it arrives in a few days, you connect the Snowball Edge device to your network')
old('FIFO_WINDOW',30,"If you retry the \nSendMessage\n            action within the 5-minute deduplication interval, Amazon SQS doesn't introduce any\n            duplicates into the queue.")
old('LAMBDA_SQS_AT_LEAST_ONCE',91,'Lambda event source mappings process each event at least once, and duplicate processing of records can occur.')
old('S3_EVENT_TYPES',281,'ObjectCreated:Put\nObjectCreated:Post\nObjectCreated:Copy\nObjectCreated:CompleteMultipartUpload\nObject Created')
old('S3_REPLICATION_EVENTS',280,'This field is not present for cross-Region replication events.')
src('S3_DIRECT_DESTINATIONS','s3-notifications','Amazon Simple Notification Service (Amazon SNS) topics Amazon Simple Queue Service (Amazon SQS) queues AWS Lambda Amazon EventBridge')
# Target list and managed replication snapshots are reused from the frozen official catalogue.
old('S3_MANAGED_REPLICATION',264,'You can use replication to enable automatic, asynchronous copying of objects across Amazon S3 buckets.')
# Generic exact words are sufficient here; the matching target-list context remains in the bound snapshot.
src('EVENTBRIDGE_SAGEMAKER','eventbridge-targets','Amazon SageMaker Runtime Model Building Pipelines')
src('S3_OVERHEAD','s3-pricing','AWS charges for 40 KB of additional metadata for each archived object, with 8 KB charged at S3 Standard rates')
old('DX_DTO_EXAMPLE',166,'Data transfer out rate\n$0.02 per GB')
old('AURORA_SERVERLESS',202,'You can specify that Aurora serverless DB instances scale down to zero ACUs and automatically pause')

# Bind selected public price-list facts, including their original SKU and complete terms, without treating a search snippet as a price proof.
price_sources={}
def price(key,file,service,predicate,termtype='OnDemand'):
 p=E/file;j=json.loads(p.read_text());matches=[]
 for sku,z in j['products'].items():
  if predicate(z['attributes']):
   matches.append({'sku':sku,'attributes':z['attributes'],'terms':j['terms'].get(termtype,{}).get(sku,{})})
 assert matches,key
 price_sources[key]={'url':f'https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/{service}/current/us-east-1/index.json','snapshotPath':str(p.resolve()),'snapshotSha256':sha(p),'version':j['version'],'publicationDate':j['publicationDate'],'termType':termtype,'products':matches}
 return matches
price('S3_ZIA','s3-price-list-us-east-1.raw.json','AmazonS3',lambda a:a.get('usagetype') in ['TimedStorage-ZIA-ByteHrs','Retrieval-ZIA','Requests-ZIA-Tier2'])
price('S3_STANDARD','s3-price-list-us-east-1.raw.json','AmazonS3',lambda a:a.get('usagetype') in ['TimedStorage-ByteHrs','Requests-Tier2'])
price('S3_GDA','s3gda-price-list-us-east-1.raw.json','AmazonS3GlacierDeepArchive',lambda a:a.get('usagetype') in ['TimedStorage-GDA-ByteHrs','Requests-GDA-Tier3','Standard-Retrieval-Bytes','Requests-GDA-Tier5','Bulk-Retrieval-Bytes'])
price('EFS_CLASSES','amazonefs-price-list-us-east-1.raw.json','AmazonEFS',lambda a:a.get('usagetype') in ['USE1-TimedStorage-Z-ByteHrs','USE1-IATimedStorage-Z-ByteHrs','USE1-TimedStorage-ByteHrs','USE1-IATimedStorage-ByteHrs'])
price('RDS_ORACLE_OD','amazonrds-price-list-us-east-1.raw.json','AmazonRDS',lambda a:a.get('databaseEngine')=='Oracle' and a.get('databaseEdition')=='Standard Two' and a.get('licenseModel')=='Bring your own license' and a.get('instanceType') in ['db.t3.small','db.r5.4xlarge'] and a.get('deploymentOption')=='Single-AZ' and 'InstanceUsage:' in a.get('usagetype',''))
price('RDS_ORACLE_RI','amazonrds-price-list-us-east-1.raw.json','AmazonRDS',lambda a:a.get('databaseEngine')=='Oracle' and a.get('databaseEdition')=='Standard Two' and a.get('licenseModel')=='Bring your own license' and a.get('instanceType') in ['db.t3.small','db.r5.4xlarge'] and a.get('deploymentOption')=='Single-AZ' and 'InstanceUsage:' in a.get('usagetype',''),'Reserved')
price('RDS_SMALL_INDEX','amazonrds-price-list-us-east-1.raw.json','AmazonRDS',lambda a:a.get('databaseEngine')=='PostgreSQL' and a.get('instanceType')=='db.t4g.micro' and a.get('deploymentOption')=='Single-AZ' and 'InstanceUsage:' in a.get('usagetype',''))

# Q953: two concrete, stem-compatible object sizes reverse A/C total cost. The generated-image components are identical in A and C and cancel.
GIB=1024**3
calcs=[]
for label,size in [('small_10_KiB',10*1024),('large_100_MiB',100*1024**2)]:
 n=1000;gb=size/GIB
 a_storage=n*12*((size+32*1024)/GIB*0.00099+8*1024/GIB*0.023)
 a_restore=n*2*(0.0001+gb*0.02)
 a_temp=n*gb*0.023*2/30
 a_get=n*2*0.0000004
 a_ingest=n*0.00005
 c_storage=n*12*(max(size,128*1024)/GIB*0.01)
 c_read=n*2*(gb*0.01+0.000001)
 c_ingest=n*0.00001
 a=a_storage+a_restore+a_temp+a_get+a_ingest;c=c_storage+c_read+c_ingest
 calcs.append({'case':label,'originalImages':n,'bytesEach':size,'region':'us-east-1','retentionMonths':12,'trainingReadsPerYear':2,'retrieval':'GDA Standard; retain restored copy one day each time','premiumAndNonPremiumGeneratedImageCosts':'Identical A/C components held fixed; cancel in comparison','A_USD':a,'C_USD':c,'lowerCostOriginalOption':'A' if a<c else 'C','componentsA':{'storageIncludingArchiveMetadata':a_storage,'restoreRequestAndBytes':a_restore,'temporaryRestoredCopy':a_temp,'getRequests':a_get,'initialIngestOrTransition':a_ingest},'componentsC':{'storageWith128KiBMinimum':c_storage,'reads':c_read,'initialIngestOrTransition':c_ingest},'notOriginalFacts':'All size/retention/retrieval settings here are counterfactual examples, not restored hidden inputs.'})
assert [x['lowerCostOriginalOption']for x in calcs]==['C','A']
(E/'q953-counterfactual-costs.json').write_text(json.dumps({'schema':'official-price-counterfactual-proof-v1','priceSourceRefs':['S3_ZIA','S3_STANDARD','S3_GDA'],'rounding':'GB=2^30 bytes; 12 months; temporary restore 1 day; same generated-image bill cancels','cases':calcs},ensure_ascii=False,indent=2)+'\n')

def proof(rule,fields,role):
 c=cards[rule]
 return {'ruleId':rule,'bodySha256':c['bodySha256'],'role':role,'visibleQuotes':[{'field':f,'quote':c['visibleBody'][f]} for f in fields]}
def cp(rule,role,fields=('answerZH','keyPointZH')):return proof(rule,fields,role)
def row(qid,status,choice,summary,ps,opts,refs,gaps=None,conditions=None,issue=None):
 q=next(q['question'] for q in questions if q['qid']==qid)
 assert len(opts)==len(q['options'])
 return {'qid':qid,'status':status,'questionSha256':hashlib.sha256(canon(q).encode()).hexdigest(),'questionHashMethod':'SHA256 UTF-8 canonical JSON of full frozen question object (qid, stem, every option ordinal/label/text), ensure_ascii=false, sort_keys=true, compact separators','selectedOptionOrdinals':choice,'summary':summary,'necessaryCardEvidence':ps,'options':[{'ordinal':o['ordinal'],'originalLabel':o['originalLabel'],'judgment':why}for o,why in zip(q['options'],opts)],'officialEvidenceRefs':refs,'knownVisibleCardGaps':gaps or [],'explicitConditions':conditions or [],'sourceIssue':issue,'implementationOmissionsNotPromotedToSourceDefects':['ordinary routes/security groups/permissions/configuration may be implemented where the named architecture supports them; no production SLA deployment test required'],'originalQuestionModified':False,'fullQuestionAndAllOptionsRead':True,'nearestCompetitorOrdinals': []}
results=[]
results.append(row(49,'CONDITIONAL',[4],
 'D是当前卡组能解释的标准方案：S3保留可即时读取的新文件，RDS索引定位对象，旧文件转Deep Archive。尚不能把它升级成对所有原文允许数据量/元数据检索实现都最便宜的唯一答案。',
 [cp('GSC-031','查询索引与对象正文分工'),cp('CUR:CMP-M01','即时读取与可等待归档的边界'),cp('VC-006','Deep Archive恢复有等待')],
 ['标签本身不是已存在的可查询索引；Instant Retrieval也不免去请求及取回计费。','S3内对象不是Glacier vault archive；该项还把Athena/Glacier Select当成通用检索与取回链路，不能仅凭名字证明可用。','不能把“元数据在S3”直接判为不可能：应用可把它组织为可读取索引；但原文未说明查询实现及归档规模，无法与持续RDS索引费用作唯一最低成本比较。','在需数据库式查询、且旧归档规模足够时，符合当前卡的索引与冷归档机制。'],
 ['S3_OVERHEAD','S3_STANDARD','S3_GDA','RDS_SMALL_INDEX'],
 gaps=['卡组教会RDS元数据索引这一有效方案，却没有证明C的具体S3元数据检索实现必然不可用或其总费必然高于D。'],
 conditions=['若确认元数据确需当前题目所指的数据库查询，且Deep Archive存储节省大于索引成本，可选D；这是额外练习条件，不能倒写为原题事实。'],
 issue={'confirmed':False,'reason':'成本与索引语义边界尚不足以证成两个同等满足全部优化语义且有相反唯一最优的完整情境；不因未找到精确比较就宣布源错。','nextRequiredEvidence':'核定C所指检索实现以及同一查询/保存规模下C和D的完整费用；或另存补明确数据量、查询要求与成本基准的练习。'}))
results.append(row(139,'SUPPORTED',[4],
 'D用托管复制完成持续搬运，再由分析桶Object Created事件经EventBridge分别启动Lambda和SageMaker Pipelines；比维护Lambda复制程序更少运维。',
 [cp('CUR:NEW04','持续托管复制新对象'),cp('GSC-029','对象创建事件经EventBridge可指向Lambda和SageMaker Pipelines'),cp('GSC-030','不能只监听Put覆盖所有创建操作'),cp('CUR:CC17','筛选与投递目标职责')],
 ['SageMaker Pipelines不是S3直接通知目的地，且Put过滤不能涵盖复制程序可能采用的Copy或分块完成。','EventBridge目标链路可行，但还要维护复制Lambda；与D相较多一段自定义计算。','托管复制本身合理，但SageMaker Pipelines不能被直接填成S3通知目的地。','托管复制加EventBridge多目标路由满足文件增加、数据处理和流水线要求。'],
 ['S3_MANAGED_REPLICATION','S3_EVENT_TYPES','S3_REPLICATION_EVENTS','S3_DIRECT_DESTINATIONS','EVENTBRIDGE_SAGEMAKER']))
results.append(row(240,'INSUFFICIENT_CARDS',[4],
 '架构候选D：把50MB结果留在Region，仅把约500KB页面经现有专线送回办公室。卡组能推导减少约100倍外传字节，但缺少该题需要的专线与互联网DTO费率比较。',
 [cp('GSC-078','计算靠近大数据，减少外传字节；还须比较实际路径单价'),cp('CUR:NB01','专线是独立承载路径')],
 ['在互联网传出约50MB原始查询结果，不利用Region内可视化减小外传量。','仅传约500KB是正确方向，但与D尚须比较互联网和已有DX的DTO单价。','使用DX但仍外传约50MB，数据量约为D的100倍。','在适用同Region计费下，同时减少外传量并使用已有DX。'],
 ['DX_DTO_EXAMPLE'],gaps=['GSC-078明确要求查实际价格，却没有教出DX相对互联网DTO的可用比较结论/本题对应价格。缺的是学习者可见的计费判断，不是部署实测。']))
results.append(row(257,'INSUFFICIENT_CARDS',[],
 '不能从现有卡唯一选择。A确实能导出已启用的ASG CloudWatch状态指标；若题目要求逐次伸缩事件载荷，则事件与指标不是同一数据，C的定时Lambda还需明确实际读取何种状态API。',
 [cp('GCL-004','Metric Streams只导出已有指标'),cp('CUR:NS01','Firehose可近实时交付到S3'),cp('GSC-089','时间调度与事件匹配不同')],
 ['可导出CloudWatch中的ASG组状态指标；不能据此宣称已保留每次伸缩事件载荷。','EMR不是所要求的免管理常驻基础设施方案。','定时Lambda本身可无服务器读取状态并写S3，但卡面未教其ASG数据来源；调度频率和题目“events/status”的含义也未明确。','在实例启动期安装Agent会把收集配置耦合到启动，并非现有无服务器管道。'],
 ['CW_STREAMS','ASG_GROUP_METRICS','ASG_EVENTS'],gaps=['卡面未教ASG原生状态指标与逐次事件的具体区别，也未提供定时Lambda可取得所需ASG状态的实际来源。'],conditions=['若明确要的是已启用的ASG组CloudWatch指标，A可被选；若要具体事件，不能把Metric Streams当事件归档。'],issue={'confirmed':False,'reason':'不把术语混用或缺少事件字段直接判成已证无解；目前尚未证成原文通常语义下的完整唯一判题。'}))
results.append(row(284,'SOURCE_ISSUE',[],
 '“按用户列出所有AWS账单项”未提供用户归属数据或适用服务范围，不能从报告工具名称自动生成该归属。',
 [cp('GSC-153','费用交互工具与细粒度明细分工'),cp('GSC-154','成本分配维度须先激活并确有标记数据')],
 ['Athena可以查询已有明细，但不能凭空恢复缺失的用户归属。','若已有可用用户/部门归集维度，现成Cost Explorer报告最省操作；原文未给这一决定条件。','下载普通账单不自动使资源用量具备按人员归属的维度。','预算告警不产生所需历史费用报告，且修改预算不能补归属。'],
 ['CE_GROUPS','COST_TAGS','COST_USER_ATTRIBUTES','COST_IAM_PRINCIPAL'],
 issue={'confirmed':True,'subtype':'decisive_input_missing','missingInput':'所涉服务及已经启用、覆盖完整的用户成本归属维度。','positiveTechnicalBasis':'现行AWS有资源成本标签、部分按用户收费服务的用户属性、以及Bedrock IAM principal归集；它们各有启用和服务范围，不能推出任意AWS费用均天然按IAM用户归集。','counterfactualScenarios':[{'conditions':'全部成本对象已有完整且已激活的User/Department成本分配标签，报告只需这些维度的汇总。','outcome':'B可直接按已有归属维度生成和下载报告。'},{'conditions':'账单来自共享EC2/存储资源，未建立用户归属标签或其他成本分配记录；多人共同使用。','outcome':'A/B/C均不能从没有归属字段的账单自动恢复精确用户分摊，D也不能补历史归属。'}],'minimumCorrectionFields':{'costAttributionInput':'明确已有完整、已激活的用户/部门成本分配维度以及报告范围；保留按用户和预算规划目标。'},'correctedExerciseNotOriginal':True}))
results.append(row(300,'SOURCE_ISSUE',[],
 '24×7能支持比较承诺折扣，但不能决定把折扣放在哪一层最省，也不能由存储增长推出Aurora对任意遗留引擎都可用或最便宜。B与D的节省取决于两层实际规模及报价。',
 [cp('GSC-146','Spot回收风险与持续服务边界'),cp('GSC-054','RDS实例的预留折扣'),cp('VC-007','匹配承诺与持续付款义务'),cp('GSC-057','Aurora只兼容适用MySQL/PostgreSQL'),cp('CUR:CC22','兼容引擎及事务模型是迁移前提')],
 ['持续服务未给可中断与恢复条件；把数据库层改S3也不保留关系访问模型。','EC2预留节省应用层费用，但数据库仍按需。','仅适配Aurora兼容引擎，并且实例、存储及I/O总费仍须比较；增长不是自动胜出的成本证据。','RDS预留节省数据库算力，而EC2仍按需；相对B的优劣由两层可节省金额决定。'],
 ['EC2_RI','RDS_RI','RDS_ORACLE_OD','RDS_ORACLE_RI'],
 issue={'confirmed':True,'subtype':'decisive_input_missing','missingInput':'数据库兼容边界及应用层/数据库层的实际可折扣费用。','positiveTechnicalBasis':'B和D分别只对一层承诺；官方均确认其匹配预留相对按需有折扣。原文允许应用占主费与数据库占主费两种运行状态，不能只靠24×7判哪一层节省最大。','counterfactualScenarios':[{'conditions':'保留Oracle接口的遗留程序，应用层为大量相同EC2实例，数据库只需一个db.t3.small Oracle SE2 BYOL；两层均稳定全年运行。','outcome':'选择应用实例数量足以让EC2预留总节省超过小库RI节省时，B比D便宜；C不保留Oracle引擎。官方小库按需0.034美元/小时、1年无预付RI为0.0214美元/小时，差0.0126美元/小时；EC2正折扣可随实际实例数累加超过它。'},{'conditions':'同为Oracle，应用只需一个小EC2，数据库为多个db.r5.4xlarge Oracle SE2 BYOL实例；仍然全部24×7且存储增长。','outcome':'数据库实例数量足以让其预留总节省超过小应用RI节省时，D比B便宜。该RDS规格按需1.864美元/小时、1年无预付RI按实际terms比较，节省随库数量增加；C仍不保留Oracle。'}],'counterexampleCostLogic':'这是由官方正折扣和可变实例数量得到的构造；不把示例引擎/规格/数量倒写为原题。原文没有任何数量上界可固定B/D排序。','minimumCorrectionFields':{'compatibility':'明确遗留库引擎及允许的改造范围','costComparison':'补两层满足需求规格、同期限及付款方式的完整报价；仅补决定最优的成本输入。'},'correctedExerciseNotOriginal':True}))
results.append(row(435,'INSUFFICIENT_CARDS',[],
 '既有合格Snowball客户仍可评估Storage Optimized 210TB加SCT/DMS持续变更的A路径；关闭新客户不等于A全面退役。当前卡只教一般离线运输与CDC，没有教这条离线数据库初载接续机制，也不足以判定两周/总成本对D的比较。',
 [cp('GSC-077','用数据量、带宽、设备资格及交付窗口比较迁移'),cp('GSC-060','全量加载后接CDC追赶变化'),cp('GSC-061','转换与复制职责不同')],
 ['技术路线仍对既有合格客户存在；要教清SCT本地复制代理、离线初载及CDC接续，并核对当前设备/窗口。','Snowmobile不是现行可订购迁移方案；不能借旧设备名放行。','GPU旧型号已对新旧客户停订，不能用其证明现行可行。','新建专线是否能在两周内投入、费用与Snowball相比如何，题面没有给连接准备状态；不能只把20TB÷1Gbps当完整新建交付周期。'],
 ['SNOW_ELIGIBILITY','SNOW_GPU_RETIRED','SNOW_SCT_AGENT','SNOW_DB_ONGOING','SNOW_SHIPPING'],gaps=['可见卡缺少数据库离线初载与持续变更接续的必要机制；不能用审查者刚检到的SCT/DMS官方细节替卡补出A。','当前卡没有完整的新建专线与现行离线方案成本/窗口比较。'],conditions=['明确客户是否已有Snowball使用资格；新客户不能通过仅订购Snowball来实现A。既有合格客户不因新客禁入被判全服务退役。'],issue={'confirmed':False,'reason':'已证实具体资格/型号边界，但没有把普通交付参数或成本未核清一律升级成原题无解；A对合格客户的技术能力已有正证。'}))
results.append(row(511,'SOURCE_ISSUE',[],
 'A未说明Serverless或预置，也未排除按需；C只是把Aurora PostgreSQL再写为On-Demand。两项在同一按需Aurora配置下重叠，不能把A偷偷读成Aurora Serverless而宣称唯一答案。',
 [cp('CUR:XB027','自动暂停须具体版本与配置'),cp('GSC-057','Aurora Serverless v2是明确的容量方式'),cp('GSC-052','闲置不等于自动停止计费')],
 ['泛称Aurora PostgreSQL，可包含与C完全相同的按需部署，也可能包含Serverless；没有给定唯一运行模式。','Single-AZ RDS PostgreSQL是有效开发库选项；实际最低费取决于配置与启停安排。','Aurora On-Demand PostgreSQL-Compatible属于A所指的Aurora PostgreSQL范围，不能视为另一个互斥能力。','对象查询不能替代PostgreSQL数据库模式与写事务能力。'],
 ['AURORA_SERVERLESS','RDS_SMALL_INDEX'],issue={'confirmed':True,'subtype':'overlapping_answer_options','originalAnchors':['A: Amazon Aurora PostgreSQL database','C: Amazon Aurora On-Demand PostgreSQL-Compatible database'],'positiveTechnicalBasis':'Aurora PostgreSQL与On-Demand不是互斥服务；Serverless/容量范围/暂停均需明确选择，不能从没有写出的词恢复。','overlapWitness':{'configuration':'同一Region、同一Aurora PostgreSQL兼容引擎、同一按需计费实例配置','matchesOptions':[1,3],'reason':'A没有限定成不同于C的购买或容量模型。'},'minimumCorrectionFields':{'optionsAandC':'明确它们各自实际容量/购买模式，消除重叠；不要把隐含Serverless当已写事实','costInput':'若仍要求唯一最低成本，补同一开发需求下可比较的规格/伸缩与空闲恢复条件。'},'correctedExerciseNotOriginal':True}))
results.append(row(540,'SOURCE_ISSUE',[],
 'C的Oracle Multi-AZ DB cluster和D的Aurora Multi-AZ instance术语不能直接当作有效产品组合；B原生Oracle读副本能卸载报表，但其EE和Active Data Guard授权资格决定能否采用。A的DMS复制不能因省略常规建库步骤就一概判为不可能。',
 [cp('CUR:CB01','经典standby不读与Multi-AZ cluster可读差异，不能自行泛化至任意引擎'),cp('GSC-046','读副本须真正承接报告流量'),cp('GSC-060','DMS可以维护持续变化副本'),cp('GSC-057','Aurora引擎兼容范围')],
 ['DMS迁到受支持Oracle目标并持续复制在技术上存在；报告可走另一实例，仍需另行设计接管。不能只因DMS不负责点击建实例就宣布整项无效。','对具有所需EE及Active Data Guard许可的Oracle，托管读副本可卸载报告，且可提升副本恢复；该许可并非所有Oracle部署都有。','官方明确Oracle不支持RDS Multi-AZ DB clusters。','Aurora DB cluster与普通RDS Multi-AZ DB instance不同，不能用这句话证明有可读standby；Oracle应用还需兼容改造。'],
 ['RDS_NO_ORACLE_CLUSTER','RDS_CLUSTER_NOT_AURORA','ORACLE_RR_LICENSE','DMS_ORACLE_TARGET'],issue={'confirmed':True,'subtype':'decisive_input_missing','missingInput':'现有Oracle的版本/Edition及Active Data Guard许可可用性；是否只需实例级故障恢复或另需特定自动接管语义。','counterfactualScenarios':[{'conditions':'原库为受支持Oracle EE CDB，主库和读副本均有Active Data Guard与EE许可，报表只读。','outcome':'B的托管原生读副本可行，运维通常少于自行维护DMS报表复制链路。'},{'conditions':'原库为Oracle Standard Edition 2，必须保留该许可及访问模型，没有EE/Active Data Guard授权。','outcome':'B所述Oracle原生可查询读副本不受支持，C也不受支持；A的DMS到Oracle目标需单独评估，不能据B作唯一答案。'}],'minimumCorrectionFields':{'oracleQualification':'若按B练习，仅补受支持EE与Active Data Guard许可均已具备；如要求AZ级自动HA，则另明确主库Multi-AZ部署而不是强迫错误Oracle cluster。'},'correctedExerciseNotOriginal':True}))
results.append(row(728,'INSUFFICIENT_CARDS',[2],
 'B最符合把主数据迁云并只保留热点本地的容量目标。当前卡能排除stored仍保留全部主数据；但尚未教出题面“at no additional cost”与正常出站传输费的边界，不能把缓存未命中取回说成所有费用均为零。',
 [cp('GSC-010','stored保留全量主数据，cached以S3为主且未命中回源',('answerZH','keyPointZH','watchOutZH')),cp('VC-006','归档取回要等待与计费')],
 ['归档的expedited不是即时且免费，并有预置取回容量费用。','缓存模式解决本地容量扩张；缓存未命中仍有云端访问及适用传输费用。','完整主数据仍留本地，没有解决迁走不断增长主数据的容量约束。','新增专线并不改变stored仍需本地完整主数据，还增加连接费用。'],
 ['VOLUME_CACHED','VOLUME_STORED','GATEWAY_DTO'],gaps=['当前卡未明确“无额外归档恢复费”不等于“任何云端读取和传输均免费”。'],conditions=['B可在“immediate”指在线非归档访问、“no additional cost”仅指无另收归档恢复费的正常解释下使用；如果原文意图所有数据出站零费，则B不能满足，不能隐瞒此差别。'],issue={'confirmed':False,'reason':'该成本措辞有边界，但不能把远程S3读取的正常延迟或适用网络费直接当作题目保证全量本地、零网络费的硬条件。暂不宣布原题无有效答案。'}))
results.append(row(734,'INSUFFICIENT_CARDS',[4],
 'D是把既有专线共享给跨Region多个VGW/VPC的常规候选。当前卡没有讲Direct Connect gateway的跨Region关联及允许/不允许的中转流，不能由TGW或peering知识替它完成整题证明。',
 [cp('GSC-073','VIF与对应网关决定可达范围'),cp('GSC-075','中心路由与非传递peering不同'),cp('CUR:CB16','peering须双向路由')],
 ['VPC peering不提供把既有专线经一个VPC传给其他VPC的中转。','跨Region访问需要正确DX gateway/VGW结构，不能把private VIF直接画到远端多个VPC代替。','全网格自管VPN增加设备及连接维护，不是已存在DX下的低运维常规结构。','DX gateway支持跨账户/Region VGW关联，但必须明确所需流量是否只是机房到VPC；不能泛称任意VPC/VIF彼此中转都自动支持。'],
 ['DXGW_ACROSS_REGIONS','DXGW_NONTRANSIT','DXGW_SUPERNET_EXCEPTION'],gaps=['359卡全文中未找到Direct Connect gateway主机制与该题所需跨Region VGW关联规则；不能用VIF名称或TGW规则抵扣。'],conditions=['先核原文所需的Region/VPC/机房流量矩阵。常规VGW关联不能直接当全互通；官方也记载特定supernet情形例外，不能笼统说所有VPC间通信绝不可能。'],issue={'confirmed':False,'reason':'原文未明确每一对端点都需互访；不把可能的全互通解读当已明示硬条件，也不因普通路由/关联省略确认源错。'}))
results.append(row(752,'SOURCE_ISSUE',[],
 'A+D是少基础设施管理的意向组合，但FIFO发送去重窗口与Lambda/SQS至少一次处理，不能无条件保证应用消息恰好投递/产生一次业务效果。',
 [cp('CUR:CA17','托管按请求计算减少常驻服务器管理'),cp('CUR:NC04','FIFO/Standard投递语义与业务完成不是同一层'),cp('GSC-081','未删除消息可在可见性超时后重现'),cp('GSC-082','支付重试须业务幂等'),cp('VC-001','SQS事件源默认确认与失败重试',('answerZH','keyPointZH','watchOutZH'))],
 ['Lambda可减少计算基础设施管理，但并不消除重复处理。','EC2需要更多基础设施管理，也不能自行产生exactly-once语义。','泛称SNS没有指定端到端有序去重链路，不满足绝对保证。','FIFO帮助避免去重窗口内重复发送入队；不能单凭它保证每次消费/应用业务效果只有一次。','EKS仍需更多集群/节点管理；换编排系统不补消息保证。'],
 ['FIFO_WINDOW','LAMBDA_SQS_AT_LEAST_ONCE'],issue={'confirmed':True,'subtype':'overstated_delivery_guarantee','hardConstraint':'must guarantee exactly-once delivery for application messaging','positiveContradiction':'官方对FIFO发送去重限定5分钟；官方对Lambda SQS事件源明确每事件至少处理一次，重复可能发生。GSC-081也明确超时后重现。','failureWitness':'一个函数已完成扣款却在确认/删除前失败；消息可重新可见并再次处理。A+D本身未提供业务幂等。','minimumCorrectionFields':{'messagingGuarantee':'把绝对保证限定为FIFO的组内有序及去重窗口内重复发送去重，并明确业务消费者实施幂等；保留少基础设施管理目标。'},'candidateAfterCorrection':[1,4],'correctedExerciseNotOriginal':True}))
results.append(row(800,'INSUFFICIENT_CARDS',[2],
 'B的同Region、匹配AZ的跨账户peered-VPC EFS访问有AWS官方正证，不能以“跨账户一概不支持”排除。当前卡GCL-030只泛称须确认支持，没有教会这一决定性正向路径。',
 [cp('GSC-001','共享EFS可随文件增加扩展'),cp('CUR:CB16','peering和双向路由'),cp('GCL-030','必须实际配置EFS接入点与本地挂载，现有跨账户提醒仍待确认',('frontZH','answerZH','keyPointZH','watchOutZH')),cp('CUR:CMP-M08','layer不是持续变化文件系统')],
 ['复制新文件系统增加存储与传输，并要处理后续新增同步，不是直接共享原文件系统。','在官方支持的同Region/对应AZ、网络和EFS授权/挂载配置成立时，直接访问现有EFS，不新增数据副本或代理函数。','同账户挂载的代理函数可提供另一种文件服务接口，但增加调用与处理路径，未有必要优于已支持直接挂载。','layer是版本化部署归档，不随新增EFS文件自动伸缩同步；题目还把分享账户方向写反。'],
 ['LAMBDA_EFS_CROSS_ACCOUNT','LAMBDA_EFS_PEERING','LAMBDA_CROSS_ACCOUNT_VPC'],gaps=['缺少学习者可见的“Lambda可通过同AZ跨账户VPC访问EFS”明确结论；一般peering和“须确认”不能抵扣此服务集成支持边界。'],conditions=['在实际服务支持Region、匹配AZ及正确路由/2049/访问点/客户端授权下应用；这些普通实施配置不要求改写整道题或实测部署SLA。']))
results.append(row(806,'SOURCE_ISSUE',[],
 'B和D都能提供某种NFS路径，但File Gateway不是完整POSIX文件系统；原文只说NFS，未说明当前程序必要文件操作和冷热工作集，不能仅凭NFS名词确认唯一最低成本。',
 [cp('GSC-012','File Gateway把文件映射对象并缓存热点'),cp('GSC-001','EFS共享NFS自动容量伸缩'),cp('GSC-002','One Zone不是多AZ容灾'),cp('GCL-018','EFS冷分层仍要比较访问费')],
 ['Volume Gateway提供块卷，不是现有NFS文件接口；S3生命周期也不能把其内部存储当普通桶任意管理。','支持简单NFS到S3对象及冷热层策略；但不支持硬链接/符号链接，不能替代任意现有NFS语义。','Regional EFS多AZ对有此要求时有价值；原文没有把多AZ写成必须条件。','One Zone EFS可保留真正文件系统语义，冷分层费用也随实际访问变动；其单AZ风险不是原文已禁止的条件。'],
 ['FG_NO_LINKS','EFS_LINKS','EFS_ONPREM','EFS_LIFECYCLE','EFS_CLASSES','S3_STANDARD'],issue={'confirmed':True,'subtype':'decisive_input_missing','missingInput':'原NFS工作负载是否必须保留链接/完整文件语义，以及实际热数据容量与保留访问模式。','counterfactualScenarios':[{'conditions':'100TiB活跃数据，每份文件至少每周访问，程序仅需基本文件读写；已有可运行网关的机房VM与热点缓存，接受对象映射。','outcome':'B的S3 Standard存储约0.023美元/GB月（分级大容量更低）远低于相同活跃数据留在EFS One Zone标准层的0.16美元/GB月；在已有网关计算与受控流量的该具体情境，B可以更省。'},{'conditions':'相同现有NFS应用在处理链路中必须创建符号链接/硬链接，原数据不可放弃这些语义；允许One Zone，不要求多AZ。','outcome':'B会在必要链接操作报错，不能作为有效迁移；D仍提供文件系统语义，且在EFS选项内One Zone成本低于Regional。'}],'minimumCorrectionFields':{'requiredFileSemantics':'仅补是否必须保留完整POSIX链接等原应用实际操作；若保留成本唯一比较，再补工作集冷热与容量。'},'correctedExerciseNotOriginal':True}))
results.append(row(919,'SOURCE_ISSUE',[],
 '原始“1TB io1、64,000 IOPS”已违反50 IOPS/GiB上限；即使把容量修正到至少1,280GiB，A仍要以实例EBS路径有余量为前提。',
 [cp('GSC-016','先辨实例路径与单卷瓶颈',('frontZH','answerZH','keyPointZH','watchOutZH'))],
 ['在真实可创建的卷、且实例EBS路径有足够余量时，多卷条带化可提高聚合I/O；不能绕过实例上限。','io1单卷不能再提高到64,000以上。','仅扩容量不能把已经声称64,000的单卷提高到更高io1 IOPS，且原始配置本身无效。','storage-optimized名称本身不保证更高EBS带宽；是否改善要看具体实例与瓶颈。'],
 ['IO1_RATIO'],issue={'confirmed':True,'subtype':'invalid_original_configuration','originalAnchor':'1 TB Provisioned IOPS SSD (io1) EBS volume with 64,000 IOPS','hardContradiction':{'officialMaximumIOPSPerGiB':50,'if1TiB_GiB':1024,'maximumAt1TiB_IOPS':51200,'minimumGiBFor64000':1280,'decimal1TBAlsoInsufficient':True},'secondaryBoundary':'原题未给当前实例EBS性能；不能用A的常见正确方向隐藏实例可能先饱和这一已教边界。','minimumCorrectionFields':{'initialVolumeCapacity':'改成至少1,280GiB的io1卷，保留64,000 IOPS','bottleneck':'若练习希望唯一选A，仅补已确认单卷限制且实例EBS尚有聚合余量；不要求实测部署SLA。'},'correctedExerciseNotOriginal':True}))
results.append(row(953,'SOURCE_ISSUE',[],
 'A与C对所有生成图像的存储完全相同；唯一区别是上传原图Deep Archive还是One Zone-IA。官方每对象请求/元数据及最低计费可使10KiB和100MiB两种原图在同一每年两次训练下反转成本排序，原题没有图像大小/留存/取回档位。',
 [cp('CUR:CMP-M01','先满足立即访问再比较归档费用'),cp('GSC-024','小对象最低计费、转换与元数据开销'),cp('VC-006','取回档位影响等待和费用')],
 ['大原图长期存且训练可提前恢复时可能最省；不是对所有原图大小都固定胜出。','Premium需要任意时间访问，不应把所有生成图像放需恢复的Flexible Retrieval。','小原图每年两次按对象恢复的请求费可使该项总费低于A；若可接受单AZ，它没有被题面禁止。','同B，不能满足Premium任意时间下载的在线访问条件。'],
 ['S3_ZIA','S3_STANDARD','S3_GDA','S3_OVERHEAD'],issue={'confirmed':True,'subtype':'decisive_input_missing','missingInput':'上传原图的典型大小、保留计费周期及训练恢复档位；是否允许单AZ也应按原文未禁止处理。','counterfactualScenarios':calcs,'calculationArtifact':{'path':str((E/'q953-counterfactual-costs.json').resolve()),'sha256':sha(E/'q953-counterfactual-costs.json')},'positiveTechnicalBasis':'两例均保留每年两次训练、相同生成图像访问方案和相同Region；只改变原文未给的原图大小。1000张10KiB时C约0.02684美元/年而A约0.2538；1000张100MiB时A约5.470而C约13.684，排序相反。精确数值以计算文件为准。','minimumCorrectionFields':{'pricingScope':'仅补Region、原图大小、保存期和训练取回档位这些决定输入；仍保留最低总成本目标，不加入任意工具偏好。'},'correctedExerciseNotOriginal':True}))
src('EC2_T3_RATES','ec2-t3','t3.micro 2 1.0 10% 12 5 Up to 2,085 $0.0104 $0.006 $0.005')
r300=next(r for r in results if r['qid']==300)
r300['officialEvidenceRefs'].append('EC2_T3_RATES')
r300['sourceIssue']['counterfactualScenarios']=[
 {'conditions':'us-east-1，保留Oracle专有代码的遗留应用；10台低于CPU基线的Linux t3.micro应用实例加1台Oracle SE2 BYOL db.t3.small，均24×7全年运行，数据存储按相同自动增长策略处理；比较一年Partial Upfront有效小时费。','outcome':'EC2按需0.0104/小时、1年预留有效价0.006/小时；B对10台应用每小时节省0.044。RDS按需0.034/小时，Partial Upfront为89美元加0.0102/小时，有效0.02035981735/小时，D每小时只节省约0.01364018。因此B比D约低0.03035982/小时；C不能保留Oracle专有代码。'},
 {'conditions':'相同Region、引擎、数据库及购买期限，应用只需1台低于CPU基线的t3.micro；其余仍24×7且存储增长。','outcome':'B只节省0.0044/小时；D节省约0.01364018/小时。因此D比B约低0.00924018/小时。两例的存储与I/O需求保持相同，费用在B/D间相消。'}
]
r300['sourceIssue']['counterexampleCostLogic']='两例的EC2价格来自AWS T3产品页同一Region一年有效RI价格；RDS报价来自当前官方价格表同一年Partial Upfront，effective=0.0102+89/8760。它们是题面未给出的可行具体情境，不是原题事实。'
r953=next(r for r in results if r['qid']==953)
r953['sourceIssue']['positiveTechnicalBasis']='两例保留每年两次训练及完全相同生成图像访问/费用；只改原文未给原图大小。1000张10KiB：C=0.02683917236美元/年，A=0.25377765096；1000张100MiB：A=5.46941409505，C=13.683875，排序相反。价格、元数据、请求、临时恢复副本都已计入计算文件。'
for r in results:
 if r['qid'] in [49]:r['nearestCompetitorOrdinals']=[3]
 if r['qid'] in [139]:r['nearestCompetitorOrdinals']=[2]
 if r['qid'] in [240]:r['nearestCompetitorOrdinals']=[2,3]
 if r['qid'] in [257]:r['nearestCompetitorOrdinals']=[1,3]
 if r['qid'] in [284]:r['nearestCompetitorOrdinals']=[1,2]
 if r['qid'] in [300]:r['nearestCompetitorOrdinals']=[2,3,4]
 if r['qid'] in [435]:r['nearestCompetitorOrdinals']=[1,4]
 if r['qid'] in [511]:r['nearestCompetitorOrdinals']=[1,2,3]
 if r['qid'] in [540]:r['nearestCompetitorOrdinals']=[1,2]
 if r['qid'] in [728]:r['nearestCompetitorOrdinals']=[2,3]
 if r['qid'] in [734]:r['nearestCompetitorOrdinals']=[3,4]
 if r['qid'] in [752]:r['nearestCompetitorOrdinals']=[1,4]
 if r['qid'] in [800]:r['nearestCompetitorOrdinals']=[1,2,3]
 if r['qid'] in [806]:r['nearestCompetitorOrdinals']=[2,3,4]
 if r['qid'] in [919]:r['nearestCompetitorOrdinals']=[1,4]
 if r['qid'] in [953]:r['nearestCompetitorOrdinals']=[1,3]
 r['wholeQuestionSupportFromVisibleCards']='SUPPORTED' if r['status']=='SUPPORTED' else ('PARTIAL_WITH_EXPLICIT_GAPS' if r['knownVisibleCardGaps'] else 'NOT_UPGRADED_TO_SUPPORTED')
 r['selectedOptionOrdinalsMeaning']='Supported selection only for SUPPORTED; otherwise best candidate or conditional branch, not an accepted original answer.'
 assert all(k in sources or k in price_sources for k in r['officialEvidenceRefs'])
 assert r['status'] in ['SUPPORTED','CONDITIONAL','INSUFFICIENT_CARDS','SOURCE_ISSUE','UNKNOWN']
 assert r['status']!='SOURCE_ISSUE' or r['sourceIssue']['confirmed']
assert {r['qid']for r in results}=={q['qid']for q in questions}
obj={'schema':'independent-current-source-and-card-gap-review-v1','reviewer':'/root/domain_primary_audit','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'16 full original questions; current 359 visible Chinese candidate pool; no new authoring or domain reclassification','status':'COMPLETE_WITH_OPEN_CARD_GAPS_AND_EXPLICIT_CONDITIONAL','inputManifest':{'path':str((P/'manifest.json').resolve()),'sha256':sha(P/'manifest.json'),'allBindingsVerified':True},'sourceAmbiguityRuleBinding':{'path':str((V/'inputs/source-ambiguity-rule-clarification-20261107.md').resolve()),'sha256':sha(V/'inputs/source-ambiguity-rule-clarification-20261107.md'),'actuallyRead':True},'independence':{'priorQuestionAnswerLettersUsed':False,'sourceQuestionDomainsUsed':False,'externalModelCliApiCalls':0,'nativeUsage':'unknown','subagentsSpawned':0,'productionOrMainRunModified':False},'officialSources':sources,'officialPriceSources':price_sources,'results':results,'counts':dict(collections.Counter(r['status']for r in results)),'limits':['Current 359 is a frozen candidate pool, not final N.','External official findings do not fill unlearned visible-card premises.','Original source issues and candidate corrected exercises remain separate; no original was changed.','One remaining conditional Q49 is precisely scoped to metadata-query/cost comparison; it is not silently accepted or treated as a proven source error.']}
(R/'results.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print('WROTE',obj['counts'])

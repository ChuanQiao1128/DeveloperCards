import concurrent.futures,datetime,hashlib,html,json,re,subprocess
from pathlib import Path
root=Path.cwd();out=root/'review/remaining-source10/evidence';cat=json.loads((root/'review/final-core-closure01/input/official-snapshot-catalogue.json').read_text());known={x['url']:x for x in cat}
urls={
'lambda-efs-launch':'https://aws.amazon.com/blogs/aws/new-a-shared-file-system-for-your-lambda-functions/',
'lambda-crossvpc':'https://docs.aws.amazon.com/lambda/latest/dg/configuration-vpc-cross-account.html',
's3-cost-analysis':'https://aws.amazon.com/blogs/storage/analyze-access-patterns-and-use-the-most-cost-effective-amazon-s3-storage-class/',
'dms-sct-integration':'https://docs.aws.amazon.com/SchemaConversionTool/latest/userguide/CHAP_DMSIntegration.html',
'snow-how':'https://docs.aws.amazon.com/snowball/latest/developer-guide/how-it-works.html',
'snow-availability':'https://docs.aws.amazon.com/snowball/latest/developer-guide/snowball-edge-availability-change.html',
'ec2-ri-pricing':'https://aws.amazon.com/ec2/pricing/reserved-instances/pricing/',
'aurora-pg-overview':'https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/Aurora.AuroraPostgreSQL.html'
}
def fetch(item):
 k,u=item;p=out/(k+'.json')
 if p.exists():return k,'existing'
 if u in known:
  z=known[u];p.write_bytes(Path(z['snapshotPath']).read_bytes());return k,'reused'
 rawp=out/(k+'.html')
 try:
  r=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','30','--output',str(rawp),'--write-out','%{url_effective}\n%{http_code}',u],capture_output=True,check=True)
  final,status=r.stdout.decode().splitlines();raw=rawp.read_bytes();s=raw.decode('utf-8');s=re.sub(r'<(script|style)\b.*?</\1\s*>','',s,flags=re.I|re.S);s=html.unescape(re.sub(r'<[^>]+>',' ',s));s=re.sub(r'\s+',' ',s).strip()
  p.write_text(json.dumps({'url':u,'finalUrl':final,'httpStatus':int(status),'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':s,'textSha256':hashlib.sha256(s.encode()).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest()},ensure_ascii=False,indent=2)+'\n');return k,len(s)
 except Exception as e:return k,str(e)
for r in concurrent.futures.ThreadPoolExecutor(5).map(fetch,urls.items()):print(json.dumps(r),flush=True)

import concurrent.futures,datetime,hashlib,html,json,re,subprocess
from pathlib import Path
root=Path.cwd();out=root/'review/remaining-source10/evidence';cat=json.loads((root/'review/final-core-closure01/input/official-snapshot-catalogue.json').read_text());known={x['url']:x for x in cat}
urls={
'ebs-io1':'https://docs.aws.amazon.com/ebs/latest/userguide/provisioned-iops.html',
'ebs-optimized':'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ebs-optimized.html',
'lambda-efs':'https://docs.aws.amazon.com/lambda/latest/dg/configuration-filesystem.html',
'lambda-limits':'https://docs.aws.amazon.com/lambda/latest/dg/gettingstarted-limits.html',
's3-replication-limit':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/replication-what-is-isnot-replicated.html',
's3-notifications':'https://docs.aws.amazon.com/AmazonS3/latest/userguide/notification-how-to-event-types-and-destinations.html',
'eventbridge-targets':'https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-targets.html',
'cw-streams':'https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch-Metric-Streams.html',
'asg-events':'https://docs.aws.amazon.com/autoscaling/ec2/userguide/automating-ec2-auto-scaling-with-eventbridge.html',
'asg-metrics':'https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-metrics.html',
'ce-groups':'https://docs.aws.amazon.com/cost-management/latest/userguide/ce-filtering.html',
'cost-user-tags':'https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/custom-tags.html',
'rds-cluster':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/multi-az-db-clusters-concepts.html',
'rds-oracle-replica':'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/oracle-read-replicas.html',
'dxgw':'https://docs.aws.amazon.com/directconnect/latest/UserGuide/direct-connect-gateways-intro.html',
'dxgw-vgw':'https://docs.aws.amazon.com/directconnect/latest/UserGuide/virtualgateways.html',
'vg-cached':'https://docs.aws.amazon.com/storagegateway/latest/vgw/StorageGatewayConcepts.html',
'vg-pricing':'https://aws.amazon.com/storagegateway/pricing/',
'efs-classes':'https://docs.aws.amazon.com/efs/latest/ug/storage-classes.html',
'efs-pricing':'https://aws.amazon.com/efs/pricing/',
'fg-nfs':'https://docs.aws.amazon.com/filegateway/latest/files3/nfs-client.html',
's3-pricing':'https://aws.amazon.com/s3/pricing/',
'dms-snowball':'https://docs.aws.amazon.com/dms/latest/userguide/CHAP_LargeDBs.html',
'dms-oracle-target':'https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Target.Oracle.html',
'snow-pricing':'https://aws.amazon.com/snowball/pricing/',
'snow-updates':'https://aws.amazon.com/blogs/storage/aws-snow-device-updates/'
}
def fetch(item):
 k,u=item;p=out/(k+'.json')
 if p.exists():return k,'existing'
 if u in known:
  z=known[u];p.write_bytes(Path(z['snapshotPath']).read_bytes());return k,'reused'
 rawp=out/(k+'.html')
 try:
  r=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','30','--output',str(rawp),'--write-out','%{url_effective}\n%{http_code}',u],capture_output=True,check=True)
  final,status=r.stdout.decode().splitlines();raw=rawp.read_bytes();s=raw.decode('utf-8');s=re.sub(r'<(script|style)\b.*?</\1\s*>','',s,flags=re.I|re.S);s=html.unescape(re.sub(r'<[^>]+>',' ',s));s=re.sub(r'\s+',' ',s).strip()
  p.write_text(json.dumps({'url':u,'finalUrl':final,'httpStatus':int(status),'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text':s,'textSha256':hashlib.sha256(s.encode()).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest()},ensure_ascii=False,indent=2)+'\n');return k,len(s)
 except Exception as e:return k,str(e)
for r in concurrent.futures.ThreadPoolExecutor(5).map(fetch,urls.items()):print(json.dumps(r),flush=True)

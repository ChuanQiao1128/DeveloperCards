# -*- coding: utf-8 -*-
import pathlib,json,hashlib,datetime
D=pathlib.Path(__file__).resolve().parent;I=D/'input';V=D.parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
cs=json.loads((I/'cases.json').read_text());C={x['ruleId']:x for x in json.loads((I/'visible-pool.frozen.json').read_text())};m=json.loads((I/'manifest.json').read_text())
def anchor(k,f):return dict(ruleId=k,field=f,quote=C[k]['visibleBody'][f],bodySha256=C[k]['bodySha256'])
def premise(pid,text,refs,status='TAUGHT'):
 return dict(premiseId=pid,judgment=text,status=status,anchors=[anchor(k,f) for k,f in refs])
base=[]
for c in cs:
 orig=c['originalQuestion'];new=c['correctedQuestion'];expected=orig['stem']
 for d in c['deltas']:expected=expected.replace(d['old'],d['new'])
 assert expected==new['stem'] and orig['options']==new['options']
 base.append(dict(variantId=c['variantId'],originalQid=c['originalQid'],originalQuestionCanonicalSha256=canonical(orig),correctedQuestionCanonicalSha256=canonical(new),originalQuestion=orig,correctedQuestion=new,deltas=c['deltas'],minimalityVerdict='PASS_CAPACITY_ONLY_DELTA',learningTargetPreserved=True,allOptionsUnchanged=True,originalStatus='SOURCE_ISSUE',originalNeverUpgradedByVariant=True,sourceFindingUsedAsLearningPremise=False))
q=base[0];q.update(variantVerdict='INSUFFICIENT_CARDS',cardGroupSufficiency='NOT_PASS',selectedOptionOrdinals=[],candidateOptionOrdinals=[3],usedRuleIds=['GSC-001','GSC-002','GSC-020','CUR:CB03','CUR:NA05','GCL-021'])
q['necessaryPremises']=[
 premise('P1','标准共享文件接口与容量随文件增长由EFS提供。',[('GSC-001','keyPointZH')]),
 premise('P2','Regional EFS跨AZ保存并配置各AZ挂载入口。',[('GSC-002','answerZH'),('GSC-002','keyPointZH'),('GCL-021','keyPointZH')]),
 premise('P3','多AZ计算分散实例并由ASG维持容量。',[('CUR:CB03','answerZH'),('CUR:CB03','keyPointZH')]),
 premise('P4','EBS MultiAttach不能当跨AZ普通共享文件系统。',[('GSC-020','answerZH'),('GSC-020','keyPointZH')]),
 premise('P5','S3按对象API访问，与必须保普通文件系统结构有接口差别。',[('CUR:NA05','frontZH'),('CUR:NA05','keyPointZH')]),
 premise('P6','单个数百GB文件须在EFS适用单文件范围内；当前卡未明确该范围，也未给该容量已满足的题面前提。',[],'NOT_TAUGHT_NO_PRIVATE_SUBSTITUTION')]
q['reasoningAndClosestCompetitor']='C的共享文件、自动总容量增长、多AZ计算与存储机制均能由当前卡推导；A改对象接口，B/D的EBS不能直接构成所需跨AZ共享文件。容量修订事实可由官方单文件上限独立核实，但私有sourceFinding不是学习者卡面；不能把总文件系统自动扩容当作单文件任意大小均可。故选型方向明确，严格完整条件下本版本未获卡组充分PASS。'
q['missingJudgments']=['单文件数百GB处于支持范围这一容量前提没有可见卡句；不要求因此自动新增47.9TiB孤立数字卡。']
q['nextAction']='可把新练习前提中性限定为“假定适用的单文件及总容量限制均已满足”，再独立回测；这只是下一版本提议，未修改当前纠错版或原题。'
q['implementationChecks']=['使用Regional EFS并实际配置mount targets、路由及文件权限；未部署/未压测不另列教学缺口。']
q=base[1];q.update(variantVerdict='UNKNOWN',cardGroupSufficiency='NOT_PASS',selectedOptionOrdinals=[],candidateOptionOrdinals=[2,4],usedRuleIds=['GSC-010','GSC-011','GSC-012','GSC-013'])
q['necessaryPremises']=[
 premise('P1','stored将完整主数据留本地；cached仅本地缓存，未命中访问云端。',[('GSC-010','answerZH'),('GSC-010','keyPointZH'),('GSC-010','watchOutZH')]),
 premise('P2','兼容VolumeGateway快照可创建EBS再挂EC2，不是直接挂S3桶。',[('GSC-011','answerZH'),('GSC-011','keyPointZH')]),
 premise('P3','FileGateway提供文件接口/热点缓存，不保本地全量或原iSCSI块接口。',[('GSC-012','keyPointZH'),('GSC-012','watchOutZH')]),
 premise('P4','TapeGateway提供虚拟磁带设备，虚拟磁带数据由AWS保存。',[('GSC-013','answerZH'),('GSC-013','keyPointZH')]),
 premise('P5','当前题面已明示10TiB处于StorageGateway和EBS容量范围；无需从私有上限引文补学事实。',[],'GIVEN_EXPLICITLY_IN_CORRECTED_STEM'),
 premise('P6','D是否必然比B变更更少：B未要求移走原本地卷，可继续本地即时访问，只新增磁带备份；当前卡不能据原文唯一排除它。',[],'UNRESOLVED_CLOSE_COMPETITOR')]
q['reasoningAndClosestCompetitor']='D的stored本地全量+快照恢复EBS链路由卡支持，A改NFS/对象且恢复路径不等同磁盘，C缓存未命中不能保证全量本地；10TB cache与10TiB数据的单位差亦不能使C保证全量缓存。但原需求是DR计划，未要求网关替换主存。B可保原本地iSCSI卷不变并新增磁带备份，在线访问仍本地；“least change”是否应排B需要真实流程/前提，不能仅因不是VolumeGateway就说它不做DR。没有据此确认B一定最优或已证明多解，故保持UNKNOWN。'
q['missingJudgments']=[]
q['unresolvedQuestions']=['B的具体云端恢复流程与改动代价，以及为何必然不如D；当前卡与题面没有足够依据作唯一比较。']
q['nextAction']='先核B的实际恢复方案及原选项是否有漏文/错误，再决定是否仍需最小纠错；不能为迎合D无证增添“必须替换主卷”等新目标。'
q['implementationChecks']=['“without latency”按不发生云端回源等待理解；不宣称物理零延迟。原题没给EC2恢复RTO，未使用FSR或未演练不据此另报缺卡。']
# Positive official fact check for Tape Gateway recovery capability supports caution only, never supplies card learning premises.
p=D/'evidence/tape-requirements.json';d=json.loads(p.read_text());t=d['text'];st=t.index('You use a backup application to read, write, and manage tapes');endtext='Restoration of full and partial data from tapes and verification of data\nintegrity.';en=t.index(endtext,st)+len(endtext)
supplementary=dict(url=d['url'],snapshotPath=str(p),snapshotSha256=sha(p.read_bytes()),textSha256=sha(t.encode()),quoteStart=st,quoteEnd=en,quote=t[st:en],role='只验证不能笼统宣称TapeGateway无恢复功能；不是学习者已学的EC2/EBS恢复前提，也没有据此确认B完整可行。')
checks={}
checks['all_frozen_inputs_unchanged']=all(sha(pathlib.Path(p).read_bytes())==h for p,h in m.items())
checks['two_exact_variant_ids']={x['variantId'] for x in base}=={'Q052-CV01','Q324-CV01'}
checks['all_original_and_new_hashes_match']=all(c['originalQuestionCanonicalSha256']==canonical(c['originalQuestion']) and c['correctedQuestionCanonicalSha256']==canonical(c['correctedQuestion']) for c in cs)
checks['all_options_unchanged']=all(c['originalQuestion']['options']==c['correctedQuestion']['options'] for c in cs)
checks['declared_stem_deltas_only']=all((lambda c:(lambda s:s)(c['originalQuestion']['stem'].replace(c['deltas'][0]['old'],c['deltas'][0]['new']))) (c)==c['correctedQuestion']['stem'] for c in cs)
checks['all_card_field_quotes_and_hashes_match']=all(a['bodySha256']==C[a['ruleId']]['bodySha256'] and a['quote']==C[a['ruleId']]['visibleBody'][a['field']] for r in base for p in r['necessaryPremises'] for a in p['anchors'])
checks['all_used_cards_in_frozen357']=all(k in C for r in base for k in r['usedRuleIds']) and len(C)==357
checks['original_capacity_evidence_bound']=all((lambda p,d,e:sha(p.read_bytes())==e['fileSha256'] and sha(d['text'].encode())==e['textSha256'] and d['text'][e['quoteStart']:e['quoteEnd']]==e['quote'])(pathlib.Path(e['sourcePath']),json.loads(pathlib.Path(e['sourcePath']).read_text()),e) for c in cs for e in c['sourceFinding']['officialEvidence'])
checks['tape_positive_quote_exact']=t[st:en]==supplementary['quote'] and sha(p.read_bytes())==supplementary['snapshotSha256']
checks['original_SOURCE_ISSUE_not_promoted']=all(x['originalStatus']=='SOURCE_ISSUE' and x['originalNeverUpgradedByVariant'] for x in base)
checks['no_private_fact_learning_substitution']=all(not x['sourceFindingUsedAsLearningPremise'] for x in base)
assert all(checks.values()),checks
result=dict(schemaVersion=1,reviewer='actual_gap_review',reviewedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozenManifestPath=str(I/'manifest.json'),frozenManifestSha256=sha((I/'manifest.json').read_bytes()),scopePolicy='minimal_corrected_variants_for_independently_confirmed_original_errors',visiblePoolCount=357,counts=dict(SUPPORTED=0,INSUFFICIENT_CARDS=1,UNKNOWN=1),results=base,supplementaryOfficialEvidence=[supplementary],mechanicalReadback=dict(status='PASS_MECHANICAL_ONLY',checks=checks),originalQuestionsModified=False,correctedQuestionsModified=False,formalInventoryModified=False,externalModelCliApiCalls=0,nativeUsage='unknown',supplemental02NotAppliedOrBorrowed=True,fullLibraryNStillUnknown=True)
dump(D/'results.json',result);print(result['counts'],'all checks',all(checks.values()))

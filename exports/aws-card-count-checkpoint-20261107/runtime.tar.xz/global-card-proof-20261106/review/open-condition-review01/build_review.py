import json,pathlib,hashlib,datetime,collections,re
O=pathlib.Path(__file__).parent; V=O.parent.parent; I=O/'input'
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
manifest=json.loads((I/'manifest.json').read_text())
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,p
pool=json.loads((I/'visible-pool.frozen.json').read_text());cards={c['ruleId']:c for c in pool}
for c in pool:assert sha(canon(c['visibleBody']))==c['bodySha256'],c['ruleId']
cases={x['qid']:x for n in range(1,5) for x in json.loads((I/('cases%02d.json'%n)).read_text())}
cat=json.loads((I/'official-snapshot-catalogue.json').read_text()); ev={}
def evidence(eid,selector,needles):
 rs=[r for r in cat if selector in r['snapshotPath'] or selector==r['url']]
 if selector.startswith('@'):p=O/'evidence'/(selector[1:]+'.snapshot.json');r={'snapshotPath':str(p)}
 else:assert rs,selector;r=rs[0];p=pathlib.Path(r['snapshotPath'])
 d=json.loads(p.read_text());t=d['text'];q=[]
 for n in needles:
  st=t.find(n)
  if st<0:
   m=re.search(r'\s+'.join(map(re.escape,n.split())),t,re.I);st=m.start() if m else -1
  assert st>=0,(eid,n)
  a=max(0,st-100);b=min(len(t),st+len(n)+220);q.append({'quote':t[a:b],'start':a,'end':b})
 ev[eid]={'url':d.get('url',r.get('url')),'snapshotPath':str(p),'snapshotSha256':sha(p.read_bytes()),'textSha256':sha(t.encode()),'quotes':q}
 return eid
R=[]
def D(q,status,ids,choice,reason,competition,remaining='',kind='implementation_validation',evs=(),source=None):
 ids=ids.split();used=[]
 def use(r):
  if r in used:return
  assert r in cards,r
  used.append(r)
  for k in cards[r]['prerequisiteRuleIds']:use(k)
 for r in ids:use(r)
 anchors=[]
 for r in used:
  c=cards[r]
  for f,t in c['visibleBody'].items():
   if t:anchors.append({'ruleId':r,'bodySha256':c['bodySha256'],'field':f,'quote':t,'start':0,'end':len(t),'role':'used_card_context' if r in ids else 'recursive_prerequisite_context'})
 x=cases[q];R.append({'qid':q,'status':status,'questionCanonicalSha256':x['questionCanonicalSha256'],'questionInputObjectSha256':sha(canon(x['question'])),'selectedOptionOrdinals':choice,'choiceReasoning':reason,'keyCompetitionReasoning':competition,'directlyUsedRuleIds':ids,'actualUsedRuleIdsIncludingRecursivePrerequisites':used,'cardBindings':[{'ruleId':r,'bodySha256':cards[r]['bodySha256'],'prerequisiteRuleIds':cards[r]['prerequisiteRuleIds']} for r in used],'necessaryPremiseAnchors':anchors,'remainingConditions':([{'kind':kind,'description':remaining,'blocksOriginalSupport':status!='SUPPORTED'}] if remaining else []),'officialEvidenceIds':list(evs),'sourceConfirmation':source,'factReReviewPerformed':False})
def S(kind,a,b,repair):return {'subtype':kind,'construct1':a,'construct2':b,'minimalClarificationRecommendation':repair,'originalRemainsUnchanged':True,'correctedVariantAuthored':False}
def savepart(n):
 p=O/('part%02d.results.json'%n);p.write_text(json.dumps({'reviewer':'independent_native_open_condition_review01','results':R[(n-1)*20:n*20]},ensure_ascii=False,indent=2));print(p.name,len(R[(n-1)*20:n*20]))
# All decisions below are independent semantic adjudications. Bindings and offsets above are mechanical only.
D(19,'CONDITIONAL','CUR:XB002',[4], 'D是透明跨VPC检查的架构：应用路由到GWLB endpoint，再由GWLB送设备。', 'A/B不是该卡所教的透明IP检查连接；C单独的TGW不会自动形成设备检查跳点。', '设备能接收IP包不证明能处理GWLB的GENEVE。待确认设备版本/模式；这是真实协议能力条件，不是路由或权限部署检查。未确认其不支持，故不宣称题源已错。','service_capability_condition',('GWLB',))
D(59,'SOURCE_ISSUE','CUR:NS01 CUR:XB004 CUR:XB013 GSC-093 CUR:XB019',[2,4], 'D是流摄取→托管交付S3→Redshift分析的可行链；B也允许EC2处理并把结果交给S3/Redshift。原文只要求每日30TB，没有实时性、最少维护或唯一框架约束。', 'C把CloudFront当收集缓存不构成可靠的点击流摄取；不能因为D更托管就补入原文未问的最少运维目标来排除B。', '已确认选择范围不唯一；吞吐分片/实例数属于两种架构的正常容量设计。','decisive_input_missing',('REDSHIFT_LOAD','ASG','FIREHOSE'),S('multiple_valid_options','生产者把点击流交给可伸缩EC2消费者，处理后落S3并COPY到Redshift；30TB/日约347MB/s，可按量横向分配。','生产者把同规模记录写Kinesis，Firehose交付S3并载入Redshift；二者满足同一明示日量和分析需求。','优先把题目改为选择全部可行架构（至少B、D）；若要单选，须新增明确的托管摄取/最少运维目标，并独立检查其确实区分选项。'))
D(64,'CONDITIONAL','GCL-008 CUR:CA15 GSC-012',[4], 'D保留Windows文件共享后端，并给机房加本地热点缓存；云内应用直接访问FSx，避免都绕机房。', 'A的机房访问每次走VPN；B把云内请求也绕本地网关；C让部分Windows文件访问改为S3对象API，较大改动。', '当前FSx File Gateway只对符合既有资格的客户可用。原题未给资格，卡也明确此前提；这不是全面退役，也不把缓存命中推成所有文件均零网络延迟。','service_eligibility',('FSX_GATEWAY',))
D(107,'INSUFFICIENT_CARDS','CUR:CA17 CUR:XB013 CUR:CC03 CUR:NA02 CUR:NC01',[2], 'B提供REST入口和业务计算，最接近位置数据写入/查询链；但B没有命名持久层，当前卡只教入口调用函数及独立数据库用途。', 'Athena/S3、QuickSight/Redshift侧重分析；D的流分析不是自动的随机位置记录查询接口。不能靠私有记忆补Lambda到位置存储的具体写读链，或把分析平台当完整REST存取层。', '缺实际可见的持久位置记录存取连接及在本题中排除D的必要机制。当前不能据“Lambda万能”宣称完整卡组充分；也未证实所有候选均不可实现。','card_premise_missing')
D(138,'SOURCE_ISSUE','GSC-087 GSC-086 CUR:CB03 CUR:CB01 CUR:CC22 GCL-012',[], '关系库托管Multi-AZ和应用跨AZ方向成立，但A/B把RabbitMQ写成active/standby冗余对，套用了不相同引擎的部署模式。', 'C/D只把RabbitMQ或PostgreSQL装进ASG，不建立消息/数据库状态复制与接管；因此不能提供所问的最高可用和最少运维。', '原选项的RabbitMQ部署模式存在明确技术冲突。','explicit_technical_conflict',('MQ_RABBIT',),S('explicit_technical_conflict','RabbitMQ受管HA为跨AZ三节点cluster deployment，官方正面定义了节点数与部署形态。','A/B所写RabbitMQ active/standby pair并非该受管RabbitMQ部署形态；C/D的实例补足也不自动完成状态复制。','只修B的消息层为受支持的跨AZRabbitMQ集群及相应队列复制；保留原应用ASG和RDS Multi-AZ条件。'))
D(146,'SUPPORTED','GSC-146 VC-007 CUR:CB03',[2], 'B把持续存在的低谷基线放在匹配的预留折扣容量上，额外无状态、可横向替换的Web容量使用Spot，避免为每天峰值长期买满。', 'A让全部容量受Spot回收影响；C的相同稳定基线没有预留折扣；D引入题目不需要的Dedicated成本且峰值仍按On-Demand。', '按基线核实承诺利用率，并为Spot回收设置健康替换、分散容量及稳定兜底。题目所问是保持可用的架构选型，不要求证明任何实例永不故障或新增零中断硬保证。')
D(157,'CONDITIONAL','CUR:NS03 CUR:XB008 GSC-047',[4,5], 'E用长期周期备份策略安排五年恢复点保留及到期清理；D把数据库内部审计持续导出并独立无限期保存。两种保留不能用同一个自动备份窗口代替。', 'A不自动到期；C不能把普通Aurora PITR窗口设成五年；B笼统自动备份生命周期不足以替代支持的长期备份方案。', '若“all data必须五年后删除”也要求清掉主库中的五年前业务行，E的恢复点到期不负责删除仍在主库的行。原题没有界定业务行生命周期与备份保留的范围；只在其指五年恢复点保留时D/E充分，不能宣称已证明活跃主库的逐行删除。','retention_scope_condition')
D(215,'CONDITIONAL','GSC-077 CUR:CMP-M01',[1], '700TB÷500Mbps的理想在线下限约129.6天，超过一月；B/D仍受公网链路限制，C同样500Mbps也不能搬完。A的离线设备路线并长期Deep Archive符合低频七年方向。', '加VPN、DataSync或同速专线不会把500Mbps提升到所需约2.16Gbps（月按30天）。', 'A须是现行仍有订购资格且设备容量、配送/导入窗口可安排的客户；当前卡没有给这个题的资格事实，故保留条件。普通现场复制及运输安排应验证，但不据未做实测单独把A判无解。','service_eligibility',('SNOW_CURRENT',))
D(234,'SUPPORTED','CUR:CC08 CUR:CC09 CUR:CB13 CUR:CMP-M11',[3], 'C选对KMS静态加密与ACM/TLS传输保护的职责：EBS和Aurora落盘由KMS，实际客户端HTTPS入口绑定ACM证书。CMP-M11进一步要求应用到数据库等后续连接也实际启用TLS。', 'A/D颠倒或混淆密钥与TLS证书用途；B不存在一次根账户开关包办所有存储和连接。', '在ALB→EC2、EC2→Aurora各段配置适用TLS和证书验证，并启用两类存储的加密。ALB终止TLS不自动加密后段；这些是同一正确架构的实施配置，不是原题无解的证据。')
D(235,'CONDITIONAL','GSC-060 GSC-061',[3], 'C涵盖异构schema转换、全部表全量加载和持续CDC；A/B的DataSync不是关系库异构复制替代，D只选大表遗漏共同写入的其他表。', 'C的单向任务只把Oracle变化送目标；不因应用逐步搬迁就自动形成双向无冲突同步。', '须明确月间迁移时的写入权威/键归属和反向变化路径。若两库同时改同一行，官方DMS双向复制本身不做冲突解决；若全部写入仍归一个权威库，C可用。此处保留真实写入方向条件，未拿普通权限或复制实例调参当阻碍。','write_ownership_condition',('DMS_BIDIR',))
D(237,'SUPPORTED','CUR:CB16',[1], 'A以peering形成跨账户EC2私网直连，连接不依赖独立中转设备，符合无此类单点或带宽瓶颈的选择。', 'B的gateway endpoint不是任意EC2文件服务入口；C单挂VGW没有对端VPN；D的VIF也不是给一台EC2附加的跨VPC连线。', '按卡面核对CIDR不重叠，双方配路由和收窄访问控制。原题没有给重叠事实，不因常规连接前提未列出便确认源错。')
D(240,'INSUFFICIENT_CARDS','GSC-078 CUR:NB01',[4], '把可视化放仓库同Region，只把500KB页面传机房，而非每次传50MB结果；这一步能从GSC-078直接推导。', 'A/C传原始大结果；B/D仅剩Internet与现有DX这两条小页面出站路径。', '卡只要求按实际费率比较，并未提供常规同Region DX与Internet出站单价关系，因此不能只凭卡断言D一定比B便宜。缺的是路径价格关系的可见教学；不要求搜索所有Region、免费档或极端市场最低价。','card_premise_missing')
D(258,'UNKNOWN','GSC-029 GSC-095 GSC-133',[1,4], 'D是事件触发Glue ETL转换；卡足以排除“crawler本身转换”的误会。A的1GB文件也没有仅因大小就超出当前Lambda存储/内存限制。', 'B额外自管Spark任务；C是周期查询/目录链而非逐PUT转换。真正待定是A与D在这项仅CSV→Parquet工作中的最低运维比较。', '尚未取得足够官方正证，证明该具体转换在Lambda可直接完成并且可合理比较A/D的运维，或证明A受硬限制。不能用旧512MB临时存储或900秒未经证实的运行估计排除A，也不确认原题错误。','technical_comparison_unresolved',('LAMBDA_LIMITS','LAMBDA_EPHEMERAL'))
D(290,'SUPPORTED','GSC-146 VC-007 CUR:CB03',[3], 'C保留On-Demand基线并让适用的弹性Web容量用Spot降低费用；无须购买长期承诺。', 'D含预留承诺，与明确无长期承诺冲突；A无专用硬件需求；B放弃题中可伸缩实例池可用的Spot降费机会。', '实现混合容量与回收替换，按业务需要保留稳定部分；题目未提出全部增量请求不可重试或绝不短暂替换的约束。')
D(295,'CONDITIONAL','CUR:XR001 CUR:NA05',[2], 'B在读取返回路径按调用应用去除PII，无须维护三份衍生数据或自管代理，是卡面所教的用途。', 'A自管代理；C/D预存多份数据并同步其更新，增加维护。', '现行S3 Object Lambda使用资格未给，不能把既有合格客户能力套到任意新客户；资格确认后再验证三应用各自的访问路径和授权。仅新客关闭并不等于全面退役。','service_eligibility',('OBJECT_LAMBDA_CURRENT',))
D(300,'SOURCE_ISSUE','CUR:CC22 GSC-050 GSC-054 GSC-146 VC-007',[2,3,4], '持续运行和增长容量说明稳定折扣与存储扩展的重要性，但没有告诉所用数据库引擎。Aurora预留并不能无条件替代任意legacy关系库。', 'A的Spot/S3不能直接保留数据库语义；B/D能选择其他RDS引擎，C只限Aurora支持的MySQL/PostgreSQL方向。不能仅因Aurora存储增长就从未说明的legacy数据库跳到C。', '原题缺少决定Aurora兼容性的引擎输入；即使兼容还应比较两层稳定利用率的承诺选择。','decisive_input_missing',('AURORA_ENGINES','RDS_RI'),S('decisive_input_missing','legacy数据库为兼容的MySQL，C的Aurora MySQL是可行迁移方向，容量可增长。','legacy数据库为依赖Oracle特性的Oracle；原文明示条件仍成立，但C不能直接提供Oracle引擎，RDS Oracle方向仍可行。','新增数据库引擎/兼容性这一必要练习设定；不要把“legacy”偷偷解释成MySQL。若要比较唯一最低成本，另明确同类稳定用量比较口径，而不添加任意工具偏好。'))
D(337,'SOURCE_ISSUE','VC-003 GSC-057 GSC-045 CUR:CC22',[1], 'Aurora共享存储低延迟reader及reader数量伸缩适合本题方向；低于一秒的目标不要求另证明每种故障下绝对SLA。问题在A强行把已有stored procedures换为native functions。', 'B/D改变数据访问和存储过程模型且需更多应用变化；C增加自管维护。A的额外替换不能泛称无损或最低改动。', '存储过程的内容未给；官方明确支持过程及定时事件，而函数不允许显式事务控制。','decisive_input_missing',('AURORA_PROC','AURORA_UDF','AURORA_SCHEDULE'),S('decisive_input_missing','已有定时过程只做纯标量计算，可在重写调用后改为函数，A额外步骤至少有可能实现。','已有定时过程含COMMIT/ROLLBACK并执行交易处理，同样符合原文；Aurora MySQL存储函数不允许该显式事务控制，A要求的替换不可直接保持语义。','最小删掉A要求的过程→函数替换，保留兼容的存储过程和适用调度；另存练习并独立验，不改原题为充分。'))
D(373,'CONDITIONAL','CUR:CMP-M01 GSC-024 GSC-025',[1,4], '前一年须即时访问，排除需恢复的归档访问层；满一年才转Deep Archive。A的独立即时Intelligent-Tiering加Lifecycle、D的Standard→IA都具备这条访问路径。', 'B把Intelligent-Tiering内部归档配置误当跨存储类Lifecycle；C从写入第一天就放IA，不适合每日重读近30天的设计方向。', 'trillions个对象让逐对象监控、转换及最低对象计费成为本题真实成本输入。卡教了这些因素但未给足价格/大小做A与D的成本反例，故不凭“最便宜”猜选，也未独立确认题源错误。','cost_input_condition',('S3_TIER','S3_PRICING'))
D(390,'SUPPORTED','CUR:NB08 CUR:NB04 CUR:XB013 GSC-032',[2,4], 'B/D把会话从Web实例外置到共享DynamoDB或配置复制/快照恢复的Redis；实例退出后其他实例可继续读会话，不依赖粘滞到旧机器。', 'A只改变路由不复制本机会话；C登录身份池不是任意交易会话数据持久层；E不是会话存储。', 'Redis按支持部署配置副本、自动接管和备份。题目只要求durably，未要求每笔已确认写入的零RPO，不能追加该门槛排除有持久化与恢复能力的Redis。',evs=('REDIS_PERSISTENCE','REDIS_BACKUP'))
D(398,'INSUFFICIENT_CARDS','GSC-077 CUR:NB01 CUR:CMP-M11',[3], '600TB÷100Mbps约555.6天，A/B不可能在两周搬完；离线Snowball C符合避开窄链路的方向，D新10Gbps专线另有固定资源成本。', 'TLS/VPN能加密，不会解决100Mbps的数量级期限冲突。', '当前卡没有教Snowball设备所存数据在物理运输中的加密能力及相应现行资格，不能靠审查者记忆补这项硬条件而升级C。既有GSC-077只教离线比较，不是设备加密事实；也不据未安排物流单独确认源错。','card_premise_missing',('SNOW_CURRENT',))
savepart(1)
D(424,'CONDITIONAL','GSC-146 VC-007 CUR:XB019',[2], '前端24×7稳定使用适合匹配的预留折扣；B让只短时出现、数量变化的后端使用Spot，避免长期为峰值承诺。', 'C/D把需持续可用的前端全放Spot；A换Fargate需容器适配且不是现有EC2购买方式的直接最小调整。', '短命后端不自动等于可中断。原题未说后端任务能重试/恢复或丢失中间状态，只有在这一任务属性成立时B充分；不是要求额外保证全部生产SLA。','workload_interruptibility_condition')
D(435,'INSUFFICIENT_CARDS','GSC-060 GSC-061 GSC-077',[1], 'A的存储型离线设备与DMS后续CDC符合大库初始搬运、减少切换停机的方向；C的GPU设备没有所问优势，B的极大设备也不合20TB规模。', '20TB通过现成1Gbps链路理想约1.85天；但D要求新建专线，设备与链路两类方案的端到端成本不能由数据库大小单独推出。', '当前可见卡没有教离线初始数据库备份/导入怎样与DMS持续变更接续，也没有存储型/GPU型设备成本与当前订购资格。不能仅凭“Snowball”标签和记忆判A完整；不以未实测物流时长自动判原题错误。','card_premise_missing',('SNOW_CURRENT',))
D(451,'SUPPORTED','CUR:CC22 CUR:XB019 CUR:CMP-M11',[2,3,6], 'B是客户决定创建数据库及维护窗口；C是客户给工作负载安排监控、日志、软件补丁及适用侵入检测；F是在专线承载上实际实施加密。', 'A/E的RDS基础设施、OS与物理安全由AWS负责；D把全部数据库补丁安装都转给客户，不符合托管RDS职责。', 'C按实际ECS运行方式落实：EC2承载时客户维护宿主机，Fargate时AWS维护宿主机而客户仍管理镜像和应用采集。不能把ECS三个字读成AWS包办应用全部运维，也不把C扩大成有权登录Fargate宿主机。')
D(473,'SUPPORTED','CUR:CA13 CUR:XA055 CUR:CB10',[1], 'A把静态响应留在边缘，减少随访问量增长而发生的区域源站工作；CA13解释缓存命中机制，XA055解释需按实际边缘/回源路径算费用。', 'B的ALB不是把ElastiCache当静态文件HTTP源的连接；C的WAF检查请求而不缓存文件；D重复ALB并不复制静态内容或自动降低传出费。', '原题缺完整问句但保留了静态内容及费用忧虑，选项足以辨认边缘缓存方案。按真实流量套餐核账，不额外要求证明每一免费档下都省钱。')
D(485,'CONDITIONAL','VC-006 CUR:CMP-M01',[1], 'A的Flexible Retrieval Expedited是分钟级归档取回方向；Standard retrieval小时级，不能配五分钟。C/D即时读取，但存储单价路线不同。', '不能把“Glacier”一词当足够，也不能把通常1–5分钟硬解释成任意大对象、任意需求均五分钟。', '卡明示小于250MB及严格分钟需求应评估预置容量，原题只说旧视频没有给对象大小。A在支持的对象/预置取回条件下成立；当前不能以该通常窗口证明未界定大小的全部视频硬五分钟。C/D仍是即时层竞争者，需取回需求与费用信息。','hard_retrieval_window_condition',('GLACIER_WINDOW','S3_PRICING'))
D(490,'CONDITIONAL','GSC-043 CUR:NB04',[2], 'B启用连续PITR基础并以无RCU扫描的托管导出生成S3副本，编码量低、不会挤占线上读取。', 'A扫描型计算增加集群；C需维护Streams消费者和增量文件处理；D自行周期扫描/导出程序并非最少编码。', '连续的是DynamoDB的PITR备份，不是启用PITR后S3对象会连续自动同步。若题目要求S3桶本身连续追随每次更新，B未安排导出调度/增量窗口，不能直接升级；若是“连续PITR＋按时间点导出S3”，B充分。','backup_vs_export_continuity_condition',('DDB_EXPORT',))
D(493,'CONDITIONAL','CUR:CMP-M15 GSC-106 GSC-105',[4,5,6], 'D把录音转原语言文字，E把文字译成英语，F分析英语文本情绪；顺序和各服务作用由三卡直接组成。', 'A混淆Comprehend与翻译音频；C的Polly不是音频转写；B的Lex不是离线情绪报告工具。', '现有四种和未来语言须分别受到相应转写/翻译功能支持。选项的“any language”不能证明无限语言覆盖；当前不知具体语言，保留支持条件，不把服务链因正常语言支持核对一概当无解。','language_support_condition')
D(501,'SOURCE_ISSUE','CUR:CA17 CUR:XB004 CUR:NC01 CUR:NS01 CUR:CMP-M06 CUR:NA05',[1,4], 'A可由Kinesis事件源触发Lambda，分析后由函数写S3；D可由API Gateway接收数据调用Lambda，分析后写S3。二者均能每分钟接收付款并先分析后入湖。', 'Firehose负责缓冲交付，不是现行Flink输入流的自动替代；不能把未明示的流重放需求补进题干，借此只允许A，或把未明示的HTTP生产接口补入后只允许D。', '现行能力已支持两条托管链，但原题没有给入口协议、持久重放/消费者要求，无法据“most operational efficiency”唯一取舍。','decisive_input_missing',('LAMBDA_KINESIS','APIGW_LAMBDA'),S('decisive_input_missing','现有支付端已以HTTP POST提交每分钟记录，API Gateway→Lambda即完成分析再写S3；新增持久Kinesis不是明示需要。','支付端已有多消费者持久流且须重放，Kinesis→Lambda保留流读取路径；此时A比把入口改为仅HTTP函数更符合实际输入。两种现有入口都不违反题干。','优先改为选择全部可行的先分析后入湖路径（A/D至少有条件成立）；若保持单选，只补真正的入口/重放要求这一练习设定。'))
D(511,'SOURCE_ISSUE','CUR:CC22 CUR:XB027 GSC-052 GSC-057',[1,2,3], 'B是单AZ RDS PostgreSQL；A和C都写Aurora PostgreSQL而没有在A明确Serverless或暂停策略。不能把A自行补成Serverless、再按半天使用判其最便宜。', 'D的对象选择不能替代PostgreSQL schema。A的通称覆盖C的on-demand provisioned形态，原选项并未形成可判的独立数据库计费方案。', '这是原题候选定义缺必要计费/容量模式，而非需要证明市场全部数据库的绝对最低价。','decisive_input_missing',('AURORA_BILLING','AURORA_PAUSE'),S('decisive_input_missing','A部署为按小时计费的provisioned Aurora PostgreSQL，则它同C描述可以指同一配置，两选项重叠。','A部署为支持0 ACU暂停的Aurora Serverless PostgreSQL，半天无连接时可暂停；C的provisioned on-demand形态不具有这条降零机制。原文A没有区分这两种。','明确A究竟是哪种容量模式及空闲暂停条件；新增设定另存。不要仅把“Amazon Aurora”当作“Serverless”，也不要暗加未问的全市场最低价门槛。'))
D(512,'SUPPORTED','CUR:CC10 CUR:CC09 CUR:NS03',[1], 'A用Config发现实际未标记资源，程序化补标签，再用计划标签选择资源；比各账户人工盘点更自动，并让新旧资源进入统一备份选择机制。', 'B是否运行与是否需备份无关，vault也不是直接放资源的清单；C人工维护高；DInspector不负责此类标签配置合规与Backup资源选择。', '备份范围须按AWS Backup支持资源清单落实并在组织各账户启用授权；“all resources”是需要备份的基础设施集合，不据此声称任意AWS对象都能被Backup保护。标签整改与备份计划均实际配置，不能只标红。')
D(514,'SOURCE_ISSUE','CUR:XB025 CUR:CMP-M10 CUR:CMP-M06',[1,4], '私有Kubernetes端点已开启不说明节点失败原因。A的节点角色权限和D的节点出站网络都是真实的注册前提；B的EKS管理API端点不能代替Kubernetes API。', 'C违背数据平面必须私有子网；但A、D之间没有故障日志或已验证条件，不能仅凭私有端点选择一个。', '官方列举NodeCreationFailure同时包括权限与出站问题；可独立构造两种符合题面的失败。','decisive_input_missing',('EKS_FAILURE','EKS_NODE_IAM','EKS_SG'),S('decisive_input_missing','节点到私有控制面网络已通，节点IAM角色缺必需权限；A修复，单改D不会补权限。','节点IAM角色正确，节点SG把到私有API的TCP 443出站拒绝；D修复，重复授予A不会打开网络。两种均保持private=true/public=false与私有节点。','优先改为多选“哪些配置错误可能导致此失败”（A、D）；若维持单选，给出对应拒绝诊断，并注明它是新增练习设定。'))
D(515,'UNKNOWN','GSC-102 GSC-101 CUR:XB013 GSC-089 CUR:CMP-M20',[1,3], 'A的Data API可直接由GSC-102支撑；C的定时分析方向符合仓库用途。但第三个选项无法由当前卡组可靠裁定。', 'D是缓存用例，E把在线请求特征套到分析仓库；B的“client-side encryption”范围与F的“secondary replica”含义都没有精确定义。', '官方泛化加密页面仍描述client-side encryption，但COPY/UNLOAD的该功能已在2026-04-30结束；F可能指快照创建新集群，也可能声称受管持续副本。不能把较窄命令功能退役外推为一切客户端密文不可能，亦不能把快照新集群当live replica。技术/术语范围尚未闭合，原题不豁免。','technical_scope_unresolved',('REDSHIFT_ENCRYPTION','REDSHIFT_COPY_END','REDSHIFT_SNAPSHOT','REDSHIFT_SHARING'))
D(540,'SOURCE_ISSUE','CUR:CB01 CUR:CC22 GSC-046 GSC-060',[], 'C想用Oracle的Multi-AZ DB cluster reader，但官方该部署只支持MySQL/PostgreSQL。保留Oracle并托管HA/报表分流，应区分classic Multi-AZ standby与独立可读副本。', 'B的主库和读副本在同AZ不能实现所需故障域保护；D混淆Aurora集群和RDS Multi-AZ DB instance部署。A把一个DB instance描述为跨多个Region创建，不能等同官方的跨Region独立实例复制与接管方案。', '原选项在HA拓扑/数据库引擎和部署类型上存在明确冲突，不能因C看起来最托管就忽略Oracle硬条件。','explicit_technical_conflict',('RDS_MULTIAZ_ENGINES','AURORA_ENGINES'),S('explicit_technical_conflict','官方Multi-AZ DB cluster包含writer和两个可读reader，但只支持MySQL/PostgreSQL，Oracle列为不支持。','保留Oracle时经典Multi-AZ DB instance提供standby而非可读reader；原C/D所混用部署定义不能凭名称拼接成Oracle可读集群。','把C最小改为RDS for Oracle受支持的Multi-AZ DB instance，另建受支持读副本并将报表导向它；核对引擎许可/功能前提后独立验练习版。'))
D(565,'SOURCE_ISSUE','GSC-050 GSC-057 GSC-046 GSC-060 CUR:CC22',[1,3], 'A的自动扩展是存储容量；C的Aurora Auto Scaling扩的是reader数量。二者解决不同增长，题干只写transactional data、increased demand。', 'B/D改变关系模型/兼容性；但不能用“需求增长”四字证明必定是可分流读负载，也不能把Aurora Auto Scaling误称writer自动扩算力。', '官方已清楚两种伸缩维度；缺的是本题增长资源维度这一必要输入。','decisive_input_missing',('RDS_STORAGE_SCALING','AURORA_SCALING'),S('decisive_input_missing','交易数据持续新增使磁盘逼近上限，但CPU/读取保持低；A的MySQL存储自动扩展直接解决。','数据容量平稳而只读查询并发增长，应用可将只读连接发往Aurora readers；C的reader Auto Scaling解决。两种都符合“transactional database demand increases”。','新增“增长为可分流的读负载”或“增长为存储容量”这一必要练习设定；不能把C改成Serverless后冒称原题已有writer自动伸缩。'))
D(571,'SUPPORTED','CUR:CB13 CUR:NEW02',[1], 'A先由指定外部CA签发再导入ACM，绑定HTTP API自定义域名；CB13已明示现行HTTP API可以协商TLS1.3。', 'B由ACM申请证书不能代替指定外部CA签发；C/D的function URL证书绑定也不是题中要求的外部CA入口流程。', '确保实际HTTP API端点使用允许TLS1.3的安全策略及同Region证书。原文要求TLS1.3支持，没有写“拒绝所有较低TLS版本”，不能另加最低版本必须1.3的门槛。')
D(574,'SUPPORTED','CUR:XB027 CUR:CC22 GSC-057 GSC-052 VC-007',[1], 'A选择兼容MySQL、可按负载调整并在支持版本配置0 ACU空闲暂停的Serverless v2，使每周仅两小时使用不必持续付整周算力。', 'B的普通Aurora集群没有自动降零机制；C预留承诺仍按期支付；D改成自管数据库容器还需维护数据库平台，不能把容器等于自动暂停的托管库。', '选择支持自动暂停的MySQL版本、min=0及空闲间隔，安排无持续连接并核实恢复等待。它们是A的正常配置，不因题目没列ACU参数就确认无解，也不要求全市场所有规格成本穷尽。')
D(588,'SUPPORTED','CUR:NB04 GSC-067 GSC-068 GSC-070 CUR:NS03',[4], '24小时RPO/RTO允许采用备份恢复路线；D把周期快照复制到异区，灾难时恢复，不必平时维持跨区数据库计算。', 'A/B持续复制/副本维护增加常驻资源；C还需管理native备份导出及S3复制，D直接沿用受管快照恢复更简明。', '把复制完成时刻纳入24小时RPO并演练数据库/应用恢复，确保复制周期留出耗时。未做生产演练本身不是考试架构选择的缺卡，也不能把“每日发起复制”误记为目标端必然正好24小时。')
D(622,'SUPPORTED','CUR:CA13 CUR:CA16 CUR:XB013 GSC-038',[1,4], 'D用S3/CloudFront交付静态单页，避免维护Web实例容量；A的DynamoDB灵活项目属性和on-demand容量适合用户数量变化大的在线记录访问。', 'B保留关系schema且不能仅凭Serverless消除模型差异；C要管理预置容量和伸缩范围，相比A多一层预估；E自管静态Web实例不如对象与边缘直接交付。', '按需模式仍需常规预热/配额和增长检查；不把“most scalability”解释成无限瞬时吞吐或在全部可能工作负载上逐美元最便宜。')
D(659,'SOURCE_ISSUE','GSC-077 CUR:NC07 CUR:NB01',[1,3], '50TB两周要求迁移净带宽约331Mbps。90%占用只给比例，现行VPN存在1.25Gbps和5Gbps两种隧道带宽，剩余绝对量可能分处门槛两侧。', '不能只凭“90%”自动排除DataSync；也不能用DataSync端点提高实际链路带宽。新专线不解决当前带宽数字缺失；Snowball还须既有资格。', '这里的欠定来自给定期限与缺失的绝对可用带宽，已可正面构造不同可行性；并非因没做部署测速而误判源错。','decisive_input_missing',('VPN_THROUGHPUT','SNOW_CURRENT'),S('decisive_input_missing','VPN为5Gbps配置，90%占用后约500Mbps可用于DataSync；50TB理想约9.26天，小于两周，A在线路线可行。','VPN为1.25Gbps配置，90%占用后约125Mbps；理想约37.0天，A不能满足，须选择符合资格且交付可安排的C等离线路线。两种均满足原文90%占用。','补“实际可供迁移带宽”的数值及设备资格作为新增练习设定；不要只补利用率，也不要把仅新客关闭写成全面退役。'))
D(673,'SUPPORTED','GSC-012 CUR:CMP-M01 VC-006',[2], 'B用S3 File Gateway保留本地SMB路径和热点缓存，七天后Lifecycle转Deep Archive；需要旧数据时选Standard取回，通常12小时，符合24小时架构窗口。', 'C的FSx后端不是S3，不能给它套S3 Lifecycle；D把文件用户改成直接对象访问；A只说复制没有提供整个容量/生命周期接口设计。', '安排归档对象的恢复流程，选Standard而非通常48小时的Bulk，并纳入实际取回/下载时间。这里验证题中24小时级方案，不把未提供每一对象的生产SLA测试当作必须新增卡。')
savepart(2)
D(687,'CONDITIONAL','GSC-109 CUR:XB012 CUR:CMP-M06',[4,5], 'E用专用托管预测服务处理S3历史时序，D的函数URL提供调用入口；相比自行SageMaker训练部署，符合缺ML建模维护资源的方向。', 'A/B仍要负责自行模型训练部署；C只增加SageMaker入口不能替代模型建设；D要在已有训练模型后实际取得forecast结果。', 'Forecast只面向符合既有资格的客户；具体时序与API工作流须受支持。原题没有说明客户资格，故当前不能无条件让新客户选择D/E；不是全面退役。','service_eligibility',('FORECAST_CURRENT',))
D(693,'CONDITIONAL','CUR:CB03 CUR:XB013 GSC-037 GSC-060',[4], 'D跨三个AZ部署应用，数据库改为支持最终一致读取的托管DynamoDB，减少自管复制；ALB没必要换NLB。', 'A/B没有修复应用单AZ；C仍需维护嵌入式数据库复制，运维较多。', 'DMS须实际支持原嵌入式NoSQL引擎及迁移路径；“NoSQL”不是一个通用DMS源协议。若引擎不支持，D的迁移机制不能照用；原题没提供引擎，不靠审查者默认它就是MongoDB。','migration_source_support_condition')
D(728,'INSUFFICIENT_CARDS','GSC-010 CUR:CMP-M01',[2], 'B让主数据在云端、仅热点留本地，能缓解本地容量并避免每次热点读取走云端；C/D仍要求全量本地容量，A归档取回不是无等待路线。', 'GSC-010足以解释cached与stored数据位置差异，但缓存未命中仍需云端读回；不能把缓存等同全数据本地或免费网络。', '卡未教cached Volume Gateway的即时块读取及具体“无额外取回费”口径。原题的“no additional cost”是指归档取回费还是还包括数据传出，尚未被当前卡面解释；保留卡组缺口，不宣称源错或用记忆补价格。','card_premise_missing')
D(733,'SUPPORTED','CUR:CC02 CUR:CC17 CUR:XB011',[2], 'B的RDS Protection直接分析受支持Aurora PostgreSQL登录的成功、失败和未完成模式，检测异常；组织成员账户按范围统一启用，比自行集中日志再写检测更省维护。', 'A的SCP只设权限上限不分析数据库登录；C仅存日志；D把数据库内部登录混为CloudTrail管理API事件，均未形成题中检测机制。', 'GuardDuty产生发现后配置相应响应控制以阻断风险，CC17/XB011已教由事件路由到执行动作的函数。不能声称启用GuardDuty本身就阻断登录；实际响应权限和目标是实施配置，不是另加未问的完整SOC生产验证。')
D(735,'SUPPORTED','CUR:XB004 CUR:XB013 GSC-093 GSC-094',[1], 'A用受管Kinesis吸收流式突增，Lambda按流消费处理，结果写DynamoDB；有序业务键用一致partition key并按shard顺序消费。若要求整个输入域全序，则该域不能散在多shard后再假称已有全局顺序。', 'B引入EC2维护且Redshift侧重分析；C普通SNS无所需序列及持久数据库高可用；D自管消费者比Lambda路径维护更多，普通队列也不自动给定顺序。', '设置所需顺序域、生产并发和分片消费规则，并核吞吐。题目没有给超过单顺序域容量的数值，不能因未做峰值实测就宣布A不可能；也不把多shard常规伸缩误称全局有序。')
D(756,'CONDITIONAL','CUR:XR001 CUR:NA05',[1], 'A在请求当时对原始对象脱敏后返回，能抽到最新文件，又不必反复维护整套去PII副本；符合少维护的动态视图用途。', '第二ordinal的批处理可能滞后最新记录；第三ordinal自管Web服务；D把文件内容转另一数据模型并维护复制流。原题两个B标签按ordinal保留，不混为一项。', '现行Object Lambda资格未给，须核实既有使用资格；脱敏函数、外部方只准访问处理后入口及最新对象可见性属于实施。不能把全部题目客户默认成旧合格客户。','service_eligibility',('OBJECT_LAMBDA_CURRENT',))
D(763,'CONDITIONAL','GSC-077 GSC-023',[2], '150TB即使100Mbps昼夜不断也约138.9天，只在夜间更长；C/D没有突破出口硬上限。B用多台适用离线设备搬运，A的超大车载规模不合这里的一次150TB。', '加速改善长距离路径，不能把100Mbps上传口变为超过一个月所需约463Mbps的有效链路。', 'B须确认现行订购资格、每台可用容量和一月内交付导入安排。既有资格设备能力不能一概按全面退役抹去；未安排物流实测本身不额外制造题源错误。','service_eligibility',('SNOW_CURRENT',))
D(764,'SOURCE_ISSUE','CUR:CB04 CUR:CC22 CUR:NB04',[1,3], 'A/C均把应用与MySQL保留在EC2＋托管RDS MySQL，并可按RDS备份机制PITR；区别只是Web实例子网。原题没有规定访客网络范围或Web实例必须有公网地址。', 'B/D改为Aurora虽兼容MySQL方向，但比保留RDS MySQL需额外核兼容；D还把应用/数据库公开，题中没有这种必要性。不能把“web”自动推为实例必须公网。', 'A的私有Web可由现有VPN或公网ALB访问；C的公有子网Web同样可被适当入口访问。两种都保留三层并提供MySQL PITR，原文没区分它们的运维目标。','decisive_input_missing',('ALB_PRIVATE_TARGETS','RDS_PITR'),S('multiple_valid_options','保留三层应用，将Web/App均置私网，沿已存在的私有访问入口或ALB到私有Web；A可达且RDS MySQL支持PITR。','保留三层应用，将Web置公有子网且用适当入口/安全组，App/DB私有；C可达且同样RDS MySQL PITR。原文未限制入口或Web公网地址。','优先改为选择可行迁移方案（A/C）；若单选，补真正的现有入口/实例地址约束作为新增练习设定，不能只把Web层改叫互联网而仍假设必须给实例公网。'))
D(778,'CONDITIONAL','GSC-077 CUR:NB01',[2], '每处1PB通过2Gbps理想也约46.3天，1Gbps约92.6天，超过四周；D仍走原出口，B把每个分散站点的数据分批装适用设备并行运往S3。', 'A每个办公室新建10Gbps专线有大量一次性网络资源；C单辆超大设备不等于能在80个全球分散地点同时完成搬运。', 'B仍须已有设备资格及各地设备/导入窗口可安排，卡没有给该公司资格。四周内具体复制运输是实施验证，不据此追加必须证明每个站点生产物流SLA的门槛。','service_eligibility',('SNOW_CURRENT',))
D(786,'CONDITIONAL','GSC-066',[2], 'B先设置Migration Hub home Region，再由Application Discovery Service取得本地服务器配置、利用率及依赖，是卡面所教的迁移评估数据。', 'SCT/DMS负责数据库结构和记录迁移；Trusted Advisor不是机房服务器发现采集器；A的通用SSM没有给出此迁移发现能力。', '现行Discovery Service资格与采集方式须支持本地平台；已退役的是特定Discovery Connector，不把它外推为所有既有Discovery能力全面结束。','service_eligibility',('ADS_CURRENT',))
D(806,'SOURCE_ISSUE','GSC-012 GSC-002 GCL-018',[2,3,4], 'B保留NFS入口而把数据作为S3对象保存并缓存热点；C/D保留真正EFS文件系统并可生命周期分层。原题没有交代应用所需NFS文件锁/更新语义及故障域，不能用NFS三个字锁定任一种。', 'A是块卷入口，不能直接替代NFS；B与EFS之间的文件锁语义差异是真正的迁移兼容性，非普通权限配置。', '官方明确S3 File Gateway NFS应以nolock挂载，而EFS支持NFSv4文件锁；两种现存NFS应用都符合题面，却有不同可行方案。这里只确认必要输入缺失，不声称计算出全市场最低价。','decisive_input_missing',('FGW_NOLOCK','EFS_LOCKS'),S('decisive_input_missing','采集程序只追加独立文件，处理者读完整文件，无跨客户端文件锁；S3 File Gateway的NFS与对象存储路线B可行。','多处理者依赖NFSv4字节区间锁协调同一文件更新，仍符合收集/处理数据的本地NFS描述；关闭锁的B不能保持该语义，EFS C/D有相应文件锁能力。','先补是否依赖NFS文件锁/共享更新的必要练习设定；如比较C/D再补需否承受AZ故障。不添加任意产品偏好来强制B。'))
D(827,'SOURCE_ISSUE','GSC-059',[1,4], 'B/C不是Aurora集群存储配置。真正比较A/D时，I/O-Optimized免单独读写I/O请求费但其他单价不同，单凭应用traffic大不能确定总成本。', 'GSC-059直接要求用I/O占比判断；计算/缓存命中型流量和存储I/O密集型流量都可能很大。', '官方以I/O费用占比25%为可比阈值，已能正面给两种相反选择，无须穷尽所有实例或Region。','decisive_input_missing',('AURORA_IO',),S('decisive_input_missing','Serverless v2承受大量请求但数据大多缓存命中，存储I/O仅占Aurora总费10%；官方建议Standard，A符合成本取舍。','请求量同样很大，但读写密集导致I/O占Aurora总费40%；官方建议I/O-Optimized，D符合成本取舍。两种均符合原文large traffic/increased load。','补I/O占总Aurora费用的必要输入，例如超过25%，作为新增练习设定；保留现有容量模式和性能目标，不把“大流量”改写成已测I/O密集。'))
D(841,'SOURCE_ISSUE','GSC-018',[2,3], 'A不能直接把EBS原生快照作为普通对象按S3 Deep Archive处理；D也未保留原生恢复点语义。B归档变成全量，C标准层保留增量共享，5%日变化不足以唯一确定哪种更便宜。', '每天相同5%块反复改，与每天更换不同5%块，在月末快照间形成的共享比例不同；不能把日变化率直接当月快照增量率。', '以官方Archive $0.0125/GB月、Standard $0.05/GB月和完整/增量机制给出两种账量反例；不忽略350TB、日5%、七年这几个硬参数。','decisive_input_missing',('EBS_ARCHIVE','EBS_TARIFFS'),S('decisive_input_missing','350TB都已写满，每天反复改同一17.5TB（5%），其余332.5TB不变。84个月末标准点可共享332.5TB，加84×17.5TB版本约1802.5TB；归档84×350TB=29400TB，按四分之一单价仍相当7350TB标准量，C更省。','350TB已写满，每天轮转更新不重叠17.5TB，20天改遍全库；月末点之间几乎不共享旧块。标准约84×350TB，归档同样全量但单位价四分之一，B更省。两种均每日5%变化并保留同样月点。','补月末恢复点之间的独立已变更块比例/共享情况，或把单选改为“需比较B/C，哪些信息决定成本”。反例计算只比较存储主项，双方相同最近一月日快照保留不能扭转该数量级。'))
D(851,'UNKNOWN','CUR:XA020 CUR:XB027 CUR:CC22',[2,3], 'B明确Service Catalog限制配置，C明确共享Serverless集群但写default capacity。卡证明目录约束与min=0暂停是两项不同配置，不能把默认Serverless当自动停费。', 'A按统一日程启停不匹配全球开发者实际需要；D事后删除空闲数据库也不提供安全自助和保留数据的完整路径。B与C如何落实每人限额和空闲计费仍未确定。', '当前官方文档允许不同引擎版本/默认容量范围；C未明确所用默认值、版本与大小约束。尚未形成两个经费用/配置正证的具体可比方案来确认题源错误；保留UNKNOWN，既不暗改C的default为0，也不强加每个逻辑库必须独占物理集群。','capacity_defaults_scope_unresolved',('AURORA_CREATE','AURORA_PAUSE'))
D(919,'CONDITIONAL','GSC-016 GSC-015',[1], 'A的多卷条带化可以突破单卷能力，前提是实例到EBS路径还有余量。扩大同一io1卷的GiB本身不是消除单卷IOPS上限，B超过io1允许的最大值也非可用配置。', 'D的storage-optimized名称不能自动让现有同一io1卷更多IOPS；若真正瓶颈在实例EBS路径，则应先解决实例能力，不能由卷配置猜诊断。', '原题没有给实例具体EBS能力/当前瓶颈；A只可在单卷而非实例路径受限时选。这里保留性能前提，不因没跑生产基准就把所有选项都判不可行，也未确认源错。','bottleneck_condition')
D(930,'CONDITIONAL','GSC-029 GSC-133 GSC-146 CUR:CB03 CUR:CA16',[1], 'A给持续Web保留On-Demand跨实例容量，文档到达后才运行函数；B把关键门户放Spot，D需要把动态Web重写成静态前端/API，C将间歇任务与长期承诺池绑定。', 'Lambda短时按请求执行很适合间歇提取，但不等于任何现成提取程序无改动就能运行在标准Linux函数环境。', 'A要求现有extractor已能以支持的运行时/入口打包调用且工作符合限制，否则“no code changes”未证明。100% uptime按题中高可用选型目标处理，不另要求任何云架构给出绝对无故障生产SLA。','existing_program_runtime_condition',('LAMBDA_LIMITS',))
D(940,'SUPPORTED','GSC-054 CUR:CB02 VC-007',[4], '对题中给定的长期稳定匹配用量，D的RDS三年全预付与EC2 Instance Savings Plan三年全预付以更长承诺/更多预付换取所列最深折扣；RDS另用其预留，不套Compute SP。', 'A的RDS仍On-Demand；B/C是一年且预付较少，保留更多灵活性但不是所列最高承诺折扣。', '核对未来稳定利用率、可承担预付及购买属性。原文没有写预算上限或短期退出，不为普通“most cost effective”另加所有期限/风险情境的全市场最低价证明。')
D(943,'SUPPORTED','GSC-153 GSC-154 GSC-089 CUR:XB011',[3], 'C以应用标签标识归属，激活成本分配标签后用现成Cost Explorer按应用分析，并可按计划生成/投递定期报告。', 'D没激活标签且人工账单处理；B自建RDS查询管道更重；A预算不是完成应用维度历史分析的首选工具。', '配置实际报表计划/适用API授权。题干“过去三个月迁入”不等于必须无条件复原未曾打标的三个月全部费用；若另外要求追溯，则按GSC-154核历史标签及回填支持，不虚报已复原。')
D(949,'UNKNOWN','CUR:CMP-M04',[4], 'D完整表达PrivateLink消费者端点到供应商已发布服务的私有连接，正常供应商配合和端点授权属于实施，不据“hosted on AWS”自行认为它已发布。', 'A/B也需要供应商网络配合且扩大网络连接范围；C的原文在“establish.”处截断，未保留完整谓语对象，无法判断其与D是否同义。', '实际阻碍唯一选择的是完整选项C的语义缺失，以及供应商endpoint service可发布这一真实前提；目前未确认它是原题印刷问题还是文本损伤。保留UNKNOWN并建议恢复C原文，不编造一个错的C。','question_text_unresolved')
D(950,'SUPPORTED','CUR:CMP-M11 CUR:CMP-M10 CUR:CB15',[3], 'C用Site-to-Site VPN实现网络层IPsec加密，正确路由使机房可达VPC，SG/NACL按实际源和端口收窄访问；会话层仍按CMP-M11给实际应用连接启用TLS。', 'A的专线不自动提供IPsec且路由表不是任意Allow/Deny防火墙；B只限控制台身份；D的TGW是路由枢纽，未给加密机房连接。', '在所需会话上配置TLS并验证对端；VPN不会自动给应用开TLS。C是网络与访问控制架构选择，TLS属于可见卡已教的分层实施要求，不据省略证书配置就宣称无解。')
savepart(3)
D(953,'SUPPORTED','CUR:CMP-M01 VC-006 GSC-024',[1], 'A把半年才用来训练的原始上传图片放长期Deep Archive，训练可预先恢复；生成图中premium需随时下载，应保持即时访问，non-premium也不应整体塞进需恢复的归档层。', 'B/D把premium生成图也放Flexible Retrieval，不能提供任意时点即时下载；C对半年低频原图使用One Zone-IA，放弃长期归档的费用方向并减少故障域保护。', '先完成生成图所需原始输入处理再归档；训练预取选合适恢复档，核实际对象大小/取回费用。6小时是非premium下载频次权限，并非其请求可以等待6小时；不把该频次直接解释为归档恢复容忍。')
D(954,'SUPPORTED','GSC-079 GSC-114 GSC-137 GSC-136',[4], 'D以持久SQS吸收异步单个/批量请求，模型消费者ECS按队列工作量增加任务，并由底层容量伸缩提供可运行资源，适合长闲置与大批请求交替。', 'B的ALB流量伸缩没有对应持久异步积压机制；C把CPU资源随队列自动增加写成Lambda原生操作，实际CPU随内存配置而变；A也没有给异步缓冲和正确函数调用伸缩机制。', '将“number of services”按ECS Service Auto Scaling的实际任务副本数实施，而非动态创建服务定义；按每任务积压/处理时长设目标，模型数据容量与任务资源按配置核定。这是既有服务正常配置。')
D(956,'SUPPORTED','GSC-146 CUR:CMP-M01 GSC-024',[4], '作业不能承受Spot回收，D用On-Demand；数据前30天仍被访问，先Standard，之后按长期仅保留的阶段转Deep Archive并两年到期，符合分段访问规则。', 'A/C直接违反不可中断条件；B从首日放极少读/长保留的GIR，还在30天提前迁出，须承担其最短保留及访问费用，不能只看较低GiB单价。', '安排Lifecycle日期、适用对象条件和恢复需求；不把低层存储价格当总成本，也不要求穷尽题外所有规格/免费档。',evs=('GLACIER_CLASSES','S3_PRICING'))
D(969,'CONDITIONAL','GCL-032 CUR:XB019 GSC-137 GSC-143',[1], 'A用App2Container生成容器/工件，再由ECS/Fargate运行并按CloudWatch业务指标扩任务，减少主机维护；B仍需管理EC2，C/D混淆App Runner和向ECS/EKS生成部署。', '现行官方已明确App2Container支持Linux上的ASP.NET及相应.NET运行时，不能再因“ASP.NET on Linux”直接判题错。', '仍须既有服务资格，且原程序在支持的.NET/runtime/distribution内；容器化不自动完成任意代码版本现代化。只有资格/支持范围条件未给，故保留CONDITIONAL，而非全面退役或Linux能力冲突。','service_eligibility_and_runtime',('A2C_CURRENT',))
D(977,'SUPPORTED','CUR:CC08 CUR:CB13 CUR:CMP-M11',[1], 'A选受管KMS静态加密和TLS证书/连接保护，而非自行做每个字段的第三方加密或搭建隧道。数据库客户端必须真正启用并验证RDS原生TLS；ACM绑定实际支持的应用TLS入口。', 'B/D把IPsec/VPN当所有应用连接TLS的替代且增加网络维护；C把静态保护改为客户自行应用加密。A中的ACM不应误实施为把ACM证书安装到受管RDS端点。', '应用HTTPS入口按其支持方式使用ACM；EC2→RDS使用RDS提供CA的客户端TLS。原文没有说“RDS端点只能使用ACM证书”，不能额外加入这一不支持的操作后确认原题无解；按实际连接边界配置是正常实施。')
D(998,'CONDITIONAL','CUR:CMP-M02 CUR:CMP-M04 CUR:XB042',[1], 'A通过同Region gateway endpoint及路由把S3流量送VPC端点路径，不走IGW/NAT；桶不搬进VPC，访问点也不是自己建立网络私有连接。', 'B不成立，C仅权限命名入口，D不是VPC到区域S3所需的专线连接方案。', '若“not use public endpoint”指不走公共互联网路径，A由卡完整解释；gateway仍解析S3公有地址。若明确要求目标必须为私有IP/DNS入口，则需要interface endpoint而选项没有它。原文未区分网络路径与地址口径，保留语义条件，不把公有IP必经互联网混为一谈。','public_endpoint_semantics',('S3_GATEWAY',))
D(1002,'SOURCE_ISSUE','GSC-039 GSC-038',[1,4], 'A/D均可使用global tables管理多Region复制；差别是on-demand与provisioned＋Auto Scaling。全球增长与高可用目标不自动决定哪个容量模式总费最低。', 'B/C要求客户自己维护跨Region复制；DAX不替代复制。真正不能消去的A/D差异是负载利用率与可预测性，非是否使用global tables。', '官方成本模式规则已给出具体利用率/负载特征，能构造原文允许的两个相反成本选择。','decisive_input_missing',('DDB_MODES','DDB_PRICING'),S('decisive_input_missing','玩家请求高度不规律，预置容量平均利用率低于35%，大部分时间空闲但偶有峰；官方指出此类on-demand更省，A合理。','同样用户增长但请求基线持续稳定、可预估且预置容量接近实际消耗；可用provisioned Auto Scaling减少单位请求成本，D合理。二者均可配同样global tables实现多Region可用。','只补可预测性/稳定利用率这一必要练习输入，或改成多选有效的托管global tables方案（A/D）而不问没有输入的唯一最便宜。'))
D(1004,'SOURCE_ISSUE','CUR:CA13 CUR:NS02 GSC-130 GSC-073',[2,3], 'B的CloudFront可就近承接HTTP连接并缓存可复用响应；C的Global Accelerator在AWS网络转送TCP/UDP到区域API。题目没有交代API响应能否共享缓存、鉴权或变体键。', 'A的public VIF与Direct Connect gateway组合不是给每客户现成访问EC2 API的低维护入口；D不是专用物理网络，也需每客户建立连接。B/C之间不能以“API都是动态不可缓存”或“API都可公用缓存”来猜。', 'CachingOptimized的实际缓存键不含任意鉴权/查询变体且正最小TTL可能覆盖private/no-store；可构造B正确与错误两种现有API。','decisive_input_missing',('CF_CACHE_OPTIMIZED','CF_PERSISTENT','GA_PERFORMANCE'),S('decisive_input_missing','公共GET API只返回按URL确定的可共享价格目录，允许至少一秒缓存；CachingOptimized可安全复用，B改善边缘响应。','同一路径的ERP GET响应随Authorization或查询客户ID变化且禁止共享；原B的CachingOptimized不按该身份/查询区分，可能串数据，不能满足正确API行为；C转发不引入该共享缓存错误。二者均是题中客户信息交换API。','优先改为选择可改善路径的方案并分别写清适用缓存条件；若保持单选C，只新增“认证、不可共享缓存”的必要API语义作为练习设定，不添加无关产品偏好。'))
D(1009,'SOURCE_ISSUE','CUR:aws-rb2-domain1-normal-batch07-20261105-s3-bucket-key-request-cost CUR:CC05',[1,2], '卡面明确Bucket Key减少而不消除KMS调用。原题只说现在使用KMS、严格加密，没有明示今后必须保留KMS，同时“without additional calls”可能指零新增或零总调用。', 'C仍调用KMS，D也要从KMS取得客户钥并由客户传给S3；A的SSE-S3满足静态加密且不要求KMS请求，B则保留SSE-KMS并减少请求。不能暗加“必须继续KMS”后强选B并说不再调用KMS。', 'AWS对SSE-S3默认加密和Bucket Key保留短时KMS调用均有正证；缺的是密钥治理约束/调用口径，不是未找到服务能力。','decisive_input_missing',('S3_DEFAULT','BUCKET_KEYS'),S('decisive_input_missing','安全政策只要求S3数据以受管密钥静态加密，允许SSE-S3；现用KMS是可更换实现，A可消除之后对象访问所需KMS请求。','安全政策要求保留SSE-KMS密钥治理，且目标是减少逐对象请求而非绝对零调用；B符合，A违反密钥治理。两种政策都可能被原文“strict encryption requirements/currently uses KMS”描述，但原文没有区分。','若要B，明确新增“必须继续SSE-KMS，并减少而非消除KMS请求”练习设定；若要求零KMS调用且允许SSE-S3，A是另一题。不得倒写成原意已知。'))
savepart(4)
# Final self-check corrects two provisional classifications before issuing this review.
adjustments=[]
for x in R:
 if x['qid']==540:
  adjustments.append({'qid':540,'provisionalStatus':x['status'],'finalStatus':'UNKNOWN','reason':'C的Oracle支持冲突已证实，但A/D存在可作合理迁移/部署简写的解释，不能据严格字面声称所有选项都无效。'})
  x.update(status='UNKNOWN',selectedOptionOrdinals=[],sourceConfirmation=None,choiceReasoning='C的Oracle Multi-AZ DB cluster reader能力冲突已确认；B同AZ不实现跨AZ保护。但A可能被合理读成在多个Region建立独立RDS实例并由DMS复制，D也可能被读成Aurora多AZ集群的非规范简称。',keyCompetitionReasoning='不能把C看似最托管当作正确，也不能仅凭A/D的部署简写就独立确认整题无有效方案。需要确认A的目标实例/复制与D的Oracle兼容迁移含义，比较题中高可用与运维目标。',remainingConditions=[{'kind':'option_architecture_semantics_unresolved','description':'已核C的引擎冲突，不等于已核整题错误；A/D的合理架构解释尚未闭合，故UNKNOWN不进入源纠错豁免。','blocksOriginalSupport':True}])
 if x['qid']==956:
  adjustments.append({'qid':956,'provisionalStatus':x['status'],'finalStatus':'INSUFFICIENT_CARDS','reason':'B与D的成本取舍需要GIR最短计费/取回费用的具体适用知识，现有卡只有一般比较提醒。'})
  x.update(status='INSUFFICIENT_CARDS',remainingConditions=[{'kind':'card_premise_missing','description':'D是合理常规方案，A/C可由不可中断排除；但当前卡没明确GIR的90天最短保留计费及本题30天迁出时的成本，不能单凭“访问30天”推成高频或靠官方摘录代替学习者可见卡。B/D唯一最低成本仍缺可见必要费用前提。','blocksOriginalSupport':True}])
(O/'pre-final-adjudication-adjustments.json').write_text(json.dumps(adjustments,ensure_ascii=False,indent=2))
# Official excerpts bind only the source/condition issues actually used; they do not substitute for visible cards.
evidence('GWLB','@gwlb',['The Gateway Load Balancer and its registered virtual appliance instances exchange application traffic using the'])
evidence('REDSHIFT_LOAD','@redshift-load',['COPY'])
evidence('ASG','asg-multi-az.snapshot.json',['Auto Scaling'])
evidence('FIREHOSE','cache-ade454782c20103fc85a.json',['Amazon S3'])
evidence('FSX_GATEWAY','@fsx-gateway',['Amazon FSx File Gateway is no longer available to new customers.'])
evidence('MQ_RABBIT','@mq-rabbit',['three RabbitMQ broker nodes'])
evidence('SNOW_CURRENT','cache-dcf0b0f8db13fb6cbebe.json',['Effective November 7, 2025, AWS Snowball Edge devices will only be available to existing customers.'])
evidence('DMS_BIDIR','@dms-bidirectional',["AWS DMS bidirectional replication isn't intended as a full multi-master solution", "DMS bidirectional replication doesn't include conflict detection"])
evidence('LAMBDA_LIMITS','lambda-current-runtime.snapshot.json',['900 seconds'])
evidence('LAMBDA_EPHEMERAL','cache-3af84a09611cfff6a5fb.json',['10,240'])
evidence('OBJECT_LAMBDA_CURRENT','@object-lambda',['S3 Object Lambda is available only to existing customers'])
evidence('AURORA_ENGINES','@aurora-engines',["compatible with"])
evidence('RDS_RI','rds-ri-payments.json',['largest discount','All Reserved Instance types'])
evidence('AURORA_PROC','aurora-procedures-transaction-statements.snapshot.json',['COMMIT','MySQL usage'])
evidence('AURORA_UDF','aurora-functions-no-transactions.snapshot.json',['Aurora MySQL doesn’t permit stored functions to contain explicit SQL transaction statements'])
evidence('AURORA_SCHEDULE','aurora-scheduled-procedures.snapshot.json',['schedule statements or stored procedures'])
evidence('S3_TIER','@s3-tier',['128 KB','monitoring'])
evidence('S3_PRICING','@s3-tier-cost',['S3 Standard-IA and S3 One Zone-IA storage have a minimum billable object size of 128 KB.','minimum storage duration'])
evidence('REDIS_PERSISTENCE','redis-persistence-with-loss-boundary.snapshot.json',['Redis supports persistence, including backup and recovery.'])
evidence('REDIS_BACKUP','redis-backup.snapshot.json',['snapshot'])
evidence('GLACIER_WINDOW','da2fee77e2fad08a2b8c.json',['250'])
evidence('DDB_EXPORT','@ddb-export',["asynchronous, they don't consume",'continuous backups'])
evidence('LAMBDA_KINESIS','@lambda-kinesis',['Kinesis','event source mapping'])
evidence('APIGW_LAMBDA','@apigw-lambda',['Lambda'])
evidence('AURORA_BILLING','aurora-capacity-billing-modes.snapshot.json',['Aurora serverless provides','On-Demand instances'])
evidence('AURORA_PAUSE','aurora-auto-pause.snapshot.json',['minimum capacity of 0 ACUs','automatically pause'])
evidence('EKS_FAILURE','eks-node-creation-two-positive-causes.snapshot.json',['Common causes of this failure are insufficient node IAM role permissions or lack of outbound internet access'])
evidence('EKS_NODE_IAM','eks-node-iam.snapshot.json',['Before you can launch nodes and register them into a cluster'])
evidence('EKS_SG','eks-required-sg.snapshot.json',['443'])
evidence('REDSHIFT_ENCRYPTION','redshift-general-client-server-encryption.snapshot.json',['Use client-side encryption'])
evidence('REDSHIFT_COPY_END','redshift-cse-ended.snapshot.json',["After April 30, 2026, you won't be able to"])
evidence('REDSHIFT_SNAPSHOT','redshift-snapshot-new-cluster.snapshot.json',['new cluster'])
evidence('REDSHIFT_SHARING','redshift-live-sharing-no-copy.snapshot.json',['without'])
evidence('RDS_MULTIAZ_ENGINES','@rds-multiaz-engines',['Multi-AZ DB clusters are supported only for the MySQL and PostgreSQL DB engines.'])
evidence('RDS_STORAGE_SCALING','@rds-storage-scaling',['when Amazon RDS detects that you are running out of free'])
evidence('AURORA_SCALING','@aurora-scaling',['dynamically adjusts the number of Aurora Replicas'])
evidence('VPN_THROUGHPUT','@vpn-throughput',['Maximum bandwidth per standard VPN tunnel','Maximum bandwidth per large bandwidth VPN tunnel'])
evidence('FORECAST_CURRENT','@forecast-current',['Amazon Forecast is no longer available to new customers.'])
evidence('ALB_PRIVATE_TARGETS','alb-target-private.json',['RFC 1918'])
evidence('RDS_PITR','4dc57ecb408b5cae9acafb625c2a88860dd189dd0ee740078ce3d3831d466e55.json',['point-in-time recovery'])
evidence('ADS_CURRENT','@ads-current',['AWS Application Discovery Service is no longer open to new customers.'])
evidence('FGW_NOLOCK','@fgw-nolock',['Always use the','nolock'])
evidence('EFS_LOCKS','@efs-locks',['NFS client applications can use NFS version 4 file locking'])
evidence('AURORA_IO','17df4f8a33b97da13a61.json',['I/O spending is 25% or more','I/O spending is less than 25%'])
evidence('EBS_ARCHIVE','ebs-guidelines.json',['When you archive an incremental snapshot, the snapshot is converted to a full snapshot'])
evidence('EBS_TARIFFS','ebs-tariffs.json',['$0.0125 per GB-month','$0.05 per GB-month'])
evidence('AURORA_CREATE','aurora-create.json',['accept the default range','Choosing a minimum capacity of 0 ACUs'])
evidence('GLACIER_CLASSES','cache-db688c4edb0b275b70c6.json',['90 days'])
evidence('A2C_CURRENT','a2c-support.json',['ASP.NET applications (Windows, Linux)','For ASP.NET applications running on Linux','no longer open to new customers'])
evidence('S3_GATEWAY','s3-endpoint.json',['resolve to the Amazon S3 public IP addresses','without requiring an internet gateway or NAT device'])
evidence('DDB_MODES','dynamodb-modes.json',['below 35%','Steady, predictable and cyclical traffic'])
evidence('DDB_PRICING','dynamodb-prices.json',['predictable throughput patterns','pay-per-request'])
evidence('CF_CACHE_OPTIMIZED','cache-optimized.json',["CloudFront doesn't include any query strings or cookies in",'658327ea-f89d-4fab-a63d-7e88639e58f6'])
evidence('CF_PERSISTENT','cloudfront-dynamic.json',['persistent connections','Dynamic requests'])
evidence('GA_PERFORMANCE','global-accelerator-performance.snapshot.json',['AWS global network'])
evidence('S3_DEFAULT','s3-default-new-uploads.snapshot.json',['SSE-S3','no additional cost'])
evidence('BUCKET_KEYS','@bucket-keys',['reduce AWS KMS request costs by up to 99','short-lived bucket-level key from AWS KMS'])
# Apply the independently read clarification to two concrete capability/ownership ambiguities.
for x in R:
 if x['qid']==19:
  x['status']='SOURCE_ISSUE';x['remainingConditions'][0]['kind']='decisive_input_missing';x['remainingConditions'][0]['description']='GWLB协议能力本身已由官方查明，未知的是原设备是否具有它。仅“可接收IP包”不能区分下述两个真实协议情境；据新说明确认缺决定性输入，不要求知道原作者想的是哪一种。'
  x['sourceConfirmation']=S('decisive_input_missing','Marketplace设备具备GWLB集成，能接收UDP6081 GENEVE并解封装原IP包，D成为可行透明检查路径。','设备仅接受普通IP转发/检查流量，不具备GENEVE解封装，仍完全符合原文“IP interface can accept IP packets”；GWLB送来的封装不受支持，D不能直接连接该设备。','只新增“appliance supports GWLB GENEVE”这一必要协议设定作为练习；不将IP接口自动重写为已支持GENEVE，原题仍非SUPPORTED。')
 if x['qid']==235:
  x['status']='SOURCE_ISSUE';x['remainingConditions'][0]['kind']='decisive_input_missing';x['remainingConditions'][0]['description']='DMS单向与双向复制的能力和无冲突解决边界已有官方正证。原题缺应用分阶段搬迁时的写入归属/同键冲突条件，能构造不同可行性。'
  x['sourceConfirmation']=S('decisive_input_missing','应用计算逐个迁入AWS，但都经现有连接继续写Oracle这一权威源库，Aurora在最后切换前只读；C的full-load+单向CDC能保持目标追随源。','已迁应用写Aurora、未迁应用写Oracle，并且都可能修改共同表中的同一业务行；同样符合原文分期迁移与共表写入，但C的单向任务不把目标变化复制回源，官方DMS双向也不自动解决同键冲突。','优先明确迁移期所有写入仍有一个权威源，或补上真实的分区写入/冲突处理策略这一必要练习设定；不能把一个单向CDC任务描写成任意双写同步。')
# Final files. The original input manifest is preserved; clarification is an explicit additional dependency.
clar=V/'inputs/source-ambiguity-rule-clarification-20261107.md'
clarsha=sha(clar.read_bytes());assert clarsha=='f1a34084af82686880945dee625c4139809cdb9c7acbdfa5e8b10e3075ea1181'
extra={str(clar):clarsha,str(pathlib.Path('/Users/qc/.codex/skills/aws-card-count-verify/SKILL.md')):sha(pathlib.Path('/Users/qc/.codex/skills/aws-card-count-verify/SKILL.md').read_bytes())}
(O/'additional-rule-bindings.json').write_text(json.dumps(extra,ensure_ascii=False,indent=2))
for n in range(1,5):savepart(n)
needed=set(e for x in R for e in x['officialEvidenceIds']);assert needed<=set(ev),(needed-set(ev))
registry={'schemaVersion':1,'evidence':ev,'unusableFetches':['aurora-io.snapshot.json (redirected to guide root, 13 characters)','fgw-semantics.snapshot.json (redirected/no content, not used)'],'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown'}
(O/'official-evidence.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2))
counts=dict(collections.Counter(x['status'] for x in R))
result={'reviewId':'open-condition-review01','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'independent_native','scope':'69 original complete questions and all options against frozen 358-card candidate pool; no card authorship, no acceptance of final N','inputManifestSha256':sha((I/'manifest.json').read_bytes()),'additionalRuleBindings':extra,'candidatePoolCount':len(pool),'candidatePoolIsFinalN':False,'originalQuestionCount':len(cases),'statusCounts':counts,'newContentModelCallsCLIAPI':0,'nativeUsage':'unknown','priorClockBudgetCountersReset':False,'originalQuestionEdits':0,'currentProductionInventoryEdits':0,'correctedVariantsAuthored':0,'results':R}
(O/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
# Deterministic readback checks every declared quote, hash, recursion, evidence and original input.
checks=collections.Counter()
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,p;checks['frozenInputFileHashes']+=1
assert len(R)==69 and len(set(x['qid'] for x in R))==69 and set(x['qid'] for x in R)==set(cases)
for x in R:
 assert x['questionCanonicalSha256']==cases[x['qid']]['questionCanonicalSha256'];assert x['questionInputObjectSha256']==sha(canon(cases[x['qid']]['question']));checks['originalQuestionBindings']+=1
 for r in x['actualUsedRuleIdsIncludingRecursivePrerequisites']:
  assert set(cards[r]['prerequisiteRuleIds'])<=set(x['actualUsedRuleIdsIncludingRecursivePrerequisites']);checks['recursivePrerequisiteBindings']+=1
 for a in x['necessaryPremiseAnchors']:
  c=cards[a['ruleId']];assert a['bodySha256']==c['bodySha256'];assert c['visibleBody'][a['field']][a['start']:a['end']]==a['quote'];checks['exactCardAnchors']+=1
 assert set(x['officialEvidenceIds'])<=set(ev)
 if x['status']=='SOURCE_ISSUE':assert x['sourceConfirmation'] and x['officialEvidenceIds'];checks['confirmedSourceCasesWithOfficialEvidenceAndTwoConstructions']+=1
 if x['status']=='SUPPORTED':assert not any(r['blocksOriginalSupport'] for r in x['remainingConditions']) and x['directlyUsedRuleIds'];checks['supportedNoOpenBlocker']+=1
for eid,e in ev.items():
 p=pathlib.Path(e['snapshotPath']);assert sha(p.read_bytes())==e['snapshotSha256'];d=json.loads(p.read_text());t=d['text'];assert sha(t.encode())==e['textSha256']
 for a in e['quotes']:assert t[a['start']:a['end']]==a['quote'];checks['exactOfficialQuoteAnchors']+=1
 checks['officialSnapshotHashes']+=1
loaded=json.loads((O/'results.json').read_text());assert loaded['results']==R
parts=[x for n in range(1,5) for x in json.loads((O/('part%02d.results.json'%n)).read_text())['results']];assert parts==R
readback={'status':'PASS','scope':'deterministic completeness/binding readback, not a second semantic reviewer','resultsSha256':sha((O/'results.json').read_bytes()),'officialEvidenceSha256':sha((O/'official-evidence.json').read_bytes()),'questionCount':69,'candidatePoolCount':len(pool),'statusCounts':counts,'checks':dict(checks),'partCounts':[20,20,20,9],'originalFilesUnchanged':True,'additionalRulesSha256':clarsha,'nativeUsage':'unknown','newContentModelCallsCLIAPI':0}
(O/'readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2))
lines=['# 69道开放条件独立复核','',f'原题69道；候选卡池{len(pool)}张，不是最终N。','', '状态：'+ '；'.join('%s %d'%(k,v) for k,v in sorted(counts.items()))+'。','', '支持：'+', '.join('Q'+str(x['qid']) for x in R if x['status']=='SUPPORTED')+'。','', '确认题源问题：'+', '.join('Q'+str(x['qid']) for x in R if x['status']=='SOURCE_ISSUE')+'。','', '仍未知：'+', '.join('Q'+str(x['qid']) for x in R if x['status']=='UNKNOWN')+'。','', '每题完整原题hash、实际使用卡与递归先修、具体卡句偏移、竞争推理、剩余条件和源问题双情境见results.json。官方原句/URL/快照及偏移见official-evidence.json。readback.json只验证数据完整及绑定，不代替第二次语义复审。','', '本轮未作者卡或纠错题，未改原题/current/生产库存/学习记录，未调用外部模型CLI/API、未派Agent；native用量unknown；原时钟与预算未重置。纠错练习尚须另存及独立验，不把本轮SOURCE_ISSUE计为原题充分。']
(O/'summary.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(readback,ensure_ascii=False,indent=2))

import json,pathlib,hashlib,datetime,collections,difflib,re
O=pathlib.Path(__file__).parent;V=O.parent.parent;I=O/'input'
def sha(b):return hashlib.sha256(b).hexdigest()
def can(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
manifest=json.loads((I/'manifest.json').read_text())
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h,p
cases=json.loads((I/'cases.json').read_text());C={x['originalQid']:x for x in cases};pool=json.loads((I/'core-visible.frozen.json').read_text());cards={x['ruleId']:x for x in pool};assert len(pool)==len(cards)==360
for c in pool:assert sha(can(c['visibleBody']))==c['bodySha256'],c['ruleId']
originalProofPath=V/'review/open-condition-review01/results.json';originalProof=json.loads(originalProofPath.read_text());originalResults={x['qid']:x for x in originalProof['results']}
for x in cases:
 assert sha(can(x['originalQuestion']))==x['originalQuestionCanonicalSha256'],x['variantId']
 assert sha(can(x['correctedQuestion']))==x['correctedQuestionCanonicalSha256'],x['variantId']
 assert x['originalQuestionCanonicalSha256']==originalResults[x['originalQid']]['questionCanonicalSha256']
 assert originalResults[x['originalQid']]['status']=='SOURCE_ISSUE'
 assert sha(originalProofPath.read_bytes())==x['sourceFinding']['independentResultSha256']
 assert x['sourceFinding']['finding']==originalResults[x['originalQid']]
# Source proof is reused for original defect confirmation, not as a variant answer key.
oldE=json.loads((V/'review/open-condition-review01/official-evidence.json').read_text())['evidence'];supp=json.loads((V/'review/reuse-a/supplemental11.review.json').read_text())['evidenceRegistry'];E={}
def use(eid,record):E[eid]=record
for eid in ['GWLB','MQ_RABBIT','DMS_BIDIR','AURORA_ENGINES','AURORA_PAUSE','AURORA_BILLING','AURORA_SCHEDULE','AURORA_PROC','AURORA_UDF','EKS_FAILURE','EKS_NODE_IAM','EKS_SG','RDS_STORAGE_SCALING','AURORA_SCALING','FGW_NOLOCK','EFS_LOCKS','AURORA_IO','EBS_ARCHIVE','EBS_TARIFFS','DDB_MODES','DDB_PRICING','CF_CACHE_OPTIMIZED','GA_PERFORMANCE','BUCKET_KEYS','SNOW_CURRENT']:use(eid,oldE[eid])
for eid in ['GLUE_STREAM','FLINK_SOURCE','FLINK_SINK','AURORA_NATIVE_REPLICA']:use(eid,supp[eid])
def newevi(eid,f,needles):
 p=O/'evidence'/f;d=json.loads(p.read_text());t=d['text'];a=[]
 for n in needles:
  m=re.search(r'\s+'.join(re.escape(w) for w in n.split()),t,re.I);assert m,(eid,n);st=max(0,m.start()-70);en=min(len(t),m.end()+280);a.append({'quote':t[st:en],'start':st,'end':en})
 E[eid]={'url':d['url'],'snapshotPath':str(p),'snapshotSha256':sha(p.read_bytes()),'textSha256':sha(t.encode()),'quotes':a}
newevi('DATA_PIPELINE_EMR','datapipeline-emr.snapshot.json',['Existing customers','schedule moving input data into Amazon S3','schedule launching clusters'])
newevi('SNOW_PHYSICAL_ENCRYPTION','snow-physical-encryption.snapshot.json',['256-bit','transit'])
R=[]
def review(q,status,ids,choice,minreason,reason,missing='',eids=(),finding=None):
 x=C[q];direct=ids.split();used=[]
 def add(r):
  if r in used:return
  assert r in cards,r;used.append(r)
  for p in cards[r]['prerequisiteRuleIds']:add(p)
 for r in direct:add(r)
 anchors=[]
 for r in used:
  c=cards[r]
  for f,t in c['visibleBody'].items():
   if t:anchors.append({'ruleId':r,'bodySha256':c['bodySha256'],'field':f,'quote':t,'start':0,'end':len(t),'role':'necessary_used_card_context' if r in direct else 'recursive_prerequisite_context'})
 delta=list(difflib.unified_diff(json.dumps(x['originalQuestion'],ensure_ascii=False,sort_keys=True,indent=2).splitlines(),json.dumps(x['correctedQuestion'],ensure_ascii=False,sort_keys=True,indent=2).splitlines(),n=0))
 obj={'variantId':x['variantId'],'originalQid':q,'status':status,'minimalityVerdict':'PASS','minimalityReason':minreason,'closureEligibleUnderAcceptedCorrectionPolicy':status=='SUPPORTED','originalQuestionCanonicalSha256':x['originalQuestionCanonicalSha256'],'correctedQuestionCanonicalSha256':x['correctedQuestionCanonicalSha256'],'originalStemUtf8Sha256':sha(x['originalQuestion']['stem'].encode()),'originalOptionsCanonicalSha256':sha(can(x['originalQuestion']['options'])),'variantStemUtf8Sha256':sha(x['correctedQuestion']['stem'].encode()),'variantOptionsCanonicalSha256':sha(can(x['correctedQuestion']['options'])),'completeOriginalAndAllOptionsRead':True,'completeVariantAndAllOptionsRead':True,'semanticDelta':delta,'independentOriginalDefectConfirmation':{'path':str(originalProofPath),'fileSha256':sha(originalProofPath.read_bytes()),'qid':q,'status':'SOURCE_ISSUE','questionCanonicalSha256':originalResults[q]['questionCanonicalSha256'],'confirmation':originalResults[q]['sourceConfirmation']},'originalStatusAfterThisReview':'SOURCE_ISSUE','doesNotUpgradeOriginal':True,'selectedOptionOrdinals':choice if status=='SUPPORTED' else [],'independentlySupportedPartialOptionOrdinals':choice if status!='SUPPORTED' else [],'directlyUsedRuleIds':direct,'actualUsedRuleIdsIncludingRecursivePrerequisites':used,'cardBindings':[{'ruleId':r,'bodySha256':cards[r]['bodySha256'],'prerequisiteRuleIds':cards[r]['prerequisiteRuleIds']} for r in used],'necessaryAnchors':anchors,'visibleCardReasoning':reason,'minimumRemainingJudgments':missing,'findings':[] if not finding else [finding],'officialEvidenceIds':list(eids),'officialFactsDoNotSubstituteForVisibleTeaching':True,'unmeasuredLearnerEffect':True,'ordinaryImplementationChecksAreNotNewCards':True}
 R.append(obj)
review(19,'SUPPORTED','CUR:XB002',[4], '只增加原设备是否兼容GENEVE这一决定性协议前提，并明确是练习设定；保留完整三层网络、先检查后到Web、跨VPC及最少运维。', '给定设备兼容后，XB002的GWLB置检查VPC、应用侧endpoint、路由指向检查跳点正好组成D。A/B并非该透明网络检查入口，C的TGW单独不建立设备检查链。UDP6081已作为给定条件，不要求学习者额外背端口。',eids=('GWLB',))
review(59,'INSUFFICIENT_CARDS','CUR:NS01 CUR:XB004 CUR:XB013 GSC-093 CUR:CB03 CUR:CA13 GSC-029',[2,4], '把缺唯一目标的单选改为全部可行架构，符合获准的最小多选修复；没有改每日30TB、全球网站或分析目标。', 'D的KDS→Firehose→S3→Redshift可以由可见流/仓库卡组成；B的可伸缩EC2处理落S3/仓库也与计算分工一致。但Select ALL把A的Data Pipeline→EMR有效性也纳入必须裁定范围。', '360池没有Data Pipeline到S3/EMR的可见机制/现行资格。官方明确该链对既有客户仍可用，不能只因停止新客就排除A；本练习也没有给该公司是否有资格。仅给B/D不会完成ALL的任务，不能把先前“至少两个可行”当作已排尽选项。',('DATA_PIPELINE_EMR',),{'id':'CV10-F01','kind':'visible_card_gap_and_open_eligibility','priority':'P1','detail':'Q059-CV10要求ALL，但A仍有资格与服务链判断未由当前卡面支撑。','minimumAction':'先明确既有资格这一必要练习输入，并以可见卡教会或可靠推导A的实际链；不把A标作全面退役，也不静默省略该选项。'})
review(138,'SUPPORTED','GSC-087 GSC-086 CUR:CB03 CUR:CB01 CUR:CC22 GCL-012',[2], '只修B中错误RabbitMQ主备对的拓扑为受支持跨AZ三节点与队列复制，其他场景及所有竞争项保留。', 'GSC087给出RabbitMQ跨AZ集群；CB03给应用跨AZ ASG，CC22/CB01给托管RDS PostgreSQL和Multi-AZ。B在三层都具备适当可用性且减少自管平台。A保留不适用RabbitMQ模式并自管PG，C/D的ASG不会自动复制队列/数据库状态。',eids=('MQ_RABBIT',))
review(235,'SUPPORTED','GSC-060 GSC-061 CUR:NC07',[3], '只把未知的迁移期写入归属补为Oracle单一权威、最终切换前Aurora只追复制，保留按月逐应用迁移、异构引擎和高读写需求。', 'GSC060说明全量搬存量、CDC接续Oracle新写入并追平切换；GSC061说明Oracle→PostgreSQL还需schema/code转换。A/B用文件DataSync充当异构数据库初始迁移，D只选大表遗漏必须同步的表，C的全部表＋转换＋CDC满足。选择C无需额外背memory/compute实例参数，因为D先因表范围不足被排除。',eids=('DMS_BIDIR',))
review(300,'SUPPORTED','CUR:CC22 GSC-050 GSC-054 GSC-057 GSC-146 VC-007',[2,3,4], '新增引擎兼容性作为必要设定，并改成全部可行及成本所需输入；仍保留连续运行、容量增长和费用目标，没有预先指定胜者。', '兼容MySQL已给，RDS/Aurora均保留关系模型；B/C/D的稳定计算与匹配预留/按需组合可持续运行，增长存储按GSC050/兼容产品配置扩展。A把关系层换为S3，不保留所问关系库。成本还需EC2与DB实际规格、稳定利用率和承诺期匹配、存储/IO增长及相应单价；GSC054和VC007明确实例承诺不使存储/IO免费、闲置也继续支付。没有把“还需信息”替代关系兼容和持续运行的实际判断。',eids=('AURORA_ENGINES',))
review(337,'SUPPORTED','VC-003 GSC-057 GSC-045 CUR:CC22 GSC-061',[1], '只去掉强制把过程改成函数这一不安全替换，保留已有兼容过程与受支持调度，没有改变低于一秒的目标、读扩展或最低改动/运维。', 'VC003的共享存储及通常<100ms区域reader配合GSC057的reader数量伸缩，给出A的低延迟扩读方向；Aurora的MySQL兼容关系允许保留兼容的MySQL业务对象，GSC061提醒仍核兼容而不宣称所有代码自动迁好。相比B/D更换访问/过程模型、C自管EC2，A保留兼容逻辑最少改动。具体过程版本与调度启用属于该方案的迁移配置；题目未问事件调度器的命令，不需为此背整本手册，也不把通常复制延迟升级为全部故障的绝对SLA。',eids=('AURORA_SCHEDULE','AURORA_PROC','AURORA_UDF'))
review(501,'INSUFFICIENT_CARDS','CUR:CA17 CUR:XB004 CUR:NC01 CUR:NS01 GSC-095 CUR:CMP-M06 CUR:NA05',[1,4], '去掉没有输入基础的唯一最省运维排名，改为全部可行的先分析后写湖路径；原每分钟数据和实时分析顺序均保留。', 'A的KDS→Lambda与D的HTTP入口→Lambda可由当前卡构成，并由函数写S3。C若指Firehose直接作为Flink输入，NC01已明确不能这样接。问题是ALL及“normal supported output configuration”也要求认真评估B。', '官方Glue streaming ETL能把结果写KDS，Flink又能读KDS，所以B可通过Glue→KDS→Flink→S3形成支持的桥接；当前GSC095只教Glue流输入后写S3，没有教KDS输出接口。不能据卡未写便声称B技术不可能，或只给A/D当作ALL已答完。这里没有为弱干扰项要求全套手册，而是明确未教的具体输出连接。',('GLUE_STREAM','FLINK_SOURCE','FLINK_SINK'),{'id':'CV10-F02','kind':'visible_output_interface_gap','priority':'P1','detail':'Q501-CV10的ALL范围未闭合B的Glue→KDS输出→Flink输入链；只审A/D不足。','minimumAction':'明确ALL允许的“正常输出配置”范围，并补出或由现卡可靠推导实际接口。不得靠不相关工具禁用条款强迫A/D，也不拿官方研究页代学习卡。'})
review(511,'SUPPORTED','CUR:CC22 CUR:XB027 GSC-057 GSC-052 GSC-054 VC-007',[1,2,3], '给原A明确容量模式和真正降零配置，修复与C的泛称重叠；将唯一成本问法改为全部兼容方案和必要价格/负载输入，保留每人数据库与半天使用。', 'A是已给支持版本且min0/auto-pause的兼容PG；B是RDS PostgreSQL单AZ，C是兼容Aurora按需，均能运行schema；D对象选择不是PG关系库。XB027说明无连接后暂停/恢复及空闲算力费用，GSC052说明停止/存储费用边界，GSC057给单实例容量维度。总费还需活跃时计算/IO/存储需求、空闲连接是否关闭、暂停间隔和恢复容忍、各配置实际单价；不能单靠四小时选绝对最低，但现在问的是这些已教机制下还缺什么。',eids=('AURORA_PAUSE','AURORA_BILLING',))
review(514,'SUPPORTED','CUR:XB025 CUR:CMP-M06 CUR:CMP-M10',[1,4], '只把没有故障诊断的单选改成相应诊断下所有有效纠正项，保留私有端点与私有节点硬限制。', 'A对应节点身份缺权限，CMPM06角色授权原则可用于节点；D对应节点到私有控制面的出站被拦，CMPM10要求发起端放行正确接收端口。XB025区分EKS管理API端点与集群Kubernetes API，故B不是该连接的替代；C违背私有节点要求。并非声称A和D对任意根因都必然有效。',eids=('EKS_FAILURE','EKS_NODE_IAM','EKS_SG'))
review(565,'SUPPORTED','GSC-057 GSC-046 GSC-060 CUR:CC22 GSC-050',[3], '只说明增长为可分流的读查询、writer与存储已足够，这是原未给出的伸缩资源维度；没有改引擎兼容或擅加工具偏好。', 'GSC057把Aurora Auto Scaling定义为增减reader，GSC046要求应用把读连接发往副本，GSC060给DMS迁移，组成C。A扩磁盘不扩读计算，B/D改变关系兼容模型，不能满足已给MySQL应用需求。',eids=('RDS_STORAGE_SCALING','AURORA_SCALING'))
review(659,'INSUFFICIENT_CARDS','GSC-077 GSC-006 CUR:NC07 CUR:NB01',[3], '补实际可用带宽及当前设备资格、容量/窗口，使50TB两周的容量选择可判；这些均与原硬期限和现行服务可用性直接有关，没有新增不相关偏好。', '100Mbps连续两周理想最多约15.12TB，不能搬完50TB；给定设备两周全过程可安排后，离线Snowball是所列已有条件下的容量路线，GSC006也说明返运最终入S3。', '原题仍保留securely transfer。GSC077只教离线带宽比较和资格/窗口，GSC006只教返运到S3；360池没有教Snowball运输中的数据加密/访问保护。官方已能确认该能力，但不能由“设备物流已安排”替代学习者的安全判断；这不是普通IAM漏配或生产SLA实测要求。',('SNOW_CURRENT','SNOW_PHYSICAL_ENCRYPTION'),{'id':'CV10-F03','kind':'visible_security_capability_gap','priority':'P1','detail':'Q659-CV10的带宽/设备资格缺口闭合，securely transfer所需设备数据保护仍无卡句。','minimumAction':'保留原安全要求，以可见卡补明或推导真实设备数据保护机制；不要把这一服务知识当新增题干已给事实来绕过。'})
review(806,'INSUFFICIENT_CARDS','GSC-012 GSC-002 GCL-018 GSC-001',[3,4], '新增真实文件锁语义作为必要输入，并用多选保留Regional/OneZone可能性和原费用取舍；没有凭空要求AZ故障保护。', '候选C/D的EFS容量/生命周期、Regional与OneZone故障域差异可见；A的块卷不是同一NFS共享接口。可是判B与C/D的决定条件已经变成NFSv4字节区间锁。', '360池没有S3 File Gateway NFS应nolock、EFS支持NFSv4文件锁的可见句。仅说“文件接口/对象后端”不能推导二者锁语义，不能把官方已核事实或新增条件本身当已教能力。改问成本需要哪些信息也不能抵扣前半句“哪些保留锁”的未教判断。',('FGW_NOLOCK','EFS_LOCKS'),{'id':'CV10-F04','kind':'visible_file_semantics_gap','priority':'P1','detail':'Q806-CV10没有卡面依据排除File Gateway并确认EFS字节锁。','minimumAction':'把必要锁语义纳入现有文件机制的可见教学或可推导规则；仍保留两个EFS候选，不加不相关HA要求强制唯一。'})
review(827,'INSUFFICIENT_CARDS','GSC-059',[4], '只给I/O请求费占可比Standard总费40%这一真正缺失的费用输入，保留Aurora PG Serverless v2和性能/费用目标。', '卡可以排除B/C的普通RDS卷类型，并解释I/O-Optimized不单收IO、其他单价可能更高。但当前GSC059回答的是“要比较总费用”，且明确只是“可能”省。', '当前卡没有可判的I/O占比阈值或匹配的总费计算规则。40%本身不能从“免IO但其他更贵”推出D更便宜；需要官方25%选择规则或足够费用关系实际进入可见教学。该官方规则已核，仍不能以审查者记忆代卡。',('AURORA_IO',),{'id':'CV10-F05','kind':'visible_cost_decision_rule_gap','priority':'P1','detail':'Q827-CV10补了决定数据，但GSC059只教比较，没有教由该数据作选择的充分规则。','minimumAction':'定向补可理解的选择条件/总费用关系；不要求新增长卡或穷尽所有Region价格。'})
review(841,'SUPPORTED','GSC-018 CUR:NS03 GSC-011',[2], '只明确每日变化块轮转导致月末点之间整批已写块刷新，以及同Region同口径存储费比较；350TB、5%日变、日保留一月和月保留七年均未改。', '在该给定下，长期各月点不能继续共享旧块，标准层的增量优势对这些月点消失；Archive虽转全量，但本来月点已相对独立，GSC018给出的“归档每GiB便宜”遂能用于相同数据量比较，B更省。NS03的快照生命周期计划降低管理工作。A/D把原生快照当用户S3对象路径，不能凭普通S3层名替代受支持EBS恢复点；GSC011强调备份恢复需要创建真实块卷。这里无需背精确单价，也没有声称归档可立即恢复。',eids=('EBS_ARCHIVE','EBS_TARIFFS'))
review(1002,'SUPPORTED','GSC-039 GSC-038 GCL-023',[1], '只把原缺的负载可预测性与预置闲置程度写清，保留跨Region可靠性和总费目标，没有改global tables选项。', 'GSC039给受管global tables复制，排除B/C自管复制维护方向；GSC038按难预测、不宜预置的负载考虑on-demand，而稳定可规划才比较预置。给定高度不规律且预置严重闲置，A与这条已教条件→容量模式取舍一致，D的稳定规划优势不在。35%是保留的题给数据，推理不要求学生另背未教的数值阈值，也不把按需说成无限吞吐。',eids=('DDB_MODES','DDB_PRICING'))
review(1004,'INSUFFICIENT_CARDS','CUR:CA13 CUR:NS02 GSC-130 GSC-073 CUR:NB01',[3], '只增加认证身份相关且不能混用的响应语义，修复原缓存适用条件缺失；不将“API一概不能缓存”或某产品偏好加成原事实。', 'NS02给Global Accelerator经AWS网络送往区域端点，适合不依赖响应缓存的入口加速；GSC130说明来源转发与cache key不同。A的public VIF/DXGW组合不匹配，D的VPN不等同专用物理加速路径。', '要准确排除原B，还须知道CachingOptimized实际不把Authorization/查询客户标识放进key，且其正最小TTL的行为。360池只有通用语言变体key规则，没有该Managed policy的字段或强缓存边界。新增“不得混用”是业务要求，不能直接充当“B必然混用”的服务知识。',('CF_CACHE_OPTIMIZED','GA_PERFORMANCE'),{'id':'CV10-F06','kind':'visible_managed_cache_policy_gap','priority':'P1','detail':'Q1004-CV10缺CachingOptimized具体行为的可见锚点，不能只凭策略名称排除B。','minimumAction':'在现有缓存键规则中教出需要的实际托管策略边界，或用有证据且不改变原业务目标的最小方式表述练习；不添加价格/工具偏好强迫C。'})
review(1009,'SUPPORTED','CUR:aws-rb2-domain1-normal-batch07-20261105-s3-bucket-key-request-cost CUR:CC05 VC-011',[2], '分别明确继续SSE-KMS治理、减少而非消除KMS请求两项原歧义，选项和频繁访问情境保持；重复解释口径没有另加独立业务目标。', '当前Bucket Key卡正面就是继续SSE-KMS时减少请求费，机制为短时桶级密钥生成对象密钥，且明确仍有KMS调用、仅新对象适用。B降低适用新对象的请求费用；既有对象不会自动改造，原题未要求全部存量立刻重写。A改SSE-S3不保留KMS治理，C/D不提供该桶级减少逐对象调用的路径。',eids=('BUCKET_KEYS',))
assert len(R)==17
# Narrow evidence quote for the new all-feasible Glue branch, which the visible card has not taught.
glue=E['GLUE_STREAM'];gp=pathlib.Path(glue['snapshotPath']);gt=json.loads(gp.read_text())['text'];needle='you can produce data for Amazon Kinesis Data Streams';m=re.search(r'\s+'.join(re.escape(w) for w in needle.split()),gt,re.I);assert m
E['GLUE_KDS_OUTPUT']={'url':glue['url'],'snapshotPath':glue['snapshotPath'],'snapshotSha256':glue['snapshotSha256'],'textSha256':glue['textSha256'],'quotes':[{'quote':gt[max(0,m.start()-80):m.end()+250],'start':max(0,m.start()-80),'end':m.end()+250}]}
for r in R:
 if r['originalQid']==501:r['officialEvidenceIds'].append('GLUE_KDS_OUTPUT')
counts={'reviewed':17,'minimalityPASS':17,'closureEligible':sum(r['closureEligibleUnderAcceptedCorrectionPolicy'] for r in R),'statusCounts':dict(collections.Counter(r['status'] for r in R)),'originalPromotions':0}
result={'schemaVersion':1,'reviewId':'corrected-variants10-current01','reviewer':'independent_native','completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputManifestPath':str(I/'manifest.json'),'inputManifestSha256':sha((I/'manifest.json').read_bytes()),'inputHashes':manifest,'frozenVisiblePoolCount':360,'candidatePoolNotFinalN':True,'priorOldSnapshotPreserved':True,'originalSourceConfirmationPath':str(originalProofPath),'counts':counts,'results':R,'officialEvidenceRegistry':E,'findingIds':[f['id'] for r in R for f in r['findings']],'allOriginalStatusesRemainUnchanged':True,'newCardsAuthored':0,'variantsEdited':0,'currentProductionInventoryEdits':0,'correctedVariantPassDoesNotUpgradeOriginal':True,'nativeUsage':'unknown','externalModelCLIApiCalls':0,'clockBudgetHistoryReset':False}
(O/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
checks=collections.Counter()
for p,h in manifest.items():assert sha(pathlib.Path(p).read_bytes())==h;checks['frozenInputsUnchanged']+=1
for r in R:
 x=C[r['originalQid']];assert r['originalQuestionCanonicalSha256']==sha(can(x['originalQuestion']));assert r['correctedQuestionCanonicalSha256']==sha(can(x['correctedQuestion']));checks['originalVariantHashPairs']+=1
 assert r['originalStatusAfterThisReview']=='SOURCE_ISSUE' and r['doesNotUpgradeOriginal'];assert r['closureEligibleUnderAcceptedCorrectionPolicy']==(r['status']=='SUPPORTED')
 for b in r['cardBindings']:assert set(b['prerequisiteRuleIds'])<=set(r['actualUsedRuleIdsIncludingRecursivePrerequisites']);assert b['bodySha256']==cards[b['ruleId']]['bodySha256'];checks['recursiveCardBindings']+=1
 for a in r['necessaryAnchors']:assert cards[a['ruleId']]['visibleBody'][a['field']][a['start']:a['end']]==a['quote'];assert a['bodySha256']==cards[a['ruleId']]['bodySha256'];checks['exactCardAnchors']+=1
 assert set(r['officialEvidenceIds'])<=set(E)
for e in E.values():
 p=pathlib.Path(e['snapshotPath']);assert sha(p.read_bytes())==e['snapshotSha256'];t=json.loads(p.read_text())['text'];assert sha(t.encode())==e['textSha256'];checks['officialSnapshots']+=1
 for q in e['quotes']:assert t[q['start']:q['end']]==q['quote'];checks['officialQuoteAnchors']+=1
assert json.loads((O/'results.json').read_text())==result
rb={'status':'PASS','meaning':'deterministic completeness/hash/quote readback; semantic eligibility only for the eleven explicitly SUPPORTED variants','resultsSha256':sha((O/'results.json').read_bytes()),'inputManifestSha256':result['inputManifestSha256'],'counts':counts,'checks':dict(checks),'eligibleVariantIds':[r['variantId'] for r in R if r['closureEligibleUnderAcceptedCorrectionPolicy']],'failedVariantIds':[r['variantId'] for r in R if not r['closureEligibleUnderAcceptedCorrectionPolicy']],'originalPromotions':0,'nativeUsage':'unknown','externalModelCLIApiCalls':0}
(O/'readback.json').write_text(json.dumps(rb,ensure_ascii=False,indent=2));print(json.dumps(rb,ensure_ascii=False,indent=2))

# -*- coding: utf-8 -*-
import collections,datetime,hashlib,json
from pathlib import Path
V=Path.cwd();R=V/'review/unchanged-service-scope01';P=R/'input'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
objsha=lambda x:hashlib.sha256(canon(x).encode()).hexdigest()
o=json.loads((R/'results.json').read_text());rr=o['results'];cases={c['qid']:c for c in json.loads((P/'cases.json').read_text())}
pool={c['ruleId']:c for c in json.loads((P/'visible-pool.frozen.json').read_text())}
priorbinding=o['priorProofSnapshotBinding'];prior={r['qid']:r for r in json.loads(Path(priorbinding['path']).read_text())['rows']}
refs=o['officialEvidenceRegistry']
def close(ids):
 seen=set(ids);queue=list(ids)
 while queue:
  for k in pool[queue.pop()]['prerequisiteRuleIds']:
   if k not in seen:seen.add(k);queue.append(k)
 return sorted(seen)
checks={
 'allOriginalInputsUnchanged':all(sha(p)==h for p,h in o['inputHashes'].items()),
 'manifestFileBindingExact':sha(o['inputManifestPath'])==o['inputManifestSha256'],
 'exact18UniqueQids':set(cases)=={r['qid']for r in rr}and len(rr)==len({r['qid']for r in rr})==18,
 'fullOriginalQuestionHashesExact':all(r['questionCanonicalSha256']==objsha(cases[r['qid']]['question'])for r in rr),
 'separateStemAndOptionsHashesExact':all(r['originalStemUtf8Sha256']==hashlib.sha256(cases[r['qid']]['question']['stem'].encode()).hexdigest()and r['originalOptionsCanonicalSha256']==objsha(cases[r['qid']]['question']['options'])for r in rr),
 'everyOriginalOptionReadBackExactly':all([(x['ordinal'],x['originalLabel'],x['textSha256'])for x in r['optionReadback']]==[(x['ordinal'],x['originalLabel'],hashlib.sha256(x['text'].encode()).hexdigest())for x in cases[r['qid']]['question']['options']]for r in rr),
 'all362FrozenCardBodiesBound':len(pool)==362 and all(objsha(c['visibleBody'])==c['bodySha256']for c in pool.values()),
 'priorProofSnapshotBound':sha(priorbinding['path'])==priorbinding['sha256'],
 'allPriorProofFilesUnchanged':all(sha(r['priorKnowledgeProofReuse']['path'])==r['priorKnowledgeProofReuse']['fileSha256']for r in rr),
 'allPriorProofSnapshotRowsBound':all(objsha(prior[r['qid']]['proof'])==r['priorKnowledgeProofReuse']['proofRowCanonicalSha256']for r in rr),
 'allPriorStatusesWereSupported':all(r['priorKnowledgeProofReuse']['priorStatus']=='SUPPORTED'for r in rr),
 'allUsedCurrentCardBindingsExact':all(p['bodySha256']==pool[p['ruleId']]['bodySha256']and p['prerequisiteRuleIds']==pool[p['ruleId']]['prerequisiteRuleIds']for r in rr for p in r['cardBindings']),
 'allNecessaryQuotesVisibleAtExactOffsets':all(pool[a['ruleId']]['visibleBody'][a['field']][a['quoteStart']:a['quoteEnd']]==a['quote']and a['bodySha256']==pool[a['ruleId']]['bodySha256']for r in rr for a in r['necessaryAnchors']),
 'allRecursiveBindingsComplete':all(r['actualUsedRuleIdsIncludingRecursivePrerequisites']==close(r['usedRuleIds'])and {b['ruleId']for b in r['recursiveUsedPrerequisiteBindings']}==set(close(r['usedRuleIds']))-set(r['usedRuleIds'])for r in rr),
 'allOfficialSnapshotHashesExact':all(sha(s['snapshotPath'])==s['snapshotSha256']for s in refs.values()),
 'allOfficialTextHashesExact':all(hashlib.sha256(json.loads(Path(s['snapshotPath']).read_text())['text'].encode()).hexdigest()==s['textSha256']for s in refs.values()),
 'allOfficialQuotesExactAtOffsets':all(json.loads(Path(s['snapshotPath']).read_text())['text'][s['quoteStart']:s['quoteEnd']]==s['quote']for s in refs.values()),
 'allOfficialRefsResolve':all(r['officialEvidenceIds']and all(k in refs for k in r['officialEvidenceIds'])for r in rr),
 'allSourceIssuesHavePositiveTwoCaseProofs':all(r['sourceIssue']['confirmed']and r['sourceIssue']['positiveTechnicalBasis']and len(r['sourceIssue']['counterfactualScenarios'])==2 and all(c['condition']and c['outcome']for c in r['sourceIssue']['counterfactualScenarios'])and r['sourceIssue']['minimalCorrectionFields']for r in rr if r['status']=='SOURCE_ISSUE'),
 'onlySupportedRowsRetainAcceptedSelections':all(bool(r['selectedOptionOrdinals'])==(r['status']=='SUPPORTED')for r in rr),
 'allAcceptedSelectionsInOriginalOptions':all(set(r['selectedOptionOrdinals'])<=set(x['ordinal']for x in cases[r['qid']]['question']['options'])for r in rr),
 'q702ExistingDeviceUsageNotReopened':next(r for r in rr if r['qid']==702)['status']=='SUPPORTED'and next(r for r in rr if r['qid']==702)['scopeFinding']=='EXISTING_USAGE_ESTABLISHED_BY_ORIGINAL',
 'q302CurrentAESelectionPreserved':next(r for r in rr if r['qid']==302)['selectedOptionOrdinals']==[1,5]and next(r for r in rr if r['qid']==302)['priorKnowledgeProofReuse']['priorSelectedOptionOrdinals']==[1,5],
 'q65LanguageNotSilentlyAssumed':next(r for r in rr if r['qid']==65)['status']=='SOURCE_ISSUE'and next(r for r in rr if r['qid']==65)['selectedOptionOrdinals']==[],
 'q784NotKeywordOnlySourceIssue':next(r for r in rr if r['qid']==784)['status']=='SOURCE_ISSUE'and all(k in next(r for r in rr if r['qid']==784)['officialEvidenceIds']for k in ['PIPELINE_WORKFLOW','PIPELINE_RETRIES','PIPELINE_CONCURRENCY','PIPELINE_DEPENDENCIES']),
 'q673RefreshBindsActualCurrentText':next(r for r in rr if r['qid']==673)['currentQuoteRefreshRuleIds']==['CUR:CMP-M01','GSC-012','VC-006'],
 'countsMatchRows':o['counts']==dict(collections.Counter(r['status']for r in rr)),
 'noOriginalOrCurrentMutation':all(not r['originalModified']and not r['currentOrInventoryModified']for r in rr),
}
assert all(checks.values()),{k:v for k,v in checks.items()if not v}
out={'schemaVersion':1,'status':'PASS','checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewer':'/root/domain_primary_audit','resultsPath':str((R/'results.json').resolve()),'resultsSha256':sha(R/'results.json'),
 'checks':checks,'counts':o['counts'],'sourceIssueQids':[r['qid']for r in rr if r['status']=='SOURCE_ISSUE'],
 'supportedQids':[r['qid']for r in rr if r['status']=='SUPPORTED'],
 'all18OriginalsAnd362InputCardsPreserved':True,'productionAndMainRunModifiedByReviewer':False,
 'fullLibraryOrFinalNVerified':False,'externalModelCliApiCalls':0,'nativeUsage':'unknown',
 'mechanicalBindingChecksDoNotSubstituteForSemanticReview':True}
(R/'readback.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks),'counts':o['counts'],'sourceIssueQids':out['sourceIssueQids']},ensure_ascii=False,indent=2))

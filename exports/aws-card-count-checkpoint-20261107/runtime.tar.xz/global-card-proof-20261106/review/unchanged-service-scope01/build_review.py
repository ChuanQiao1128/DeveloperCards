# -*- coding: utf-8 -*-
import collections,datetime,hashlib,json,re
from pathlib import Path
V=Path.cwd();R=V/'review/unchanged-service-scope01';P=R/'input';E=R/'evidence'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
objsha=lambda x:hashlib.sha256(canon(x).encode()).hexdigest()
manifest=json.loads((P/'manifest.json').read_text());assert all(sha(p)==h for p,h in manifest.items())
cases=json.loads((P/'cases.json').read_text());pool={x['ruleId']:x for x in json.loads((P/'visible-pool.frozen.json').read_text())}
assert len(pool)==362 and all(objsha(c['visibleBody'])==c['bodySha256']for c in pool.values())
priorSnapshot=json.loads((E/'prior-proof-snapshot.json').read_text());old={r['qid']:r for r in priorSnapshot['rows']};sources={}
def source(key,path,quote):
 p=Path(path);j=json.loads(p.read_text());t=j['text'];m=re.search(r'\s+'.join(re.escape(s)for s in quote.split()),t);assert m,(key,quote)
 a,b=m.span();sources[key]={'url':j['url'],'snapshotPath':str(p.resolve()),'snapshotSha256':sha(p),'textSha256':hashlib.sha256(t.encode()).hexdigest(),'quote':t[a:b],'quoteStart':a,'quoteEnd':b}
residual=V/'review/residual-conditions02-current01/evidence'
source('SNOW_CURRENT_EXISTING',V/'review/remaining-source10/evidence/snow-availability.json',
 'This change will not impact customers currently using AWS Snowball Edge to meet their edge compute and data migration needs.')
source('SNOW_NEW_CUSTOMERS',V/'review/remaining-source10/evidence/snow-availability.json',
 'AWS will no longer offer any AWS Snow Family devices for new customers to order.')
source('FSX_GATEWAY_SCOPE',residual/'fsx-client-eligibility.json',
 'Amazon FSx File Gateway is no longer available to new customers. Existing customers of FSx File Gateway can continue to use the service normally.')
source('FORECAST_SCOPE',residual/'forecast-eligibility.json',
 'Amazon Forecast is no longer available to new customers. Existing customers of Amazon Forecast can continue to use the service as normal.')
source('A2C_SCOPE',residual/'app2container-what.json',
 'is no longer open to new customers. If you would like to use the service, sign up prior to November 7, 2025.')
source('MIGRATION_HUB_SCOPE',residual/'migrationhub-eligibility.json',
 'AWS Migration Hub is no longer open to new customers as of November 7, 2025.')
source('FULL_SHUTDOWN_MEANING',residual/'full-shutdown.json',
 'Services and features in full shutdown are completely removed from the AWS portfolio and are no longer available or supported in any capacity.')
for k,quote in [('ELASTIC_TRANSCODER_SHUTDOWN','Amazon Elastic Transcoder November 13, 2025'),
                ('QLDB_SHUTDOWN','Amazon Quantum Ledger Database (Amazon QLDB) July 31, 2025'),
                ('SNOWMOBILE_SHUTDOWN','AWS Snowmobile March 14, 2024')]:source(k,residual/'full-shutdown.json',quote)
source('S3_SELECT_SCOPE',E/'s3-select-availability.json',
 'Amazon S3 Select is no longer available to new customers. Existing customers of Amazon S3 Select can continue to use the feature as usual.')
source('S3_SELECT_ONE_OBJECT',E/'s3-select-availability.json','Amazon S3 Select only allows you to query one object at a time.')
source('CM_ENGLISH_ONLY',V/'review/current-impact02/a/evidence/comprehend-medical-languages.snapshot.json',
 'Amazon Comprehend Medical only detects medical entities in English language (US-EN) texts.')
source('TEXTRACT_PRINTED_LANGUAGES',E/'textract-limits.json',
 'AnalyzeDocument (Forms), StartDocumentAnalysis (Forms), and GetDocumentAnalysis APIs are limited to English, Spanish, Italian, Portuguese, French, and German.')
source('PIPELINE_SCOPE',E/'datapipeline-what.json',
 'AWS Data Pipeline is no longer available to new customers. Existing customers of AWS Data Pipeline can continue to use the service as normal.')
source('PIPELINE_WORKFLOW',E/'datapipeline-what.json',
 'With AWS Data Pipeline, you can define data-driven workflows, so that tasks can be dependent on the successful completion of previous tasks.')
source('PIPELINE_MANAGED_WORK',E/'datapipeline-what.json',
 'A pipeline schedules and runs tasks by creating Amazon EC2 instances to perform the defined work activities.')
source('PIPELINE_RETRIES',E/'datapipeline-shell-activity.json',
 'maximumRetries The maximum number attempt retries on failure.')
source('PIPELINE_DEPENDENCIES',E/'datapipeline-shell-activity.json',
 'dependsOn Specifies a dependency on another runnable object.')
source('PIPELINE_CONCURRENCY',E/'datapipeline-shell-activity.json',
 'maxActiveInstances The maximum number of concurrent active instances of a component.')
source('PIPELINE_RETRY_DELAY',E/'datapipeline-shell-activity.json',
 'retryDelay The timeout duration between two retry attempts.')
source('DATABREW_REMAINS_SUPPORTED',E/'databrew-what.json',
 'AWS Glue DataBrew is a visual data preparation tool')

scope={
1:('DISTRACTOR_ONLY',['SNOW_CURRENT_EXISTING','SNOW_NEW_CUSTOMERS'],
   'Snowball仅在C。全球各站有高速Internet、每日持续500GB且要快并少运维，寄送每日设备不是A的直接分块加速聚合路径；即使旧合格客户可订设备也不改变A。'),
65:('DECISIVE_LANGUAGE_INPUT_MISSING',['CM_ENGLISH_ONLY','TEXTRACT_PRINTED_LANGUAGES'],
    'C依赖Comprehend Medical英文限定，原文没有给报告语言。旧证明把英文当普通实施范围补入，但当前卡正面和提醒已经明确英文，不能反写到原题。'),
283:('DISTRACTOR_ONLY',['FSX_GATEWAY_SCOPE'],
     '命中B的FSx File Gateway。D的ONTAP同一数据NFS/SMB多协议直接满足不改Linux/Windows应用和去掉双份副本；网关资格不会使B成为该多协议后端。'),
287:('DISTRACTOR_ONLY',['FSX_GATEWAY_SCOPE'],
     '命中A。当前判断是B的EC2自管SQL Server与云端FSx Windows共享文件；FSx File Gateway是对文件后端的缓存延伸，不是替代云端共享文件后端。旧客户资格不改变该职责差别。'),
302:('ALREADY_CURRENT_RETIREMENT_DISPOSITION',['ELASTIC_TRANSCODER_SHUTDOWN','FULL_SHUTDOWN_MEANING'],
     '当前充分凭证已经选A+E，而非历史A+C。Elastic Transcoder已全面关闭，不能当成仅新客关闭。当前卡已教CDN分发与EC2实际转码；本次复用已接受的当前AWS服务范围裁定，不再把退役C当可选托管方案。MediaConvert不在选项里，不能静默替换C。'),
304:('DISTRACTOR_ONLY',['SNOW_CURRENT_EXISTING','SNOW_NEW_CUSTOMERS'],
     'Snowball仅在B。两Region的NFS需周期来回传文件，DataSync已有文件位置、任务和校验机制；设备资格不改变该周期在线传输和较少操作的选择。'),
482:('DISTRACTOR_ONLY',['SNOW_CURRENT_EXISTING','SNOW_NEW_CUSTOMERS'],
     'Snowball仅在C。一次100GB、100Mbps理想约2.22小时，直接CLI默认TLS已满足传输加密；无需订设备或额外VPN，旧设备资格也不让C比A更少操作。'),
495:('DISTRACTOR_ONLY',['S3_SELECT_SCOPE','S3_SELECT_ONE_OBJECT'],
     'S3 Select仅在D。它按单对象SQL取子集，不是题面按受管PII/财务识别器扫描桶内容的Macie作业；既有资格不改变C的角色匹配。'),
626:('DISTRACTOR_ONLY',['SNOW_CURRENT_EXISTING','SNOW_NEW_CUSTOMERS'],
     'Snowball仅在A，未提供本题所要的托管在线复制后校验任务。DataSync原生管理传输和校验；不把订离线设备解释成已经配置任意自写在线校验程序。'),
631:('DISTRACTOR_ONLY_FULLY_RETIRED',['QLDB_SHUTDOWN','FULL_SHUTDOWN_MEANING'],
     'QLDB仅在C/D且已全面关闭。当前B使用图数据库Neptune和自身Neptune Streams，关系遍历及变更流的必要机制已在当前卡面；QLDB退役不影响该正确链。'),
673:('DISTRACTOR_ONLY',['FSX_GATEWAY_SCOPE'],
     'FSx File Gateway仅在C，它不把FSx后端变成可套S3 Lifecycle的对象桶。B是S3 File Gateway加S3归档；24小时用Deep Archive Standard约12小时范围，不能选通常48小时的Bulk。'),
702:('EXISTING_USAGE_ESTABLISHED_BY_ORIGINAL',['SNOW_CURRENT_EXISTING','SNOW_NEW_CUSTOMERS'],
     '原文已经说copies onto devices且sending devices back，实际已持有并使用设备。无需新增“是否能新订”的缺项。当前B先导入S3再关联Lustre SSD；不把停止新客或旧型号停订泛化成已有返运任务无效。'),
718:('DISTRACTOR_VIOLATES_ON_PREMISES_COMPUTE',['SNOW_CURRENT_EXISTING','SNOW_NEW_CUSTOMERS'],
     'Snowball仅在D，D把数据送S3再在Region EMR处理，违反必须留机房计算的硬条件；资格不会改变。C采用受支持Outposts上的EMR，当前卡已明确这条本地处理路径。'),
784:('DECISIVE_SERVICE_ELIGIBILITY_INPUT_MISSING',['PIPELINE_SCOPE','PIPELINE_WORKFLOW','PIPELINE_MANAGED_WORK','PIPELINE_RETRIES','PIPELINE_DEPENDENCIES','PIPELINE_CONCURRENCY','PIPELINE_RETRY_DELAY','DATABREW_REMAINS_SUPPORTED'],
     '不能仅把D当过时名词。Data Pipeline仍供既有客户，官方明确其依赖、重试与并发字段。原文只给regular intervals，没有排除每日午夜；该间隔可用独立并行活动加后续dependsOn。对合格旧客户D与C均可承载所问编排目标；新客户D不能开通。'),
799:('DISTRACTOR_WRONG_TASK',['FORECAST_SCOPE'],
     'Amazon Forecast仅在B，题目任务是已在S3的食谱文本抽实体而非时序预测。即使已有Forecast资格，也不把它变成成分实体提取模型；A的S3事件和文本理解判断维持。未扩查所有通用文本模型或再加泛泛语言检查。'),
805:('DISTRACTORS_NOT_LOCAL_EKS_PLATFORM',['SNOW_CURRENT_EXISTING','SNOW_NEW_CUSTOMERS','SNOWMOBILE_SHUTDOWN','FULL_SHUTDOWN_MEANING'],
     'Snowmobile B已全面关闭，Snowball D资格受限；即使有可用设备，也不代替题目需要的现场AWS EKS local cluster。C Outposts把控制面/节点留现场，仍匹配驻留条件。'),
887:('DISTRACTOR_WRONG_CONTROL',['MIGRATION_HUB_SCOPE'],
     'Migration Hub只在D，给迁移工具配KMS key不形成账户/Region的EBS默认创建加密约束。A所教的EBS默认加密控制不依赖Hub资格。'),
1010:('DISTRACTOR_WRONG_MIGRATION_TYPE',['A2C_SCOPE'],
      'App2Container只在E，既有资格也只是分析并生成容器工件，不是VM lift-and-shift复制/测试/切换流程。当前B+C+D的Application Migration Service链不依赖A2C资格。')
}
def close(ids):
 seen=set(ids);todo=list(ids)
 while todo:
  for dep in pool[todo.pop()]['prerequisiteRuleIds']:
   if dep not in seen:seen.add(dep);todo.append(dep)
 return sorted(seen)
def full_anchors(ids):
 return [{'ruleId':k,'bodySha256':pool[k]['bodySha256'],'field':f,'quote':q,'quoteStart':0,'quoteEnd':len(q)}for k in ids for f,q in pool[k]['visibleBody'].items()if q]
rows=[]
for case in cases:
 qid=case['qid'];q=case['question'];prior=old[qid];p=prior['proof'];assert sha(prior['proofPath'])==prior['proofSha256']
 kind,refs,reason=scope[qid];ids=p.get('usedRuleIds',p.get('directlyUsedRuleIds',[]));assert ids
 # Exact necessary old clauses are reused. Q673 has harmless wording revisions, so bind the actual current context.
 a=[];refreshed=[]
 for z in p.get('necessaryAnchors',p.get('necessaryPremiseAnchors',[])):
  k=z.get('ruleId',z.get('cardId'));field=z['field'];quote=z['quote'];text=pool[k]['visibleBody'][field]
  if quote not in text:refreshed.append(k);continue
  start=text.index(quote);a.append({'ruleId':k,'bodySha256':pool[k]['bodySha256'],'field':field,'quote':quote,'quoteStart':start,'quoteEnd':start+len(quote)})
 if qid in [65,673,784]:a=full_anchors(ids)
 assert a
 status='SOURCE_ISSUE'if qid in [65,784]else'SUPPORTED'
 selected=p['selectedOptionOrdinals'] if status=='SUPPORTED'else[]
 options=[{'ordinal':x['ordinal'],'originalLabel':x['originalLabel'],'textSha256':hashlib.sha256(x['text'].encode()).hexdigest(),
   'riskScopeAssessment':'Known service/model restriction inspected in the context of this complete option; no keyword-only defect conclusion.'}for x in q['options']]
 row={'qid':qid,'status':status,'selectedOptionOrdinals':selected,
  'candidateOptionOrdinals':([3]if qid==65 else[3,4]if qid==784 else[]),
  'questionCanonicalSha256':objsha(q),'originalStemUtf8Sha256':hashlib.sha256(q['stem'].encode()).hexdigest(),
  'originalOptionsCanonicalSha256':objsha(q['options']),'fullStemAndAllOptionsRead':True,
  'auditScope':'Known service eligibility, full shutdown versus new-customer restriction, and explicitly relevant Comprehend Medical language boundary only.',
  'serviceScopeSearchHits':case['serviceScopeSearchHits'],'searchIsNotSemanticDependency':True,
  'scopeFinding':kind,'reasoningAndClosestCompetitor':reason,
  'priorKnowledgeProofReuse':{'path':prior['proofPath'],'fileSha256':prior['proofSha256'],'proofRowCanonicalSha256':objsha(p),
    'priorStatus':p['status'],'priorSelectedOptionOrdinals':p['selectedOptionOrdinals'],
    'scope':'Other technical selection reasoning reused only where the necessary visible clauses remain applicable; this is not a new global review.'},
  'usedRuleIds':ids,'necessaryAnchors':a,'actualUsedRuleIdsIncludingRecursivePrerequisites':close(ids),
  'cardBindings':[{'ruleId':k,'bodySha256':pool[k]['bodySha256'],'prerequisiteRuleIds':pool[k]['prerequisiteRuleIds']}for k in close(ids)],
  'recursiveUsedPrerequisiteBindings':[{'ruleId':k,'bodySha256':pool[k]['bodySha256'],'prerequisiteRuleIds':pool[k]['prerequisiteRuleIds']}for k in close(ids)if k not in ids],
  'currentQuoteRefreshRuleIds':sorted(set(refreshed)),'optionReadback':options,'officialEvidenceIds':refs,
  'sourceIssue':None,'knownUnrelatedKnowledgeGaps':[],
  'ordinaryImplementationNotNewGates':'No generic source-platform compatibility check, deployment exercise or production SLA measurement is added. Existing device usage/project qualification is read from the actual original.',
  'originalModified':False,'currentOrInventoryModified':False,'learnerEffectMeasured':False}
 if qid==65:
  row['sourceIssue']={'confirmed':True,'subtype':'decisive_input_missing','missingDecisiveInput':'PDF/JPEG报告实际语言是否US-English',
   'positiveTechnicalBasis':'官方Comprehend Medical只检测US-EN文字医疗实体；Textract对打印西班牙文PDF/JPEG有正向OCR支持。原文没有英文限定，不能从当前卡面题干借入。',
   'counterfactualScenarios':[
    {'condition':'医院的所有报告均为清晰打印的US-English PDF/JPEG，正常支持的格式、页数和大小；需要现成托管PHI识别。','outcome':'C的Textract→Comprehend Medical直接可用，比自建OCR/PHI模型减少维护。'},
    {'condition':'相同报告格式与PHI目标，报告为清晰打印的西班牙文，不含英文正文；Textract可提取该语言文本。','outcome':'C/D的Comprehend Medical不能直接完成这些原语言PHI识别；须改用适用模型或增加明确翻译/处理路径，不能仍报原C充分。'}],
   'minimalCorrectionFields':{'language':'若练习C，只补US-English报告这一决定输入；该值是练习设定，不能倒写原文。'},
   'newValuesAreExerciseInputsNotRecoveredOriginalFacts':True}
 if qid==784:
  row['sourceIssue']={'confirmed':True,'subtype':'decisive_input_missing','missingDecisiveInput':'公司是否具备AWS Data Pipeline既有有效使用资格',
   'positiveTechnicalBasis':'当前官方仍给旧客户使用权，支持data-driven workflow、dependsOn、maximumRetries、retryDelay及活动并发。每日午夜是原文未排除的regular interval；D不是由于缺这些机制而必错。题面只要求免自写job错误/重试/状态管理，未额外要求零EC2基础设施。',
   'counterfactualScenarios':[
    {'condition':'公司已是Data Pipeline合格旧客户。S3营销CSV每日午夜开跑两项独立准备活动，之后两项按dependsOn串行；Data Pipeline正常定义受支持EC2/ShellCommandActivity及maximumRetries/retryDelay。','outcome':'D能满足同样的定期并行、后续依赖和托管任务状态/重试目标；C的DataBrew+Step Functions也可用，原题没有额外目标排除D。'},
    {'condition':'完全相同的S3文件、每日午夜并行/顺序准备及错误/重试目标，但公司此前没有Data Pipeline服务资格，是该服务的新客户。','outcome':'D不能开通，C仍可由DataBrew和Step Functions实现；可行候选集合发生变化。'}],
   'minimalCorrectionFields':{'eligibility':'若练习当前C，可只明确公司无Data Pipeline既有资格；或按明确的既有资格改为选择全部满足目标的方案，不追加原文没有的产品偏好。'},
   'newValuesAreExerciseInputsNotRecoveredOriginalFacts':True}
  row['knownCorrectionCardImpact']='若另存练习保留既有Data Pipeline并要求ALL，当前卡只教C的编排机制，不能用本次私有官方研究代替D的可见教学；本次不报该练习PASS。'
 rows.append(row)
out={'schemaVersion':1,'reviewId':'unchanged-service-scope01','reviewer':'/root/domain_primary_audit',
 'completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'18 targeted original questions outside the A/B224 pass; no full-library rerun.',
 'inputManifestPath':str((P/'manifest.json').resolve()),'inputManifestSha256':sha(P/'manifest.json'),'inputHashes':manifest,
 'priorProofSnapshotBinding':{'path':str((E/'prior-proof-snapshot.json').resolve()),'sha256':sha(E/'prior-proof-snapshot.json')},
 'frozenVisiblePoolCount':362,'candidateCountIsFinalN':False,'officialEvidenceRegistry':sources,'results':rows,
 'counts':dict(collections.Counter(r['status']for r in rows)),
 'noKeywordOnlyDefects':True,'originalsCurrentInventoryMainRunModified':False,'newCardsAuthored':0,'variantsAuthored':0,
 'externalModelCliApiCalls':0,'nativeUsage':'unknown','clockBudgetHistoryReset':False,
 'unusedFetchNotes':['datapipeline-faq URL redirected to a Glue marketing page; it is not used as Data Pipeline evidence.'],
 'limits':['SUPPORTED means design support only, not measured learner accuracy or production SLA.',
  'Known current Elastic Transcoder retirement disposition for Q302 was already A+E; no original option was silently replaced.',
  'The broad General Reference Snowball Edge label is not used to negate the more specific current existing-customer/device guidance.']}
(R/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':out['counts'],'sourceIssueQids':[r['qid']for r in rows if r['status']=='SOURCE_ISSUE'],'currentQuoteRefreshQids':[r['qid']for r in rows if r['currentQuoteRefreshRuleIds']]},ensure_ascii=False,indent=2))

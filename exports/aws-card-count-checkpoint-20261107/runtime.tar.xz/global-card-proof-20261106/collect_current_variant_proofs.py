from pathlib import Path
import json,hashlib,collections,copy
V=Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106');rd=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();wr=lambda p,x:Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');latest={}
for p in sorted((V/'deliverables').glob('corrected-variants.source-errors*.json')):
 for c in rd(p):latest[c['originalQid']]=(c,p)
a=V/'review/final-core-closure01/a/results.json';proofs={c['variantId']:(c,a) for c in rd(a)['correctedPracticeResults']}
for f,key in [('review/corrected-variants09/results.json','results'),('review/corrected-variants10-current01/results.json','results'),('review/reuse-a/supplemental13.review.json','correctedPracticeResults'),('review/reuse-a/supplemental14.review.json','correctedVariantImpactReview'),('review/reuse-a/supplemental15.review.json','correctedVariantImpactReview')]:
 rp=V/f
 if rp.exists():
  for r in rd(rp).get(key,[]):
   if 'variantId' in r:proofs[r['variantId']]=(r,rp)
for f,key in [('review/corrected-variants11/results.json','results'),('review/reuse-a/supplemental17.review.json','correctedVariantImpactReview'),('review/reuse-a/supplemental18.review.json','correctedVariantImpactReview'),('review/corrected-variants13/results.json','results')]:
 rp=V/f
 if rp.exists():
  for r in rd(rp).get(key,[]):
   if 'variantId' in r:proofs[r['variantId']]=(r,rp)
cards={c['ruleId']:c for c in rd(V/'deliverables/cards.current.json')};states={c['ruleId']:c['status'] for c in rd(V/'validation/current-card-review-index.json')['cards']};rows=[]
for qid,(c,p) in sorted(latest.items()):
 pair=proofs.get(c['variantId']);issues=[];effective='PENDING_INDEPENDENT_REVIEW'
 if pair:
  r,rp=pair
  if r.get('correctedQuestionCanonicalSha256')!=c['correctedQuestionCanonicalSha256']:issues.append('variant question changed')
  for an in r.get('necessaryAnchors',[]):
   rid=an['ruleId'];b=cards.get(rid)
   if not b or b['bodySha256']!=an.get('bodySha256') or an.get('quote','') not in b['visibleBody'].get(an.get('field',''),'') or states[rid]!='PASS':issues.append('current body or necessary quote changed: '+rid)
  for e in r.get('actualVisibleGroup',[])+r.get('cardBindings',[])+r.get('recursiveUsedPrerequisiteBindings',[]):
   rid=e['ruleId'];b=cards.get(rid)
   if not b or e.get('bodySha256')!=b['bodySha256'] or states[rid]!='PASS':issues.append('recursive/used body binding changed: '+rid)
  effective='NEEDS_CURRENT_DEPENDENCY_RECHECK' if issues else 'ELIGIBLE' if r.get('closureEligibleUnderAcceptedCorrectionPolicy',r.get('closureEligible',False)) else 'NOT_ELIGIBLE'
 else:r={};rp=None
 rows.append(dict(originalQid=qid,variantId=c['variantId'],variantPath=str(p),variantFileSha256=sha(p),currentEffectiveStatus=effective,independentProofPath=str(rp) if rp else None,independentProofSha256=sha(rp) if rp else None,latestIndependentStatus=r.get('status',r.get('standalonePracticeCardGroupStatus')),minimalityVerdict=r.get('minimalityVerdict',r.get('minimality',{}).get('status')),currentBindingIssues=issues,originalStatusNeverPromoted=True))
wr(V/'validation/current-corrected-variant-index.json',dict(scope='Current unique latest variants and exact necessary-body binding; no semantic or policy certification by this formatter',counts=dict(collections.Counter(c['currentEffectiveStatus'] for c in rows)),uniqueOriginalsWithDraftVariants=len(rows),rows=rows,finalCardCountVerified=False));print('variants',len(rows),dict(collections.Counter(c['currentEffectiveStatus'] for c in rows)))

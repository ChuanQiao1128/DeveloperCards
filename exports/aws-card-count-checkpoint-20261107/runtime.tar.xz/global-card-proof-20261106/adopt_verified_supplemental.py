import pathlib,json,hashlib,shutil,subprocess,datetime,sys
V=pathlib.Path('/Users/qc/.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106');rd=lambda p:json.loads(pathlib.Path(p).read_text());sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();wr=lambda p,x:pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');ch=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();name,batch,repair=sys.argv[1:4];p=V/'review/reuse-a'/(name+'.review.json');r=rd(p);mp=pathlib.Path(r['inputManifestPath']);assert sha(mp)==r['inputManifestSha256']
for f,h in rd(mp).items():assert sha(f)==h,f
assert str(rd(p.with_name(name+'.readback.json'))['status']).startswith('PASS')
for f in ['deliverables/cards.current.json','validation/current-card-review-index.json','deliverables/core-selection.provisional.json','deliverables/core-visible-knowledge.provisional.json','inputs/supplemental-catalogue.approved.json']:
 f=V/f;a=V/'validation/immutable-contexts'/(sha(f)+'.json')
 if not a.exists():shutil.copyfile(f,a)
cs=rd(V/'drafts'/(name+'.json'));rs=r.get('cards',r.get('results',[]));adopt=[c for c in cs if any(x.get('ruleId')==c['ruleId'] and x.get('status',x.get('verdict'))=='PASS' and x.get('bodySha256')==ch({k:c.get(k,'') for k in ['frontZH','answerZH','keyPointZH','watchOutZH']}) for x in rs)];assert adopt
currentids={c['ruleId'] for c in rd(V/'deliverables/cards.current.json')};new=[c for c in adopt if c['ruleId'] not in currentids];old=[c for c in adopt if c['ruleId'] in currentids]
for n,rows in [(batch,new),(repair,old)]:
 if not rows:continue
 f=V/'drafts'/(n+'.json');assert not f.exists();wr(f,rows)
approved=rd(V/'inputs/supplemental-catalogue.approved.json');pn=V/'inputs'/(name.replace('supplemental','supplemental-catalogue')+'.proposed.json');props=rd(pn) if pn.exists() else []
for c in props:
 if c['ruleId'] not in {x['ruleId'] for x in new}:continue
 if name=='supplemental10' and c['ruleId']=='VC-012':c['questionIds']=[534];c['reason']='最低存储计费独立规则；独立审查只确认Q534必要partial，其余旧候选关联不成立。核心纳入和其他用途待最终全池核验。'
 c.update(displayId=c['ruleId'].replace('-',''),recallTask=next(x['frontZH'] for x in new if x['ruleId']==c['ruleId']),formalNewUidCreated=False,designOnly=True,coreStatus='PROVISIONAL_PENDING_FINAL_WHOLE_QUESTION_CLOSURE',approvalBasis='Independent current body and whole-pool substitution checks; final necessity pending',evidenceReceipts=[dict(path=str(p),sha256=sha(p))]);approved.append(c)
assert {x['ruleId'] for x in new}<={x['ruleId'] for x in approved};wr(V/'inputs/supplemental-catalogue.approved.json',approved)
subprocess.run(['python3',str(V/'assemble_current.py')],check=True);subprocess.run(['python3',str(V/'write_card_status.py')],check=True)
cur=rd(V/'deliverables/cards.current.json');omit=currentids-set(rd(V/'deliverables/core-selection.provisional.json')['selectedRuleIds']);pool=[c for c in cur if c['ruleId'] not in omit];ix={c['ruleId']:c['status'] for c in rd(V/'validation/current-card-review-index.json')['cards']};assert all(ix[c['ruleId']]=='PASS' for c in pool)
s=rd(V/'deliverables/core-selection.provisional.json');s.update(selectedRuleIds=[c['ruleId'] for c in pool],selectedCount=len(pool),currentCardBodiesSha256=sha(V/'deliverables/cards.current.json'),finalCoreCountVerified=False,lastRefresh=name+' passing bodies only; failed candidates not adopted');wr(V/'deliverables/core-selection.provisional.json',s);wr(V/'deliverables/core-visible-knowledge.provisional.json',pool)
wr(V/'validation'/(name+'-adoption.json'),dict(status='LOCAL_PASSED_BODY_ADOPTION',adoptedRuleIds=[c['ruleId'] for c in adopt],notAdoptedRuleIds=[c['ruleId'] for c in cs if c not in adopt],receipt=dict(path=str(p),sha256=sha(p)),candidates=len(cur),provisionalCoreCount=len(pool),finalNVerified=False,atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
cp=V/'collect_current_proofs.py';s=cp.read_text();needle='\n\ndef binding_issues(entry, current_cards):';key='questionImpactReview' if 'questionImpactReview' in r else 'affectedQuestions';line="\nadd('review/reuse-a/%s.review.json', key='%s')\n"%(name,key);assert line not in s;s=s.replace(needle,line+needle);cp.write_text(s);subprocess.run(['python3',str(cp)],check=True);print('ADOPT',name,len(adopt),'N_PROVISIONAL',len(pool))

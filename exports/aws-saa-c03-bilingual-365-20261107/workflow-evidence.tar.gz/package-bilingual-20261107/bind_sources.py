from pathlib import Path
import json,hashlib,re,html
p=Path.home()/'.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106/package-bilingual-20261107';r=p.parent
rd=lambda f:json.loads(Path(f).read_text());sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
reuse=rd(r/'review/reuse-a/reuse-results.json');old={x['ruleId']:x for x in reuse['results']};proof={x['ruleId']:x for x in rd(r/'validation/current-card-review-index.json')['cards']};current={x['ruleId']:x for x in rd(r/'deliverables/cards.current.json')};order=rd(p/'order.json')
cat=rd(r.parent/'domain1-final-card-catalog-20261105/official-sources.catalog.json');byurl={}
for x in cat: byurl.setdefault(x['url'],[]).append(x)
# Extra official snapshots retain their existing quote/text and exact file hash.
for f in (r/'evidence').rglob('*.json'):
 try:x=rd(f)
 except (ValueError,OSError):continue
 if isinstance(x,dict) and isinstance(x.get('url'),str):byurl.setdefault(x['url'],[]).append(dict(sourcePath=str(f),fileSha256=sha(f),url=x['url']))
for f in (r/'evidence').rglob('*.html'):
 text=f.read_text(errors='replace')
 urls=re.findall(r'<link[^>]*rel=[\"\']canonical[\"\'][^>]*href=[\"\']([^\"\']+)',text,re.I)
 urls+=re.findall(r'<link[^>]*href=[\"\']([^\"\']+)[\"\'][^>]*rel=[\"\']canonical[\"\']',text,re.I)
 for u in urls:
  u=html.unescape(u)
  if u.startswith('https://'):byurl.setdefault(u,[]).append(dict(url=u,sourcePath=str(f),fileSha256=sha(f)))
out={};unbound=[]
for rid in order:
 c=current[rid];b=proof[rid];assert b['status']=='PASS' and b['currentBodySha256']==c['bodySha256'],rid
 for x in b['proofs']:assert sha(x['path'])==x['sha256'],(rid,x['path'])
 oldEvidence=[reuse['sourceEvidenceRegistry'][i] for i in old.get(rid,{}).get('factEvidenceIds',[])]
 urls=list(dict.fromkeys((c.get('sourceUrls') or [])+[x['url'] for x in oldEvidence]))
 assert urls and all(x.startswith(('https://docs.aws.amazon.com/','https://aws.amazon.com/','https://pricing.us-east-1.amazonaws.com/')) for x in urls),(rid,urls)
 refs=[]
 for url in urls:
  for x in byurl.get(url,[]):
   f=Path(x['sourcePath'])
   if f.exists() and (not x.get('fileSha256') or sha(f)==x['fileSha256']):
    refs.append(dict(x,fileSha256=sha(f),priorManifestHashProvided=bool(x.get('fileSha256'))));break
  else:
   if not any(x['url']==url for x in oldEvidence):unbound.append([rid,url])
 out[rid]=dict(sourceUrls=urls,currentBodySha256=c['bodySha256'],currentChineseReview=b,priorOfficialQuotes=oldEvidence,snapshotReferences=refs,priorQuotesScope='prior facts only; changed body acceptance is bound by currentChineseReview')
previous=rd(p/'source-bindings.json') if (p/'source-bindings.json').exists() else {}
for rid,row in out.items():
 for key in ['supplementalCurrentSnapshots','unavailableSupplementalUrls','sourceUrlCorrection']:
  if key in previous.get(rid,{}):row[key]=previous[rid][key]
 if row.get('sourceUrlCorrection'):row['sourceUrls']=previous[rid]['sourceUrls']
(p/'source-bindings.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
historicalInvalid=[];remaining=[]
for rid,url in unbound:
 row=out[rid]
 if any(x['url']==url and x['status']=='stored' for x in row.get('supplementalCurrentSnapshots',[])):continue
 if row.get('sourceUrlCorrection',{}).get('invalidOriginalUrl')==url:historicalInvalid.append([rid,url]);continue
 remaining.append([rid,url])
(p/'source-binding-check.json').write_text(json.dumps(dict(cards=len(out),withUrls=sum(bool(x['sourceUrls']) for x in out.values()),unresolvedSnapshotUrls=remaining,historicalInvalidUrlsRetained=historicalInvalid,supplementalSnapshotsAreNotHistoricalFactReceipts=True),ensure_ascii=False,indent=2)+'\n')
print('source bindings',len(out),'unresolved URLs',len(unbound))
print(unbound[:8])

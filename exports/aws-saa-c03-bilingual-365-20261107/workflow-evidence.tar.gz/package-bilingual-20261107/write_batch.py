from pathlib import Path
import json,sys,hashlib
p=Path.home()/'.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106/package-bilingual-20261107'
c={x['ruleId']:x for x in json.loads((p.parent/'deliverables/cards.current.json').read_text())}
rows=json.load(sys.stdin);out=[]
for rid,kind,tz,te,q,a,k,w,m in rows:
 assert kind in ['Easy','Rare','Legend'] and rid in c
 assert all(isinstance(v,str) and v.strip() for v in [tz,te,q,a,k])
 assert isinstance(m,list) and 1<=len(m)<=3
 out.append(dict(ruleId=rid,kind=kind,topicZh=tz,topicEn=te,frontEn=q,answerEn=a,keyPointEn=k,watchOutEn=w,learningGoal=c[rid]['visibleBody']['frontZH'],mustAnswer=m,sourceBodySha256=c[rid]['bodySha256']))
f=p/'batches'/('batch-'+sys.argv[1]+'.json');assert not f.exists(),f
f.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(f.name,len(out))

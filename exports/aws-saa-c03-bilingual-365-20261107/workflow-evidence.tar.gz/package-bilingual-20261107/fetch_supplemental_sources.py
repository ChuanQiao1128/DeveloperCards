from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request,urlopen
import json,hashlib,datetime,subprocess
p=Path.home()/'.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106/package-bilingual-20261107';d=p/'source-snapshots';d.mkdir(exist_ok=True)
urls=sorted({u for _,u in json.loads((p/'source-binding-check.json').read_text())['unresolvedSnapshotUrls']});index=d/'manifest.json';old=json.loads(index.read_text()) if index.exists() else {};out=dict(old)
def fetch(u):
 if u in old and old[u].get('status')=='stored':return u,old[u]
 try:
  result=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','25',u],capture_output=True,check=True)
  data=result.stdout;target=u;ctype='text/html'
  f=d/(hashlib.sha256(u.encode()).hexdigest()+('.json' if 'json' in ctype else '.html'));f.write_bytes(data)
  return u,dict(status='stored',url=u,finalUrl=target,sourcePath=str(f),fileSha256=hashlib.sha256(data).hexdigest(),fetchedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),provenance='supplemental current official snapshot; does not replace historical FACT receipt')
 except Exception as e:return u,dict(status='fetch_failed',url=u,error=type(e).__name__+': '+str(e)[:150])
with ThreadPoolExecutor(max_workers=3) as pool:
 for i,(u,x) in enumerate(pool.map(fetch,urls),1):
  out[u]=x;index.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
  if i%20==0:print('archived',i,'/',len(urls),flush=True)
print('stored',sum(x['status']=='stored' for x in out.values()),'failed',sum(x['status']!='stored' for x in out.values()),flush=True)

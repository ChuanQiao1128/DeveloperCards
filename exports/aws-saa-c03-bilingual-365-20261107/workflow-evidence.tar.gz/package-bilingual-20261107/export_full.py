from pathlib import Path
import json,hashlib,tarfile,shutil,datetime,io
repo=Path('/Users/qc/Desktop/DeveloperCards');r=Path.home()/'.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106';p=r/'package-bilingual-20261107';out=repo/'exports/aws-saa-c03-bilingual-365-20261107';out.mkdir(exist_ok=True)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();rd=lambda f:json.loads(Path(f).read_text())
for name in ['cards.deck.md','cards.json','cards.public.json','cards.import.json','cards.private.json','progress.json','WORKFLOW.md','validation365.json','current-review-index.json','completion.json','domain-index.json']:
 shutil.copy2(p/name,out/name)
refs={}
for row in rd(p/'source-bindings.json').values():
 for x in row['priorOfficialQuotes']+row['snapshotReferences']+row['currentChineseReview']['proofs']:
  f=Path(x.get('sourcePath',x.get('path','')))
  if f.is_file() and p not in f.parents:
   digest=sha(f);refs[str(f)]={'sha256':digest,'archivePath':'evidence-files/'+digest+f.suffix,'bytes':f.stat().st_size}
archive=out/'workflow-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:t.add(f,arcname='package-bilingual-20261107/'+str(f.relative_to(p)),recursive=False)
 added=set()
 for origin,x in refs.items():
  if x['archivePath'] not in added:t.add(origin,arcname=x['archivePath'],recursive=False);added.add(x['archivePath'])
 for name in ['deliverables/cards.current.json','deliverables/core-selection.provisional.json','validation/s8-domain-attribution.json','validation/current-card-review-index.json','workflow-auto-closeout-20261107/state.json']:
  t.add(r/name,arcname='global-inputs/'+name,recursive=False)
 index=json.dumps(refs,ensure_ascii=False,indent=2).encode();info=tarfile.TarInfo('evidence-index.json');info.size=len(index);t.addfile(info,io.BytesIO(index))
with tarfile.open(archive,'r:gz') as t:
 for x in refs.values():assert hashlib.sha256(t.extractfile(x['archivePath']).read()).hexdigest()==x['sha256']
manifest=dict(status='COMPLETE_LOCAL_BILINGUAL_PACKAGE',cards=365,planned=365,remaining=0,formalBilingualPackageComplete=True,archiveSha256=sha(archive),archivedExternalReferenceFiles=len(refs),evidenceIndexPath='evidence-index.json',files={f.name:sha(f) for f in out.iterdir() if f.is_file() and f.name not in ['manifest.json','README.md']},createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(out/'README.md').write_text("""# AWS SAA-C03双语核心卡包

**365张，365/365通过本地独立总验。未发布、未OTA。**

- [阅读稿](cards.deck.md)、[导入JSON](cards.import.json)、[公开数据](cards.public.json)、[私有数据与证据](cards.private.json)。
- [四领域导航](domain-index.json)：唯一主归116/46/159/44；含共享复习159/137/197/117。共享引用使用同一stableUid，不复制正文。
- [最终完成凭证](completion.json)、[逐卡语义索引](current-review-index.json)、[完整性验证](validation365.json)、[最终状态](progress.json)、[自动工作流](WORKFLOW.md)。完成状态以completion.json为准；归档中较早formal:false仅记录当时尚未完成总验。
- [工作流与证据归档](workflow-evidence.tar.gz)保留36批译文、初审/局部修复、旧失败、独立总验、365张中文来源绑定、123份补采官方页面及665份原引用文件。evidence-index.json将原绝对路径映射到便携副本；原运行目录仍保留，历史全库证明可沿既有保存点续查。

题侧范围：899原题充分＋115最小纠错练习＋4用户接受例外Q49/201/454/783。例外不算原题充分，练习不升级原题状态。学习者真实记忆和正确率未测。

验证：真实parser、translationRules、严格Linter及roundtrip零错误零警告；旧347 UID交集0；无先修悬空或环；四域导航逐UID集合一致；原中文正文未改。来源回读保留原FACT receipt与补采provenance；GCL-008错误链接及纠正证据均保留。逐文件和归档SHA见manifest.json。

正式库存和学习记录未改，手机导入与生产发布不在本地包验收中。历史时钟、预算与失败谱系保留，新增内容模型CLI/API调用0、native用量未知。
""")
print(json.dumps({'directory':str(out),'files':len(list(out.iterdir())),'archiveMB':round(archive.stat().st_size/1e6,2),'externalReferences':len(refs),'archiveHash':sha(archive)}))

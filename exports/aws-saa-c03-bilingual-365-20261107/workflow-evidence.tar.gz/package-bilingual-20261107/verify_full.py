from pathlib import Path
import json,hashlib,re,subprocess,sys,datetime,tempfile,shutil
p=Path.home()/'.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106/package-bilingual-20261107'
rd=lambda f:json.loads(Path(f).read_text());sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
public=rd(p/'cards.json');private=rd(p/'cards.private.json')['cards'];review=rd(p/'current-review-index.json');order=rd(p/'order.json');source=rd(p/'source-bindings.json');pool={x['ruleId']:x for x in rd(p.parent/'deliverables/cards.current.json')};old=rd(p.parents[2]/'regenerate-publish-20261030/current347-complete-deck-inventory.json')
assert len(public)==len(private)==review['semanticPassed']==review['authored']==365
assert len(order)==len(set(order))==365
assert set(x['ruleId'] for x in private)==set(order)
assert not review['authoredAwaitingReview'] and not review['unmatchedReviewInputs']
uids={x['stableUid'] for x in public};assert len(uids)==365
assert all(re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*',u) and len(u)<=128 for u in uids)
oldids={x['stableUid'] for x in old['items']};assert len(oldids)==347 and not oldids&uids
keys={x['cardKey'] for x in private};plannedkeys={r.replace('CUR:','').replace(':','-').lower() for r in order};pending=[]
for pub,pri in zip(public,private):
 assert pub['stableUid']==pri['stableUid'] and pub['difficulty']=={'Easy':1,'Rare':2,'Legend':3}[pri['kind']]
 assert pub['translations']['zh-CN']['v']==1 and pub['source']['url'].startswith('https://')
 b=pool[pri['ruleId']]['visibleBody']
 for a,z in [('frontZh','frontZH'),('answerZh','answerZH'),('keyPointZh','keyPointZH'),('watchOutZh','watchOutZH')]:assert pri[a]==b.get(z,'').strip()
 for k in pri['prerequisiteCardKeys']:
  assert k in plannedkeys
  if k not in keys:pending.append(dict(card=pri['ruleId'],prerequisite=k))
 assert source[pri['ruleId']]['currentBodySha256']==pool[pri['ruleId']]['bodySha256']
 assert review['cards'][pri['ruleId']]['chineseBodySha256']==pool[pri['ruleId']]['bodySha256']
 assert len(pri['mustAnswer']) in [1,2,3]
files=['cards.deck.md','cards.json','cards.public.json','cards.import.json','cards.private.json'];before={f:sha(p/f) for f in files}
assert not pending, 'Unresolved prerequisites'
# A missing-batch control runs in an isolated tree and must not overwrite sentinel outputs.
with tempfile.TemporaryDirectory() as temp:
 root=Path(temp);q=root/'package';q.mkdir();(q/'batches').mkdir()
 for name in ['deliverables','validation']:(root/name).symlink_to(p.parent/name,target_is_directory=True)
 for name in ['assemble.py','source-bindings.json']:shutil.copy2(p/name,q/name)
 for f in (p/'batches').glob('batch-*.json'):
  if f.name!='batch-36.json':shutil.copy2(f,q/'batches'/f.name)
 for name in files:(q/name).write_text('sentinel')
 r=subprocess.run([sys.executable,str(q/'assemble.py'),'all'],capture_output=True,text=True)
 assert r.returncode and 'Missing requested translations: 10' in r.stderr
 assert all((q/name).read_text()=='sentinel' for name in files)
assert before=={f:sha(p/f) for f in files}, 'Current outputs changed'
assert rd(p/'source-binding-check.json')['unresolvedSnapshotUrls']==[]
out=dict(status='PASS_ALL_365_STRUCTURE_AND_CURRENT_RECEIPTS',atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),authored=365,independentSemanticPassed=365,planned=365,remaining=0,old347UidIntersection=0,untranslatedPrerequisites=pending,allAssemblyFailsClosedWithoutOverwrite=True,outputHashes=before,formalBilingualPackageComplete=False,published=False,learnerOutcomeMeasured=False)
(p/'validation365.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='outputHashes'}))

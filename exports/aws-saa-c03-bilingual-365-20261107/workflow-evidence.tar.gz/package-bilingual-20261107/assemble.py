"""Assemble bilingual deck + public/private/import JSONs from authored translation batches.
Deterministic: ZH fields and sources come from deliverables/cards.current.json; EN fields and
kind/mustAnswer/topicEn come from authored batches/batch-NN.json."""
from pathlib import Path
import json, hashlib, re, sys
from datetime import datetime, timezone
V = Path(__file__).resolve().parent.parent
P = Path(__file__).resolve().parent
rd = lambda p: json.loads(Path(p).read_text())
wr = lambda p, x: Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
cards = {c['ruleId']: c for c in rd(V / 'deliverables/cards.current.json')}
dom = rd(V / 'validation/s8-domain-attribution.json')
primary = {r: d for d, cats in dom['uniquePrimaryCards'].items() for r in cats}
order = sorted(dom['uniquePrimaryCards']['1']) + sorted(dom['uniquePrimaryCards']['2']) + sorted(dom['uniquePrimaryCards']['3']) + sorted(dom['uniquePrimaryCards']['4'])
sources = rd(P / 'source-bindings.json') if (P / 'source-bindings.json').exists() else {}
batches = {}
for f in sorted((P / 'batches').glob('batch-*.json')):
    for e in rd(f):
        assert e['ruleId'] not in batches, 'duplicate ' + e['ruleId']
        batches[e['ruleId']] = e
KDIFF = {'Easy': 1, 'Rare': 2, 'Legend': 3}
def slugify(front_zh, rule_id):
    s = re.sub(r'[^0-9A-Za-z\u4e00-\u9fff]+', '-', front_zh)[:0]  # slug from rule id instead
    base = rule_id.replace('CUR:', '').replace(':', '-').lower()
    return base
def build_card(rid):
    c = cards[rid]; e = batches[rid]; b = c['visibleBody']
    assert e['kind'] in KDIFF, e['kind']
    if e.get('sourceBodySha256'): assert e['sourceBodySha256'] == c['bodySha256'], rid
    front_zh = b['frontZH'].strip()
    a_zh = '答：' + b['answerZH'].strip()
    kp = b.get('keyPointZH', '').strip()
    if kp: a_zh += '\n考点：' + kp
    wo = b.get('watchOutZH', '').strip()
    if wo: a_zh += '\n易错提醒：' + wo
    a_en = 'Answer: ' + e['answerEn'].strip()
    if e.get('keyPointEn'): a_en += '\nKey point: ' + e['keyPointEn'].strip()
    if e.get('watchOutEn'): a_en += '\nWatch out: ' + e['watchOutEn'].strip()
    binding = sources.get(rid, {})
    urls = binding.get('sourceUrls') or c.get('sourceUrls') or []
    topic = (e['topicEn'].strip() + ' / ' + e['topicZh'].strip())
    card_key = slugify(front_zh, rid)
    return dict(rid=rid, cardKey=card_key,
        stableUid=f"aws-rb2-20261107-pack-{card_key}",
        kind=e['kind'], difficulty=KDIFF[e['kind']], domain=primary[rid],
        topic=topic, topicZh=e['topicZh'].strip(), topicEn=e['topicEn'].strip(),
        question=e['frontEn'].strip(), frontZh=front_zh, frontEn=e['frontEn'].strip(),
        explanation=a_en, explanationZh=a_zh,
        answerZh=b['answerZH'].strip(), keyPointZh=kp, watchOutZh=wo,
        answerEn=e['answerEn'].strip(), keyPointEn=e.get('keyPointEn','').strip(), watchOutEn=e.get('watchOutEn','').strip(),
        learningGoal=e['learningGoal'].strip(),
        mustAnswer=e['mustAnswer'],
        prerequisiteCardKeys=[slugify('', x) for x in (c.get('prerequisiteRuleIds') or [])],
        objectiveIds=[rid.lower()],
        sourceUrl=urls[0] if urls else None, sourceUrls=urls)
def deck_text(items):
    out = ['# deck: aws-saa-c03-pack-20261107', '']
    for it in items:
        out.append(f"## {it['stableUid']} | d{it['difficulty']}")
        out.append('TOPIC: ' + it['topic'])
        out.append('Q:'); out.append(it['question'])
        out.append('Q_ZH:'); out.append(it['frontZh'])
        out.append('A:'); out.append(it['explanation'])
        out.append('A_ZH:'); out.append(it['explanationZh'])
        if it['sourceUrl']:
            out.append('SOURCE: ' + it['sourceUrl'])
        out.append('')
    return '\n'.join(out)
which = sys.argv[1] if len(sys.argv) > 1 else 'all'
todo = order if which == 'all' else order[:int(which)]
assert len(order) == len(set(order)) == 365
assert set(order) == set(rd(V / 'deliverables/core-selection.provisional.json')['selectedRuleIds'])
assert not set(todo) - set(batches), 'Missing requested translations: ' + str(len(set(todo) - set(batches)))
items = [build_card(r) for r in todo if r in batches]
missing = [r for r in todo if r not in batches]
pub = [dict(stableUid=it['stableUid'], difficulty=it['difficulty'], topic=it['topic'],
            question=it['question'], explanation=it['explanation'],
            translations={'zh-CN': {'v': 1, 'question': it['frontZh'], 'explanation': it['explanationZh']}},
            **({'source': dict(url=it['sourceUrl'], quote=None)} if it['sourceUrl'] else {})) for it in items]
priv = dict(cards=[dict(cardKey=it['cardKey'], kind=it['kind'], topic=it['topic'],
            learningGoal=it['learningGoal'], frontZh=it['frontZh'], frontEn=it['frontEn'],
            answerZh=it['answerZh'], answerEn=it['answerEn'],
            keyPointZh=it['keyPointZh'], keyPointEn=it['keyPointEn'],
            watchOutZh=it['watchOutZh'], watchOutEn=it['watchOutEn'],
            mustAnswer=it['mustAnswer'], prerequisiteCardKeys=it['prerequisiteCardKeys'],
            objectiveIds=it['objectiveIds'], sourceUrls=it['sourceUrls'],
            ruleId=it['rid'], stableUid=it['stableUid'], domain=it['domain'],
            questionIds=cards[it['rid']].get('questionIds', [])) for it in items],
            officialEvidence=[dict(ruleId=it['rid'], **sources[it['rid']]) for it in items if it['rid'] in sources])
(P / 'cards.deck.md').write_text(deck_text(items))
wr(P / 'cards.public.json', pub)
wr(P / 'cards.json', pub)
wr(P / 'cards.import.json', pub)
wr(P / 'cards.private.json', priv)
wr(P / 'assembly-state.json', dict(assembledCards=len(items), totalPlanned=len(order),
    missingRequestedRuleIds=missing, remainingRuleIds=[r for r in order if r not in batches], formalBilingualPackageComplete=False, atUtc=datetime.now(timezone.utc).isoformat()))
print('assembled', len(items), 'of planned', len(order), 'missing', len(missing))

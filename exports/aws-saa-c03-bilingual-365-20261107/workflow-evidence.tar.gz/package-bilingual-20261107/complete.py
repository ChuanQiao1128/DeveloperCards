from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re
repo=Path('/Users/qc/Desktop/DeveloperCards');r=Path.home()/'.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106';p=r/'package-bilingual-20261107';rd=lambda f:json.loads(Path(f).read_text());sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();now=datetime.now(timezone.utc).isoformat();rv=p/'review/packaging365.review.json';assert rd(rv)['overallStatus']=='PASS' and sha(rv)=='364f541884019eca2ab66a7c6adaeb06c457a201c3dc6518fc30299363a7526d';v=rd(p/'validation365.json');assert v['independentSemanticPassed']==365 and not v['untranslatedPrerequisites'];assert rd(p/'current-review-index.json')['semanticPassed']==365
# Preserve both full AGENTS versions actually read by reviewers; section 4 is unchanged.
prior=(repo/'AGENTS.md').read_bytes();(p/'inputs/AGENTS.packaging245-frozen.md').write_bytes(prior)
completion=dict(status='COMPLETE_LOCAL_BILINGUAL_PACKAGE',formalBilingualPackageComplete=True,completedUtc=now,finalCoreCount=365,independentSemanticPassed=365,remainingCards=0,questionDisposition=rd(p/'progress.json')['questionDisposition'],uniquePrimaryCounts={'1':116,'2':46,'3':159,'4':44},sharedReviewCounts={'1':159,'2':137,'3':197,'4':117},finalReview=dict(path=str(rv),sha256=sha(rv)),mechanicalValidation=dict(path=str(p/'validation365.json'),sha256=sha(p/'validation365.json')),artifactHashes={name:sha(p/name) for name in ['cards.deck.md','cards.json','cards.public.json','cards.import.json','cards.private.json','domain-index.json','current-review-index.json']},supersedes='Earlier assembly/current-review snapshots record formal:false before final gate; this completion receipt is authoritative.',published=False,ota=False,productionInventoryChanged=False,learnerOutcomeMeasured=False,newContentModelCliApiCalls=0,nativeUsage='unknown',historyReset=False)
(p/'completion.json').write_text(json.dumps(completion,ensure_ascii=False,indent=2)+'\n')
f=p/'progress.json';pr=rd(f);pr.update(status=completion['status'],atUtc=now,authored=365,independentSemanticPassed=365,assembled=365,remainingRuleIds=[],nextBatch=None,nextRuleId=None,formalBilingualPackageComplete=True,evidence='review/packaging365.review.json',verification='validation365.json',completionPath='completion.json');f.write_text(json.dumps(pr,ensure_ascii=False,indent=2)+'\n')
f=r/'workflow-auto-closeout-20261107/state.json';st=rd(f);st.setdefault('progressHistory',[]).append(dict(atUtc=now,previous=st['progress']));st['currentStage']='DONE_BILINGUAL_PACKAGE_LOCAL_ONLY';st['progress']=dict(finalCoreCount=365,authored=365,independentSemanticPassed=365,assembled=365,remainingEnglishCards=0,formalBilingualPackageComplete=True);st['phases']['bilingual-packaging-20261107'].update(status='complete',currentArtifacts=str(p/'completion.json'),nextAction=None,completedUtc=now,published=False);f.write_text(json.dumps(st,ensure_ascii=False,indent=2)+'\n')
(p/'WORKFLOW.md').write_text('''# AWS双语包自动工作流

当前365张正式双语包已完成本地验收，权威完成凭证为completion.json，执行状态为progress.json与父目录workflow-auto-closeout-20261107/state.json。没有新增需求时，不重新出卡或重复审查。

## 固定输入与范围

同一套365张共享核心卡，四域唯一主归116/46/159/44、含共享复习159/137/197/117；domain-index.json引用同一stableUid，不复制正文。题侧处置899原题充分＋115最小纠错练习＋4已接受例外Q49/201/454/783；不写成1018原题充分。

## 自动执行与恢复

1. 按order.json与batches计算缺失/变更ID；只读现有visibleBody、当前中文事实凭证、官方引用及冻结AGENTS第4节。每批5–10张，由单作者翻译，不重新提取全库需求。
2. write_batch.py保存英文、kind、topic、mustAnswer及中文正文SHA。英中条件、因果、边界对齐；自评只考实际题面，不考已给前提或补充提醒。
3. fork_turns:none隔离Reviewer审本批完整卡与教学标准；review记录输入SHA。失败保留history，仅定向修正并局部复审。未变PASS须与冻结条目精确相同方可复用。
4. collect_reviews.py收集当前语义凭证；assemble.py all必须完整365才装配。真实tools/aws_cards/roundtrip.mjs、严格lint-deck.mts及verify_full.py检查双语v:1、UID、先修、来源与数据完整性。隔离缺批负控须拒绝且不覆盖已有输出。
5. 全部当前凭证与正式文件通过独立最终回读后才生成completion.json、更新状态、导出并保存PR。不因格式/哈希通过自动升级语义；变更后的完成凭证需重新校验受影响依赖。

当前输入、逐卡初审/修复、旧失败、原中文FACT receipt及补采provenance均保留。assemble/current-review-index中的formal:false是完成总验之前的审查快照，最终完成状态以completion.json为准。输入变化须使旧completion失效，不盲用旧完成状态。

本工作流沿用全自动授权，不重复确认已接受范围或已授权步骤；不擅自扩大卡数/预算，不改正式库存、学习记录或生产环境，不发布/OTA。历史时钟与计数保留，新增内容模型CLI/API调用0、native用量未知。学习者实际记忆与正确率未测。
''')
f=repo/'reports/2026-11-07-aws-bilingual-package-final.md';f.write_text('''# AWS SAA-C03双语核心卡包：365张

**365/365张已完成本地双语封装与验收，待审0、问题0。未发布、未OTA。**

| 领域 | 唯一主归 | 含共享复习 |
|---|---:|---:|
| 1 | 116 | 159 |
| 2 | 46 | 137 |
| 3 | 159 | 197 |
| 4 | 44 | 117 |

全库按唯一UID计365；共享复习数允许重叠，不能相加。导航索引引用同一套卡，不生成重复正文。

[正式本地包与说明](../exports/aws-saa-c03-bilingual-365-20261107/README.md)包含阅读稿、导入JSON、公开/私有数据、领域导航、完成凭证和可回查证据归档。[旧245张保存点](../exports/aws-bilingual-package-checkpoint-20261107/README.md)保留为历史。

验收结果：365张当前双语语义凭证有效，初审/修订及失败历史保留；真实parser、translationRules、严格Linter与导入往返零错误零警告；新UID与旧347 UID交集0；先修无悬空、无环；原中文正文未改；四域导航逐UID精确一致。791份来源/审查文件哈希回读通过，补采官方网页单独保留provenance，不替代原FACT receipt。GCL-008错误链接保留并以正确官方页面原句闭合。隔离缺批负控拒绝且不覆盖已验输出。

题库范围处置为899原题充分支撑＋115最小纠错练习＋4用户已接受例外（Q49教学缺口暂缓；Q201/Q454/Q783退役例外），合计1018。例外不算原题充分，纠错练习也不升级原题状态。365是当前证据与已接受范围支持的核心卡数，不声称数学最小集。

完成凭证completion.json；独立总验review/packaging365.review.json（overallStatus=PASS、issues=[]）；完整性validation365.json。工作流已闭合本地双语阶段，旧预算、时钟和失败谱系保留，新增内容模型CLI/API调用0、native用量未知。

正式库存与学习记录未改；尚未执行手机导入、发布或OTA，学习者记忆与实际做题正确率未实测。本地卡包验收不等于这些后续事项已经完成。
''')
f=repo/'reports/2026-11-07-aws-bilingual-package-progress.md';text=f.read_text();f.write_text(text.replace('# AWS 双语包进度（2026-11-07）','# AWS 双语包进度（2026-11-07）\n\n> 已续接至365/365并完成本地总验，详见[最终报告](2026-11-07-aws-bilingual-package-final.md)。下文245张为历史保存点。',1))
f=repo/'reports/2026-11-07-aws-card-count-final.md';text=f.read_text().replace('双语包245/365，剩120，详见[双语进度](2026-11-07-aws-bilingual-package-progress.md)','双语包365/365已完成本地总验，详见[双语终报](2026-11-07-aws-bilingual-package-final.md)');f.write_text(text)
f=repo/'AGENTS.md';text=f.read_text();old=text.splitlines()[4];text=text.replace(old,'> **2026-11-07最新保存点**：N=365，正式双语包365/365已完成本地独立总验，待审0。题侧为899原题＋115最小纠错练习＋4用户接受例外（Q49/201/454/783），不是1018原题充分。见 [最终报告](reports/2026-11-07-aws-bilingual-package-final.md) 与 [365卡包](exports/aws-saa-c03-bilingual-365-20261107/README.md)。未发布/OTA，学习者实际效果未测，禁止重提全库考点。',1);f.write_text(text)
section=lambda s:re.search(r'^## 4\..*?(?=^## 5\.)',s,re.M|re.S).group();assert section(prior.decode())==section(text)
print('365 completion receipt and final reports written')

from pathlib import Path
import json,hashlib,re
p=Path.home()/'.local/share/codex-workflows/recallsmith/aws-basics-bilingual-rag-release-20261028/runtime/full-card-rebuild-v2-20261102/global-card-proof-20261106/package-bilingual-20261107'
rd=lambda f:json.loads(Path(f).read_text());sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();digest=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
current={x['ruleId']:x for f in (p/'batches').glob('batch-*.json') for x in rd(f)};body={x['ruleId']:x for x in rd(p.parent/'deliverables/cards.current.json')};receipts={};unmatched=[]
for f in sorted((p/'review').glob('batch-*.review.json')):
 d=rd(f);batch=re.search(r'batch-\d\d',f.name).group();source=p/'batches'/f'{batch}.json';inputs=d.get('inputFiles',{})
 expected=inputs.get(str(source));candidates=[source]+list((p/'history').glob(f'{batch}.*.json'))
 frozen=next((z for z in candidates if expected and sha(z)==expected),None)
 if frozen is None:
  unmatched.append(str(f));continue
 authored={x['ruleId']:x for x in rd(frozen)}
 for row in d.get('cards',d.get('reviewedCards',[])):
  rid=row['ruleId']
  if row['status']=='PASS' and rid in current and authored.get(rid)==current[rid]:
   receipts[rid]=dict(status='PASS',reviewPath=str(f),reviewSha256=sha(f),frozenAuthorPath=str(frozen),frozenBatchSha256=sha(frozen),authorEntrySha256=digest(current[rid]),chineseBodySha256=body[rid]['bodySha256'])
order=rd(p/'order.json');pending=[r for r in order if r not in receipts]
out=dict(scope='bilingual equivalence, recall-task self-assessment, kind; Chinese FACT reuses its separate current receipt',planned=365,authored=len(current),semanticPassed=len(receipts),remainingUntranslated=[r for r in order if r not in current],authoredAwaitingReview=[r for r in order if r in current and r not in receipts],cards=receipts,unmatchedReviewInputs=unmatched,formalBilingualPackageComplete=False)
(p/'current-review-index.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ['cards','remainingUntranslated']})
